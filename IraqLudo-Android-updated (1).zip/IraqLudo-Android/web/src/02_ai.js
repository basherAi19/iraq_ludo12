/* =====================================================================
   Iraq Ludo — Ludo computer player (one level, the former "medium")
   The AI never sees future dice and never changes the rules: it only
   chooses which legal token to move after a fair roll.
   ===================================================================== */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./01_engine.js'));
  else root.LudoAI = factory(root.LudoEngine);
})(typeof self !== 'undefined' ? self : this, function (E) {
  'use strict';
  const { YARD, LAST_MAIN, HOME, START, isSafe, globalOf } = E;

  /* Chance that one opponent token standing `d` squares behind can hit us before our next turn */
  const hitChance = d => (d >= 1 && d <= 6) ? 1 / 6 : (d >= 7 && d <= 12) ? 1 / 36 : (d >= 13 && d <= 18) ? 1 / 216 : 0;

  /* Probability that a token of `color` standing on shared square g is captured before its next turn.
     `tokens` lets the caller evaluate a hypothetical board. */
  function threat(st, tokens, color, g) {
    if (g < 0 || isSafe(g)) return 0;
    let own = 0;
    for (let i = 0; i < 4; i++) { const r = tokens[color][i]; if (r >= 0 && r <= LAST_MAIN && globalOf(color, r) === g) own++; }
    if (own >= 2) return 0;                                   // protected pair
    let safeP = 1;
    for (const c of st.colors) {
      if (c === color || st.out[c] || st.winner === c) continue;
      for (let i = 0; i < 4; i++) {
        const r = tokens[c][i];
        let p = 0;
        if (r === YARD) {
          const k = (g - START[c] + 52) % 52;                  // enter with a 6, then roll k
          if (k >= 1 && k <= 6) p = 1 / 36;
        } else if (r >= 0 && r <= LAST_MAIN) {
          const hg = globalOf(c, r);
          const d = (g - hg + 52) % 52;
          if (d > 0 && r + d <= LAST_MAIN) p = hitChance(d);   // they must still be on the shared track
        }
        safeP *= (1 - p);
      }
    }
    return 1 - safeP;
  }

  /* Value of a token at a position: losing a far-travelled token costs more */
  const worth = r => (r === YARD || r > LAST_MAIN) ? 0 : 10 + r;

  /* How the computer weighs a move: it thinks about its moves and pushes back a bit, with some variety */
  const PROFILE = { random: 0.12, risk: 24, chase: 1.0, noise: 0.25, enter: 26, home: 45, column: 22, capture: 30 };

  function score(st, m, color, P) {
    let s = 0;
    const from = m.from, to = m.to;
    const after = JSON.parse(JSON.stringify(st.tokens));
    after[color][m.t] = to;
    for (const cap of m.captures) after[cap.color][cap.t] = YARD;

    s += (m.enter ? 1 : (to - from)) * 0.9;                    // progress
    if (m.enter) {
      const onBoard = st.tokens[color].filter(r => r >= 0 && r < HOME).length;
      s += P.enter + (onBoard === 0 ? 18 : 0);
    }
    if (m.home) s += P.home;
    else if (from <= LAST_MAIN && to > LAST_MAIN) s += P.column;      // safe forever in the home column
    for (const cap of m.captures) s += P.capture + cap.rel * 0.9;

    // safety of the moving token: before vs after
    const gFrom = from >= 0 && from <= LAST_MAIN ? globalOf(color, from) : -1;
    const gTo = to <= LAST_MAIN ? globalOf(color, to) : -1;
    const riskBefore = gFrom >= 0 ? threat(st, st.tokens, color, gFrom) : 0;
    const riskAfter = gTo >= 0 ? threat(st, after, color, gTo) : 0;
    s += (riskBefore * worth(from) - riskAfter * worth(to)) * P.risk / 10;

    // leaving a protected pair exposes the partner token
    if (gFrom >= 0 && !isSafe(gFrom)) {
      for (let i = 0; i < 4; i++) {
        if (i === m.t) continue;
        const r = st.tokens[color][i];
        if (r >= 0 && r <= LAST_MAIN && globalOf(color, r) === gFrom) {
          s -= threat(st, after, color, gFrom) * worth(r) * P.risk / 12;
        }
      }
    }
    if (gTo >= 0 && isSafe(gTo)) s += 4;

    // chasing: standing a few squares behind an exposed opponent gives capture chances next turn
    if (P.chase && gTo >= 0) {
      for (const c of st.colors) {
        if (c === color || st.out[c]) continue;
        for (let i = 0; i < 4; i++) {
          const r = after[c][i];
          if (r < 0 || r > LAST_MAIN) continue;
          const hg = globalOf(c, r);
          if (isSafe(hg)) continue;
          const d = (hg - gTo + 52) % 52;
          if (d >= 1 && d <= 6 && to + d <= LAST_MAIN) s += P.chase * (1 + r / 25);
        }
      }
    }
    return s;
  }

  function choose(st, rand) {
    const rnd = typeof rand === 'function' ? rand : Math.random;
    const P = PROFILE;
    const moves = E.legalMoves(st);
    if (!moves.length) return null;
    if (moves.length === 1) return moves[0].t;
    // identical moves (two yard tokens entering) are interchangeable
    if (rnd() < P.random) return moves[Math.floor(rnd() * moves.length)].t;
    const color = E.current(st);
    let best = null, bestS = -Infinity;
    for (const m of moves) {
      let s = score(st, m, color, P);
      if (P.noise) s *= 1 + (rnd() * 2 - 1) * P.noise;
      if (s > bestS) { bestS = s; best = m; }
    }
    return best.t;
  }

  return { choose, threat, PROFILE };
});
