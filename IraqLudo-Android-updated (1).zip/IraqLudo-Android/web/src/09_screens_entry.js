/* ============ Entry screens: splash, language, sign in, register, recovery ============ */
const field = (id, label, input, extra = '') => `<div class="field"><label for="${id}">${esc(label)}</label>${input}${extra}</div>`;
const pwInput = (id, ph = '', ac = 'current-password') => `<div class="pwbox"><input class="input ltr" id="${id}" type="password" autocomplete="${ac}" maxlength="64" placeholder="${esc(ph)}" spellcheck="false"><button class="eye" type="button" data-act="togglePw" data-for="${id}" aria-label="${t('showPw')}">${ic('eye')}</button></div>`;
const appLink = () => IS_SITE && CONFIG.androidUrl ? `<a class="linkbtn applink" href="${esc(CONFIG.androidUrl)}" target="_blank" rel="noopener">${ic('dice', 's')}${esc(t('getApp'))}</a>` : '';
const demoBanner = () => Accounts.mode === 'local' ? `<div class="note" style="margin:6px 0 16px">${esc(t('demoBanner'))}</div>` : '';

/* After start-up or sign-in: where to go */
function enterApp(kind = 'fade') {
  if (!store.get('welcomed', false)) return reset('welcome', { first: true }, kind);
  if (!Accounts.user) return reset('login', {}, kind);
  Progress.load(Accounts.user.uid);
  return reset('home', {}, kind);
}

SCREENS.splash = {
  cls: 'splash',
  html: () => `<div>${MARK(104)}<div class="wordmark">${esc(t('appName'))}</div><div class="tagline">${esc(t('tagline'))}</div></div>`,
  init(el) {
    const mark = $('.mark', el), wm = $('.wordmark', el), tg = $('.tagline', el);
    if (!RM) {
      mark.animate([{ transform: 'translateY(-60px) rotate(-200deg) scale(.6)', opacity: 0 }, { transform: 'translateY(8px) rotate(8deg) scale(1.04)', opacity: 1, offset: .7 }, { transform: 'none', opacity: 1 }], { duration: 900, easing: 'cubic-bezier(.2,.8,.3,1)' });
      wm.animate([{ opacity: 0, transform: 'translateY(10px)' }, { opacity: 1, transform: 'none' }], { duration: 500, delay: 450, fill: 'backwards', easing: EASE });
      tg.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 500, delay: 700, fill: 'backwards' });
    }
    Promise.all([Accounts.init().catch(e => logErr('init', e.message)), sleep(1500)]).then(() => enterApp('zoom'));
  }
};

/* ---------- Welcome slides: first launch, and again from Settings ---------- */
const WELCOME_ART = [
  () => `<div class="wglow"></div>${MARK(128)}${[['red', -104, -62, 0], ['green', 100, -74, .6], ['yellow', 108, 60, 1.2], ['blue', -98, 68, 1.8]]
    .map(([c, x, y, d]) => `<span class="wtok c-${c}" style="--x:${x}px;--y:${y}px;--d:${d}s"><i></i></span>`).join('')}`,
  () => `<div class="wglow"></div><div class="wboard">${Board.svg('classic', 'wb')}</div><div class="wdie">${Board.diceHtml('classic')}</div>
    <svg class="wdom" viewBox="0 0 60 60" aria-hidden="true"><g transform="translate(12 4) rotate(-14 10 20) scale(1.2)">${domSvgTile(6, 6)}</g><g transform="translate(26 18) rotate(18 10 20) scale(1.2)">${domSvgTile(6, 3)}</g></svg>`,
  () => `<div class="wglow"></div>${TROPHY}<span class="wmed m1">🎁</span><span class="wmed m2">${DINAR(38)}</span><span class="wmed m3">🏅</span>`
];
const isRtl = () => document.documentElement.dir === 'rtl';
function welcomeGo(el, p, i) {
  const n = t('welcome').length;
  p.i = clamp(i, 0, n - 1);
  $('.wtrack', el).style.transform = `translateX(${(isRtl() ? 1 : -1) * p.i * 100}%)`;
  $$('.wslide', el).forEach((s, k) => { s.classList.toggle('on', k === p.i); s.setAttribute('aria-hidden', String(k !== p.i)); });
  $$('.wdots i', el).forEach((d, k) => d.classList.toggle('on', k === p.i));
  $('#wl-next', el).textContent = p.i === n - 1 ? t('welcomeGo') : t('welcomeNext');
}
SCREENS.welcome = {
  cls: 'welcome',
  html: (p) => {
    p.i = p.i || 0;
    const slides = t('welcome');
    return `<div class="wtop"><div class="wlang" role="group" aria-label="${esc(t('language'))}">
        <button data-act="pickLang" data-v="ar" class="${S.lang === 'ar' ? 'on' : ''}" lang="ar">ع</button><button data-act="pickLang" data-v="en" class="${S.lang === 'en' ? 'on' : ''}" lang="en">En</button></div>
        <button class="linkbtn" data-act="welcomeDone">${esc(t('welcomeSkip'))}</button></div>
      <div class="wview"><div class="wtrack">${slides.map(([h, d], i) => `<div class="wslide${i === p.i ? ' on' : ''}" aria-hidden="${i !== p.i}"><div class="wart"><div class="wsc">${WELCOME_ART[i]()}</div></div><h2>${esc(h)}</h2><p>${esc(d)}</p></div>`).join('')}</div></div>
      <div class="wfoot"><div class="wdots">${slides.map((_, i) => `<i class="${i === p.i ? 'on' : ''}"></i>`).join('')}</div>
        <button class="btn gold block" data-act="welcomeNext" id="wl-next">${esc(p.i === slides.length - 1 ? t('welcomeGo') : t('welcomeNext'))}</button></div>`;
  },
  init(el, p) {
    const view = $('.wview', el), track = $('.wtrack', el);
    track.classList.add('drag'); welcomeGo(el, p, p.i); void track.offsetWidth; track.classList.remove('drag');
    $$('.wdie .dice', el).forEach(d => Board.showFace(d, 6));
    // swipe between slides (next is to the left in Arabic, to the right in English)
    let x0 = null, dx = 0;
    view.addEventListener('pointerdown', e => { x0 = e.clientX; dx = 0; track.classList.add('drag'); try { view.setPointerCapture(e.pointerId); } catch (x) {} });
    view.addEventListener('pointermove', e => { if (x0 === null) return; dx = e.clientX - x0; track.style.transform = `translateX(calc(${(isRtl() ? 1 : -1) * p.i * 100}% + ${dx}px))`; });
    const end = () => {
      if (x0 === null) return;
      x0 = null; track.classList.remove('drag');
      const step = Math.abs(dx) > Math.min(70, view.clientWidth * .18) ? ((isRtl() ? dx > 0 : dx < 0) ? 1 : -1) : 0;
      if (step) Sound.fx.tap();
      welcomeGo(el, p, p.i + step);
    };
    view.addEventListener('pointerup', end); view.addEventListener('pointercancel', end);
  },
  onBack() { const top = topEntry(); if (top.params.first) return false; back(); return true; }
};

SCREENS.lang = {
  cls: 'lang',
  html: (p) => `${p.first ? '' : hdr({ title: t('language') })}<div class="scroll"><div class="wrap">
    <div class="authtop">${p.first ? MARK(64) : ''}<h2>${esc(t('chooseLang'))}</h2><p>${esc(t('langHint'))}</p></div>
    <div style="height:18px"></div>
    <button class="langcard ${S.lang === 'ar' ? 'on' : ''}" data-act="pickLang" data-v="ar" lang="ar" dir="rtl"><span class="lg">ع</span><span><b>العربية</b><small>باللهجة العراقية</small></span></button>
    <button class="langcard ${S.lang === 'en' ? 'on' : ''}" data-act="pickLang" data-v="en" lang="en" dir="ltr"><span class="lg">En</span><span><b>English</b><small>Iraq Ludo in English</small></span></button>
    ${p.first ? `<div style="height:10px"></div><button class="btn gold block" data-act="langNext">${esc(t('next'))}</button>` : ''}
  </div></div>`
};

SCREENS.login = {
  html: (p) => `${p.modal ? hdr({ title: t('signIn') }) : `<div class="hdr"><span class="hdr-sp"></span><span style="flex:1"></span><button class="iconbtn" data-act="openLang" aria-label="${t('language')}">${ic('globe')}</button></div>`}
    <div class="scroll"><div class="wrap">
    <div class="authtop">${MARK(70)}<h2>${esc(t('welcomeBack'))}</h2><p>${esc(t('signInSub'))}</p></div>
    <div style="height:14px"></div>${demoBanner()}
    <form onsubmit="return false" autocomplete="on">
      ${field('li-u', t('username'), `<input class="input ltr" id="li-u" autocomplete="username" autocapitalize="none" spellcheck="false" maxlength="20" placeholder="${esc(t('usernamePh'))}">`)}
      ${field('li-p', t('password'), pwInput('li-p'))}
      <div class="msg bad" id="li-msg" role="alert"></div>
      <button class="btn gold block" data-act="doLogin" id="li-go" style="margin-top:6px">${esc(t('signIn'))}</button>
    </form>
    <div style="text-align:center;margin-top:8px"><button class="linkbtn" data-act="toRecover">${esc(t('forgot'))}</button></div>
    <div class="or">${esc(t('noAccount'))}</div>
    <button class="btn outline block" data-act="toRegister">${esc(t('createAccount'))}</button>
    ${p.modal ? '' : `<button class="btn ghost block" data-act="guest" style="margin-top:12px">${ic('dice')}${esc(t('guest'))}</button>
    <p class="help" style="text-align:center">${esc(t('guestNote'))}</p>`}
    ${appLink() ? `<div style="text-align:center;margin-top:6px">${appLink()}</div>` : ''}
  </div></div>`,
  init(el) { el.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); if (e.target.id === 'li-u') $('#li-p', el).focus(); else $('#li-go', el).click(); } }); }
};

SCREENS.register = {
  html: () => `${hdr({ title: t('register') })}<div class="scroll"><div class="wrap">
    <p class="muted" style="margin:0 4px 14px;text-align:center">${esc(t('regSub'))}</p>${demoBanner()}
    <form onsubmit="return false">
      ${field('rg-u', t('username'), `<input class="input ltr" id="rg-u" autocomplete="username" autocapitalize="none" spellcheck="false" maxlength="20" placeholder="${esc(t('usernamePh'))}">`, `<div class="msg" id="rg-um"></div><p class="help">${esc(t('usernameRules'))}</p>`)}
      ${field('rg-n', t('displayName'), `<input class="input" id="rg-n" autocomplete="nickname" maxlength="20" placeholder="${esc(t('displayNamePh'))}">`, `<div class="msg bad" id="rg-nm"></div><p class="help">${esc(t('displayNameHint'))}</p>`)}
      <div class="field"><span class="flabel">${esc(t('pickAvatar'))}</span><div class="avgrid six" id="rg-av">${AVATARS.filter(a => !a[2]).map((a, i) => `<button type="button" data-av="${a[0]}" class="${i === 0 ? 'on' : ''} ${a[1] ? '' : 'drawn'}" aria-label="${a[0]}">${avatarArt(a[0])}</button>`).join('')}</div></div>
      ${field('rg-p', t('password'), pwInput('rg-p', '', 'new-password'), `<div class="meter" id="rg-meter" data-s="-1"><i></i><i></i><i></i><i></i></div><p class="help">${esc(t('pwRules'))} <b id="rg-ps"></b></p>`)}
      ${field('rg-p2', t('confirmPw'), pwInput('rg-p2', '', 'new-password'))}
      <label class="check"><input type="checkbox" id="rg-ok"><span>${esc(t('agree'))} <button type="button" class="linkbtn" data-act="privacy" style="padding:0">(${esc(t('privacy'))})</button></span></label>
      <div class="msg bad" id="rg-msg" role="alert"></div>
      <button class="btn gold block" data-act="doRegister" id="rg-go" style="margin-top:6px">${esc(t('createAccount'))}</button>
    </form>
  </div></div>`,
  init(el) {
    const u = $('#rg-u', el), um = $('#rg-um', el);
    let timer, seq = 0;
    u.addEventListener('input', () => {
      const v = normUser(u.value); if (u.value !== v) u.value = v;
      clearTimeout(timer); um.className = 'msg'; um.textContent = '';
      if (!v) return;
      const f = checkUsernameFormat(v);
      if (f !== 'ok') { um.className = 'msg bad'; um.textContent = t(f === 'reserved' ? 'reserved' : 'invalidUser'); return; }
      um.className = 'msg wait'; um.textContent = t('checking');
      const my = ++seq;
      timer = setTimeout(async () => {
        const ok = await Accounts.available(v);
        if (my !== seq) return;
        if (ok === null) { um.textContent = ''; return; }
        um.className = 'msg ' + (ok ? 'ok' : 'bad'); um.textContent = t(ok ? 'available' : 'taken');
      }, 450);
    });
    const p = $('#rg-p', el), meter = $('#rg-meter', el), ps = $('#rg-ps', el);
    p.addEventListener('input', () => { if (!p.value) { meter.dataset.s = '-1'; ps.textContent = ''; return; } const s = pwStrength(p.value); meter.dataset.s = s; ps.textContent = t('pwStrength')[s]; });
    $('#rg-av', el).addEventListener('click', e => { const b = e.target.closest('[data-av]'); if (!b) return; $$('#rg-av button', el).forEach(x => x.classList.toggle('on', x === b)); Sound.fx.tap(); });
  }
};

/* Recovery code: shown once after sign-up or recovery; the user must confirm saving it */
SCREENS.rcode = {
  html: (p) => `<div class="hdr"><span class="hdr-sp"></span><h1>${esc(t('rcTitle'))}</h1><span class="hdr-sp"></span></div><div class="scroll"><div class="wrap">
    <p class="muted" style="text-align:center;margin:4px 6px 0">${esc(p.renewed ? t('recoverOk') : t('rcSub'))}</p>
    <div class="code-box" id="rc-code">${esc(p.code)}</div>
    <div style="display:flex;gap:10px"><button class="btn sm ghost" style="flex:1" data-act="rcCopy">${ic('copy', 's')}${esc(t('copy'))}</button><button class="btn sm ghost" style="flex:1" data-act="rcShare">${ic('share', 's')}${esc(t('share'))}</button></div>
    <div class="note" style="margin:16px 0 6px">${esc(t('rcWarn'))}</div>
    <label class="check"><input type="checkbox" id="rc-ok"><span>${esc(t('rcSaved'))}</span></label>
    <div class="msg bad" id="rc-msg"></div>
    <button class="btn gold block" data-act="rcDone" id="rc-go">${esc(t('rcContinue'))}</button>
  </div></div>`,
  init(el) { const cb = $('#rc-ok', el), go = $('#rc-go', el); go.disabled = true; cb.addEventListener('change', () => { go.disabled = !cb.checked; }); },
  blockBack: true
};

SCREENS.recover = {
  html: () => `${hdr({ title: t('recoverTitle') })}<div class="scroll"><div class="wrap">
    <p class="muted" style="margin:0 4px 16px;text-align:center">${esc(t('recoverSub'))}</p>
    <form onsubmit="return false">
      ${field('rv-u', t('username'), `<input class="input ltr" id="rv-u" autocomplete="username" autocapitalize="none" spellcheck="false" maxlength="20" placeholder="${esc(t('usernamePh'))}">`)}
      ${field('rv-c', t('rcLabel'), `<input class="input ltr code" id="rv-c" autocomplete="off" autocapitalize="characters" spellcheck="false" maxlength="24" placeholder="XXXX-XXXX-XXXX-XXXX">`)}
      ${field('rv-p', t('newPw'), pwInput('rv-p', '', 'new-password'), `<p class="help">${esc(t('pwRules'))}</p>`)}
      ${field('rv-p2', t('confirmPw'), pwInput('rv-p2', '', 'new-password'))}
      <div class="msg bad" id="rv-msg" role="alert"></div>
      <button class="btn gold block" data-act="doRecover" style="margin-top:6px">${esc(t('recoverBtn'))}</button>
    </form>
    <p class="help" style="text-align:center;margin-top:16px">${esc(t('rcWarn'))}</p>
  </div></div>`
};
