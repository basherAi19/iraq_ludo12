/* ============ Sound: synthesised effects + a short original loop in maqam Hijaz ============
   No audio files are shipped. Everything is generated with the Web Audio API on demand.
   The audio context is created on the first user tap and suspended in the background. */
const Sound = (() => {
  let ctx = null, master = null, sfxBus = null, musicBus = null;
  let musicTimer = null, nextNoteTime = 0, step = 0, musicPlaying = false;
  const pluckCache = new Map();

  function ensure() {
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      try { ctx = new AC(); } catch (e) { return null; }
      master = ctx.createGain(); master.gain.value = 0.9; master.connect(ctx.destination);
      sfxBus = ctx.createGain(); sfxBus.gain.value = 0.55; sfxBus.connect(master);
      musicBus = ctx.createGain(); musicBus.gain.value = 0.0; musicBus.connect(master);
    }
    if (ctx.state === 'suspended' && !document.hidden) ctx.resume().catch(() => {});
    return ctx;
  }
  const now = () => ctx.currentTime;

  /* ---------- building blocks ---------- */
  function tone(o) {
    const c = ensure(); if (!c) return;
    const t0 = now() + (o.when || 0), d = o.dur || 0.15;
    const osc = c.createOscillator(), g = c.createGain();
    osc.type = o.type || 'sine';
    osc.frequency.setValueAtTime(o.freq, t0);
    if (o.slide) osc.frequency.exponentialRampToValueAtTime(o.slide, t0 + d);
    if (o.detune) osc.detune.value = o.detune;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(o.vol || 0.2, t0 + (o.attack || 0.006));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    let node = osc;
    if (o.lp) { const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = o.lp; osc.connect(f); node = f; }
    node.connect(g); g.connect(o.bus || sfxBus);
    osc.start(t0); osc.stop(t0 + d + 0.05);
  }
  let noiseBuf = null;
  function noise(o) {
    const c = ensure(); if (!c) return;
    if (!noiseBuf) { noiseBuf = c.createBuffer(1, c.sampleRate * 0.6, c.sampleRate); const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; }
    const t0 = now() + (o.when || 0), d = o.dur || 0.08;
    const src = c.createBufferSource(); src.buffer = noiseBuf;
    const f = c.createBiquadFilter(); f.type = o.ftype || 'bandpass'; f.frequency.setValueAtTime(o.freq || 2400, t0); f.Q.value = o.q || 1.2;
    if (o.sweep) f.frequency.exponentialRampToValueAtTime(o.sweep, t0 + d);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(o.vol || 0.2, t0 + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    src.connect(f); f.connect(g); g.connect(o.bus || sfxBus);
    src.start(t0, Math.random() * 0.3); src.stop(t0 + d + 0.05);
  }
  /* Plucked string (Karplus–Strong), cached per pitch: an oud-like voice for the music */
  function pluckBuffer(freq) {
    const key = Math.round(freq * 10);
    if (pluckCache.has(key)) return pluckCache.get(key);
    const c = ctx, sr = c.sampleRate, len = Math.floor(sr * 1.1), N = Math.max(2, Math.round(sr / freq));
    const buf = c.createBuffer(1, len, sr), d = buf.getChannelData(0), line = new Float32Array(N);
    for (let i = 0; i < N; i++) line[i] = Math.random() * 2 - 1;
    let idx = 0, prev = 0;
    for (let i = 0; i < len; i++) {
      const cur = line[idx];
      const v = 0.996 * 0.5 * (cur + prev);
      prev = cur; line[idx] = v; d[i] = cur; idx = (idx + 1) % N;
    }
    pluckCache.set(key, buf);
    return buf;
  }
  function pluck(freq, when, vol, bus) {
    if (!ctx) return;
    const src = ctx.createBufferSource(); src.buffer = pluckBuffer(freq);
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 2600;
    const g = ctx.createGain(); g.gain.value = vol;
    src.connect(f); f.connect(g); g.connect(bus || musicBus);
    src.start(when); src.stop(when + 1.1);
  }
  const midi = m => 440 * Math.pow(2, (m - 69) / 12);

  /* ---------- effects ---------- */
  const on = () => S.prefs.sound && ensure();
  const fx = {
    tap() { if (!on()) return; tone({ freq: 660, dur: 0.05, vol: 0.06, type: 'triangle' }); },
    dice() {
      if (!on()) return;
      for (let i = 0; i < 6; i++) noise({ when: i * 0.075 + Math.random() * 0.03, dur: 0.05, freq: 1800 + Math.random() * 1600, vol: 0.18, q: 2.5 });
      tone({ when: 0.5, freq: 180, slide: 90, dur: 0.12, vol: 0.18, type: 'triangle' });
      noise({ when: 0.5, dur: 0.06, freq: 900, vol: 0.12 });
    },
    step(i) { if (!on()) return; tone({ freq: 520 + (i % 6) * 22, slide: 300, dur: 0.07, vol: 0.12, type: 'triangle' }); },
    enter() { if (!on()) return; tone({ freq: 392, dur: 0.1, vol: 0.12, type: 'triangle' }); tone({ when: 0.08, freq: 587, dur: 0.16, vol: 0.12, type: 'triangle' }); },
    capture() {
      if (!on()) return;
      noise({ dur: 0.35, freq: 600, sweep: 4200, ftype: 'bandpass', vol: 0.22, q: 0.8 });
      tone({ when: 0.18, freq: 150, slide: 55, dur: 0.28, vol: 0.32, type: 'sine' });
    },
    home() { if (!on()) return; [74, 78, 81, 86].forEach((m, i) => tone({ when: i * 0.07, freq: midi(m), dur: 0.35, vol: 0.1, type: 'triangle' })); },
    win() {
      if (!on()) return;
      [62, 66, 69, 74].forEach((m, i) => tone({ when: i * 0.12, freq: midi(m), dur: 0.3, vol: 0.13, type: 'sawtooth', lp: 2200 }));
      [62, 66, 69, 74, 78].forEach(m => tone({ when: 0.55, freq: midi(m), dur: 1.2, vol: 0.07, type: 'sawtooth', lp: 1800 }));
      noise({ when: 0.55, dur: 0.6, freq: 6000, ftype: 'highpass', vol: 0.05 });
    },
    lose() { if (!on()) return; [67, 65, 62].forEach((m, i) => tone({ when: i * 0.16, freq: midi(m), dur: 0.32, vol: 0.1, type: 'triangle' })); },
    emoji() { if (!on()) return; tone({ freq: 880, slide: 1500, dur: 0.12, vol: 0.12, type: 'sine' }); },
    coin() { if (!on()) return; tone({ freq: 1318, dur: 0.12, vol: 0.1, type: 'square', lp: 3000 }); tone({ when: 0.08, freq: 1976, dur: 0.3, vol: 0.09, type: 'square', lp: 3000 }); },
    turn() { if (!on()) return; tone({ freq: midi(81), dur: 0.25, vol: 0.07, type: 'sine' }); tone({ when: 0.1, freq: midi(86), dur: 0.35, vol: 0.06, type: 'sine' }); },
    error() { if (!on()) return; tone({ freq: 160, dur: 0.18, vol: 0.12, type: 'square', lp: 900 }); },
    // dominoes: a tile clacks onto the table, slides from the pile, a knock on the table, the shuffle
    tile() {
      if (!on()) return;
      noise({ dur: 0.035, freq: 2600, q: 1.6, vol: 0.32 });
      tone({ freq: 1150, slide: 700, dur: 0.045, vol: 0.07, type: 'triangle' });
      noise({ when: 0.03, dur: 0.025, freq: 3400, q: 2.2, vol: 0.12 });
    },
    draw() { if (!on()) return; noise({ dur: 0.16, freq: 900, sweep: 2600, q: 0.9, vol: 0.12 }); },
    knock() {
      if (!on()) return;
      [0, 0.15].forEach(w => { tone({ when: w, freq: 150, slide: 85, dur: 0.1, vol: 0.38, type: 'sine' }); noise({ when: w, dur: 0.03, freq: 1100, q: 1.4, vol: 0.12 }); });
    },
    shuffle() { if (!on()) return; for (let i = 0; i < 9; i++) noise({ when: i * 0.055 + Math.random() * 0.02, dur: 0.03, freq: 2000 + Math.random() * 1500, vol: 0.14, q: 2 }); },
    // celebrations
    tick() { if (!on()) return; tone({ freq: 1760 + Math.random() * 300, dur: 0.06, vol: 0.05, type: 'triangle' }); },
    lose2() { if (!on()) return; tone({ freq: 520, slide: 260, dur: 0.22, vol: 0.06, type: 'triangle' }); },
    land() { if (!on()) return; tone({ freq: 140, slide: 70, dur: 0.12, vol: 0.22, type: 'sine' }); noise({ dur: 0.05, freq: 1300, vol: 0.12, q: 1.2 }); },
    flip() { if (!on()) return; noise({ dur: 0.03, freq: 3200, q: 2, vol: 0.12 }); },
    pop() { if (!on()) return; noise({ dur: 0.18, freq: 900, sweep: 5200, ftype: 'bandpass', vol: 0.12, q: 0.7 }); tone({ when: 0.02, freq: 90, slide: 50, dur: 0.16, vol: 0.12 }); },
    chest() { if (!on()) return; tone({ freq: 160, slide: 110, dur: 0.3, vol: 0.12, type: 'sawtooth', lp: 700 }); noise({ when: .1, dur: .25, freq: 600, vol: .08, q: .8 }); },
    levelup() {
      if (!on()) return;
      [67, 71, 74, 79].forEach((m, i) => tone({ when: i * 0.1, freq: midi(m), dur: 0.26, vol: 0.12, type: 'square', lp: 2600 }));
      [79, 83, 86].forEach(m => tone({ when: 0.42, freq: midi(m), dur: 0.9, vol: 0.06, type: 'sawtooth', lp: 2200 }));
      noise({ when: 0.42, dur: 0.5, freq: 7000, ftype: 'highpass', vol: 0.04 });
    }
  };

  /* ---------- music: original 8-bar tune in Hijaz on D, maqsum rhythm ---------- */
  // [midi or null, length in eighths]
  const MEL = [
    [62, 2], [63, 1], [66, 1], [67, 2], [66, 1], [63, 1],
    [62, 1], [63, 1], [66, 1], [67, 1], [69, 3], [null, 1],
    [70, 1], [69, 1], [67, 1], [66, 1], [67, 2], [69, 2],
    [67, 1], [66, 1], [63, 1], [66, 1], [62, 4],
    [69, 2], [70, 1], [72, 1], [74, 2], [72, 1], [70, 1],
    [69, 1], [70, 1], [69, 1], [67, 1], [66, 2], [67, 2],
    [69, 1], [67, 1], [66, 1], [63, 1], [66, 2], [67, 1], [66, 1],
    [63, 1], [62, 1], [60, 1], [63, 1], [62, 4]
  ];
  const SEQ = [];                                  // flatten to one entry per eighth
  MEL.forEach(([m, len]) => { SEQ.push(m); for (let i = 1; i < len; i++) SEQ.push(undefined); });
  const EIGHTH = 60 / 84 / 2;
  const DRUM = { 0: 'dum', 1: 'tak', 3: 'tak', 4: 'dum', 6: 'tak' };
  function scheduleMusic() {
    if (!musicPlaying || !ctx) return;
    while (nextNoteTime < ctx.currentTime + 0.35) {
      const i = step % SEQ.length, inBar = i % 8;
      const m = SEQ[i];
      if (typeof m === 'number') pluck(midi(m), nextNoteTime, 0.5);
      if (inBar === 0) pluck(midi(50), nextNoteTime, 0.35);
      if (inBar === 4) pluck(midi(45), nextNoteTime, 0.22);
      const d = DRUM[inBar];
      if (d === 'dum') { tone({ when: nextNoteTime - ctx.currentTime, freq: 95, slide: 55, dur: 0.22, vol: 0.32, bus: musicBus }); }
      if (d === 'tak') { noise({ when: nextNoteTime - ctx.currentTime, dur: 0.05, freq: 3200, q: 3, vol: 0.12, bus: musicBus }); }
      nextNoteTime += EIGHTH; step++;
    }
  }
  function startMusic() {
    if (!S.prefs.music || musicPlaying || document.hidden) return;
    const c = ensure(); if (!c) return;
    musicPlaying = true; step = 0; nextNoteTime = c.currentTime + 0.1;
    musicBus.gain.cancelScheduledValues(c.currentTime);
    musicBus.gain.setValueAtTime(musicBus.gain.value, c.currentTime);
    musicBus.gain.linearRampToValueAtTime(0.16, c.currentTime + 1.2);
    clearInterval(musicTimer); musicTimer = setInterval(scheduleMusic, 120);
  }
  function stopMusic() {
    if (!musicPlaying) return;
    musicPlaying = false; clearInterval(musicTimer); musicTimer = null;
    if (ctx) { musicBus.gain.cancelScheduledValues(ctx.currentTime); musicBus.gain.setValueAtTime(musicBus.gain.value, ctx.currentTime); musicBus.gain.linearRampToValueAtTime(0.0001, ctx.currentTime + 0.4); }
  }
  /* Background/foreground: stop everything while the app is hidden */
  function pause() { stopMusic(); if (ctx && ctx.state === 'running') ctx.suspend().catch(() => {}); }
  function resume() { if (ctx && ctx.state === 'suspended') ctx.resume().catch(() => {}); }
  document.addEventListener('visibilitychange', () => { if (document.hidden) pause(); else { resume(); if (Sound.wantMusic) startMusic(); } });

  return { fx, unlock: ensure, startMusic, stopMusic, pause, resume, wantMusic: false, get playing() { return musicPlaying; } };
})();
