/* ============ Celebrations: dinars flying to the balance, level up, the daily chest, fireworks, big emojis ============
   Everything here is decoration on top of the game: it never decides anything, never blocks the turn loop, and
   is skipped (or shortened) when the player chose "light" or "no" motion. */
/* centre of an element, or a point already measured ({x, y}) */
const fxPt = el => { if (!el.getBoundingClientRect) return el; const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2, w: r.width, h: r.height }; };
const fxLayer = () => { let l = $('#fxl'); if (!l) { l = document.createElement('div'); l.id = 'fxl'; $('#app').appendChild(l); } return l; };
const easeOut = k => 1 - Math.pow(1 - k, 3);

/* A number that rolls from one value to another */
function countUp(el, from, to, ms = 800) {
  if (!el) return Promise.resolve();
  if (RM || from === to || ms <= 0) { el.textContent = fmtNum(to); return Promise.resolve(); }
  return new Promise(res => {
    const t0 = performance.now();
    const step = now => {
      if (!el.isConnected) return res();
      const k = Math.min(1, (now - t0) / ms);
      el.textContent = fmtNum(Math.round(from + (to - from) * easeOut(k)));
      if (k < 1) requestAnimationFrame(step); else res();
    };
    requestAnimationFrame(step);
  });
}
function pulse(el, s = 1.16) { if (el && !RM) el.animate([{ transform: 'scale(1)' }, { transform: `scale(${s})` }, { transform: 'scale(1)' }], { duration: 260, easing: EASE }); }
function shake(el, px = 7, ms = 360) {
  if (!el || !FX()) return;
  el.animate([0, -1, 1, -.8, .8, -.4, .4, 0].map((k, i) => ({ transform: `translate(${(k * px).toFixed(1)}px,${(i % 2 ? .5 : -.5) * k * px}px)` })), { duration: ms, easing: 'linear' });
}

/* ---------- game dinars flying to (or away from) the balance ---------- */
function balancePill() {
  const top = topEntry();
  const own = top && $$('.pts', top.el).find(p => p.offsetParent !== null && p.getBoundingClientRect().top < innerHeight * .4);
  if (own) return { el: own, temp: false };
  const el = document.createElement('div'); el.className = 'fpts';
  el.innerHTML = `${DINAR(22)}<b></b><small>${esc(t('curShort'))}</small>`;
  fxLayer().appendChild(el);
  if (!RM) el.animate([{ opacity: 0, transform: 'translate(-50%,-14px)' }, { opacity: 1, transform: 'translate(-50%,0)' }], { duration: 240, easing: EASE, fill: 'backwards' });
  return { el, temp: true };
}
function flyNote(from, to, delay, keep) {
  const n = document.createElement('div'); n.className = 'fnote'; n.innerHTML = DINAR(30);
  n.style.left = from.x + 'px'; n.style.top = from.y + 'px';
  fxLayer().appendChild(n);
  const dx = to.x - from.x, dy = to.y - from.y, side = (Math.random() - .5) * 120, r0 = (Math.random() - .5) * 60;
  const a = n.animate([
    { transform: `translate(-50%,-50%) scale(.4) rotate(${r0}deg)`, opacity: 0 },
    { transform: `translate(calc(-50% + ${(dx * .15 + side * .4).toFixed(0)}px),calc(-50% + ${(dy * .15 - 40).toFixed(0)}px)) scale(1.15) rotate(${r0 + 40}deg)`, opacity: 1, offset: .22 },
    { transform: `translate(calc(-50% + ${(dx * .55 + side).toFixed(0)}px),calc(-50% + ${(dy * .5 - 70).toFixed(0)}px)) scale(1) rotate(${r0 + 140}deg)`, opacity: 1, offset: .55 },
    { transform: `translate(calc(-50% + ${dx.toFixed(0)}px),calc(-50% + ${dy.toFixed(0)}px)) scale(.5) rotate(${r0 + 300}deg)`, opacity: keep ? .9 : 0 }
  ], { duration: 760 + Math.random() * 160, delay, easing: 'cubic-bezier(.45,0,.35,1)', fill: 'backwards' });
  return a.finished.then(() => n.remove()).catch(() => n.remove());
}
/* delta dinars were just added (or taken). `origin` is where they come from (the reward chip, the chest, a button). */
async function dinarFly(origin, delta) {
  if (!delta || !Progress.data) return;
  const after = Progress.data.points, before = Math.max(0, after - delta);
  const pill = balancePill(), num = $('b', pill.el);
  num.textContent = fmtNum(before);
  const done = () => { num.textContent = fmtNum(after); if (pill.temp) setTimeout(() => { if (!pill.el.isConnected) return; pill.el.animate([{ opacity: 1 }, { opacity: 0, transform: 'translate(-50%,-10px)' }], { duration: 260, fill: 'forwards' }).finished.then(() => pill.el.remove()).catch(() => pill.el.remove()); }, 900); };
  if (!FX() || !origin || (origin.getBoundingClientRect && !origin.isConnected)) { await countUp(num, before, after, RM ? 0 : 600); return done(); }
  const n = clamp(Math.round(Math.abs(delta) / 12), 4, 9), a = fxPt(origin), b = fxPt(pill.el);
  const gain = delta > 0, from = gain ? a : b, to = gain ? b : a;
  let first = true;
  const flights = Array.from({ length: n }, (_, i) => flyNote(from, to, i * 75, gain).then(() => {
    if (gain) { pulse(pill.el, 1.12); Sound.fx.tick(); }
    if (first) { first = false; countUp(num, before, after, 140 + n * 75); }
  }));
  if (!gain) { pulse(pill.el, .9); Sound.fx.lose2(); countUp(num, before, after, 500); }
  await Promise.all(flights);
  done();
}

/* ---------- level up: a big golden badge ---------- */
const LEVEL_BADGE = n => `<svg viewBox="0 0 160 170" class="lvsvg" aria-hidden="true">
  <defs><linearGradient id="lvg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFF1BF"/><stop offset=".5" stop-color="#F2BE4A"/><stop offset="1" stop-color="#B9771A"/></linearGradient>
  <linearGradient id="lvr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--gold-hi)"/><stop offset="1" style="stop-color:var(--gold-lo)"/></linearGradient></defs>
  <path d="M40 120L24 166L52 152L66 168L74 124Z" fill="url(#lvr)"/><path d="M120 120L136 166L108 152L94 168L86 124Z" fill="url(#lvr)"/>
  <path d="M80 6L140 40V104L80 138L20 104V40Z" fill="url(#lvg)" stroke="#8A5410" stroke-width="3"/>
  <path d="M80 18L130 46V98L80 126L30 98V46Z" fill="none" stroke="#FFF6D8" stroke-opacity=".7" stroke-width="2.5"/>
  <g transform="translate(80 30)">${rosette(0, 0, 9, '#8A5410', '#FFF6D8')}</g>
  <text x="80" y="104" text-anchor="middle" font-size="${n > 9 ? 46 : 54}" font-weight="800" fill="#5A3405" font-family="Baloo Bhaijaan 2, sans-serif">${n}</text>
</svg>`;
/* A full-screen celebration layer: tap (or the Back button) closes it; `ms` closes it by itself */
function fxOverlay(cls, html, ms) {
  const w = document.createElement('div'); w.className = 'fxov ' + cls; w.innerHTML = html;
  w.setAttribute('role', 'dialog'); w.setAttribute('aria-live', 'polite');
  $('#app').appendChild(w);
  let closed = false, res;
  const done = new Promise(r => { res = r; });
  const close = () => {
    if (closed) return; closed = true; overlays = overlays.filter(x => x !== close);
    const a = RM ? null : w.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 220, fill: 'forwards' });
    (a ? a.finished : Promise.resolve()).catch(() => {}).then(() => { w.remove(); res(); });
  };
  w.addEventListener('click', close); overlays.push(close);
  if (ms) setTimeout(close, ms);
  return { el: w, done, close };
}
function sparkles(host, n, colors) {
  if (!FX()) return;
  for (let i = 0; i < n; i++) {
    const s = document.createElement('i'); s.className = 'fxspark';
    s.style.setProperty('--c', colors[i % colors.length]);
    host.appendChild(s);
    const ang = Math.random() * Math.PI * 2, r = 90 + Math.random() * 110;
    s.animate([{ transform: 'translate(-50%,-50%) scale(0)', opacity: 1 }, { transform: `translate(calc(-50% + ${(Math.cos(ang) * r).toFixed(0)}px),calc(-50% + ${(Math.sin(ang) * r).toFixed(0)}px)) scale(1)`, opacity: 1, offset: .7 },
      { transform: `translate(calc(-50% + ${(Math.cos(ang) * r * 1.1).toFixed(0)}px),calc(-50% + ${(Math.sin(ang) * r * 1.1 + 24).toFixed(0)}px)) scale(.3)`, opacity: 0 }],
    { duration: 900 + Math.random() * 500, delay: 150 + Math.random() * 300, easing: 'cubic-bezier(.2,.7,.3,1)', fill: 'backwards' }).finished.then(() => s.remove()).catch(() => s.remove());
  }
}
function levelUpFx(level, bonus) {
  if (MOTION() === 'off') { toast(t('levelUp', { n: fmtNum(level) }) + (bonus ? ' · ' + countText(bonus, 'dinarPlus') : '')); return Promise.resolve(); }
  const o = fxOverlay('lvfx', `<div class="lvstage"><div class="lvrays"></div><div class="lvbadge">${LEVEL_BADGE(level)}</div></div>
    <div class="lvtxt"><b>${esc(t('levelUp', { n: fmtNum(level) }))}</b>${bonus ? `<span class="lvbonus">${DINAR(24)}${esc(countText(bonus, 'dinarPlus'))}</span>` : ''}<small>${esc(t('tapToClose'))}</small></div>`, 3200);
  Sound.fx.levelup(); haptic('success');
  sparkles($('.lvstage', o.el), 26, ['#FFE08A', '#FFFFFF', 'var(--gold-hi)', '#F2A92A']);
  return o.done;
}

/* ---------- the daily reward chest (golden on day 7) ---------- */
const CHEST = gold => {
  const wood = gold ? ['#FFE38A', '#E8A922', '#9E650C'] : ['#B9783E', '#8A5426', '#5A3315'];
  const band = gold ? '#FFF6D2' : '#E6B44C';
  return `<svg viewBox="0 0 200 170" class="chsvg" aria-hidden="true">
    <g class="chbody"><rect x="26" y="80" width="148" height="78" rx="10" fill="${wood[1]}"/><rect x="26" y="80" width="148" height="20" fill="${wood[0]}" opacity=".55"/>
      <path d="M26 118H174" stroke="${wood[2]}" stroke-width="3" opacity=".6"/><rect x="40" y="80" width="14" height="78" fill="${band}"/><rect x="146" y="80" width="14" height="78" fill="${band}"/>
      <rect x="86" y="94" width="28" height="30" rx="5" fill="${band}" stroke="${wood[2]}" stroke-width="2.5"/><circle cx="100" cy="106" r="4.5" fill="${wood[2]}"/><path d="M100 108v9" stroke="${wood[2]}" stroke-width="3.5" stroke-linecap="round"/>
      ${gold ? '<circle cx="47" cy="140" r="5" fill="#E2484E"/><circle cx="153" cy="140" r="5" fill="#2F7BEF"/><circle cx="100" cy="146" r="5.5" fill="#2DAA62"/>' : ''}</g>
    <g class="chlid"><path d="M22 82C22 46 48 30 100 30S178 46 178 82Z" fill="${wood[0]}"/><path d="M22 82C22 58 40 44 64 38" stroke="#fff" stroke-opacity=".35" stroke-width="5" fill="none" stroke-linecap="round"/>
      <path d="M40 82C40 52 46 40 54 35M146 35C154 40 160 52 160 82" stroke="${band}" stroke-width="14" fill="none"/><rect x="20" y="74" width="160" height="12" rx="5" fill="${wood[2]}"/></g>
  </svg>`;
};
async function chestFx(origin, reward, xp, levelUp, bonus) {
  const gold = xp > 0;
  if (!FX()) {                                     // light or no motion: just the balance
    toast(t('dailyGot', { n: fmtNum(reward + (bonus || 0)) }) + (xp ? ' ' + t('xpPlus', { n: fmtNum(xp) }) : ''));
    await dinarFly(origin, reward + (bonus || 0)); if (levelUp) await levelUpFx(levelUp, bonus); return;
  }
  let opened = false;
  const o = fxOverlay('chfx' + (gold ? ' gold' : ''), `<div class="chstage"><div class="chglow"></div>${CHEST(gold)}</div>
    <div class="lvtxt"><b class="chsum">${esc(countText(reward, 'dinarPlus'))}</b>${xp ? `<span class="lvbonus">${esc(t('xpPlus', { n: fmtNum(xp) }))}</span>` : ''}<small>${esc(t('tapToClose'))}</small></div>`, 0);
  const w = o.el, body = $('.chsvg', w), lid = $('.chlid', w), glow = $('.chglow', w), stage = $('.chstage', w);
  const close = o.close, p = o.done;
  {
    await body.animate([{ transform: 'translateY(-160px) scale(.7)', opacity: 0 }, { transform: 'translateY(10px) scale(1.04)', opacity: 1, offset: .7 }, { transform: 'none', opacity: 1 }], { duration: 480, easing: EASE, fill: 'backwards' }).finished.catch(() => {});
    Sound.fx.chest();
    await body.animate([0, -6, 6, -5, 5, -3, 3, 0].map(r => ({ transform: `rotate(${r}deg)` })), { duration: 520, easing: 'linear' }).finished.catch(() => {});
    lid.animate([{ transform: 'none' }, { transform: 'translate(-6px,-38px) rotate(-16deg)' }], { duration: 360, easing: 'cubic-bezier(.3,1.5,.5,1)', fill: 'forwards' });
    glow.animate([{ opacity: 0, transform: 'translate(-50%,-50%) scale(.4)' }, { opacity: 1, transform: 'translate(-50%,-50%) scale(1)' }], { duration: 420, fill: 'forwards' });
  }
  opened = true;
  Sound.fx.coin(); haptic('success');
  sparkles(stage, gold ? 34 : 20, gold ? ['#FFE08A', '#FFFFFF', '#E2484E', '#2F7BEF', '#2DAA62'] : ['#FFE08A', '#FFFFFF', 'var(--gold-hi)']);
  await dinarFly(body, reward + (bonus || 0));
  setTimeout(() => { if (opened) close(); }, 900);
  await p;
  if (levelUp) await levelUpFx(levelUp, bonus);
}

/* ---------- fireworks over an element (a player's tokens all home, a won match) ---------- */
function fireworks(host, colors, bursts = 3) {
  if (!FX() || !host) return;
  const W = host.clientWidth, H = host.clientHeight;
  for (let b = 0; b < bursts; b++) {
    setTimeout(() => {
      if (!host.isConnected) return;
      const x = W * (.25 + Math.random() * .5), y = H * (.18 + Math.random() * .3), c = colors[b % colors.length];
      const rk = document.createElement('i'); rk.className = 'fwrk'; rk.style.left = x + 'px'; rk.style.top = H + 'px'; rk.style.setProperty('--c', c);
      host.appendChild(rk);
      rk.animate([{ transform: 'translateY(0)', opacity: 1 }, { transform: `translateY(${-(H - y)}px)`, opacity: 1 }], { duration: 420, easing: 'cubic-bezier(.2,.6,.4,1)' }).finished.then(() => {
        rk.remove(); if (!host.isConnected) return;
        Sound.fx.pop();
        for (let i = 0; i < 22; i++) {
          const s = document.createElement('i'); s.className = 'fwsp'; s.style.left = x + 'px'; s.style.top = y + 'px'; s.style.setProperty('--c', i % 4 ? c : '#FFF6D8');
          host.appendChild(s);
          const ang = i / 22 * Math.PI * 2, r = 40 + Math.random() * 34;
          s.animate([{ transform: 'translate(-50%,-50%) scale(1)', opacity: 1 }, { transform: `translate(calc(-50% + ${(Math.cos(ang) * r).toFixed(0)}px),calc(-50% + ${(Math.sin(ang) * r).toFixed(0)}px)) scale(.9)`, opacity: 1, offset: .65 },
            { transform: `translate(calc(-50% + ${(Math.cos(ang) * r * 1.08).toFixed(0)}px),calc(-50% + ${(Math.sin(ang) * r + 26).toFixed(0)}px)) scale(.3)`, opacity: 0 }],
          { duration: 820 + Math.random() * 260, easing: 'cubic-bezier(.15,.7,.3,1)' }).finished.then(() => s.remove()).catch(() => s.remove());
        }
      }).catch(() => rk.remove());
    }, b * 260);
  }
}

/* ---------- a big emoji that flies up from a player's picture ---------- */
function bigEmoji(fromEl, emoji) {
  if (!fromEl) return;
  const p = fxPt(fromEl), L = fxLayer();
  const mk = (size, cls) => { const e = document.createElement('span'); e.className = 'bigemo ' + cls; e.textContent = emoji; e.style.left = p.x + 'px'; e.style.top = p.y + 'px'; e.style.fontSize = size + 'px'; L.appendChild(e); return e; };
  const main = mk(64, 'main'), dir = p.y > innerHeight * .55 ? -1 : 1;              // from the bottom it flies up, from the top it drops in
  main.animate([{ transform: 'translate(-50%,-50%) scale(.2)', opacity: 0 }, { transform: `translate(-50%,calc(-50% + ${dir * 40}px)) scale(1.3) rotate(-8deg)`, opacity: 1, offset: .22 },
    { transform: `translate(-50%,calc(-50% + ${dir * 95}px)) scale(1.1) rotate(7deg)`, opacity: 1, offset: .6 }, { transform: `translate(-50%,calc(-50% + ${dir * 150}px)) scale(.9) rotate(-4deg)`, opacity: 0 }],
  { duration: 1700, easing: 'cubic-bezier(.2,.8,.3,1)' }).finished.then(() => main.remove()).catch(() => main.remove());
  for (let i = 0; i < 4; i++) {
    const m = mk(26, 'mini'), sx = (i - 1.5) * 34 + (Math.random() - .5) * 14;
    m.animate([{ transform: 'translate(-50%,-50%) scale(.2)', opacity: 0 }, { transform: `translate(calc(-50% + ${sx * .5}px),calc(-50% + ${dir * 30}px)) scale(1)`, opacity: .95, offset: .3 },
      { transform: `translate(calc(-50% + ${sx}px),calc(-50% + ${dir * 120}px)) scale(.7)`, opacity: 0 }],
    { duration: 1300, delay: 120 + i * 90, easing: 'ease-out', fill: 'backwards' }).finished.then(() => m.remove()).catch(() => m.remove());
  }
}

/* ---------- after a match: fireworks for a win, the dinars to the balance, then a level-up badge ---------- */
async function resultFx(el, r, won) {
  if (won) fireworks(el, ['#FFE08A', '#E2484E', '#2DAA62', '#2F7BEF'], 3);
  if (!r) return;
  await sleep(RM ? 0 : 320);
  if (!el.isConnected) return;
  await dinarFly($('.earn .p', el) || $('.earn .m', el) || $('.lvup', el), r.points);
  if (r.levelAfter > r.levelBefore && el.isConnected) await levelUpFx(r.levelAfter, r.bonus);
}

/* ---------- podium on the result screens ---------- */
/* entries: [{ place, avatar, name, color, score }] — 1st in the middle, 2nd on its left, 3rd on its right (in reading order) */
function podiumHtml(entries, crown) {
  const order = entries.length >= 3 ? [1, 0, 2] : entries.length === 2 ? [1, 0] : [0];
  const h = { 1: 96, 2: 70, 3: 52 };
  return `<div class="podium">${order.filter(i => entries[i]).map((i, k) => { const e = entries[i];
    return `<div class="pstep p${e.place}" style="--pc:${e.color};--h:${h[e.place] || 44}px;--d:${(e.place === 1 ? 0.45 : 0.1 + k * 0.12).toFixed(2)}s">
      <div class="pav">${e.place === 1 && crown ? '<span class="pcrown">👑</span>' : ''}${e.avatars.map(a => `<span class="av">${avatarArt(a)}</span>`).join('')}</div>
      <b class="pname">${esc(e.name)}</b><div class="pblock"><span>${fmtNum(e.place)}</span>${e.score !== undefined ? `<small>${fmtNum(e.score)}</small>` : ''}</div></div>`; }).join('')}</div>`;
}
