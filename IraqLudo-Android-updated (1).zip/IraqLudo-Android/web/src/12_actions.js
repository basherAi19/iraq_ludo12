/* ============ Actions (every button has data-act="name") ============ */
const prm = () => topEntry().params;
const rectOf = el => { const r = el.getBoundingClientRect(); return { top: r.top, left: r.left, right: r.right, bottom: r.bottom }; };
const scr = b => b.closest('.screen');
async function afterSignIn(user, kind = 'zoom') {
  Progress.load(user.uid);
  // an account that was only half made is finished at sign-in, and gets its recovery code now
  if (user.newCode) { const code = user.newCode; delete user.newCode; return reset('rcode', { code, username: user.username }, 'push'); }
  return reset('home', {}, kind);
}
const ACT = {
  back: () => window.ludoBack(),
  togglePw: b => {
    const inp = $('#' + b.dataset.for); if (!inp) return;
    const show = inp.type === 'password'; inp.type = show ? 'text' : 'password';
    b.innerHTML = ic(show ? 'eyeOff' : 'eye'); b.setAttribute('aria-label', t(show ? 'hidePw' : 'showPw'));
  },

  /* language */
  openLang: () => go('lang', {}, 'rise'),
  pickLang: b => { S.lang = b.dataset.v; store.set('lang', S.lang); S.langChosen = true; applyPrefs(); rerenderAll(); Sound.fx.tap(); },
  langNext: () => { S.langChosen = true; store.set('lang', S.lang); enterApp('push'); },

  /* welcome slides */
  welcomeNext: b => { const p = prm(); if (p.i >= t('welcome').length - 1) return ACT.welcomeDone(); Sound.fx.tap(); welcomeGo(scr(b), p, p.i + 1); },
  welcomeDone: () => {
    const p = prm(); store.set('welcomed', true); S.langChosen = true; store.set('lang', S.lang); Sound.fx.tap();
    return p.first ? enterApp('zoom') : back();
  },
  welcomeAgain: () => go('welcome', {}, 'rise'),
  setLang: b => { S.lang = b.dataset.v; store.set('lang', S.lang); applyPrefs(); rerenderAll(); },

  /* sign in / register / recover */
  doLogin: async b => {
    const el = scr(b), u = $('#li-u', el).value, p = $('#li-p', el).value, m = $('#li-msg', el);
    m.className = 'msg bad'; m.textContent = '';
    if (!u.trim() || !p) { m.textContent = t('required'); Sound.fx.error(); return; }
    b.disabled = true; m.className = 'msg wait'; m.textContent = t('signingIn');
    try { const user = await Accounts.login(u, p); haptic('success'); await afterSignIn(user); }
    catch (e) { b.disabled = false; m.className = 'msg bad'; m.textContent = authMsg(e); Sound.fx.error(); }
  },
  toRegister: () => go('register'),
  toRecover: () => go('recover'),
  guest: () => { const u = Accounts.playAsGuest(); afterSignIn(u); },
  toLoginFromGuest: () => go('login', { modal: true }, 'rise'),
  doRegister: async b => {
    const el = scr(b), m = $('#rg-msg', el);
    const u = normUser($('#rg-u', el).value), n = $('#rg-n', el).value, p = $('#rg-p', el).value, p2 = $('#rg-p2', el).value;
    const av = ($('#rg-av .on', el) || {}).dataset ? $('#rg-av .on', el).dataset.av : DEFAULT_AVATAR;
    const fail = msg => { m.className = 'msg bad'; m.textContent = msg; Sound.fx.error(); };
    $('#rg-nm', el).textContent = '';
    const f = checkUsernameFormat(u);
    if (f !== 'ok') return fail(t(f === 'reserved' ? 'reserved' : 'invalidUser'));
    if (!checkName(n)) { $('#rg-nm', el).textContent = t('badName'); return fail(t('badName')); }
    if (!pwOk(p)) return fail(t('pwWeak'));
    if (p !== p2) return fail(t('pwMismatch'));
    if (!$('#rg-ok', el).checked) return fail(t('mustAgree'));
    b.disabled = true; m.className = 'msg wait'; m.textContent = t('creating');
    const wasGuest = Accounts.isGuest;
    try {
      const r = await Accounts.register(u, n, p, av);
      if (wasGuest) Progress.adoptGuest(r.user.uid); else Progress.load(r.user.uid);
      haptic('success');
      reset('rcode', { code: r.code, username: u }, 'push');
    } catch (e) { b.disabled = false; fail(authMsg(e)); }
  },
  rcCopy: async () => { const ok = await copyText(prm().code); toast(ok ? t('copied') : prm().code); },
  rcShare: () => { const p = prm(); if (!shareText(t('rcShareText', { u: p.username, c: p.code }), () => ACT.rcCopy())) ACT.rcCopy(); },
  rcDone: b => {
    const el = scr(b); if (!$('#rc-ok', el).checked) { $('#rc-msg', el).textContent = t('rcConfirm'); return; }
    if (prm().signIn || !Accounts.user) { toast(t('recoverSignIn')); return reset('login', {}, 'zoom'); }   // the password is changed; sign in with it
    Progress.load(Accounts.user.uid); reset('home', {}, 'zoom');
  },
  doRecover: async b => {
    const el = scr(b), m = $('#rv-msg', el);
    const u = normUser($('#rv-u', el).value), c = $('#rv-c', el).value, p = $('#rv-p', el).value, p2 = $('#rv-p2', el).value;
    const fail = msg => { m.className = 'msg bad'; m.textContent = msg; Sound.fx.error(); };
    if (!u || !c.trim()) return fail(t('required'));
    if (normCode(c).length !== 16) return fail(t('recoverBad'));
    if (!pwOk(p)) return fail(t('pwWeak'));
    if (p !== p2) return fail(t('pwMismatch'));
    b.disabled = true; m.className = 'msg wait'; m.textContent = t('loading');
    try {
      const r = await Accounts.recover(u, c, p);
      if (r.user) Progress.load(r.user.uid);
      reset('rcode', { code: r.code, username: u, renewed: true, signIn: !r.user }, 'push');
    } catch (e) { b.disabled = false; fail(authMsg(e)); }
  },
  privacy: () => infoSheet(t('privacy'), [t('privacyP'), t(Accounts.mode === 'fb' ? 'privacyWhere' : 'privacyLocal'), t('termsP')], [
    { icon: 'shield', label: t('privacyFull'), url: safeUrl(CONFIG.privacyUrl) },
    { icon: 'info', label: t('contactUs'), sub: supportMail(), url: supportMail() ? 'mailto:' + supportMail() : '' }]),
  about: () => infoSheet(`${t('appName')} ${CONFIG.version}`, t('aboutP'), [
    { icon: 'info', label: t('contactUs'), sub: supportMail(), url: supportMail() ? 'mailto:' + supportMail() : '' }]),

  /* home */
  profile: () => go('profile'), settings: () => go('settings'), online: () => go('online'), daily: () => go('daily'), challenges: () => go('challenges'),
  shop: () => go('shop'), vip: () => go('vip'), howto: () => go('howto'), stats: () => go('stats'), matchmaking: () => go('match'),
  playLudo: b => go('offSetup', { _grow: rectOf(b) }, 'grow'),
  playDom: b => go('domSetup', { _grow: rectOf(b) }, 'grow'),
  design: () => go('design'),
  setLook: b => {
    const k = b.dataset.k, v = b.dataset.v;
    if (k === 'board') Progress.equip('board', v);
    else { S.prefs[k] = v; savePrefs(); applyLook(); }
    Sound.fx.tap(); haptic(); refreshTop();
  },
  lookReset: () => { Object.assign(S.prefs, LOOK_DEFAULTS); savePrefs(); applyLook(); Progress.equip('board', 'classic'); Sound.fx.tap(); toast(t('lookResetDone')); refreshTop(); },
  playFree: () => reset('home', {}, 'fade'),                    // from the online screens: back to the two games
  resume: () => resumeGame(),
  dResume: () => resumeDom(),

  /* Ludo setup */
  setPlayers: b => { prm().players = +b.dataset.v; Sound.fx.tap(); refreshTop(); },
  setColor: b => { prm().color = b.dataset.v; Sound.fx.tap(); refreshTop(); },
  startGame: async () => { const p = prm(); if (busy) return; Sound.fx.tap(); if (await replaceSaved('ludo')) startGame(newSetup(p.players, p.color)); },

  /* dominoes setup + game */
  setDomPlayers: b => { prm().players = +b.dataset.v; Sound.fx.tap(); refreshTop(); },
  setDomTarget: b => { prm().target = +b.dataset.v; Sound.fx.tap(); refreshTop(); },
  startDom: async () => { const p = prm(); if (busy) return; Sound.fx.tap(); if (await replaceSaved('dom')) startDom(newDomSetup(p.players, p.target)); },
  dMenu: () => dMenu(),
  dDraw: () => dHumanDraw(false),
  dPlayAgain: async () => { const p = prm(); if (busy) return; if (await replaceSaved('dom')) startDom(newDomSetup(p.setup.players, p.setup.target)); },

  /* matchmaking (no fake opponents: without the game server it says so) */
  mmGame: b => { prm().game = b.dataset.v; refreshTop(); },
  mmMode: b => { prm().mode = +b.dataset.v; refreshTop(); },
  mmColor: b => { prm().color = b.dataset.v; refreshTop(); },
  mmStart: () => { const p = prm(); p.state = CONFIG.onlineEnabled ? 'searching' : 'off'; refreshTop(); },
  mmCancel: () => { const p = prm(); p.state = 'idle'; refreshTop(); },

  /* profile */
  pickAvatar: () => avatarSheet(),
  editName: () => nameSheet(),
  statsTab: b => { prm().tab = b.dataset.v; refreshTop(); },
  rulesTab: b => { prm().tab = b.dataset.v; Sound.fx.tap(); refreshTop(); },

  /* settings */
  togglePref: b => {
    const k = b.dataset.k; S.prefs[k] = !S.prefs[k]; savePrefs();
    if (k === 'music') { if (S.prefs.music) { Sound.wantMusic = true; Sound.startMusic(); } else Sound.stopMusic(); }
    if (k === 'vibrate' && S.prefs.vibrate) haptic();
    Sound.fx.tap(); refreshTop();
  },
  setSpeed: b => { S.prefs.speed = b.dataset.v; savePrefs(); refreshTop(); },
  changePw: () => pwSheet(),
  logout: async () => {
    if (!(await confirmBox(t('logoutQ'), t('logoutP'), t('logout'), true))) return;
    try { await Accounts.logout(); } catch (e) {}
    reset('login', {}, 'zoom');
  },
  deleteAcc: () => deleteSheet(),

  /* rewards */
  claimDaily: b => {
    const r = Progress.claimDaily(); if (!r) return;
    const from = fxPt(b);
    haptic('success'); refreshTop();                           // the day is marked at once; the chest plays on top
    chestFx(from, r.reward, r.xp, r.levelUp, r.bonus);
  },
  chTab: b => { prm().tab = b.dataset.v; refreshTop(); },
  claimCh: async b => {
    const r = Progress.claimChallenge(b.dataset.id); if (!r) return;
    const from = fxPt(b);
    Sound.fx.coin(); haptic('success'); toast(countText(r.points, 'dinarPlus') + ' · ' + t('xpPlus', { n: fmtNum(r.xp) }));
    refreshTop();
    await dinarFly(from, r.points);
    if (r.levelUp) levelUpFx(r.levelUp, 50);
  },
  shopTab: b => { prm().tab = b.dataset.v; refreshTop(); },
  equip: b => { if (Progress.equip(b.dataset.k, b.dataset.id)) { Sound.fx.tap(); haptic(); refreshTop(); } },
  buy: b => {
    const r = Progress.buy(b.dataset.k, b.dataset.id);
    if (r === 'ok') {
      const price = (Progress.catalog(b.dataset.k).find(i => i.id === b.dataset.id) || {}).price || 0;
      Progress.equip(b.dataset.k, b.dataset.id); Sound.fx.coin(); haptic('success'); toast(t('unlocked')); refreshTop();
      const it = $(`[data-k="${b.dataset.k}"][data-id="${b.dataset.id}"]`, topEntry().el) || $('.item.on', topEntry().el);
      if (it) dinarFly(it, -price);
    }
    else if (r === 'poor') { Sound.fx.error(); toast(t('notEnough'), 'bad'); }
  },

  /* game */
  gMenu: () => gameMenu(),
  gSound: b => {
    const on = !(S.prefs.sound || S.prefs.music);
    S.prefs.sound = on; S.prefs.music = on; savePrefs();
    if (on) { Sound.wantMusic = true; Sound.startMusic(); } else Sound.stopMusic();
    b.innerHTML = ic(on ? 'sound' : 'mute'); toast(t(on ? 'soundOn' : 'soundOff'));
  },
  roll: () => humanRoll(),
  emoji: () => { const top = topEntry(); if (top && top.name === 'dgame') domEmoji(); else ludoEmoji(); },
  playAgain: async () => { const p = prm(); if (busy) return; if (await replaceSaved('ludo')) startGame(newSetup(p.setup.players, p.setup.human)); },
  toHome: () => reset('home', {}, 'fade')
};

document.addEventListener('click', e => {
  const a = e.target.closest('[data-act]'); if (!a || a.disabled) return;
  const fn = ACT[a.dataset.act]; if (!fn) return;
  e.preventDefault();
  Promise.resolve(fn(a, e)).catch(err => { logErr('action ' + a.dataset.act, err && (err.stack || err.message || err)); toast(t('errGeneric'), 'bad'); });
});
/* The first touch unlocks audio (browsers and WebViews require a user gesture) */
document.addEventListener('pointerdown', () => { Sound.unlock(); if (Sound.wantMusic && S.prefs.music && !Sound.playing) Sound.startMusic(); }, { capture: true });

/* Android back button / gesture (called by MainActivity); returns true when handled */
window.ludoBack = () => {
  if (overlayClose()) return true;
  if (busy) return true;
  const top = topEntry(); if (!top) return false;
  const def = SCREENS[top.name];
  if (def.blockBack) return true;
  if (def.onBack) return def.onBack();
  if (stack.length > 1) { back(); return true; }
  if (top.name !== 'home' && top.name !== 'login' && top.name !== 'splash' && Accounts.user) { reset('home', {}, 'fade'); return true; }
  return false;
};
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { window.ludoBack(); return; }
  // Space or Enter rolls the dice when it is your turn (keyboard play on the website)
  if ((e.key === ' ' || e.key === 'Enter') && !overlays.length && !/^(INPUT|TEXTAREA|BUTTON|A)$/.test((e.target && e.target.tagName) || '')) {
    const top = topEntry();
    if (top && top.name === 'game' && $('[data-act="roll"]', top.el)) { e.preventDefault(); humanRoll(); }
    else if (top && top.name === 'dgame' && $('[data-act="dDraw"]', top.el)) { e.preventDefault(); dHumanDraw(false); }
  }
});
/* Website: the browser's Back button works like the phone's back button (one step inside the game) */
if (IS_SITE && !NATIVE && window.history && history.pushState) {
  let armed = false;
  const arm = () => { if (!armed) { try { history.pushState({ ludo: 1 }, ''); armed = true; } catch (e) {} } };
  document.addEventListener('pointerdown', arm, { capture: true });
  window.addEventListener('popstate', () => {
    armed = false;
    if (window.ludoBack()) arm(); else history.back();
  });
}
/* Website: keep a copy so the game opens and plays the computer without internet */
if (IS_SITE && !NATIVE && 'serviceWorker' in navigator && window.isSecureContext && /^https?:$/.test(location.protocol)) {
  window.addEventListener('load', () => { navigator.serviceWorker.register('sw.js').catch(e => logErr('sw', e.message)); });
}
/* Native lifecycle hooks (MainActivity calls these on pause/resume) */
/* Time spent with the app in the background is not playing time */
let awaySince = 0;
function awayFromGame(on) {
  if (on) { if (!awaySince) awaySince = Date.now(); return; }
  if (!awaySince) return;
  const gone = Date.now() - awaySince; awaySince = 0;
  if (G.alive) G.t0 += gone;
  if (DG.alive) DG.t0 += gone;
}
document.addEventListener('visibilitychange', () => awayFromGame(document.hidden));
window.ludoNative = {
  onPause() { Sound.pause(); if (G.alive && G.st && G.st.phase !== 'over') saveGame(); if (DG.alive && DG.st && DG.st.phase !== 'over') dSave(); awayFromGame(true); },
  onResume() { awayFromGame(false); Sound.resume(); if (Sound.wantMusic && S.prefs.music) Sound.startMusic(); }
};

/* Progress arrived from another device (the app or the website): redraw screens that show it */
Progress.onSync = () => {
  const run = (tries = 0) => {
    if ((busy || overlays.length) && tries < 60) { setTimeout(() => run(tries + 1), 150); return; }   // wait for a screen change or a sheet to finish
    const top = topEntry();
    if (top && !busy && !overlays.length && ['home', 'profile', 'stats', 'daily', 'challenges', 'shop'].includes(top.name)) refreshTop();
  };
  run();
};

/* The server ended the session (the password was changed, or the account deleted, on another device).
   The match in progress is saved under the account first; then the player is asked to sign in again. */
Accounts.onSessionEnd = () => {
  while (overlayClose());
  toast(t('sessionEnded'), 'bad');
  reset('login', {}, 'fade').then(() => { Accounts.user = null; Accounts.closing = false; });
};

/* ============ Boot ============ */
applyPrefs();
reset('splash', {}, 'fade');
