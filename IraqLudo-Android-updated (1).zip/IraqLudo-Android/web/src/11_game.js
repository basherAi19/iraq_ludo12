/* ============ Offline game vs the computer ============ */
const E = LudoEngine;
const OPP2 = { red: 'yellow', yellow: 'red', green: 'blue', blue: 'green' };   // 2-player games use opposite corners
/* Computer players: a name and a drawn character of the same kind (the name lists alternate men and women) */
const BOT_CHARS = { m: CHAR_IDS.filter(id => CHAR_DEFS[id].g === 'm'), f: CHAR_IDS.filter(id => CHAR_DEFS[id].g === 'f') };
function botPicker() {
  const names = t('botNames').map((n, i) => ({ n, g: i % 2 ? 'f' : 'm' })), used = new Set([Accounts.user.avatar]);
  return () => {
    const who = names.splice(randInt(names.length), 1)[0];
    let pool = BOT_CHARS[who.g].filter(a => !used.has(a));
    if (!pool.length) pool = CHAR_IDS.filter(a => !used.has(a));
    const av = pool[randInt(pool.length)]; used.add(av);
    return { name: who.n, avatar: av };
  };
}
const EMOJIS = ['😂', '😎', '👏', '❤️', '😭', '😡', '🎉', '🤔', '👍', '👎'];

const G = { alive: false, busy: false, paused: false, gen: 0, st: null, setup: null, view: null, el: null, dice: null, t0: 0, elapsed: 0, ro: null, settled: null, shown: false };
/* Every interruption (leaving the screen, a new game) bumps G.gen, so stale async steps stop */
const live = gen => G.alive && G.gen === gen;
async function gate(gen) { while (G.paused && live(gen)) await sleep(120); return live(gen); }
const humanColor = () => G.setup.human;
const isHuman = c => c === G.setup.human;
const nameOf = c => isHuman(c) ? t('you') : G.setup.names[c];
const TURBO = () => !!window.__LUDO_TURBO;                         // test hook only; never set in the app
const speed = () => TURBO() ? { step: 3, think: 0, pick: 0 } : S.prefs.speed === 'fast' ? { step: 85, think: 260, pick: 220 } : { step: 135, think: 560, pick: 420 };
const saveKey = () => 'save:' + (Accounts.user ? Accounts.user.uid : 'guest');

/* One computer level for everyone; it is never shown */
function newSetup(players, human) {
  const colors = players === 4 ? ['red', 'green', 'yellow', 'blue'] : [human, OPP2[human]];
  const names = {}, avatars = {}, bot = botPicker();
  colors.forEach(c => {
    if (c === human) { names[c] = Accounts.user.guest ? t('guestName') : Accounts.user.name; avatars[c] = Accounts.user.avatar; return; }
    const b = bot(); names[c] = b.name; avatars[c] = b.avatar;
  });
  return { game: 'ludo', players, colors, human, names, avatars, first: colors[randInt(colors.length)] };
}
function saveGame() {
  if (!G.st) { store.del(saveKey()); return; }
  if (G.st.phase === 'over') { settle(false); return; }          // decided: counted at once, nothing left to resume
  store.set(saveKey(), { setup: G.setup, st: G.st, elapsed: G.elapsed + (G.alive ? Date.now() - G.t0 : 0), savedAt: Date.now() });
}
/* Counts the match exactly once: the moment it is decided, or when it is given up.
   (So closing the app while the last move is still on screen cannot lose a win or dodge a loss.) */
function settle(forfeit) {
  if (!G.settled) {
    if (G.st.phase === 'over') forfeit = false;                  // already decided: it counts as played
    const res = humanResult(forfeit);
    G.settled = { res, forfeit, reward: forfeit && G.st.stats[humanColor()].rolls === 0 ? null : Progress.recordGame(res) };   // a give-up only counts once you have rolled
    store.del(saveKey());
  }
  return G.settled;
}

/* Visual corner of each colour after rotating the board so the human sits bottom-left */
function cornerOf(color) {
  const base = { red: 0, green: 1, yellow: 2, blue: 3 }[color];
  const shift = Board.ROT[humanColor()] / 90;
  return ['tl', 'tr', 'br', 'bl'][((base + shift) % 4 + 4) % 4];
}
function panelHtml(corner) {
  const c = G.setup.colors.find(x => cornerOf(x) === corner);
  const cls = `pp ${corner[0] === 't' ? 'top' : ''} ${corner[1] === 'r' ? 'r' : ''}`;
  if (!c) return `<div class="${cls}" style="visibility:hidden"><div class="pav"></div></div>`;
  return `<div class="${cls}" data-c="${c}" style="--pc:${COLOR_HEX[c]}">
    <div class="pav">${avatarEmoji(G.setup.avatars[c])}<span class="lvb">${isHuman(c) ? esc(t('you')) : '🤖'}</span></div>
    <div class="pn"><b>${esc(isHuman(c) ? G.setup.names[c] : G.setup.names[c])}</b><span class="homes">${[0, 1, 2, 3].map(() => '<i></i>').join('')}</span></div>
    <div class="dslot"></div></div>`;
}

SCREENS.game = {
  cls: 'game', keep: true,
  html: () => `<div class="gbar">
      <button class="iconbtn" data-act="gMenu" aria-label="${esc(t('menu'))}">${ic('menu')}</button>
      <div class="mode">${esc(t('offTitle'))}</div>
      <button class="iconbtn" data-act="gSound" aria-label="${esc(S.prefs.sound ? t('soundOn') : t('soundOff'))}">${ic(S.prefs.sound ? 'sound' : 'mute')}</button>
    </div>
    <div class="arena" id="arena">
      <div class="prow">${panelHtml('tl')}${panelHtml('tr')}</div>
      <div class="board" id="board"></div>
      <div class="prow">${panelHtml('bl')}${panelHtml('br')}</div>
    </div>
    <div class="ghint"><div class="msgtxt" id="gmsg"></div><button class="emobtn" data-act="emoji" aria-label="${esc(t('emojis'))}">😊</button></div>`,
  init(el) {
    G.el = el;
    G.view = Board.mount($('#board', el), { colors: G.setup.colors, human: G.setup.human, skin: Progress.data.equipped.board });
    const holder = document.createElement('div'); holder.innerHTML = Board.diceHtml(Progress.data.equipped.dice); G.dice = holder.firstChild;
    if (G.st.lastRoll) Board.showFace(G.dice, G.st.lastRoll.value);
    const fit = () => {
      const a = $('#arena', el); if (!a) return;
      // offsetWidth/Height are layout sizes, unaffected by the screen's entry animation (transform)
      const bs = Math.floor(Math.max(220, Math.min(a.offsetWidth - 16, a.offsetHeight - 2 * 66 - 20, 720)));
      el.style.setProperty('--bs', bs + 'px');
    };
    fit();
    if (window.ResizeObserver) { if (G.ro) G.ro.disconnect(); G.ro = new ResizeObserver(fit); G.ro.observe($('#arena', el)); }
    G.view.layout(G.st);
    $('#board', el).addEventListener('click', e => { const tk = e.target.closest('.tok.can'); if (tk) humanMove(+tk.dataset.t); });
    updatePanels();
    keepAwake(true);
  },
  after() {
    if (G.alive) return;
    G.alive = true; G.busy = false; G.paused = false; G.gen++; G.t0 = Date.now();
    keepAwake(true);
    if (G.view) { G.view.setMovable(null); G.view.layout(G.st); }
    next();
  },
  leave(el, p, final) {
    if (G.alive && G.st && G.st.phase !== 'over') { G.elapsed += Date.now() - G.t0; G.alive = false; saveGame(); }
    G.alive = false; G.busy = false; G.gen++;
    if (final && G.ro) { G.ro.disconnect(); G.ro = null; }
    keepAwake(false);
  },
  onBack() { gameMenu(); return true; }
};

/* ---------- start / resume ---------- */
function startGame(setup) {
  G.alive = false; G.gen++; G.busy = false; G.paused = false; G.settled = null; G.shown = false;
  G.setup = setup;
  G.st = E.createGame({ colors: setup.colors, first: setup.first });
  G.elapsed = 0;
  store.set('lastPlayers', setup.players); store.set('lastColor', setup.human);
  saveGame();
  return reset('game', {}, 'zoom');
}
function resumeGame() {
  const sv = savedGame(); if (!sv) return;
  G.alive = false; G.gen++; G.busy = false; G.paused = false; G.settled = null; G.shown = false;
  G.setup = sv.setup; G.st = sv.st; G.elapsed = sv.elapsed || 0;
  return reset('game', {}, 'zoom');
}

/* ---------- UI helpers ---------- */
function setHint(html) { const m = G.el && $('#gmsg', G.el); if (m) m.innerHTML = html; }
/* A short message over the board or the table */
function flashOn(host, text, ms = 1200) {
  if (!host) return;
  $$('.flash', host).forEach(f => f.remove());
  const f = document.createElement('div'); f.className = 'flash'; f.textContent = text; host.appendChild(f);
  if (!RM) f.animate([{ opacity: 0, transform: 'translate(-50%,-40%) scale(.9)' }, { opacity: 1, transform: 'translate(-50%,-50%) scale(1)' }], { duration: 220, easing: EASE });
  setTimeout(() => { if (!f.isConnected) return; const a = f.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 250, fill: 'forwards' }); a.finished.then(() => f.remove()).catch(() => f.remove()); }, ms);
}
function flash(text, ms = 1200) { flashOn(G.el && $('#board', G.el), text, ms); }
function panelOf(c) { return G.el && $(`.pp[data-c="${c}"]`, G.el); }
function updatePanels() {
  if (!G.el) return;
  const cur = E.current(G.st);
  G.setup.colors.forEach(c => {
    const p = panelOf(c); if (!p) return;
    p.classList.toggle('on', c === cur && G.st.phase !== 'over');
    p.classList.toggle('out', !!G.st.out[c]);
    const home = G.st.tokens[c].filter(x => x === E.HOME).length;
    $$('.homes i', p).forEach((d, i) => d.classList.toggle('on', i < home));
  });
  const slot = $(`.pp[data-c="${cur}"] .dslot`, G.el);
  if (slot && G.dice.parentNode !== slot) {
    slot.appendChild(G.dice);
    if (!RM) G.dice.animate([{ opacity: 0, transform: 'scale(.6)' }, { opacity: 1, transform: 'scale(1)' }], { duration: 220, easing: EASE });
  }
  const ready = isHuman(cur) && G.st.phase === 'roll' && !G.busy;
  G.dice.classList.toggle('ready', ready);
  if (ready) G.dice.setAttribute('data-act', 'roll'); else G.dice.removeAttribute('data-act');
}
function bubble(c, content, isEmoji) {
  const p = panelOf(c); if (!p) return;
  if (isEmoji && FX()) { bigEmoji($('.pav', p), content); return; }
  $$('.bubble', p).forEach(b => b.remove());
  const b = document.createElement('div'); b.className = 'bubble' + (isEmoji ? ' emo' : '');
  b.style.setProperty('--bdir', RTL() ? 'rtl' : 'ltr');
  b.textContent = content; p.appendChild(b);
  if (!RM) b.animate([{ opacity: 0, transform: 'translateY(6px) scale(.7)' }, { opacity: 1, transform: 'none' }], { duration: 260, easing: 'cubic-bezier(.3,1.4,.5,1)' });
  setTimeout(() => { if (!b.isConnected) return; b.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 300, fill: 'forwards' }).finished.then(() => b.remove()).catch(() => b.remove()); }, 2300);
}
function botReact(c, list, chance) {
  if (!G.alive || isHuman(c) || Math.random() > chance) return;
  setTimeout(() => { if (G.alive) { bubble(c, list[randInt(list.length)], true); Sound.fx.emoji(); } }, 500 + randInt(700));
}

/* ---------- turn loop ---------- */
function next() {
  if (!G.alive || G.busy) return;                    // one turn at a time
  updatePanels();
  if (G.st.phase === 'over') { finishGame(false); return; }
  const c = E.current(G.st);
  if (isHuman(c)) {
    if (G.st.phase === 'roll') { setHint(`<button class="btn gold sm" data-act="roll">${ic('dice', 's')}${esc(t('rollBtn'))}</button>`); Sound.fx.turn(); }
    else promptPick();
  } else {
    setHint(`<span class="dim">${esc(t('waitTurn', { n: nameOf(c) }))}</span>`);
    botTurn(G.gen);
  }
}
function uniqueFrom(moves) { return new Set(moves.map(m => m.from + ':' + m.to)).size === 1; }
function promptPick() {
  const moves = E.legalMoves(G.st);
  // (waits while the pause menu is open, so the move is not lost)
  if (S.prefs.autoMove && moves.length && uniqueFrom(moves)) { const gen = G.gen; setTimeout(async () => { if (await gate(gen)) humanMove(moves[0].t, true); }, 260); return; }
  G.view.setMovable(humanColor(), moves.map(m => m.t));
  setHint(`<span>${esc(t('pickToken'))}</span>`);
}
async function doRoll(gen) {
  const value = 1 + randInt(6);
  Sound.fx.dice(); haptic();
  updatePanels();
  await Board.rollFly(G.dice, value, TURBO() ? 10 : S.prefs.speed === 'fast' ? 460 : 620, $('#board', G.el));
  if (!live(gen)) return null;
  const ev = E.roll(G.st, value);
  saveGame();
  return ev;
}
async function humanRoll() {
  if (G.busy || !G.alive || G.paused || !isHuman(E.current(G.st)) || G.st.phase !== 'roll') return;
  const gen = G.gen;
  G.busy = true; setHint(''); G.dice.classList.remove('ready'); G.dice.removeAttribute('data-act');
  try {
    const ev = await doRoll(gen); if (!ev) return;
    await playEvents(ev, gen);
  } finally { if (live(gen)) G.busy = false; }
  if (!live(gen)) return;
  if (G.st.phase === 'move' && isHuman(E.current(G.st))) promptPick(); else next();
}
async function humanMove(tk, auto) {
  if (G.busy || !G.alive || G.paused || !isHuman(E.current(G.st)) || G.st.phase !== 'move') return;
  if (!E.legalMoves(G.st).some(m => m.t === tk)) { Sound.fx.error(); return; }
  const gen = G.gen;
  G.busy = true; G.view.setMovable(null); setHint('');
  if (!auto) haptic();
  try { const ev = E.move(G.st, tk); saveGame(); await playEvents(ev, gen); }
  finally { if (live(gen)) G.busy = false; }
  if (live(gen)) next();
}
async function botTurn(gen) {
  const sp = speed();
  G.busy = true;
  try {
    await sleep(sp.think); if (!(await gate(gen))) return;
    if (G.st.phase === 'roll') {
      const ev = await doRoll(gen); if (!ev) return;
      await playEvents(ev, gen); if (!live(gen)) return;
    }
    if (G.st.phase === 'move') {
      await sleep(sp.pick); if (!(await gate(gen))) return;
      const tk = LudoAI.choose(G.st);
      const mv = E.move(G.st, tk); saveGame();
      await playEvents(mv, gen);
    }
  } finally { if (live(gen)) G.busy = false; }
  if (live(gen)) next();
}

/* ---------- play engine events as animations ---------- */
async function playEvents(events, gen) {
  const sp = speed();
  for (const e of events) {
    if (!live(gen)) return;
    switch (e.type) {
      case 'move':
        if (e.enter) Sound.fx.enter();
        await G.view.hop(e.color, e.t, e.path, sp.step, k => Sound.fx.step(k));
        break;
      case 'capture': {
        const [x, y] = Board.pos(e.victim, e.rel, e.vt);
        G.view.burst(x, y, COLOR_HEX[e.color], false);
        Sound.fx.capture(); haptic('heavy'); shake($('#board', G.el), 7, 380);
        if (isHuman(e.color)) flash(t('youCaptured', { b: nameOf(e.victim) }));
        else if (isHuman(e.victim)) flash(t('gotCaptured', { a: nameOf(e.color) }));
        else flash(t('otherCaptured', { a: nameOf(e.color), b: nameOf(e.victim) }));
        await G.view.sendHome(e.victim, e.vt, TURBO() ? 10 : 520);
        botReact(e.color, ['😂', '😎', '🎉'], 0.4);
        botReact(e.victim, ['😭', '😡', '🤔'], 0.4);
        break;
      }
      case 'home': {
        const [x, y] = Board.pos(e.color, E.HOME, e.t);
        G.view.burst(x, y, '#F4B740', true); Sound.fx.home();
        G.view.lightColumn(e.color);
        const all = G.st.tokens[e.color].every(p => p === E.HOME);
        fireworks($('#board', G.el), [COLOR_HEX[e.color], '#FFE08A', '#FFFFFF'], all ? 3 : 1);
        G.view.layout(G.st); updatePanels();
        break;
      }
      case 'again':
        G.view.layout(G.st);
        if (isHuman(e.color)) flash(t({ six: 'againSix', capture: 'againCapture', home: 'againHome' }[e.reason]), 950);
        else if (e.reason !== 'six') flash(t('botAgain', { n: nameOf(e.color) }), 800);
        break;
      case 'pass':
        flash(t(e.reason === 'threeSixes' ? 'threeSixes' : 'noMove'), 900);
        await sleep(TURBO() ? 0 : S.prefs.speed === 'fast' ? 450 : 700);
        break;
      case 'turn':
        G.view.layout(G.st); updatePanels();
        break;
      case 'win':
        G.view.layout(G.st);
        break;
    }
  }
  if (live(gen)) { G.view.layout(G.st); updatePanels(); }
}

/* ---------- emojis + fixed phrases (no free text anywhere); shared by Ludo and dominoes ---------- */
let lastEmojiAt = 0;
function emojiTray(onSend) {
  sheet(`<h3>${esc(t('emojis'))}</h3><div class="emogrid">${EMOJIS.map((e, i) => `<button data-e="${i}" aria-label="${e}">${e}</button>`).join('')}</div>
    <h3 style="font-size:17px">${esc(t('phrases'))}</h3><div class="phr">${t('phraseList').map((p, i) => `<button data-p="${i}">${esc(p)}</button>`).join('')}</div>`, (sh, close) => {
    sh.addEventListener('click', e => {
      const b = e.target.closest('[data-e],[data-p]'); if (!b) return;
      if (Date.now() - lastEmojiAt < 2000) { toast(t('sendWait')); return; }
      lastEmojiAt = Date.now();
      const isE = b.dataset.e !== undefined;
      onSend(isE ? EMOJIS[+b.dataset.e] : t('phraseList')[+b.dataset.p], isE);
      Sound.fx.emoji(); haptic();
      close();
    });
  });
}
function ludoEmoji() {
  emojiTray((content, isE) => {
    bubble(humanColor(), content, isE);
    G.setup.colors.filter(c => !isHuman(c)).forEach(c => botReact(c, ['👍', '😂', '🤔', '😎'], 0.25));
  });
}

/* ---------- pause menu ---------- */
function gameMenu() {
  if (overlays.length || !G.st || !G.alive || G.st.phase === 'over') return;
  G.paused = true;
  sheet(`<h3>${esc(t('menu'))}</h3><div class="menu-list">
    <button class="row" data-m="resume"><span class="ri">${ic('dice')}</span><span class="rt">${esc(t('resumeGame'))}</span></button>
    <button class="row" data-m="rules"><span class="ri">${ic('book')}</span><span class="rt">${esc(t('howTo'))}</span></button>
    <button class="row" data-m="exit"><span class="ri">${ic('home')}</span><span class="rt">${esc(t('saveExit'))}<small>${esc(t('saveExitSub'))}</small></span></button>
    <button class="row" data-m="restart"><span class="ri">${ic('refresh')}</span><span class="rt">${esc(t('restart'))}<small>${esc(t('restartP'))}</small></span></button>
    <button class="row danger" data-m="forfeit"><span class="ri">${ic('flag')}</span><span class="rt">${esc(t('forfeit'))}<small>${esc(t('forfeitP'))}</small></span></button></div>`, (sh, close) => {
    sh.addEventListener('click', async e => {
      const b = e.target.closest('[data-m]'); if (!b) return;
      const m = b.dataset.m;
      await close();
      if (m === 'rules') go('howto', { tab: 'ludo' });
      else if (m === 'exit') { saveGame(); reset('home', {}, 'fade'); }
      else if (m === 'restart') { if (await confirmBox(t('restartQ'), t('restartP'), t('restart'), true)) { const s = G.setup; recordForfeit(); startGame(newSetup(s.players, s.human)); } else G.paused = false; }
      else if (m === 'forfeit') { if (await confirmBox(t('forfeitQ'), t('forfeitP'), t('forfeit'), true)) finishGame(true); else G.paused = false; }   // "cancel" carries on with the match
    });
  }, { onClose: () => { setTimeout(() => { if (!overlays.length) G.paused = false; }, 0); } });
}
function humanResult(forfeit) {
  const h = humanColor(), s = G.st.stats[h];
  return { game: 'ludo', players: G.setup.players, won: !forfeit && G.st.winner === h, forfeit, captures: s.captures, lost: s.lost, sixes: s.sixes, home: s.home, rolls: s.rolls, turns: s.turns,
    durationSec: Math.round((G.elapsed + (G.alive ? Date.now() - G.t0 : 0)) / 1000) };
}
function recordForfeit() {
  if (G.st) settle(true);
  G.alive = false; G.gen++;
}
function finishGame(forfeit) {
  if (!G.st || !G.setup || G.shown) return;          // the result screen is already on its way
  G.shown = true;
  const done = settle(forfeit), res = done.res, reward = done.reward;
  forfeit = done.forfeit;
  G.alive = false;
  while (overlayClose());                            // the menu may still be open when the last move lands
  const ranks = G.setup.colors.map(c => ({ c, name: nameOf(c), avatar: G.setup.avatars[c], captures: G.st.stats[c].captures, home: G.st.stats[c].home, prog: E.progress(G.st, c) }))
    .sort((a, b) => (b.c === G.st.winner) - (a.c === G.st.winner) || b.prog - a.prog);
  if (forfeit) ranks.sort((a, b) => (a.c === humanColor()) - (b.c === humanColor()) || b.prog - a.prog);
  G.gen++;
  const won = res.won;
  if (won) { Sound.fx.win(); haptic('success'); } else Sound.fx.lose();
  setTimeout(() => reset('result', { won, forfeit, winner: forfeit ? null : G.st.winner, ranks, reward, setup: G.setup, res }, 'zoom'), forfeit ? 0 : 700);
}

/* ---------- result ---------- */
/* Dinars, XP, level, title and badges earned in a match (both games) */
function rewardHtml(r) {
  if (!r) return '';
  return `<div class="earn">${r.coins > 0 ? `<span class="p">${DINAR(24)}${esc(countText(r.coins, 'dinarPlus'))}</span>` : r.coins < 0 ? `<span class="m">${DINAR(24)}${esc(countText(-r.coins, 'dinarMinus'))}</span>` : ''}${r.xp ? `<span>${esc(t('xpPlus', { n: fmtNum(r.xp) }))}</span>` : ''}</div>
    ${r.levelAfter > r.levelBefore ? `<div class="lvup">⬆ ${esc(t('levelUp', { n: fmtNum(r.levelAfter) }))}${r.bonus ? ` · ${esc(countText(r.bonus, 'dinarPlus'))}` : ''}</div>` : ''}${r.titleUp ? `<div class="lvup">${esc(t('newTitle', { t: r.titleUp }))}</div>` : ''}
    ${r.badges.length ? `<div class="lvup">${r.badges.map(b => `<span class="bdg">${Progress.badgeList().find(x => x.id === b).emoji}</span> ${esc(t('badgeNames.' + b)[0])}`).join(' · ')}</div>` : ''}`;
}
const TROPHY = `<svg class="trophy" viewBox="0 0 120 120" aria-hidden="true"><defs><linearGradient id="trg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFE7A6"/><stop offset="1" stop-color="#E8961C"/></linearGradient></defs>
  <path d="M34 18h52v22c0 16-11.6 28-26 28S34 56 34 40z" fill="url(#trg)"/><path d="M34 26H20c0 14 6 22 16 23M86 26h14c0 14-6 22-16 23" fill="none" stroke="#F2A92A" stroke-width="6" stroke-linecap="round"/>
  <rect x="53" y="66" width="14" height="16" fill="#E8961C"/><rect x="38" y="82" width="44" height="12" rx="4" fill="url(#trg)"/><rect x="32" y="94" width="56" height="10" rx="4" fill="#1A160F"/>
  <g transform="translate(60 38)">${rosette(0, 0, 12, '#FFF3CF', '#1A160F')}</g></svg>`;
SCREENS.result = {
  cls: 'result',
  html: (p) => {
    const r = p.reward;
    const winnerName = p.winner ? (p.winner === p.setup.human ? t('you') : p.setup.names[p.winner]) : '';
    const podium = p.ranks.slice(0, 3).map((x, i) => ({ place: i + 1, avatars: [x.avatar], name: x.name, color: COLOR_HEX[x.c] }));
    return `<canvas id="confetti"></canvas><div class="respill">${ptsHtml(Progress.data.points - (r ? r.points : 0))}</div><div class="scroll" style="width:100%"><div class="wrap">
      ${podiumHtml(podium, !!p.winner)}
      <h2>${esc(p.won ? t('youWon') : t('youLost'))}</h2>
      <p class="sub">${esc(p.won ? t('wonSub') : p.forfeit ? t('forfeitP') : t('lostSub', { n: winnerName }))}</p>
      ${rewardHtml(r)}
      <div class="ranks">${p.ranks.map((x, i) => `<div class="rank ${x.c === p.winner ? 'win' : ''}" style="--pc:${COLOR_HEX[x.c]}"><span class="pl">${x.c === p.winner ? '👑' : fmtNum(i + 1)}</span><span class="av">${avatarEmoji(x.avatar)}</span>
        <span class="rn">${esc(x.name)}<small>${esc(t('homeL'))}: ${fmtNum(x.home)}/4 · ${esc(t('capturesL'))}: ${fmtNum(x.captures)}</small></span></div>`).join('')}</div>
      <button class="btn gold block" data-act="playAgain">${ic('refresh')}${esc(t('playAgain'))}</button>
      <button class="btn ghost block" data-act="toHome" style="margin-top:12px">${ic('home')}${esc(t('toHome'))}</button>
    </div></div>`;
  },
  init(el, p) { if (p.won && !RM) confetti($('#confetti', el)); },
  after(el, p) { if (p._fx) return; p._fx = true; resultFx(el, p.reward, p.won); },
  onBack() { reset('home'); return true; }
};
function confetti(cv) {
  const ctx = cv.getContext('2d'); if (!ctx) return;
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const W = cv.width = cv.clientWidth * dpr, H = cv.height = cv.clientHeight * dpr;
  const cols = ['#F4B740', '#E2484E', '#2DAA62', '#2F7BEF', '#F2C230', '#FFF3CF', '#FBF5E8'];
  const parts = Array.from({ length: 110 }, () => ({ x: Math.random() * W, y: -Math.random() * H * 0.6, vx: (Math.random() - .5) * 2 * dpr, vy: (2 + Math.random() * 3) * dpr, s: (5 + Math.random() * 6) * dpr, r: Math.random() * 6, vr: (Math.random() - .5) * .3, c: cols[randInt(cols.length)] }));
  const end = performance.now() + 3200;
  (function frame(now) {
    if (!cv.isConnected) return;
    ctx.clearRect(0, 0, W, H);
    parts.forEach(q => { q.x += q.vx; q.y += q.vy; q.r += q.vr; ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(q.r); ctx.fillStyle = q.c; ctx.fillRect(-q.s / 2, -q.s / 4, q.s, q.s / 2); ctx.restore(); });
    if (now < end) requestAnimationFrame(frame); else ctx.clearRect(0, 0, W, H);
  })(performance.now());
}
