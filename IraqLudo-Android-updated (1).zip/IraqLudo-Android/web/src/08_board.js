/* ============ Board: geometry, drawing (one static SVG), tokens, dice, effects ============
   Coordinates are in "cells" on a 15×15 grid: x = column (0 at the left), y = row (0 at the top).
   Turn order and movement are clockwise: red (top-left) → green (top-right) → yellow (bottom-right) → blue (bottom-left). */
const Board = (() => {
  const E = LudoEngine;
  // the 52 squares of the shared track, starting at red's start square
  const PATH = [[1, 6], [2, 6], [3, 6], [4, 6], [5, 6], [6, 5], [6, 4], [6, 3], [6, 2], [6, 1], [6, 0], [7, 0], [8, 0],
    [8, 1], [8, 2], [8, 3], [8, 4], [8, 5], [9, 6], [10, 6], [11, 6], [12, 6], [13, 6], [14, 6], [14, 7], [14, 8],
    [13, 8], [12, 8], [11, 8], [10, 8], [9, 8], [8, 9], [8, 10], [8, 11], [8, 12], [8, 13], [8, 14], [7, 14], [6, 14],
    [6, 13], [6, 12], [6, 11], [6, 10], [6, 9], [5, 8], [4, 8], [3, 8], [2, 8], [1, 8], [0, 8], [0, 7], [0, 6]];
  const COLUMN = {
    red: [[1, 7], [2, 7], [3, 7], [4, 7], [5, 7]], green: [[7, 1], [7, 2], [7, 3], [7, 4], [7, 5]],
    yellow: [[13, 7], [12, 7], [11, 7], [10, 7], [9, 7]], blue: [[7, 13], [7, 12], [7, 11], [7, 10], [7, 9]]
  };
  const YARD = { red: [0, 0], green: [9, 0], yellow: [9, 9], blue: [0, 9] };
  const SLOTS = [[2, 2], [4, 2], [2, 4], [4, 4]];
  const FINISH = { red: [6.55, 7.5], green: [7.5, 6.55], yellow: [8.45, 7.5], blue: [7.5, 8.45] };
  const ENTRY_ARROW = { red: [0, 7, 0], green: [7, 0, 90], yellow: [14, 7, 180], blue: [7, 14, 270] }; // cell + arrow angle
  // board rotation that puts a colour's yard at the bottom-left, where the human player sits
  const ROT = { blue: 0, red: -90, green: 180, yellow: 90 };
  const PC = {
    red: { base: '#E2484E', dark: '#A8232D', light: '#F7B0B2' }, green: { base: '#2DAA62', dark: '#17723F', light: '#A6E3BF' },
    yellow: { base: '#F2C230', dark: '#B8860B', light: '#FBE7A0' }, blue: { base: '#2F7BEF', dark: '#1A4FB0', light: '#AFCBFA' }
  };
  const SKINS = {
    classic: { frame: '#14110C', grout: '#3A2F1B', tile: '#FBF5E8', tile2: '#EADFC4', rosette: '#1A160F', rosetteC: '#E6B44C', yard: '#FBF5E8', center: '#0E0C09' },
    babylon: { frame: '#1244B8', grout: '#0E3592', tile: '#EAF1FF', tile2: '#C9D9FB', rosette: '#E8A92B', rosetteC: '#FFF3CF', yard: '#EAF1FF', center: '#0F3A9E' },
    night: { frame: '#070605', grout: '#1C1812', tile: '#2E2920', tile2: '#25211A', rosette: '#E6B44C', rosetteC: '#FFF1C6', yard: '#1E1A14', center: '#070605' },
    palm: { frame: '#24513A', grout: '#2D6146', tile: '#F6EBD0', tile2: '#E6D3A8', rosette: '#24513A', rosetteC: '#E3A33A', yard: '#FBF4E2', center: '#1E4430' },
    turquoise: { frame: '#0E5E63', grout: '#0A4A4E', tile: '#F2FBFA', tile2: '#CDEDEA', rosette: '#0E7C7B', rosetteC: '#F4D27A', yard: '#EFFAF8', center: '#0B4F53' },
    sunset: { frame: '#3B1E54', grout: '#2C1640', tile: '#FFF4EC', tile2: '#FAD9C8', rosette: '#E8603C', rosetteC: '#FFE3A3', yard: '#FFF1E8', center: '#2A1440' }
  };
  /* A small picture in the middle of each yard; on the game board it moves a little (CSS, full motion only) */
  const star4 = (x, y, r, fill, cls = '') => `<path class="${cls}" d="M${x} ${y - r}L${x + r * .3} ${y - r * .3}L${x + r} ${y}L${x + r * .3} ${y + r * .3}L${x} ${y + r}L${x - r * .3} ${y + r * .3}L${x - r} ${y}L${x - r * .3} ${y - r * .3}Z" fill="${fill}"/>`;
  function deco(skinId, cx, cy, c) {
    if (skinId === 'night') return `<g class="deco">${[[-17, 0], [0, -17], [17, 0], [0, 17]].map(([dx, dy], k) => star4(cx + dx, cy + dy, 2.6, '#F3D58A', 'tw t' + k)).join('')}
      <path class="moon" d="M${cx + 3} ${cy - 5.5}a6 6 0 1 0 0 11a7.4 7.4 0 0 1 0-11z" fill="#F3D58A"/></g>`;
    if (skinId === 'babylon') return `<g class="deco"><g class="walk" style="transform-origin:${cx}px ${cy}px"><path d="M${cx - 8} ${cy + 3}c1-4 4-6 8-6h4c2-3 5-3 6 0c1 1 1 3 0 4l-1 1v4h-2v-3h-3l-1 3h-2l1-3h-6l-1 3h-2l1-3c-2 0-3-1-3-2h-1c-1 0-2-1-1-2z" fill="#E8A92B"/></g></g>`;
    if (skinId === 'palm') return `<g class="deco"><path d="M${cx} ${cy + 9}q1.5-7 0-13" stroke="#8A6236" stroke-width="2" fill="none" stroke-linecap="round"/>
      <g class="sway" style="transform-origin:${cx}px ${cy - 4}px">${[[-9, -2], [-6, -8], [0, -10], [6, -8], [9, -2]].map(([dx, dy]) => `<path d="M${cx} ${cy - 4}q${dx * .5} ${dy - 3} ${dx} ${dy}" stroke="#2D7A4E" stroke-width="2.2" fill="none" stroke-linecap="round"/>`).join('')}</g>
      <circle cx="${cx - 1.4}" cy="${cy - 2.6}" r="1.3" fill="#B5651D"/><circle cx="${cx + 1.4}" cy="${cy - 2.2}" r="1.3" fill="#B5651D"/></g>`;
    if (skinId === 'turquoise') return `<g class="deco"><g class="glint" style="transform-origin:${cx}px ${cy}px"><rect x="${cx - 5}" y="${cy - 5}" width="10" height="10" fill="#0E7C7B" opacity=".75"/>
      <rect x="${cx - 5}" y="${cy - 5}" width="10" height="10" fill="#0E7C7B" opacity=".75" transform="rotate(45 ${cx} ${cy})"/><circle cx="${cx}" cy="${cy}" r="2.4" fill="#F4D27A"/></g></g>`;
    if (skinId === 'sunset') return `<g class="deco"><g class="spin" style="transform-origin:${cx}px ${cy}px">${Array.from({ length: 8 }, (_, k) => `<path d="M${cx} ${cy - 7.5}l1.2 2.6h-2.4z" fill="#F29A5B" transform="rotate(${k * 45} ${cx} ${cy})"/>`).join('')}</g>
      <circle cx="${cx}" cy="${cy}" r="4.6" fill="#F27D47"/><circle cx="${cx - 1.4}" cy="${cy - 1.4}" r="1.4" fill="#FFE3A3"/></g>`;
    return `<g class="deco"><g class="spin slow" style="transform-origin:${cx}px ${cy}px">${rosette(cx, cy, 6, PC[c].dark, '#E6B44C')}</g></g>`;
  }

  const centerOf = (x, y) => [x + 0.5, y + 0.5];
  /* Centre (in cells) of a token at relative position rel */
  function pos(color, rel, t) {
    if (rel === E.YARD) { const o = YARD[color]; return [o[0] + SLOTS[t][0], o[1] + SLOTS[t][1]]; }
    if (rel >= 0 && rel <= E.LAST_MAIN) { const p = PATH[(E.START[color] + rel) % 52]; return centerOf(p[0], p[1]); }
    if (rel > E.LAST_MAIN && rel < E.HOME) { const p = COLUMN[color][rel - 51]; return centerOf(p[0], p[1]); }
    return FINISH[color].slice();
  }

  /* ---------- static board SVG (drawn once per game) ---------- */
  function svg(skinId, pfx = 'b') {
    const K = SKINS[skinId] || SKINS.classic;
    const U = 10;                                             // 10 svg units per cell
    let s = `<svg class="board-svg" viewBox="0 0 150 150" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <defs>
        <linearGradient id="${pfx}tg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${K.tile}"/><stop offset="1" stop-color="${K.tile2}"/></linearGradient>
        ${Object.keys(PC).map(c => `<linearGradient id="${pfx}g-${c}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${PC[c].base}"/><stop offset="1" stop-color="${PC[c].dark}"/></linearGradient>`).join('')}
      </defs>
      <rect x="0" y="0" width="150" height="150" rx="9" fill="${K.frame}"/>
      <rect x="0" y="60" width="150" height="30" fill="${K.grout}"/><rect x="60" y="0" width="30" height="150" fill="${K.grout}"/>`;
    const tile = (x, y, fill, extra = '') => `<rect x="${x * U + 0.55}" y="${y * U + 0.55}" width="8.9" height="8.9" rx="1.7" fill="${fill}"${extra}/><rect x="${x * U + 1.6}" y="${y * U + 1.2}" width="6.8" height="1.4" rx=".7" fill="#fff" opacity=".28"/>`;
    // yards
    for (const c of Object.keys(YARD)) {
      const [ox, oy] = YARD[c];
      s += `<rect x="${ox * U + 2}" y="${oy * U + 2}" width="56" height="56" rx="9" fill="url(#${pfx}g-${c})"/>
        <rect x="${ox * U + 9.5}" y="${oy * U + 9.5}" width="41" height="41" rx="8" fill="${K.yard}"/>
        ${deco(skinId, ox * U + 30, oy * U + 30, c)}
        ${SLOTS.map(([sx, sy]) => `<circle cx="${(ox + sx) * U}" cy="${(oy + sy) * U}" r="6.4" fill="${PC[c].light}" opacity=".55"/><circle cx="${(ox + sx) * U}" cy="${(oy + sy) * U}" r="6.4" fill="none" stroke="${PC[c].dark}" stroke-width=".8" opacity=".5"/>`).join('')}`;
    }
    // shared track
    PATH.forEach(([x, y], g) => {
      const startOf = Object.keys(E.START).find(c => E.START[c] === g);
      if (startOf) {
        s += tile(x, y, `url(#${pfx}g-${startOf})`) + `<g opacity=".95">${rosette(x * U + 5, y * U + 5, 4.1, '#FFFFFF', PC[startOf].dark)}</g>`;
      } else {
        s += tile(x, y, `url(#${pfx}tg)`);
        if (E.isSafe(g)) s += rosette(x * U + 5, y * U + 5, 4.1, K.rosette, K.rosetteC);
      }
    });
    // home columns
    for (const c of Object.keys(COLUMN)) COLUMN[c].forEach(([x, y]) => { s += tile(x, y, `url(#${pfx}g-${c})`); });
    // entry arrows into each home column
    for (const c of Object.keys(ENTRY_ARROW)) {
      const [x, y, a] = ENTRY_ARROW[c];
      s += `<path d="M-2.2 -2.6 L1.6 0 L-2.2 2.6" transform="translate(${x * U + 5} ${y * U + 5}) rotate(${a})" fill="none" stroke="${PC[c].base}" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>`;
    }
    // centre: four triangles meeting at a rosette
    s += `<rect x="60" y="60" width="30" height="30" fill="${K.center}"/>
      <path d="M60 60 L75 75 L60 90 Z" fill="url(#${pfx}g-red)"/><path d="M60 60 L90 60 L75 75 Z" fill="url(#${pfx}g-green)"/>
      <path d="M90 60 L90 90 L75 75 Z" fill="url(#${pfx}g-yellow)"/><path d="M60 90 L90 90 L75 75 Z" fill="url(#${pfx}g-blue)"/>
      <circle cx="75" cy="75" r="6.2" fill="${K.center}" stroke="#F4B740" stroke-width=".8"/>${rosette(75, 75, 4.6, '#F4B740', '#FFF3CF')}`;
    return s + '</svg>';
  }

  /* ---------- token + dice markup ---------- */
  const tokenHtml = (c, i) => `<button class="tok c-${c}" data-c="${c}" data-t="${i}" aria-label="${esc(t('colorNames.' + c))} ${i + 1}" tabindex="-1"><i></i></button>`;
  const PIPS = { 1: [5], 2: [3, 7], 3: [3, 5, 7], 4: [1, 3, 7, 9], 5: [1, 3, 5, 7, 9], 6: [1, 3, 4, 6, 7, 9] };
  const FACE_ROT = { 1: [0, 0], 6: [0, 180], 3: [0, -90], 4: [0, 90], 2: [-90, 0], 5: [90, 0] };
  const diceHtml = (skin = 'classic') => `<div class="dice d-${skin}" data-v="1"><div class="cube">${[1, 2, 3, 4, 5, 6].map(n => `<div class="face f${n}">${PIPS[n].map(p => `<span style="grid-area:${Math.ceil(p / 3)}/${(p - 1) % 3 + 1}"></span>`).join('')}</div>`).join('')}</div></div>`;

  /* Roll animation to a known value. The value always comes from the game controller. */
  function rollDice(diceEl, value, ms = 620) {
    const cube = $('.cube', diceEl);
    const [rx, ry] = FACE_ROT[value];
    const spinX = 360 * (1 + randInt(2)), spinY = 360 * (1 + randInt(2));
    const from = cube.style.transform || 'rotateX(0deg) rotateY(0deg)';
    const to = `rotateX(${rx + spinX}deg) rotateY(${ry + spinY}deg)`;
    diceEl.dataset.v = value;
    if (RM) { cube.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg)`; return Promise.resolve(); }
    const a = cube.animate([{ transform: from }, { transform: to }], { duration: ms, easing: 'cubic-bezier(.2,.75,.25,1)', fill: 'forwards' });
    diceEl.animate([{ transform: 'translateY(0) scale(1)' }, { transform: 'translateY(-14%) scale(1.12)', offset: .35 }, { transform: 'translateY(0) scale(1)' }], { duration: ms, easing: 'ease-out' });
    return a.finished.then(() => { cube.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg)`; a.cancel(); }).catch(() => {});
  }
  /* Full motion: the dice is thrown onto the middle of the board, tumbles with its shadow, settles, then
     goes back beside the player. Same value and the same result as rollDice; only the way there differs. */
  function rollFly(diceEl, value, ms, target) {
    if (!FX() || !target || !diceEl.isConnected || !diceEl.offsetParent) return rollDice(diceEl, value, ms);
    const cube = $('.cube', diceEl), [rx, ry] = FACE_ROT[value];
    const spinX = 360 * (2 + randInt(2)), spinY = 360 * (2 + randInt(2));
    const from = cube.style.transform || 'rotateX(0deg) rotateY(0deg)', to = `rotateX(${rx + spinX}deg) rotateY(${ry + spinY}deg)`;
    diceEl.dataset.v = value;
    const d = diceEl.getBoundingClientRect(), b = target.getBoundingClientRect();
    const lx = b.width / 2 + (Math.random() - .5) * b.width * .1, ly = b.height / 2 + (Math.random() - .5) * b.height * .1;
    const dx = b.left + lx - (d.left + d.width / 2), dy = b.top + ly - (d.top + d.height / 2), T = Math.round(ms * 1.6);
    diceEl.classList.add('flying');
    const fly = diceEl.animate([
      { transform: 'translate(0px,0px) scale(1)', offset: 0 },
      { transform: `translate(${(dx * .5).toFixed(0)}px,${(dy * .5 - 80).toFixed(0)}px) scale(1.6)`, offset: .28 },
      { transform: `translate(${dx.toFixed(0)}px,${dy.toFixed(0)}px) scale(1.25)`, offset: .52 },
      { transform: `translate(${dx.toFixed(0)}px,${(dy - 20).toFixed(0)}px) scale(1.3)`, offset: .6 },
      { transform: `translate(${dx.toFixed(0)}px,${dy.toFixed(0)}px) scale(1.25)`, offset: .68 },
      { transform: `translate(${dx.toFixed(0)}px,${dy.toFixed(0)}px) scale(1.25)`, offset: .84 },
      { transform: 'translate(0px,0px) scale(1)', offset: 1 }
    ], { duration: T, easing: 'ease-in-out' });
    const spin = cube.animate([{ transform: from }, { transform: to }], { duration: Math.round(T * .62), easing: 'cubic-bezier(.2,.7,.25,1)', fill: 'forwards' });
    const sh = document.createElement('i'); sh.className = 'dshadow'; sh.style.left = lx + 'px'; sh.style.top = ly + 'px'; sh.style.width = sh.style.height = (d.width * 1.15) + 'px';
    target.appendChild(sh);
    sh.animate([{ opacity: 0, transform: 'translate(-50%,-50%) scale(.3)' }, { opacity: .14, transform: 'translate(-50%,-50%) scale(.55)', offset: .28 },
      { opacity: .5, transform: 'translate(-50%,-50%) scale(1)', offset: .52 }, { opacity: .32, transform: 'translate(-50%,-50%) scale(.8)', offset: .6 },
      { opacity: .5, transform: 'translate(-50%,-50%) scale(1)', offset: .68 }, { opacity: .5, transform: 'translate(-50%,-50%) scale(1)', offset: .84 }, { opacity: 0, transform: 'translate(-50%,-50%) scale(.6)' }], { duration: T });
    setTimeout(() => Sound.fx.land(), T * .52);
    return Promise.all([fly.finished, spin.finished]).catch(() => {}).then(() => { cube.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg)`; spin.cancel(); diceEl.classList.remove('flying'); sh.remove(); });
  }
  function showFace(diceEl, value) { const [rx, ry] = FACE_ROT[value]; $('.cube', diceEl).style.transform = `rotateX(${rx}deg) rotateY(${ry}deg)`; diceEl.dataset.v = value; }

  /* ---------- a mounted board view ---------- */
  function mount(host, opts) {
    const rot = ROT[opts.human] || 0;
    host.innerHTML = `<div class="bwrap" style="--rot:${rot}deg">${svg(opts.skin, 'bd')}<div class="tlayer">${opts.colors.map(c => [0, 1, 2, 3].map(i => tokenHtml(c, i)).join('')).join('')}</div><div class="fx"></div></div>`;
    const wrap = $('.bwrap', host), layer = $('.tlayer', wrap), fxLayer = $('.fx', wrap);
    const els = {}; opts.colors.forEach(c => { els[c] = [0, 1, 2, 3].map(i => $(`.tok[data-c="${c}"][data-t="${i}"]`, layer)); });
    const tf = (x, y, sc = 1) => `translate(${((x - 0.5) * 100).toFixed(2)}%, ${((y - 0.5) * 100).toFixed(2)}%) scale(${sc})`;
    const resting = {};                                     // last resting transform per token

    /* Place every token for a game state; tokens sharing a square fan out a little */
    function layout(st, except) {
      const groups = new Map();
      for (const c of st.colors) {
        if (st.out[c]) { els[c].forEach(e => { e.style.display = 'none'; }); continue; }
        st.tokens[c].forEach((rel, i) => {
          const p = pos(c, rel, i);
          const k = rel === E.YARD ? `y${c}${i}` : rel === E.HOME ? `h${c}` : `${p[0]},${p[1]}`;
          if (!groups.has(k)) groups.set(k, []);
          groups.get(k).push({ c, i, p, home: rel === E.HOME });
        });
      }
      for (const g of groups.values()) {
        const n = g.length;
        g.forEach((it, k) => {
          let [x, y] = it.p, sc = 1;
          if (it.home) { const o = [[-.22, -.22], [.22, -.22], [-.22, .22], [.22, .22]][k]; x += o[0]; y += o[1]; sc = .5; }
          else if (n === 2) { x += k ? .17 : -.17; y += k ? .17 : -.17; sc = .78; }
          else if (n > 2) { const o = [[-.2, -.2], [.2, -.2], [-.2, .2], [.2, .2]][k % 4]; x += o[0]; y += o[1]; sc = .64; }
          const el = els[it.c][it.i];
          const v = tf(x, y, sc);
          resting[it.c + it.i] = v;
          if (!(except && except.c === it.c && except.i === it.i)) el.style.transform = v;
          el.style.display = '';
          el.style.zIndex = String(10 + Math.round(y * 10));
        });
      }
    }
    /* Hop a token along its path, one square at a time */
    /* Full motion: the token glides from square to square while its face jumps in an arc and squashes on landing
       (the face is counter-rotated with the board, so "up" is always up on the screen) */
    function hop(c, i, path, stepMs, onStep) {
      const el = els[c][i], arc = FX();
      const frames = [{ transform: el.style.transform, offset: 0 }];
      const n = path.length;
      path.forEach((rel, k) => {
        const [x, y] = pos(c, rel, i);
        if (!arc) frames.push({ transform: tf(x, y, 1.24), offset: (k + 0.5) / n });
        frames.push({ transform: tf(x, y, 1), offset: (k + 1) / n });
      });
      el.style.zIndex = '400';
      if (onStep) for (let k = 0; k < n; k++) setTimeout(() => onStep(k), k * stepMs + stepMs * (arc ? .85 : .45));
      if (RM) return Promise.resolve();
      const a = el.animate(frames, { duration: stepMs * n, easing: 'linear', fill: 'forwards' });
      if (arc && el.firstElementChild) {
        const base = `rotate(${-rot}deg)`, f2 = [];
        for (let k = 0; k < n; k++) {
          f2.push({ transform: `${base} translateY(0%) scale(1,1)`, offset: k / n });
          f2.push({ transform: `${base} translateY(-46%) scale(1.14,1.14)`, offset: (k + .45) / n });
          f2.push({ transform: `${base} translateY(0%) scale(1.16,.8)`, offset: (k + .86) / n });
        }
        f2.push({ transform: `${base} translateY(0%) scale(1,1)`, offset: 1 });
        el.firstElementChild.animate(f2, { duration: stepMs * n, easing: 'ease-in-out' });
      }
      return a.finished.then(() => { el.style.transform = frames[frames.length - 1].transform; a.cancel(); }).catch(() => {});
    }
    /* A captured token flies back to its yard slot */
    function sendHome(c, i, ms = 520) {
      const el = els[c][i], [x, y] = pos(c, E.YARD, i);
      const end = tf(x, y, 1);
      el.style.zIndex = '450';
      if (RM) { el.style.transform = end; return Promise.resolve(); }
      const big = FX(), start = el.style.transform;
      const kf = big ? [{ transform: start }, { transform: `${start} scale(1.5) rotate(160deg)`, offset: .18 }, { transform: `${tf(x, y, 1.6)} rotate(470deg)`, offset: .7 }, { transform: `${tf(x, y, .85)} rotate(700deg)`, offset: .88 }, { transform: `${end} rotate(720deg)` }]
        : [{ transform: start }, { transform: `${tf(x, y, 1.35)} rotate(200deg)`, offset: .6 }, { transform: end }];
      const a = el.animate(kf, { duration: big ? Math.round(ms * 1.35) : ms, easing: 'cubic-bezier(.3,.1,.3,1)', fill: 'forwards' });
      return a.finished.then(() => { el.style.transform = end; a.cancel(); }).catch(() => {});
    }
    /* A token reached home: the squares of its home column light up one after the other */
    function lightColumn(c) {
      if (!FX()) return;
      [...COLUMN[c], FINISH[c].map(v => v - .5)].forEach(([x, y], k) => {
        const g = document.createElement('i'); g.className = 'cglow'; g.style.cssText = `left:${x / 15 * 100}%;top:${y / 15 * 100}%;--gc:${PC[c].base}`;
        fxLayer.appendChild(g);
        g.animate([{ opacity: 0, transform: 'scale(.6)' }, { opacity: 1, transform: 'scale(1.08)', offset: .35 }, { opacity: 0, transform: 'scale(1)' }], { duration: 650, delay: k * 75, fill: 'backwards' })
          .finished.then(() => g.remove()).catch(() => g.remove());
      });
    }
    /* Ring + sparks at a square (capture, arrival home) */
    function burst(x, y, color, big) {
      if (RM) return;
      const b = document.createElement('i'); b.className = 'burst'; b.style.cssText = `left:${x / 15 * 100}%;top:${y / 15 * 100}%;--bc:${color}`;
      fxLayer.appendChild(b);
      b.animate([{ transform: 'translate(-50%,-50%) scale(.2)', opacity: 1 }, { transform: `translate(-50%,-50%) scale(${big ? 3.2 : 2.4})`, opacity: 0 }], { duration: 560, easing: 'ease-out' }).finished.then(() => b.remove()).catch(() => b.remove());
      const cell = wrap.clientWidth / 15 || 24;
      for (let k = 0; k < 8; k++) {
        const d = document.createElement('i'); d.className = 'spark'; d.style.cssText = `left:${x / 15 * 100}%;top:${y / 15 * 100}%;--bc:${color}`;
        fxLayer.appendChild(d);
        const ang = k * Math.PI / 4 + 0.2, r = cell * (big ? 1.7 : 1.25);
        d.animate([{ transform: 'translate(-50%,-50%) scale(1)', opacity: 1 }, { transform: `translate(calc(-50% + ${(Math.cos(ang) * r).toFixed(1)}px), calc(-50% + ${(Math.sin(ang) * r).toFixed(1)}px)) scale(.3)`, opacity: 0 }], { duration: 600, easing: 'cubic-bezier(.2,.7,.3,1)' }).finished.then(() => d.remove()).catch(() => d.remove());
      }
    }
    function setMovable(c, list) {
      layer.querySelectorAll('.tok.can').forEach(e => { e.classList.remove('can'); e.tabIndex = -1; });
      if (c && list) list.forEach(i => { els[c][i].classList.add('can'); els[c][i].tabIndex = 0; });   // keyboard: Tab to a token, Enter to move it
      wrap.classList.toggle('picking', !!(list && list.length));
    }
    return { el: wrap, layer, els, rot, layout, hop, sendHome, burst, setMovable, pos, lightColumn };
  }

  return { PATH, COLUMN, YARD, ROT, PC, SKINS, pos, svg, mount, diceHtml, rollDice, rollFly, showFace };
})();
