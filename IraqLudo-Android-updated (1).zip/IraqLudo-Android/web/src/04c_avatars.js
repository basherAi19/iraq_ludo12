/* ============ Player pictures: original Iraqi characters drawn in SVG ============
   Each character is built from a few parts (skin, hair or head cover, clothes, face details, one object in hand).
   No ids, gradients or clip paths inside the SVG: the same picture can appear many times on one screen.
   The round shape comes from CSS (svg.avc { clip-path: circle(50%) }). */
const CHAR_DEFS = {
  // male
  haji:     { g: 'm', bg: '#3C7DD9', skin: '#D9A06A', head: 'shemagh', cloth: 'dish', must: '#E8E4DC', brow: '#CFC8BC', age: 1 },
  sheikh:   { g: 'm', bg: '#C9962E', skin: '#C98E5C', head: 'kufiya', cloth: 'bisht', must: '#2A1E16', beard: '#2A1E16', brow: '#2A1E16' },
  shab:     { g: 'm', bg: '#2BAE9A', skin: '#E2AE80', head: 'hair', hair: '#1E1612', cloth: 'jacket', jc: '#28456B', beard: '#1E1612', stub: 1, brow: '#1E1612' },
  chayji:   { g: 'm', bg: '#D2693C', skin: '#C6895A', head: 'cap', capc: '#5B4636', hair: '#2B211B', cloth: 'vest', vc: '#7A2335', must: '#2B211B', brow: '#2B211B', item: 'tea' },
  sayyad:   { g: 'm', bg: '#2E86AB', skin: '#B9784A', head: 'wrap', wc: '#EDEAE4', wdots: '#3B3B3B', cloth: 'dish', dc: '#9AA6AE', must: '#231914', brow: '#231914', item: 'fish' },
  falah:    { g: 'm', bg: '#6BA34B', skin: '#C3824F', head: 'wrap', wc: '#F3F0EA', cloth: 'dish', dc: '#C9B48E', must: '#3A2A1E', brow: '#3A2A1E', item: 'dates' },
  talib:    { g: 'm', bg: '#F0A830', skin: '#E8B88E', head: 'hair', hair: '#2B1D16', side: 1, cloth: 'shirt', sc: '#8EC5F0', glasses: 1, brow: '#2B1D16', straps: 1 },
  oudi:     { g: 'm', bg: '#7A4FB0', skin: '#D49A68', head: 'hair', hair: '#151110', cloth: 'vest', vc: '#1F2B3D', must: '#151110', brow: '#151110', item: 'oud' },
  kabtin:   { g: 'm', bg: '#1E9B57', skin: '#B87A4B', head: 'curly', hair: '#141010', cloth: 'jersey', jc: '#E9F6EE', jt: '#16733F', brow: '#141010', item: 'ball' },
  // female
  hajiya:   { g: 'f', bg: '#8E5BD6', skin: '#D8A276', head: 'hijab', hj: '#16131A', hjEdge: '#ECE6DA', cloth: 'abaya', age: 1, brow: '#8A7A6E' },
  bint:     { g: 'f', bg: '#E46A8E', skin: '#E8B48A', head: 'hijab', hj: '#2FB8A8', cloth: 'shirt', sc: '#F7D9E3', brow: '#3A271E', lash: 1 },
  tabiba:   { g: 'f', bg: '#4AB0D9', skin: '#E0A97C', head: 'hijab', hj: '#24456E', cloth: 'coat', brow: '#2E2019', lash: 1, steth: 1 },
  muallima: { g: 'f', bg: '#D9874A', skin: '#D59C6E', head: 'hijab', hj: '#7A2E4A', cloth: 'cardigan', cc: '#3E5A4C', glasses: 1, brow: '#2E2019', lash: 1 },
  riyadiya: { g: 'f', bg: '#E04F5F', skin: '#C98C5E', head: 'hijab', hj: '#1B1B22', cloth: 'jersey', jc: '#FFFFFF', jt: '#E04F5F', brow: '#2A1C16', lash: 1, item: 'ball' }
};
const CHAR_IDS = Object.keys(CHAR_DEFS);
const isChar = id => !!CHAR_DEFS[id];

const charSvg = (() => {
  const cache = {};
  const shade = (hex, k) => {                     // k < 0 darker, k > 0 lighter
    const n = parseInt(hex.slice(1), 16), c = [n >> 16, (n >> 8) & 255, n & 255].map(v => Math.round(k < 0 ? v * (1 + k) : v + (255 - v) * k));
    return '#' + c.map(v => Math.max(0, Math.min(255, v)).toString(16).padStart(2, '0')).join('');
  };
  // little diamonds of the red-and-white shemagh, only where the cloth shows
  function checks(color, inside) {
    let s = '';
    for (let y = 25; y <= 80; y += 4.4) for (let x = 24 + ((y / 4.4) % 2) * 2.2; x <= 76; x += 4.4) if (inside(x, y)) s += `<rect x="${(x - .85).toFixed(1)}" y="${(y - .85).toFixed(1)}" width="1.7" height="1.7" transform="rotate(45 ${x.toFixed(1)} ${y.toFixed(1)})" fill="${color}"/>`;
    return s;
  }
  const inFace = (x, y) => ((x - 50) / 16.5) ** 2 + ((y - 47) / 18.5) ** 2 < 1.02;
  function build(d) {
    const sk = d.skin, skd = shade(sk, -.16), skd2 = shade(sk, -.32);
    let s = `<svg class="avc" viewBox="4 4 92 92" aria-hidden="true"><circle cx="50" cy="50" r="50" fill="${d.bg}"/>
      <circle cx="30" cy="22" r="44" fill="#fff" opacity=".13"/><circle cx="50" cy="118" r="62" fill="#000" opacity=".12"/>`;
    const body = fill => `<path d="M6 106C8 83 27 72.5 50 72.5S92 83 94 106Z" fill="${fill}"/>`;
    // ---------- clothes ----------
    const dc = d.dc || '#F3F0E9';
    if (d.cloth === 'dish') s += body(dc) + `<path d="M50 73v30" stroke="${shade(dc, -.14)}" stroke-width="1.3"/><path d="M43.5 73.5c2 4 4.5 6 6.5 6s4.5-2 6.5-6" fill="none" stroke="${shade(dc, -.14)}" stroke-width="1.3"/>`;
    else if (d.cloth === 'bisht') s += body('#F3F0E9') + `<path d="M6 106C8 86 22 76 37 74L46 106Z" fill="#4E331F"/><path d="M94 106C92 86 78 76 63 74L54 106Z" fill="#4E331F"/>
      <path d="M37 74L46 106M63 74L54 106" stroke="#E2B65A" stroke-width="2.2"/><path d="M44 74c2 3.5 4 5 6 5s4-1.5 6-5" fill="none" stroke="#D9D2C4" stroke-width="1.3"/>`;
    else if (d.cloth === 'jacket') s += body(d.jc) + `<path d="M41 73.5L50 92L59 73.5Z" fill="#F4F4F2"/><path d="M41 73.5L47 90L41 106M59 73.5L53 90L59 106" fill="none" stroke="${shade(d.jc, -.3)}" stroke-width="1.6"/>`;
    else if (d.cloth === 'vest') s += body('#F3EFE6') + `<path d="M6 106C8 86 22 76 38 74L45 106Z" fill="${d.vc}"/><path d="M94 106C92 86 78 76 62 74L55 106Z" fill="${d.vc}"/>
      <circle cx="47.5" cy="92" r="1.1" fill="${shade(d.vc, .5)}"/><circle cx="47.5" cy="99" r="1.1" fill="${shade(d.vc, .5)}"/>`;
    else if (d.cloth === 'abaya') s += body('#18151C') + `<path d="M30 79c5 3 9 5 12 9M70 79c-5 3-9 5-12 9" stroke="#2C2832" stroke-width="1.6" fill="none"/>`;
    else if (d.cloth === 'shirt') s += body(d.sc) + `<path d="M42 73.5l8 7 8-7" fill="none" stroke="${shade(d.sc, -.2)}" stroke-width="1.6"/><path d="M50 80.5v24" stroke="${shade(d.sc, -.16)}" stroke-width="1.2"/>`;
    else if (d.cloth === 'coat') s += body('#FBFBFA') + `<path d="M41 73.5L50 90L59 73.5Z" fill="${d.hj}"/><path d="M41 73.5L48 92L44 106M59 73.5L52 92L56 106" fill="none" stroke="#D5DADF" stroke-width="1.6"/>`;
    else if (d.cloth === 'cardigan') s += body(d.cc) + `<path d="M43 73.5L50 86L57 73.5Z" fill="#F2EDE4"/><path d="M50 86v20" stroke="${shade(d.cc, -.3)}" stroke-width="1.4"/>
      <circle cx="47" cy="93" r="1" fill="${shade(d.cc, .5)}"/><circle cx="47" cy="100" r="1" fill="${shade(d.cc, .5)}"/>`;
    else if (d.cloth === 'jersey') s += body(d.jc) + `<path d="M16 92C30 87 70 87 84 92L86 99C70 94 30 94 14 99Z" fill="${d.jt}"/><path d="M42 73.5l8 8 8-8" fill="none" stroke="${d.jt}" stroke-width="2.6"/>`;
    if (d.straps) s += `<path d="M33 76L30 106M67 76L70 106" stroke="#2D3540" stroke-width="5" stroke-linecap="round"/>`;
    if (d.steth) s += `<path d="M42 75c-2 10 0 17 6 19M58 75c2 10 0 17-6 19" fill="none" stroke="#56606B" stroke-width="1.6"/><circle cx="50" cy="95" r="3" fill="#8A949E" stroke="#56606B" stroke-width="1"/>`;
    // ---------- neck ----------
    s += `<path d="M42 58h16v13c0 5-16 5-16 0z" fill="${skd}"/>`;
    // ---------- behind the head: draped shemagh / hijab ----------
    const dropCloth = 'M26.5 80C23.5 60 25 31 50 26C75 31 76.5 60 73.5 80C68 76 64 71 63 63L37 63C36 71 32 76 26.5 80Z';
    if (d.head === 'shemagh' || d.head === 'kufiya') {
      const cl = d.head === 'shemagh' ? '#F6F3EE' : '#FAFAF7';
      s += `<path d="${dropCloth}" fill="${cl}"/><path d="M31 70c2-6 3-12 3-20M69 70c-2-6-3-12-3-20" stroke="#000" stroke-opacity=".08" stroke-width="2" fill="none"/>`;
      if (d.head === 'shemagh') s += checks('#C8333A', (x, y) => y > 30 && y < 80 && Math.abs(x - 50) < 23.5 - Math.max(0, 40 - y) * 0.6 && !inFace(x, y) && !(y > 62 && Math.abs(x - 50) < 13) && (Math.abs(x - 50) > 13.5 || y < 40));
    }
    if (d.head === 'hijab') s += `<path d="M29 54C27 31 37.5 22.5 50 22.5S73 31 71 54C71 64 66.5 72 60 76.5L40 76.5C33.5 72 29 64 29 54Z" fill="${d.hj}"/>`;
    // ---------- head ----------
    const ears = d.head !== 'hijab';
    if (ears) s += `<ellipse cx="33.6" cy="48.5" rx="3.3" ry="4.8" fill="${skd}"/><ellipse cx="66.4" cy="48.5" rx="3.3" ry="4.8" fill="${skd}"/>`;
    s += d.head === 'hijab' ? `<ellipse cx="50" cy="48" rx="14.6" ry="16.8" fill="${sk}"/>` : `<ellipse cx="50" cy="47" rx="16.5" ry="18.5" fill="${sk}"/>`;
    s += `<ellipse cx="50" cy="60" rx="11" ry="5" fill="${skd}" opacity=".35"/>`;
    // beard sits on the face
    if (d.beard) s += `<path d="M33.8 47c0 13.5 7 22.5 16.2 22.5S66.2 60.5 66.2 47c-2 6.5-4 9.5-6 10.5c-2-2.6-6-3.6-10.2-3.6S41.8 54.9 39.8 57.5c-2-1-4-4-6-10.5Z" fill="${d.beard}" opacity="${d.stub ? .32 : .92}"/>`;
    // ---------- face ----------
    const ey = d.head === 'hijab' ? 48 : 47;
    const brow = d.brow || '#2A1E16';
    s += `<path d="M40.5 ${ey - 5.6}q3.4-2 6.8 0M52.7 ${ey - 5.6}q3.4-2 6.8 0" stroke="${brow}" stroke-width="${d.age ? 2.2 : 1.8}" fill="none" stroke-linecap="round"/>`;
    s += `<ellipse cx="43.8" cy="${ey}" rx="2" ry="2.5" fill="#2A1D14"/><ellipse cx="56.2" cy="${ey}" rx="2" ry="2.5" fill="#2A1D14"/>
      <circle cx="44.5" cy="${ey - .9}" r=".75" fill="#fff"/><circle cx="56.9" cy="${ey - .9}" r=".75" fill="#fff"/>`;
    if (d.lash) s += `<path d="M41.4 ${ey - 1.6}l-1.4-1.1M58.6 ${ey - 1.6}l1.4-1.1" stroke="#2A1D14" stroke-width="1.1" stroke-linecap="round"/>`;
    if (d.age) s += `<path d="M39.5 ${ey + 3.6}q2.2 1.3 4.4 0M56.1 ${ey + 3.6}q2.2 1.3 4.4 0" stroke="${skd2}" stroke-width=".9" fill="none" opacity=".7"/>`;
    s += `<path d="M50 ${ey + 2}q-1.7 4.3.8 5.1" stroke="${skd2}" stroke-width="1.4" fill="none" stroke-linecap="round"/>`;
    s += `<circle cx="39.6" cy="${ey + 7}" r="3.2" fill="#FF7E6B" opacity=".22"/><circle cx="60.4" cy="${ey + 7}" r="3.2" fill="#FF7E6B" opacity=".22"/>`;
    if (d.must) s += `<path d="M42.3 ${ey + 7.8}c3-2.8 5.8-2.4 7.7-.7c1.9-1.7 4.7-2.1 7.7.7c-3 1.8-5.5 1.4-7.7-.1c-2.2 1.5-4.7 1.9-7.7.1z" fill="${d.must}"/>`;
    s += d.must ? `<path d="M46 ${ey + 10.6}q4 2.6 8 0" stroke="#7A2E25" stroke-width="1.6" fill="none" stroke-linecap="round"/>`
      : `<path d="M44.8 ${ey + 9}q5.2 4.6 10.4 0q-5.2 2-10.4 0z" fill="#8E2F2A" stroke="#7A2E25" stroke-width="1" stroke-linejoin="round"/>`;
    if (d.glasses) s += `<g fill="none" stroke="#1F2328" stroke-width="1.5"><rect x="38.4" y="${ey - 3.6}" width="10" height="7.6" rx="2.6"/><rect x="51.6" y="${ey - 3.6}" width="10" height="7.6" rx="2.6"/><path d="M48.4 ${ey - .6}h3.2"/></g>`;
    // ---------- hair and head covers on top ----------
    if (d.head === 'hair') {
      s += d.side ? `<path d="M33.2 46C31.5 30 39.5 23.5 50 23.5S69 29 67 45C64 38 61 35 56 33.5C50 37 42 38 33.2 46Z" fill="${d.hair}"/><path d="M56 33.5c-3 1-6 1.5-9 1.4" stroke="${shade(d.hair, .25)}" stroke-width="1" fill="none"/>`
        : `<path d="M33.2 46C31 30 39.5 23 50 23S69.5 30 66.8 46C64.5 39 61.5 35.5 57 34C52.5 36 41.5 37.5 33.2 46Z" fill="${d.hair}"/>`;
    } else if (d.head === 'curly') {
      s += `<g fill="${d.hair}">${[[36, 37], [40, 31], [46, 27.5], [53, 27], [59.5, 30], [64, 36], [38, 43], [62.5, 42], [43, 33.5], [50, 31.5], [57, 34]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="5.6"/>`).join('')}</g>`;
    } else if (d.head === 'cap') {
      s += `<path d="M33.5 45C33 37 35 34 37 33L63 33C65 34 67 37 66.5 45C63 40 37 40 33.5 45Z" fill="${d.hair}"/>
        <path d="M32 40C31 29 40 24.5 50 24.5S69 29 68 40C62 36.5 38 36.5 32 40Z" fill="${d.capc}"/><path d="M31.5 39.5C40 35.5 60 35.5 70 40C71 42 69 43.2 67 42.4C59 39.4 41 39.4 33.6 42.6C31.8 43.2 30.4 41 31.5 39.5Z" fill="${shade(d.capc, -.3)}"/>`;
    } else if (d.head === 'wrap') {
      const w = d.wc;
      s += `<path d="M31.6 44C31 30 40 24.4 50 24.4S69 30 68.4 44C62.5 38.4 37.5 38.4 31.6 44Z" fill="${w}"/>
        <path d="M33.5 37.5c10-4 23-4 33 0M33 41c10-3.6 24-3.6 34 0M38 30c7 3 17 3 24 0" stroke="#000" stroke-opacity=".12" stroke-width="1.2" fill="none"/>
        <path d="M64 37C73 43 73.5 57 69 66C67 59 64.5 50 62 44Z" fill="${shade(w, -.06)}"/>`;
      if (d.wdots) s += checks(d.wdots, (x, y) => y < 43 && y > 26 && ((x - 50) / 18) ** 2 + ((y - 34) / 10) ** 2 < 1 && !inFace(x, y + 3));
    } else if (d.head === 'shemagh' || d.head === 'kufiya') {
      const cl = d.head === 'shemagh' ? '#F6F3EE' : '#FAFAF7';
      s += `<path d="M32.4 44.5C32 30 40 25.4 50 25.4S68 30 67.6 44.5C62 38.6 56 37 50 37S38 38.6 32.4 44.5Z" fill="${cl}"/>`;
      if (d.head === 'shemagh') s += checks('#C8333A', (x, y) => y > 25 && y < 43 && ((x - 50) / 18) ** 2 + ((y - 36) / 11) ** 2 < 1 && (y < 37 || Math.abs(x - 50) > 12));
      s += `<ellipse cx="50" cy="30.8" rx="15.8" ry="4.6" fill="none" stroke="#151515" stroke-width="2.7"/><ellipse cx="50" cy="33.6" rx="16.6" ry="4.4" fill="none" stroke="#151515" stroke-width="2.4"/>`;
    } else if (d.head === 'hijab') {
      s += `<path d="M35.2 45C34.6 33 41.6 29 50 29S65.4 33 64.8 45C61.4 39.4 56 37.4 50 37.4S38.6 39.4 35.2 45Z" fill="${d.hj}"/>
        <path d="M37 64C41 69 59 69 63 64L65 77L35 77Z" fill="${shade(d.hj, -.18)}"/>`;
      if (d.hjEdge) s += `<path d="M35.6 47C35.4 36 41.6 31 50 31S64.6 36 64.4 47" fill="none" stroke="${d.hjEdge}" stroke-width="1.6"/>`;
      s += `<path d="M38 34c4-3 8-4 12-4" stroke="#fff" stroke-opacity=".22" stroke-width="2" fill="none" stroke-linecap="round"/>`;
    }
    // ---------- the object in hand ----------
    if (d.item === 'tea') s += `<g transform="translate(73 81)"><ellipse cx="0" cy="12" rx="10.5" ry="2.8" fill="#EDE7DC" stroke="#B9AE9C" stroke-width=".8"/>
      <path d="M-5.2-3C-5.2 3-3 5.6-3.6 8.6C-4 11.2 4 11.2 3.6 8.6C3 5.6 5.2 3 5.2-3Z" fill="#B95A12" opacity=".92"/><path d="M-5.2-3C-5.2 3-3 5.6-3.6 8.6C-4 11.2 4 11.2 3.6 8.6C3 5.6 5.2 3 5.2-3Z" fill="none" stroke="#FFFFFF" stroke-opacity=".8" stroke-width="1"/>
      <path d="M-3.4-1.6v6" stroke="#fff" stroke-opacity=".55" stroke-width="1.1" stroke-linecap="round"/></g>`;
    else if (d.item === 'fish') s += `<g transform="translate(72 86) rotate(-18)"><path d="M-11 0C-6-7 6-7 10 0C6 7-6 7-11 0Z" fill="#9DB6C6"/><path d="M9 0L16-6L15 0L16 6Z" fill="#7E9AAE"/>
      <circle cx="-6" cy="-1.4" r="1.3" fill="#1D2A33"/><path d="M-2-4c2 2 2 6 0 8M3-4.5c2 2 2 7 0 9" stroke="#6F8A9C" stroke-width=".9" fill="none"/></g>`;
    else if (d.item === 'dates') s += `<g transform="translate(73 84)"><path d="M0-12C-1-6 0-2 0 2" stroke="#8A6A2E" stroke-width="1.6" fill="none"/>
      ${[[-4, 1], [1, 0], [5, 3], [-2, 6], [3, 7], [-6, 6], [0, 11], [6, 9]].map(([x, y]) => `<ellipse cx="${x}" cy="${y}" rx="2.6" ry="3.6" fill="#8B3E12"/><ellipse cx="${x - .8}" cy="${y - 1.2}" rx=".8" ry="1.2" fill="#fff" opacity=".35"/>`).join('')}</g>`;
    else if (d.item === 'oud') s += `<g transform="translate(24 88) rotate(-32)"><path d="M-3-30h6v18h-6z" fill="#6E4321"/><path d="M-4-31h8v-5h-8z" fill="#4A2C14"/>
      <ellipse cx="0" cy="2" rx="14" ry="16" fill="#B87333"/><ellipse cx="0" cy="2" rx="14" ry="16" fill="none" stroke="#7A4A1E" stroke-width="1.4"/><circle cx="0" cy="-1" r="3.6" fill="#3E2410"/>
      <path d="M-1.2-30v40M1.2-30v40" stroke="#F3E2C2" stroke-width=".5"/></g>`;
    else if (d.item === 'ball') s += `<g transform="translate(74 85)"><circle r="10" fill="#FFFFFF" stroke="#2B2B2B" stroke-width="1"/><path d="M0-4.2L4 -1.3L2.5 3.4H-2.5L-4-1.3Z" fill="#202020"/>
      <path d="M0-4.2V-10M4-1.3L9.4-3M2.5 3.4L5.8 8.2M-2.5 3.4L-5.8 8.2M-4-1.3L-9.4-3" stroke="#202020" stroke-width="1"/></g>`;
    return s + '</svg>';
  }
  return id => cache[id] || (cache[id] = build(CHAR_DEFS[id]));
})();
