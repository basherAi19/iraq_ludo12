/* =====================================================================
   Iraq Ludo — Dominoes computer player (one level)
   It only uses what a real player at the table knows: its own tiles, the tiles on the
   table, how many tiles each player holds, and the numbers each player has knocked on.
   It never looks at other hands or at the draw pile.
   ===================================================================== */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./02b_domino.js'));
  else root.DominoAI = factory(root.DominoEngine);
})(typeof self !== 'undefined' ? self : this, function (D) {
  'use strict';

  function choose(st, rand) {
    const rnd = typeof rand === 'function' ? rand : Math.random;
    const moves = D.legalMoves(st);
    if (!moves.length) return null;
    if (moves.length === 1) return moves[0];
    const seat = st.turn, hand = st.hands[seat], cur = D.ends(st);
    const mine = D.teamOf(st, seat);
    const partner = st.players === 4 ? (seat + 2) % 4 : -1;
    const opps = [];
    for (let s = 0; s < st.players; s++) if (D.teamOf(st, s) !== mine) opps.push(s);
    const oppShort = opps.some(o => st.hands[o].length <= 2);            // public: tile counts
    // how many tiles of each number this player can already see (own hand + table)
    const seen = [0, 0, 0, 0, 0, 0, 0];
    const visit = id => { const [a, b] = D.TILES[id]; seen[a]++; if (b !== a) seen[b]++; };
    hand.forEach(visit);
    if (st.first) { visit(st.first.id); st.L.forEach(x => visit(x.id)); st.R.forEach(x => visit(x.id)); }

    let best = null, bestS = -Infinity;
    for (const m of moves) {
      const rest = hand.filter(x => x !== m.id);
      let ne;
      if (m.side === 'C') ne = D.TILES[m.id].slice();
      else { ne = cur.slice(); const k = m.side === 'L' ? 0 : 1; ne[k] = D.other(m.id, cur[k]); }
      let s = D.pips(m.id);                                               // shed heavy tiles: they count against you
      if (D.isDouble(m.id)) s += 3.5;                                     // a double fits one number only
      s += rest.filter(x => D.has(x, ne[0]) || D.has(x, ne[1])).length * 2.2;   // keep something to play next turn
      // numbers held by this player and still open stay under its control
      const own = v => rest.filter(x => D.has(x, v)).length;
      s += Math.min(3, own(ne[0]) + own(ne[1])) * 0.8;
      for (const o of opps) {
        const v = st.voids[o];
        if (v[ne[0]] && v[ne[1]]) s += oppShort ? 9 : 6;                 // the opponent has knocked on both numbers
        else if (v[ne[0]] || v[ne[1]]) s += 2;
      }
      if (partner >= 0) { const v = st.voids[partner]; if (v[ne[0]] && v[ne[1]]) s -= 4; }
      // a number with all seven tiles in sight is dead: leaving both ends dead closes the line early
      if (seen[ne[0]] >= 7 && seen[ne[1]] >= 7 && rest.length) s -= 3;
      s *= 1 + (rnd() * 2 - 1) * 0.15;                                    // a little variety
      if (s > bestS) { bestS = s; best = m; }
    }
    return best;
  }

  return { choose };
});
