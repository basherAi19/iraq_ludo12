/* ============ Main screens ============ */
const avatarHtml = (id, cls = '') => `<span class="av ${cls} ${isChar(id) ? 'drawn' : ''}">${avatarArt(id)}</span>`;
const levelBar = () => { const L = Progress.level(); return `<span class="lvl">${esc(t('levelN', { n: L.level }))}<span class="lvlbar"><i style="width:${Math.round(L.into / L.need * 100)}%"></i></span></span>`; };
const ptsHtml = (v = Progress.data.points) => `<span class="pts" aria-label="${esc(t('myDinars'))}">${DINAR(22)}<b>${fmtNum(v)}</b><small>${esc(t('curShort'))}</small></span>`;
const dinarLine = (n, size = 14) => `<small class="coinline">${DINAR(size)}${esc(countText(n, 'dinarN'))}</small>`;
/* A saved Ludo match that can really be opened again (a damaged or older save is ignored) */
const savedGame = () => {
  const s = store.get('save:' + (Accounts.user ? Accounts.user.uid : 'guest'), null), su = s && s.setup;
  return s && s.st && su && LudoEngine.validate(s.st) && s.st.phase !== 'over' && Array.isArray(su.colors)
    && su.colors.length === s.st.colors.length && su.colors.every(c => s.st.colors.includes(c))
    && s.st.colors.includes(su.human) && su.names && su.avatars ? s : null;
};
/* Starting a new match replaces the saved one of that game. If you had already played in it, it counts as a
   give-up (the same as "start over" in the pause menu), so the player is asked first. */
async function replaceSaved(kind) {
  const sv = kind === 'dom' ? dSaved() : savedGame();
  if (!sv) return true;
  const st = sv.st;
  const played = kind === 'dom' ? (st.round > 1 || st.stats[0].played + st.stats[0].drawn + st.stats[0].passes > 0) : st.stats[sv.setup.human].rolls > 0;
  if (played && !(await confirmBox(t('savedQ'), t('savedP'), t('startNew'), true))) return false;
  if (kind === 'dom') { DG.alive = false; DG.gen++; DG.settled = null; DG.setup = sv.setup; DG.st = st; DG.elapsed = sv.elapsed || 0; dRecordForfeit(); }
  else { G.alive = false; G.gen++; G.settled = null; G.setup = sv.setup; G.st = st; G.elapsed = sv.elapsed || 0; recordForfeit(); }
  return true;
}
const stakeChips = () => `<div class="stake"><span class="up">${DINAR(18)}${esc(t('stakeWin'))}</span><span class="down">${DINAR(18)}${esc(t('stakeLose'))}</span></div>`;

/* Game art for the home cards */
const ludoArt = () => `<span class="lart">${Board.svg(Progress.data.equipped.board, 'hm').replace('class="board-svg"', 'class="mini-board"')}</span>${Board.diceHtml(Progress.data.equipped.dice)}`;
const domArt = () => `<svg class="dart" viewBox="0 0 80 80" aria-hidden="true">
  <g transform="translate(14 8) rotate(-16 10 20) scale(1.3)">${domSvgTile(6, 6)}</g>
  <g transform="translate(40 30) rotate(64 10 20) scale(1.3)">${domSvgTile(5, 3)}</g></svg>`;

/* ---------- Home ---------- */
SCREENS.home = {
  live: true, keep: true,
  html: () => {
    const u = Accounts.user, sv = savedGame(), dsv = dSaved(), daily = Progress.dailyState(), ready = Progress.readyCount();
    const resume = (act, title, sub) => `<button class="resume" data-act="${act}">${ic('refresh', 'l')}<span style="flex:1"><b>${esc(title)}</b><small>${sub}</small></span>${ic('chev', 'fwd')}</button>`;
    return `<div class="home-top">
      <button class="who" data-act="profile">${avatarHtml(u.avatar)}<span class="wt"><b>${esc(u.guest ? t('guestName') : u.name)}</b>${levelBar()}</span></button>
      ${ptsHtml()}
      <button class="iconbtn" data-act="settings" aria-label="${esc(t('settings'))}">${ic('gear')}</button>
    </div>
    <div class="scroll"><div class="wrap">
      <div class="hero"><div class="wordmark">${esc(t('appName'))}</div><div class="slogan" id="slogan">${esc(t('slogans')[S.sloganI % 7])}</div></div>
      ${sv ? resume('resume', t('resumeLudo'), esc(countText(sv.setup.colors.length, 'playersN'))) : ''}
      ${dsv ? resume('dResume', t('resumeDom'), `${esc(countText(dsv.st.players, 'playersN'))} · ${fmtNum(dsv.st.scores[0])} – ${fmtNum(dsv.st.scores[1])}`) : ''}
      <div class="games">
        <button class="gcard" data-act="playLudo"><span class="gart">${ludoArt()}</span><b>${esc(t('ludo'))}</b><small>${esc(t('ludoSub'))}</small></button>
        <button class="gcard" data-act="playDom"><span class="gart">${domArt()}</span><b>${esc(t('dom'))}</b><small>${esc(t('domSub'))}</small></button>
      </div>
      <p class="freeline"><span class="tag free">${esc(t('free'))}</span>${esc(t('gamesFree'))}</p>
      <button class="bigbtn online" data-act="online"><span class="bi">${ic('users', 'l')}</span><span class="bt"><b>${esc(t('playOnline'))}</b><span class="sub"><span class="tag soon">${esc(t('soon'))}</span><small>${esc(t('playOnlineSub'))}</small></span></span></button>
      <div class="tiles">
        <button class="tile" data-act="daily"><span class="ti gold">${ic('gift')}</span><b>${esc(t('daily'))}</b><small>${esc(daily.can ? t('dailyReady') : t('dailyDone'))}</small>${daily.can ? '<span class="dotlabel tag soon">!</span>' : ''}</button>
        <button class="tile" data-act="challenges"><span class="ti turq">${ic('trophy')}</span><b>${esc(t('challenges'))}</b><small>${ready ? esc(t('challengesN', { n: ready })) : esc(t('renewDaily'))}</small>${ready ? '<span class="dotlabel tag paid">' + ready + '</span>' : ''}</button>
        <button class="tile" data-act="profile"><span class="ti blue">${ic('user')}</span><b>${esc(t('profile'))}</b><small>${esc(Progress.level().title)}</small></button>
        <button class="tile" data-act="shop"><span class="ti rose">${ic('palette')}</span><b>${esc(t('shop'))}</b>${dinarLine(Progress.data.points)}</button>
      </div>
      <div class="homefoot"><button class="linkbtn" data-act="vip">⭐ VIP</button><button class="linkbtn" data-act="howto">${esc(t('howTo'))}</button>${u.guest ? `<button class="linkbtn" data-act="toLoginFromGuest">${esc(t('makeAccount'))}</button>` : ''}${appLink()}</div>
    </div></div>`;
  },
  init(el) {
    $$('.gcard .dice', el).forEach(d => Board.showFace(d, 6));
    clearInterval(el._sl);
    el._sl = setInterval(() => {
      const s = $('#slogan', el); if (!s || document.hidden) return;
      s.style.opacity = '0';
      setTimeout(() => { S.sloganI = (S.sloganI + 1) % 7; s.textContent = t('slogans')[S.sloganI]; s.style.opacity = '1'; }, 450);
    }, 7000);
    Sound.wantMusic = true; Sound.startMusic();
  },
  leave(el) { clearInterval(el._sl); }
};

/* ---------- Ludo setup: players + colour (one computer level, never shown) ---------- */
const COLOR_HEX = { red: '#E2484E', green: '#2DAA62', yellow: '#F2C230', blue: '#2F7BEF' };
SCREENS.offSetup = {
  live: true,
  html: (p) => {
    p.players = p.players || store.get('lastPlayers', 2); p.color = p.color || store.get('lastColor', 'blue');
    const dots = n => `<span class="pdots">${(n === 2 ? ['blue', 'green'] : ['red', 'green', 'yellow', 'blue']).map(c => `<i style="background:${COLOR_HEX[c]}"></i>`).join('')}</span>`;
    return `${hdr({ title: t('offTitle') })}<div class="scroll"><div class="wrap">
      <p class="muted" style="text-align:center;margin:0 0 6px">${esc(t('offSub'))}</p>
      <div class="sec">${esc(t('playersLabel'))}</div>
      <div class="choices">${[2, 4].map(n => `<button class="choice ${p.players === n ? 'on' : ''}" data-act="setPlayers" data-v="${n}">${dots(n)}<b>${esc(t(n === 2 ? 'twoP' : 'fourP'))}</b><small>${esc(t(n === 2 ? 'twoPSub' : 'fourPSub'))}</small></button>`).join('')}</div>
      <div class="sec">${esc(t('yourColor'))}</div>
      <div class="swatches">${['red', 'green', 'yellow', 'blue'].map(c => `<button class="swatch ${p.color === c ? 'on' : ''}" data-act="setColor" data-v="${c}"><span class="chip" style="background:${COLOR_HEX[c]}"></span>${esc(t('colorNames.' + c))}</button>`).join('')}</div>
      <div class="stickyfoot">${stakeChips()}<button class="btn gold block" data-act="startGame">${ic('dice')}${esc(t('start'))}</button></div>
    </div></div>`;
  }
};

/* ---------- Online (free; the game server is not switched on yet) ---------- */
SCREENS.online = {
  html: () => {
    const guest = Accounts.isGuest;
    return `${hdr({ title: t('onTitle') })}<div class="scroll"><div class="wrap">
      <div style="text-align:center;padding:4px 0 6px"><div style="display:inline-flex">${['haji', 'bint', 'kabtin', 'tabiba'].map((a, i) => `<span class="av drawn" style="margin-inline-start:${i ? -10 : 0}px;box-shadow:0 0 0 3px ${COLOR_HEX[['red', 'green', 'yellow', 'blue'][i]]}">${avatarArt(a)}</span>`).join('')}</div>
      <h2 style="font-size:24px;font-weight:800;margin:14px 0 6px;line-height:1.35">${esc(t('onHero'))}</h2><p class="muted" style="margin:0">${esc(t('onSub'))}</p></div>
      <div class="card" style="margin-top:16px">${t('onFeat').map(f => `<div class="feat">${ic('check')}<span>${esc(f)}</span></div>`).join('')}</div>
      <div class="note" style="margin:16px 0">${esc(t('onSoon'))}</div>
      ${guest ? `<div class="note info" style="margin-bottom:14px">${esc(t('needAccount'))}</div>` : ''}
      <button class="btn gold block" data-act="playFree">${esc(t('mmOffBtn'))}</button>
      <button class="btn ghost block" data-act="${guest ? 'toLoginFromGuest' : 'matchmaking'}" style="margin-top:12px">${esc(guest ? t('signInOrCreate') : t('findMatch'))}</button>
    </div></div>`;
  }
};

/* ---------- Matchmaking (game server arrives in Phase 3; no fake players) ---------- */
SCREENS.match = {
  live: true,
  html: (p) => {
    p.mode = p.mode || 2; p.color = p.color || 'any'; p.state = p.state || 'idle';
    if (p.state !== 'idle') {
      return `${hdr({ title: t('mmTitle') })}<div class="scroll"><div class="wrap" style="text-align:center">
        <div class="radar"><i></i><i></i><i></i>${avatarHtml(Accounts.user.avatar)}</div>
        ${p.state === 'searching' ? `<p style="font-weight:800;font-size:18px">${esc(t('mmSearching'))}</p><button class="btn ghost block" data-act="mmCancel">${esc(t('mmCancel'))}</button>`
          : `<div class="note" style="text-align:start;margin-bottom:16px">${esc(t('mmOff'))}</div><button class="btn gold block" data-act="playFree">${esc(t('mmOffBtn'))}</button><button class="btn ghost block" data-act="mmCancel" style="margin-top:12px">${esc(t('back'))}</button>`}
      </div></div>`;
    }
    p.game = p.game || 'ludo';
    return `${hdr({ title: t('mmTitle') })}<div class="scroll"><div class="wrap">
      <div class="sec">${esc(t('mmGame'))}</div>
      <div class="seg">${['ludo', 'dom'].map(g => `<button class="${p.game === g ? 'on' : ''}" data-act="mmGame" data-v="${g}">${esc(t(g))}</button>`).join('')}</div>
      <div class="sec">${esc(t('mmMode'))}</div>
      <div class="seg">${[2, 4].map(n => `<button class="${p.mode === n ? 'on' : ''}" data-act="mmMode" data-v="${n}">${esc(t(n === 2 ? 'twoP' : 'fourP'))}</button>`).join('')}</div>
      ${p.game === 'ludo' ? `<div class="sec">${esc(t('mmColor'))}</div>
      <div class="swatches five">${['any', 'red', 'green', 'yellow', 'blue'].map(c => `<button class="swatch ${p.color === c ? 'on' : ''}" data-act="mmColor" data-v="${c}"><span class="chip" style="background:${c === 'any' ? 'conic-gradient(#E2484E 0 25%,#2DAA62 0 50%,#F2C230 0 75%,#2F7BEF 0)' : COLOR_HEX[c]}"></span>${esc(c === 'any' ? t('mmAny') : t('colorShort.' + c))}</button>`).join('')}</div>
      <p class="help">${esc(t('mmColorNote'))}</p>` : `<p class="help">${esc(t(p.mode === 4 ? 'dom4Sub' : 'dom2Sub'))}</p>`}
      <div class="stickyfoot"><button class="btn gold block" data-act="mmStart">${esc(t('mmStart'))}</button></div>
    </div></div>`;
  },
  leave(el, p) { clearTimeout(p._t); }
};

/* ---------- Profile ---------- */
SCREENS.profile = {
  live: true,
  html: () => {
    const u = Accounts.user, L = Progress.level(), st = Progress.data.stats;
    const s = { games: st.games + st.dom.games, wins: st.wins + st.dom.wins };
    const rate = s.games ? Math.round(s.wins / s.games * 100) : 0;
    const d = new Date(u.createdAt || Date.now());
    return `${hdr({ title: t('profile') })}<div class="scroll"><div class="wrap">
      <div class="prof">
        <button data-act="pickAvatar" style="background:none;border:0;padding:0;position:relative" aria-label="${esc(t('changeAvatar'))}">${avatarHtml(u.avatar, 'xl')}</button>
        <h2>${esc(u.guest ? t('guestName') : u.name)}${u.guest ? '' : `<button class="iconbtn" style="width:38px;height:38px" data-act="editName" aria-label="${esc(t('editName'))}">${ic('pencil', 's')}</button>`}</h2>
        ${u.guest ? '' : `<div class="dim" dir="ltr" style="font-weight:700">@${esc(u.username)}</div>`}
        <div class="ttl">${esc(L.title)}</div>
        <div class="xpline">${esc(t('levelN', { n: L.level }))}<span class="lvlbar"><i style="width:${Math.round(L.into / L.need * 100)}%"></i></span></div>
        <div class="dim" style="font-size:13px;font-weight:700">${esc(t('nextLevel', { n: fmtNum(L.need - L.into) }))}</div>
      </div>
      ${u.guest ? `<div class="note info" style="margin-top:14px">${esc(t('guestProfile'))}</div><button class="btn outline block" data-act="toLoginFromGuest" style="margin-top:12px">${esc(t('signInOrCreate'))}</button>` : ''}
      <div class="stats3"><div class="stat"><b>${fmtNum(s.games)}</b><small>${esc(t('games'))}</small></div><div class="stat"><b>${fmtNum(s.wins)}</b><small>${esc(t('wins'))}</small></div><div class="stat"><b>${fmtNum(rate)}%</b><small>${esc(t('winRate'))}</small></div></div>
      <button class="row" data-act="stats"><span class="ri">${ic('chart')}</span><span class="rt">${esc(t('seeStats'))}</span>${ic('chev', 'fwd')}</button>
      <button class="row" data-act="shop"><span class="ri">${ic('palette')}</span><span class="rt">${esc(t('shop'))}${dinarLine(Progress.data.points)}</span>${ic('chev', 'fwd')}</button>
      <div class="sec">${esc(t('badges'))}</div>
      <div class="badges">${Progress.badgeList().map(b => `<div class="badge ${b.got ? '' : 'off'}" title="${esc(t('badgeNames.' + b.id)[1])}"><span class="be">${b.emoji}</span><small>${esc(t('badgeNames.' + b.id)[0])}</small></div>`).join('')}</div>
      <p class="help" style="text-align:center;margin-top:18px">${esc(t('memberSince', { d: d.toLocaleDateString(S.lang === 'ar' ? 'ar-IQ' : 'en-GB', { year: 'numeric', month: 'long' }) }))}</p>
    </div></div>`;
  }
};
function avatarSheet() {
  const cur = Accounts.user.avatar;
  const cell = ([id, e, price]) => { const own = Progress.owns('avatar', id); return `<button data-av="${id}" class="${id === cur ? 'on' : ''} ${own ? '' : 'lockd'} ${e ? '' : 'drawn'}">${avatarArt(id)}${own ? '' : `<span class="lk">${DINAR(12)}${price}</span>`}</button>`; };
  sheet(`<h3>${esc(t('pickAvatar'))}</h3><div class="sec" style="margin-top:6px">${esc(t('charsL'))}</div><div class="avgrid">${AVATARS.filter(a => !a[1]).map(cell).join('')}</div>
    <div class="sec">${esc(t('emojisL'))}</div><div class="avgrid">${AVATARS.filter(a => a[1]).map(cell).join('')}</div><p class="help" style="margin-top:0">${esc(t('pointsNote'))}</p>`, (sh, close) => {
    sh.addEventListener('click', e => {
      const b = e.target.closest('[data-av]'); if (!b) return;
      const id = b.dataset.av;
      if (!Progress.owns('avatar', id)) { close().then(() => go('shop', { tab: 'avatar' })); return; }
      Progress.equip('avatar', id); Sound.fx.tap(); haptic(); close().then(refreshTop);
    });
  });
}
function nameSheet() {
  sheet(`<h3>${esc(t('editName'))}</h3>${field('nm-in', t('displayName'), `<input class="input" id="nm-in" maxlength="20" value="${esc(Accounts.user.name)}">`, `<div class="msg bad" id="nm-msg"></div><p class="help">${esc(t('displayNameHint'))}</p>`)}<div class="acts"><button class="btn ghost" data-x="no">${esc(t('cancel'))}</button><button class="btn gold" data-x="ok">${esc(t('save'))}</button></div>`, (sh, close) => {
    const inp = $('#nm-in', sh); setTimeout(() => inp.focus(), 80);
    sh.addEventListener('click', async e => {
      const b = e.target.closest('[data-x]'); if (!b) return;
      if (b.dataset.x === 'no') return close();
      if (!checkName(inp.value)) { $('#nm-msg', sh).textContent = t('badName'); Sound.fx.error(); return; }
      b.disabled = true; await Accounts.saveProfile({ name: inp.value }); toast(t('nameSaved')); close().then(refreshTop);
    });
  });
}

/* ---------- Statistics: Ludo, dominoes, online ---------- */
SCREENS.stats = {
  live: true,
  html: (p) => {
    p.tab = p.tab || 'ludo';
    const all = Progress.data.stats;
    const kv = (k, v) => `<div class="kv"><span>${esc(k)}</span><b>${v}</b></div>`;
    const wg = o => o.g ? `<bdi class="pair">${fmtNum(o.w)} / ${fmtNum(o.g)}</bdi>` : t('none');
    const head = s => `<div class="stats3"><div class="stat"><b>${fmtNum(s.games)}</b><small>${esc(t('games'))}</small></div><div class="stat"><b>${fmtNum(s.wins)}</b><small>${esc(t('wins'))}</small></div><div class="stat"><b>${fmtNum(s.losses)}</b><small>${esc(t('losses'))}</small></div></div>`;
    const rate = s => s.games ? Math.round(s.wins / s.games * 100) + '%' : t('none');
    let body;
    if (p.tab === 'on') body = `<div class="note info" style="margin-top:16px">${esc(t('onlineStatsSoon'))}</div>`;
    else if (p.tab === 'dom') {
      const s = all.dom;
      body = `${head(s)}
      <div class="card">${kv(t('winRate'), rate(s))}${kv(t('currentStreak'), fmtNum(s.streak))}${kv(t('bestStreak'), fmtNum(s.bestStreak))}${kv(t('playTime'), esc(countText(s.timeSec / 60, 'minutesN')))}${kv(t('forfeits'), fmtNum(s.forfeits))}</div>
      <div class="sec">${esc(t('dom'))}</div>
      <div class="card">${kv(t('domRounds'), fmtNum(s.rounds))}${kv(t('domRoundsWon'), fmtNum(s.roundsWon))}${kv(t('domOuts'), fmtNum(s.outs))}${kv(t('domPoints'), fmtNum(s.points))}${kv(t('domBest'), s.best ? esc(countText(s.best, 'domPtsN')) : t('none'))}${kv(t('domBlocks'), fmtNum(s.blockWins))}</div>
      <div class="sec">${esc(t('byPlayers'))}</div>
      <div class="card">${kv(t('twoP'), wg(s.p2))}${kv(t('fourP'), wg(s.p4))}</div>`;
    } else {
      const s = all;
      body = `${head(s)}
      <div class="card">${kv(t('winRate'), rate(s))}${kv(t('currentStreak'), fmtNum(s.streak))}${kv(t('bestStreak'), fmtNum(s.bestStreak))}${kv(t('fastestWin'), s.fastest ? esc(countText(s.fastest, 'turnsN')) : t('none'))}${kv(t('playTime'), esc(countText(s.timeSec / 60, 'minutesN')))}${kv(t('forfeits'), fmtNum(s.forfeits))}</div>
      <div class="sec">${esc(t('byPlayers'))}</div>
      <div class="card">${kv(t('twoP'), wg(s.p2))}${kv(t('fourP'), wg(s.p4))}</div>
      <div class="sec">${esc(t('game'))}</div>
      <div class="card">${kv(t('capturesMade'), fmtNum(s.captures))}${kv(t('tokensLost'), fmtNum(s.lost))}${kv(t('homeTokens'), fmtNum(s.home))}${kv(t('sixes'), fmtNum(s.sixes))}</div>`;
    }
    return `${hdr({ title: t('statsTitle') })}<div class="scroll"><div class="wrap">
      <div class="seg">${[['ludo', t('ludo')], ['dom', t('dom')], ['on', t('onlineStats')]].map(([k, l]) => `<button class="${p.tab === k ? 'on' : ''}" data-act="statsTab" data-v="${k}">${esc(l)}</button>`).join('')}</div>
      ${body}
    </div></div>`;
  }
};

/* ---------- Settings ---------- */
SCREENS.settings = {
  live: true,
  html: () => {
    const u = Accounts.user, P = S.prefs;
    const sw = (k, label, icon) => `<button class="row" data-act="togglePref" data-k="${k}"><span class="ri">${ic(icon)}</span><span class="rt">${esc(label)}</span><i class="sw ${P[k] ? 'on' : ''}"></i></button>`;
    return `${hdr({ title: t('settings') })}<div class="scroll"><div class="wrap">
      <button class="row designrow" data-act="design"><span class="ri">${ic('palette')}</span><span class="rt">${esc(t('design'))}<small>${esc(t('designRowSub'))}</small></span><span class="thdots">${THEMES.slice(0, 4).map(x => `<i style="background:${x[2]}"></i>`).join('')}</span>${ic('chev', 'fwd')}</button>
      <div class="sec">${esc(t('language'))}</div>
      <div class="seg"><button class="${S.lang === 'ar' ? 'on' : ''}" data-act="setLang" data-v="ar">العربية</button><button class="${S.lang === 'en' ? 'on' : ''}" data-act="setLang" data-v="en">English</button></div>
      <div class="sec">${esc(t('game'))}</div>
      ${sw('sound', t('sound'), 'sound')}${sw('music', t('music'), 'music')}${sw('vibrate', t('vibration'), 'vibrate')}${sw('autoMove', t('autoMove'), 'bolt')}
      <div class="row" style="flex-wrap:wrap"><span class="ri">${ic('dice')}</span><span class="rt">${esc(t('speed'))}</span><div class="seg" style="width:100%"><button class="${P.speed !== 'fast' ? 'on' : ''}" data-act="setSpeed" data-v="normal">${esc(t('speedNormal'))}</button><button class="${P.speed === 'fast' ? 'on' : ''}" data-act="setSpeed" data-v="fast">${esc(t('speedFast'))}</button></div></div>
      <div class="sec">${esc(t('account'))}</div>
      ${Accounts.mode === 'local' ? `<div class="note" style="margin-bottom:10px">${esc(t('demoBanner'))}</div>` : ''}
      ${u.guest ? `<button class="row" data-act="toLoginFromGuest"><span class="ri">${ic('user')}</span><span class="rt">${esc(t('signInOrCreate'))}<small>${esc(t('guestAccount'))}</small></span>${ic('chev', 'fwd')}</button>`
        : `<div class="row"><span class="ri">${ic('user')}</span><span class="rt">${esc(t('username'))}<small dir="ltr" style="text-align:start">@${esc(u.username)}</small></span></div>
           <button class="row" data-act="changePw"><span class="ri">${ic('key')}</span><span class="rt">${esc(t('changePw'))}</span>${ic('chev', 'fwd')}</button>
           <button class="row" data-act="logout"><span class="ri">${ic('logout')}</span><span class="rt">${esc(t('logout'))}</span></button>
           <button class="row danger" data-act="deleteAcc"><span class="ri">${ic('trash')}</span><span class="rt">${esc(t('deleteAcc'))}</span></button>`}
      <div class="sec">${esc(t('about'))}</div>
      <button class="row" data-act="howto"><span class="ri">${ic('book')}</span><span class="rt">${esc(t('howTo'))}</span>${ic('chev', 'fwd')}</button>
      <button class="row" data-act="welcomeAgain"><span class="ri">${ic('smile')}</span><span class="rt">${esc(t('welcomeAgain'))}</span>${ic('chev', 'fwd')}</button>
      <button class="row" data-act="privacy"><span class="ri">${ic('shield')}</span><span class="rt">${esc(t('privacy'))}</span>${ic('chev', 'fwd')}</button>
      <button class="row" data-act="about"><span class="ri">${ic('info')}</span><span class="rt">${esc(t('about'))}<small>${esc(t('version'))} ${esc(CONFIG.version)}</small></span>${ic('chev', 'fwd')}</button>
    </div></div>`;
  }
};
function pwSheet() {
  sheet(`<h3>${esc(t('changePw'))}</h3>${field('cp-o', t('currentPw'), pwInput('cp-o'))}${field('cp-n', t('newPw'), pwInput('cp-n', '', 'new-password'), `<p class="help">${esc(t('pwRules'))}</p>`)}${field('cp-n2', t('confirmPw'), pwInput('cp-n2', '', 'new-password'))}<div class="msg bad" id="cp-msg"></div><div class="acts"><button class="btn ghost" data-x="no">${esc(t('cancel'))}</button><button class="btn gold" data-x="ok">${esc(t('save'))}</button></div>`, (sh, close) => {
    sh.addEventListener('click', async e => {
      const b = e.target.closest('[data-x]'); if (!b) return;
      if (b.dataset.x === 'no') return close();
      const o = $('#cp-o', sh).value, n = $('#cp-n', sh).value, n2 = $('#cp-n2', sh).value, m = $('#cp-msg', sh);
      if (!pwOk(n)) { m.textContent = t('pwWeak'); return; }
      if (n !== n2) { m.textContent = t('pwMismatch'); return; }
      b.disabled = true; m.className = 'msg wait'; m.textContent = t('loading');
      try { await Accounts.changePassword(o, n); toast(t('pwChanged')); close(); }
      catch (x) { b.disabled = false; m.className = 'msg bad'; m.textContent = authMsg(x); Sound.fx.error(); }
    });
  });
}
function deleteSheet() {
  sheet(`<h3>${esc(t('deleteQ'))}</h3><p>${esc(t('deleteP'))}</p>${field('da-p', t('deletePw'), pwInput('da-p'))}<div class="msg bad" id="da-msg"></div><div class="acts"><button class="btn ghost" data-x="no">${esc(t('cancel'))}</button><button class="btn danger" data-x="ok">${esc(t('deleteAcc'))}</button></div>`, (sh, close) => {
    sh.addEventListener('click', async e => {
      const b = e.target.closest('[data-x]'); if (!b) return;
      if (b.dataset.x === 'no') return close();
      const pw = $('#da-p', sh).value, m = $('#da-msg', sh);
      if (!pw) { m.textContent = t('required'); return; }
      b.disabled = true; m.className = 'msg wait'; m.textContent = t('loading');
      try { await Accounts.deleteAccount(pw); await close(); toast(t('deleted')); reset('login', {}, 'zoom'); }
      catch (x) { b.disabled = false; m.className = 'msg bad'; m.textContent = authMsg(x); }
    });
  });
}
/* A sheet of plain text, with optional link rows: [{ icon, label, sub, url }] (only https: and mailto: links are shown) */
const safeUrl = u => (/^https:\/\/[^\s"'<>]+$/i.test(String(u || '')) ? String(u) : '');
const safeMail = m => (/^[^\s@"'<>]+@[^\s@"'<>]+\.[^\s@"'<>]+$/.test(String(m || '')) ? String(m) : '');
function openLink(url) {
  try { if (NATIVE && NATIVE.open) { NATIVE.open(url); return; } } catch (e) {}
  if (/^mailto:/i.test(url)) location.href = url; else window.open(url, '_blank', 'noopener');
}
function infoSheet(title, text, links) {
  const paras = [].concat(text).filter(Boolean).map(x => `<p>${esc(x)}</p>`).join('');
  const rows = (links || []).filter(l => l && l.url).map((l, i) => `<button class="row" data-link="${i}"><span class="ri">${ic(l.icon)}</span><span class="rt">${esc(l.label)}${l.sub ? `<small dir="ltr" style="text-align:start">${esc(l.sub)}</small>` : ''}</span>${ic('chev', 'fwd')}</button>`).join('');
  const list = (links || []).filter(l => l && l.url);
  sheet(`<h3>${esc(title)}</h3>${paras}${rows ? `<div class="menu-list" style="margin-bottom:16px">${rows}</div>` : ''}<button class="btn gold block" data-x="ok">${esc(t('ok'))}</button>`, (sh, close) => sh.addEventListener('click', e => {
    const l = e.target.closest('[data-link]');
    if (l) { openLink(list[+l.dataset.link].url); return; }
    if (e.target.closest('[data-x]')) close();
  }));
}
const supportMail = () => safeMail(CONFIG.supportEmail);

/* ---------- How to play (with small board strips) ---------- */
function strip(cells) {
  // cells: [{fill:'tile'|'red'|..., rosette?:true, tok?:color, tok2?:color, arrow?:true, ghost?:color}]
  const W = 34, n = cells.length;
  let s = `<svg class="strip" viewBox="0 0 ${n * W + 4} ${W + 4}" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><rect x="0" y="0" width="${n * W + 4}" height="${W + 4}" rx="8" fill="#1A160F"/>`;
  cells.forEach((c, i) => {
    const x = 2 + i * W, fill = c.fill === 'tile' || !c.fill ? '#FBF5E8' : COLOR_HEX[c.fill];
    s += `<rect x="${x + 1.5}" y="3.5" width="${W - 3}" height="${W - 3}" rx="5" fill="${fill}"/>`;
    if (c.rosette) s += rosette(x + W / 2, 2 + W / 2, 12, c.fill === 'tile' || !c.fill ? '#1A160F' : '#fff', '#E6B44C');
    const tok = (col, dx, op = 1) => `<g opacity="${op}"><circle cx="${x + W / 2 + dx}" cy="${2 + W / 2}" r="10.5" fill="${Board.PC[col].dark}"/><circle cx="${x + W / 2 + dx}" cy="${1 + W / 2}" r="9.5" fill="${Board.PC[col].base}" stroke="#fff" stroke-width="1.4"/><circle cx="${x + W / 2 + dx}" cy="${1 + W / 2}" r="1.8" fill="#FFF8E6"/></g>`;
    if (c.ghost) s += tok(c.ghost, 0, .35);
    if (c.tok2) s += tok(c.tok2, 5);
    if (c.tok) s += tok(c.tok, c.tok2 ? -5 : 0);
    if (c.x) s += `<path d="M${x + 9} 11 l16 16 M${x + 25} 11 l-16 16" stroke="#E2484E" stroke-width="3.5" stroke-linecap="round"/>`;
    if (c.arrow) s += `<path d="M${x + 10} ${2 + W / 2} h14 m-5 -5 l5 5 l-5 5" stroke="#1A160F" stroke-width="2.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
  });
  return s + '</svg>';
}
const RULE_STRIPS = {
  1: () => strip([{ fill: 'blue', tok: 'blue' }, { fill: 'blue', rosette: true, ghost: 'blue' }, { arrow: true }, {}, {}]),
  4: () => strip([{ tok: 'blue' }, { arrow: true }, { arrow: true }, { tok: 'red', x: true }, {}]),
  5: () => strip([{}, { rosette: true, tok: 'red', tok2: 'blue' }, {}, { fill: 'green', rosette: true }, {}]),
  6: () => strip([{}, { tok: 'green', tok2: 'green' }, { arrow: true }, { tok: 'red' }, {}]),
  8: () => strip([{ fill: 'yellow', tok: 'yellow' }, { fill: 'yellow' }, { fill: 'yellow', ghost: 'yellow' }, { fill: 'yellow', x: true }, {}])
};
/* Dominoes rule pictures (SVG): tiles centred at (cx, cy); h = lying flat */
const vT = (a, b, cx, cy, extra = '') => `<g transform="translate(${cx - 10} ${cy - 20})"${extra}>${domSvgTile(a, b)}</g>`;
const hT = (a, b, cx, cy, extra = '') => `<g transform="translate(${cx - 10} ${cy - 20}) rotate(-90 10 20)"${extra}>${domSvgTile(a, b)}</g>`;
const domPic = (w, h, inner) => `<svg class="strip dstrip" viewBox="0 0 ${w} ${h}" aria-hidden="true">${inner}</svg>`;
const DOM_RULE_ART = {
  0: () => domPic(150, 46, `${vT(0, 0, 14, 23)}${vT(3, 5, 44, 23)}${vT(6, 6, 74, 23)}<text x="96" y="28" font-size="13" font-weight="800" fill="#F3D58A">3+5 = 8</text>`),
  2: () => domPic(150, 46, `<circle cx="75" cy="23" r="21" fill="rgba(230,184,76,.18)"/>${vT(6, 6, 75, 23)}`),
  3: () => domPic(150, 46, `${hT(2, 6, 22, 23)}${vT(6, 6, 52, 23)}${hT(6, 4, 82, 23)}${hT(4, 1, 124, 23, ' opacity=".5"')}<path d="M104 9v28" stroke="#F9DB8B" stroke-width="1.6" stroke-dasharray="3 3"/>`)
};
SCREENS.howto = {
  live: true,
  html: (p) => {
    p.tab = p.tab || 'ludo';
    const dom = p.tab === 'dom';
    const list = dom ? t('domRules') : t('rules'), art = dom ? DOM_RULE_ART : RULE_STRIPS;
    return `${hdr({ title: t('rulesTitle') })}<div class="scroll"><div class="wrap">
    <div class="seg" style="margin-bottom:16px">${['ludo', 'dom'].map(g => `<button class="${p.tab === g ? 'on' : ''}" data-act="rulesTab" data-v="${g}">${esc(t(g))}</button>`).join('')}</div>
    <p style="text-align:center;font-weight:800;font-size:17px;margin:0 6px 16px">${esc(t(dom ? 'domIntro' : 'rulesIntro'))}</p>
    ${list.map(([h, d], i) => `<div class="rule"><span class="rn">${fmtNum(i + 1)}</span><div style="flex:1;min-width:0"><b>${esc(h)}</b><p>${esc(d)}</p>${art[i] ? art[i]() : ''}</div></div>`).join('')}
    ${dom ? '' : `<div class="note info" style="display:flex;gap:12px;align-items:center"><svg width="44" height="44" viewBox="0 0 44 44" style="flex:none"><rect width="44" height="44" rx="10" fill="#FBF5E8"/>${rosette(22, 22, 16, '#1A160F', '#E6B44C')}</svg><span>${esc(t('urNote'))}</span></div>`}
  </div></div>`;
  }
};

/* ---------- Daily reward ---------- */
SCREENS.daily = {
  live: true,
  html: () => {
    const st = Progress.dailyState();
    return `${hdr({ title: t('dailyTitle') })}<div class="scroll"><div class="wrap">
      <p class="muted" style="text-align:center;margin:0 6px 10px">${esc(t('dailySub'))}</p>
      <div class="streak">🔥 ${esc(countText(st.streak, 'streakN'))}</div>
      <div class="cal">${DAILY_REWARDS.map((r, i) => { const done = st.can ? i < st.idx : i <= st.idx; const today = st.can && i === st.idx; return `<div class="day ${i === 6 ? 'big' : ''} ${done ? 'done' : ''} ${today ? 'today' : ''}"><small>${esc(t('dayN', { n: fmtNum(i + 1) }))}</small><b class="coinline">${i === 6 ? '🎁 ' : ''}${DINAR(20)}${fmtNum(r)}</b><small>${esc(t('cur'))}${i === 6 ? ' · ' + esc(t('xpPlus', { n: 50 })) : ''}</small></div>`; }).join('')}</div>
      ${st.can ? `<button class="btn gold block" data-act="claimDaily">${ic('gift')}${esc(t('claim'))} ${DINAR(22)}${esc(countText(st.reward, 'dinarPlus'))}</button>` : `<button class="btn ghost block" disabled>${esc(t('comeBack'))}</button>`}
      <p class="help" style="text-align:center;margin-top:14px">${esc(t('pointsNote'))}</p>
    </div></div>`;
  }
};

/* ---------- Challenges + badges ---------- */
SCREENS.challenges = {
  live: true,
  html: (p) => {
    p.tab = p.tab || 'ch';
    const c = Progress.challenges();
    const item = ch => `<div class="ch ${ch.ready ? 'ready' : ''} ${ch.claimed ? 'claimed' : ''}"><div class="chtop"><span style="flex:1"><b style="display:block">${esc(t('ch.' + ch.id))}</b><span class="chrew coinline">${DINAR(15)}${esc(t('rewardOf', { p: ch.p, x: ch.x }))}</span></span>
      ${ch.claimed ? `<span class="tag free">${ic('check', 's')}${esc(t('claimed'))}</span>` : ch.ready ? `<button class="btn sm gold" data-act="claimCh" data-id="${ch.id}">${esc(t('claim'))}</button>` : `<b style="flex:none;color:var(--muted)">${fmtNum(ch.n)}/${fmtNum(ch.goal)}</b>`}</div>
      <div class="prog"><i style="width:${Math.round(ch.n / ch.goal * 100)}%"></i></div></div>`;
    return `${hdr({ title: t('chTitle') })}<div class="scroll"><div class="wrap">
      <div class="seg"><button class="${p.tab === 'ch' ? 'on' : ''}" data-act="chTab" data-v="ch">${esc(t('chTitle'))}</button><button class="${p.tab === 'b' ? 'on' : ''}" data-act="chTab" data-v="b">${esc(t('badgesTab'))}</button></div>
      ${p.tab === 'b' ? `<div class="badges" style="margin-top:16px;grid-template-columns:repeat(3,1fr)">${Progress.badgeList().map(b => `<div class="badge ${b.got ? '' : 'off'}"><span class="be">${b.emoji}</span><small>${esc(t('badgeNames.' + b.id)[0])}</small><small class="dim" style="font-weight:600">${esc(t('badgeNames.' + b.id)[1])}</small></div>`).join('')}</div>`
        : `<div class="sec">${esc(t('dailyCh'))} <span class="dim" style="font-size:13px">· ${esc(t('renewDaily'))}</span></div>${c.daily.map(item).join('')}
           <div class="sec">${esc(t('weeklyCh'))} <span class="dim" style="font-size:13px">· ${esc(t('renewWeekly'))}</span></div>${c.weekly.map(item).join('')}`}
    </div></div>`;
  }
};

/* ---------- Style shop: every board is free; pictures and dice unlock with game dinars ---------- */
function boardThumb(id) { return Board.svg(id, 'th' + id).replace('class="board-svg"', 'class="thumb"'); }
SCREENS.shop = {
  live: true,
  html: (p) => {
    p.tab = p.tab || 'avatar';
    const kind = p.tab, items = Progress.catalog(kind), eq = kind === 'avatar' ? Accounts.user.avatar : Progress.data.equipped[kind];
    const preview = it => kind === 'avatar' ? `<span class="av xl ${isChar(it.id) ? 'drawn' : ''}" style="width:76px;height:76px;font-size:42px">${avatarArt(it.id)}</span>` : kind === 'dice' ? Board.diceHtml(it.id) : boardThumb(it.id);
    const name = it => kind === 'avatar' ? (isChar(it.id) ? esc(t('charNames.' + it.id)) : '') : esc(t((kind === 'dice' ? 'diceNames.' : 'boardNames.') + it.id));
    return `${hdr({ title: t('shopTitle'), right: ptsHtml() })}<div class="scroll"><div class="wrap">
      <p class="muted" style="text-align:center;margin:0 4px 14px">${esc(t('shopSub'))}</p>
      <div class="seg">${[['avatar', 'avatarsTab'], ['dice', 'diceTab'], ['board', 'boardsTab']].map(([k, l]) => `<button class="${p.tab === k ? 'on' : ''}" data-act="shopTab" data-v="${k}">${esc(t(l))}</button>`).join('')}</div>
      ${kind === 'board' ? `<div class="note" style="margin-top:14px">${esc(t('boardsFree'))}</div>` : ''}
      <button class="row" data-act="design" style="margin-top:14px"><span class="ri">${ic('palette')}</span><span class="rt">${esc(t('design'))}<small>${esc(t('designRowSub'))}</small></span>${ic('chev', 'fwd')}</button>
      <div class="shopgrid">${items.map(it => { const own = Progress.owns(kind, it.id), on = eq === it.id; return `<div class="item ${on ? 'on' : ''}"><div class="pv">${preview(it)}</div>${name(it) ? `<b>${name(it)}${kind === 'board' ? ` <span class="tag free">${esc(t('free'))}</span>` : ''}</b>` : ''}
        ${on ? `<button class="btn sm ghost" disabled>${ic('check', 's')}${esc(t('equipped'))}</button>` : own ? `<button class="btn sm outline" data-act="equip" data-k="${kind}" data-id="${it.id}">${esc(t('equip'))}</button>` : `<button class="btn sm gold" data-act="buy" data-k="${kind}" data-id="${it.id}">${DINAR(20)}${esc(t('unlockFor', { n: fmtNum(it.price) }))}</button>`}</div>`; }).join('')}</div>
      <p class="help" style="text-align:center;margin-top:16px">${esc(t('pointsNote'))}</p>
    </div></div>`;
  },
  init(el) { $$('.item .dice', el).forEach(d => Board.showFace(d, 5)); }
};


/* ---------- VIP plans: payment activation is intentionally gated until SWITCH merchant credentials/API are configured ---------- */
SCREENS.vip = {
  html: () => {
    const ar = S.lang !== 'en';
    const title = ar ? 'عضوية VIP' : 'VIP Membership';
    const intro = ar ? 'استمتع باللعب بدون إعلانات عند تفعيل اشتراكك.' : 'Enjoy an ad-free game when your subscription is activated.';
    const features = ar ? ['إزالة إعلانات AdMob', 'شارة VIP على حسابك', 'مزايا حصرية مستقبلية'] : ['Remove AdMob ads', 'VIP profile badge', 'Future exclusive benefits'];
    const pending = ar ? 'الدفع الإلكتروني غير مفعّل بعد' : 'Online payment is not enabled yet';
    const explain = ar ? 'نحتاج بيانات التاجر وواجهة API من بوابة SWITCH حتى نربط الدفع الحقيقي ونتحقق من الإيصال بأمان. لن يتم خصم أي مبلغ حالياً.' : 'We need your SWITCH merchant details and API documentation to securely connect real payments and verify receipts. No payment will be taken now.';
    return `${hdr({ title })}<div class="scroll"><div class="wrap">
      <div class="card" style="text-align:center;padding:22px 16px;margin-top:8px"><div style="font-size:42px">👑</div><h2 style="margin:8px 0 4px">${title}</h2><p class="muted" style="margin:0">${intro}</p></div>
      <div class="card" style="margin-top:14px">${features.map(x => `<div class="feat">${ic('check')}<span>${esc(x)}</span></div>`).join('')}</div>
      <div class="sec">${ar ? 'اختر الباقة' : 'Choose a plan'}</div>
      <div class="card" style="margin-bottom:10px"><b>${ar ? 'شهري' : 'Monthly'}</b><p class="muted" style="margin:4px 0 0">${ar ? 'لمدة شهر واحد' : 'One month'}</p><button class="btn gold block" disabled style="margin-top:12px">${pending}</button></div>
      <div class="card"><b>${ar ? 'سنوي' : 'Yearly'}</b><p class="muted" style="margin:4px 0 0">${ar ? 'لمدة 12 شهراً' : '12 months'}</p><button class="btn gold block" disabled style="margin-top:12px">${pending}</button></div>
      <div class="note info" style="margin:14px 0">${explain}</div>
    </div></div>`;
  }
};
