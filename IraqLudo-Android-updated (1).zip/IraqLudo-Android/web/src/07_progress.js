/* ============ Progress: XP, levels, titles, game dinars, badges, daily reward, challenges, style items ============
   Kept on the device per account (one record: the progress itself plus, under "_s", what the server last
   agreed to and any change that is still on its way). With a Firebase account it is also copied to
   players/{uid}/progress/main, so the app and the website show the same progress.
   Game dinars (stored as "points") are play money: +50 for a win, -50 for a loss, plus rewards. They are
   not real money, cannot be bought or cashed out, and only unlock looks (pictures, dice): never an advantage.
   Ludo statistics live in stats; dominoes statistics in stats.dom. */

/* Pictures: drawn Iraqi characters first (04c_avatars.js), then the emoji pictures of earlier versions.
   [id, emoji or null for a drawn character, price in game dinars] */
const AVATARS = [
  ['haji', null, 0], ['hajiya', null, 0], ['shab', null, 0], ['bint', null, 0], ['talib', null, 0], ['muallima', null, 0],
  ['falah', null, 80], ['chayji', null, 100], ['sayyad', null, 150], ['tabiba', null, 150], ['oudi', null, 200], ['riyadiya', null, 200],
  ['kabtin', null, 250], ['sheikh', null, 300],
  ['lion', '🦁', 0], ['camel', '🐪', 0], ['eagle', '🦅', 0], ['fish', '🐟', 0], ['palm', '🌴', 0], ['cool', '😎', 0],
  ['tea', '☕', 80], ['ball', '⚽', 100], ['dice', '🎲', 120], ['owl', '🦉', 150], ['jar', '🏺', 150], ['drum', '🥁', 150],
  ['horse', '🐎', 200], ['moon', '🌙', 200], ['peacock', '🦚', 250], ['crown', '👑', 300]
];
const DICE_SKINS = [['classic', 0], ['night', 200], ['turquoise', 250], ['rose', 250], ['violet', 250], ['gold', 300], ['marble', 300], ['palm', 350]];
const BOARD_SKINS = [['classic', 0], ['palm', 0], ['night', 0], ['babylon', 0], ['turquoise', 0], ['sunset', 0]];   // every board is free
const DEFAULT_AVATAR = 'haji';
/* The picture as markup: an SVG character or an emoji (never plain text: always put it inside an element) */
const avatarArt = id => (isChar(id) ? charSvg(id) : (AVATARS.find(a => a[0] === id && a[1]) || ['', charSvg(DEFAULT_AVATAR)])[1]);
const avatarEmoji = avatarArt;

const DAILY_REWARDS = [20, 30, 40, 50, 70, 90, 150];
const TITLE_LEVELS = [1, 3, 6, 10, 15, 20];
const CH_DAILY = [
  { id: 'win1', goal: 1, m: 'wins', p: 40, x: 20 }, { id: 'domWin1', goal: 1, m: 'domWins', p: 60, x: 30 }, { id: 'cap5', goal: 5, m: 'captures', p: 40, x: 20 },
  { id: 'home8', goal: 8, m: 'home', p: 40, x: 20 }, { id: 'six8', goal: 8, m: 'sixes', p: 30, x: 15 }, { id: 'play3', goal: 3, m: 'games', p: 50, x: 25 },
  { id: 'four1', goal: 1, m: 'games4', p: 40, x: 20 }, { id: 'domOut2', goal: 2, m: 'domOuts', p: 40, x: 20 }, { id: 'domPts50', goal: 50, m: 'domPts', p: 40, x: 20 }
];
const CH_WEEKLY = [
  { id: 'win5', goal: 5, m: 'wins', p: 150, x: 80 }, { id: 'cap25', goal: 25, m: 'captures', p: 150, x: 80 }, { id: 'domWin3', goal: 3, m: 'domWins', p: 200, x: 100 },
  { id: 'play10', goal: 10, m: 'games', p: 150, x: 80 }, { id: 'domPts300', goal: 300, m: 'domPts', p: 150, x: 80 }
];
const BADGES = [
  ['firstWin', '🥇', (s) => s.wins + s.dom.wins >= 1], ['hunter10', '🎯', (s) => s.captures >= 10], ['hunter50', '⚔️', (s) => s.captures >= 50],
  ['clean', '✨', (s, g) => g && g.game !== 'dom' && g.won && g.lost === 0], ['comeback', '🔥', (s, g) => g && g.game !== 'dom' && g.won && g.lost >= 4],
  ['six50', '🎲', (s) => s.sixes >= 50], ['games10', '☕', (s) => matchesPlayed(s) >= 10], ['games50', '🫖', (s) => matchesPlayed(s) >= 50],
  ['streak7', '📅', (s, g, P) => P.daily.streak >= 7], ['table4', '👑', (s) => s.p4.w >= 1], ['level10', '🏅', (s, g, P) => levelInfo(P.xp).level >= 10],
  ['domWin', DOMI(6, 6, 30), (s) => s.dom.wins >= 1], ['domOut10', '⚡', (s) => s.dom.outs >= 10], ['domBig', '💥', (s) => s.dom.best >= 30], ['domBlock', '🔒', (s) => s.dom.blockWins >= 1]
];

/* matches really played in both games (a give-up is not one) */
const matchesPlayed = s => s.games - s.forfeits + s.dom.games - s.dom.forfeits;

function levelInfo(xp) {
  let L = 1, need = 100, rest = Math.max(0, xp | 0);
  while (rest >= need && L < 99) { rest -= need; L++; need = 60 + 40 * L; }
  let ti = 0; TITLE_LEVELS.forEach((lv, i) => { if (L >= lv) ti = i; });
  return { level: L, into: rest, need, title: t('titles')[ti], titleIndex: ti };
}

const Progress = (() => {
  let P = null, key = null;
  let SY = { base: null, pend: null };   // base: the copy the server last agreed to · pend: { op, start } sent but not confirmed yet
  let savedOk = true, lastRaw = '';
  const pair = () => ({ g: 0, w: 0 });
  const blankDom = () => ({ games: 0, wins: 0, losses: 0, forfeits: 0, rounds: 0, roundsWon: 0, outs: 0, points: 0, best: 0, blockWins: 0,
    p2: pair(), p4: pair(), streak: 0, bestStreak: 0, timeSec: 0 });
  const blankStats = () => ({ games: 0, wins: 0, losses: 0, forfeits: 0, by: { easy: pair(), medium: pair(), hard: pair() },
    p2: pair(), p4: pair(), captures: 0, lost: 0, sixes: 0, home: 0, rolls: 0, streak: 0, bestStreak: 0, fastest: 0, timeSec: 0, dom: blankDom() });
  const fresh = () => ({ v: 1, xp: 0, points: 100, badges: {}, daily: { last: null, streak: 0 }, ch: { day: '', d: [], week: '', w: [] },
    owned: { avatar: AVATARS.filter(a => !a[2]).map(a => a[0]), dice: ['classic'], board: ['classic'] }, equipped: { dice: 'classic', board: 'classic' }, stats: blankStats() });

  /* fills in anything missing (older saves, or a copy from the server) */
  function normalize(x) {
    const f = fresh(), o = Object.assign(f, JSON.parse(JSON.stringify(x || {})));
    o.stats = Object.assign(blankStats(), o.stats || {});
    o.stats.by = Object.assign(blankStats().by, o.stats.by || {});      // older versions kept wins per computer level
    for (const lv of ['easy', 'medium', 'hard']) o.stats.by[lv] = Object.assign(pair(), o.stats.by[lv]);
    for (const p of ['p2', 'p4']) o.stats[p] = Object.assign(pair(), o.stats[p]);
    o.stats.dom = Object.assign(blankDom(), o.stats.dom || {});
    for (const p of ['p2', 'p4']) o.stats.dom[p] = Object.assign(pair(), o.stats.dom[p]);
    o.owned = Object.assign(fresh().owned, o.owned || {});
    o.equipped = Object.assign(fresh().equipped, o.equipped || {});
    o.daily = Object.assign({ last: null, streak: 0 }, o.daily || {});
    o.ch = Object.assign({ day: '', d: [], week: '', w: [] }, o.ch || {});
    o.badges = o.badges || {};
    delete o.updatedAt; delete o.ops; delete o._s;
    return o;
  }
  /* Take a stored record apart: the progress, and the sync state kept beside it */
  function adopt(raw) {
    const st = raw && raw._s;
    P = normalize(raw);
    SY = { base: st && st.base ? normalize(st.base) : null,
      pend: st && st.pend && st.pend.op && st.pend.start ? { op: String(st.pend.op), start: normalize(st.pend.start) } : null };
    if (!st && key !== 'prog:guest') {                    // saves made before 1.3.1 kept the server copy under its own key
      const old = store.get('progBase:' + key.slice(5), null);
      if (old) { SY.base = normalize(old); if (persist()) store.del('progBase:' + key.slice(5)); }
    }
  }
  /* One write holds the progress and the sync state, so they can never disagree after a sudden close */
  function persist() {
    const rec = SY.base || SY.pend ? Object.assign({}, P, { _s: SY }) : P;
    savedOk = store.set(key, rec);
    if (savedOk) lastRaw = JSON.stringify(rec);
    return savedOk;
  }
  function load(uid) {
    key = 'prog:' + (uid || 'guest');
    const raw = store.get(key, null);
    lastRaw = raw ? JSON.stringify(raw) : ''; savedOk = true;
    adopt(raw);
    freshChallenges();
    if (Accounts.cloud) setTimeout(() => sync(), 0);
    return P;
  }
  const save = () => { spins = 0; persist(); later(); };
  /* A guest who creates an account keeps their progress */
  function adoptGuest(uid) {
    const g = store.get('prog:guest', null);
    if (g && !store.get('prog:' + uid, null)) { store.set('prog:' + uid, g); store.del('prog:guest'); }
    for (const k of ['save:', 'dsave:']) {                       // matches in progress move with it
      const m = store.get(k + 'guest', null);
      if (m && !store.get(k + uid, null)) store.set(k + uid, m);
      store.del(k + 'guest');
    }
    load(uid);
  }

  /* ---------- challenges ---------- */
  function pick(pool, n, seed) {
    const arr = pool.slice(); let h = hashStr(seed);
    for (let i = arr.length - 1; i > 0; i--) { h = Math.imul(h ^ (h >>> 13), 1103515245) + 12345 >>> 0; const j = h % (i + 1); [arr[i], arr[j]] = [arr[j], arr[i]]; }
    return arr.slice(0, n).map(c => ({ id: c.id, n: 0, claimed: false }));
  }
  const defOf = id => CH_DAILY.concat(CH_WEEKLY).find(c => c.id === id);
  /* Keep only challenges this version knows (older versions had level-based ones), topped up the same way on every device */
  function tidy(list, pool, n, seed) {
    const ok = (list || []).filter(c => c && pool.some(d => d.id === c.id));
    if (ok.length >= n) return ok.slice(0, n);
    return ok.concat(pick(pool.filter(d => !ok.some(c => c.id === d.id)), n - ok.length, seed + ':more'));
  }
  function freshChallenges() {
    const d = dayKey(), w = weekKey();
    if (P.ch.day !== d) { P.ch.day = d; P.ch.d = pick(CH_DAILY, 3, d + key); }
    if (P.ch.week !== w) { P.ch.week = w; P.ch.w = pick(CH_WEEKLY, 2, w + key); }
    P.ch.d = tidy(P.ch.d, CH_DAILY, 3, d + key);
    P.ch.w = tidy(P.ch.w, CH_WEEKLY, 2, w + key);
  }
  function challenges() {
    freshChallenges();
    const map = arr => arr.map(c => { const d = defOf(c.id); return Object.assign({}, d, c, { n: Math.min(c.n, d.goal), ready: c.n >= d.goal && !c.claimed }); });
    return { daily: map(P.ch.d), weekly: map(P.ch.w) };
  }
  const readyCount = () => { const c = challenges(); return c.daily.concat(c.weekly).filter(x => x.ready).length; };
  function claimChallenge(id) {
    freshChallenges();
    const c = P.ch.d.concat(P.ch.w).find(x => x.id === id), d = defOf(id);
    if (!c || !d || c.claimed || c.n < d.goal) return null;
    c.claimed = true;
    const before = levelInfo(P.xp).level;
    P.points += d.p; P.xp += d.x;
    const levelUp = levelInfo(P.xp).level > before ? levelInfo(P.xp).level : 0;
    if (levelUp) P.points += 50;
    const badges = checkBadges(null);
    save();
    return { points: d.p + (levelUp ? 50 : 0), xp: d.x, levelUp, badges };
  }

  /* ---------- daily reward ---------- */
  function dailyState() {
    const today = dayKey(), y = new Date(); y.setDate(y.getDate() - 1);
    const last = P.daily.last, can = last !== today;
    const next = last === dayKey(y) ? P.daily.streak + 1 : 1;
    const streak = can ? next : P.daily.streak;
    const idx = ((streak - 1) % 7 + 7) % 7;
    return { can, streak: can ? (last === dayKey(y) ? P.daily.streak : 0) : P.daily.streak, idx, reward: DAILY_REWARDS[idx] };
  }
  function claimDaily() {
    const st = dailyState(); if (!st.can) return null;
    const y = new Date(); y.setDate(y.getDate() - 1);
    const streak = P.daily.last === dayKey(y) ? P.daily.streak + 1 : 1;
    P.daily = { last: dayKey(), streak };
    const reward = DAILY_REWARDS[(streak - 1) % 7];
    P.points += reward;
    const lvBefore = levelInfo(P.xp).level;
    let xp = 0; if ((streak - 1) % 7 === 6) { xp = 50; P.xp += xp; }
    const lvAfter = levelInfo(P.xp).level, bonus = 50 * (lvAfter - lvBefore);
    P.points += bonus;
    const badges = checkBadges(null);
    save();
    return { reward, xp, streak, badges, bonus, levelUp: lvAfter > lvBefore ? lvAfter : 0 };
  }

  /* ---------- badges ---------- */
  function checkBadges(game) {
    const got = [];
    for (const [id, , test] of BADGES) if (!P.badges[id] && test(P.stats, game, P)) { P.badges[id] = Date.now(); got.push(id); }
    return got;
  }

  /* ---------- results ---------- */
  const STAKE = 50;                 // dinars won for a win, and lost for a loss or a give-up (never below zero)
  function recordGame(g) {
    // Ludo:     { game: 'ludo', players, won, forfeit, captures, lost, sixes, home, rolls, turns, durationSec }
    // dominoes: { game: 'dom', players, won, forfeit, rounds, roundsWon, outs, points, best, blockWins, durationSec }
    const dom = g.game === 'dom', s = dom ? P.stats.dom : P.stats, before = levelInfo(P.xp), side = g.players === 4 ? s.p4 : s.p2;
    s.games++; side.g++;
    if (g.won) { s.wins++; side.w++; s.streak++; s.bestStreak = Math.max(s.bestStreak, s.streak); if (!dom && (!s.fastest || g.turns < s.fastest)) s.fastest = g.turns; }
    else { s.losses++; s.streak = 0; if (g.forfeit) s.forfeits++; }
    s.timeSec += g.durationSec || 0;
    if (dom) { s.rounds += g.rounds; s.roundsWon += g.roundsWon; s.outs += g.outs; s.points += g.points; s.best = Math.max(s.best, g.best); s.blockWins += g.blockWins; }
    else { s.captures += g.captures; s.lost += g.lost; s.sixes += g.sixes; s.home += g.home; s.rolls += g.rolls; }

    let xp = 0, coins = 0;
    if (g.won) { xp = 45 + (g.players === 4 ? 15 : 0); coins = STAKE; }
    else { if (!g.forfeit) xp = 12; coins = -Math.min(STAKE, Math.max(0, P.points)); }
    if (!g.forfeit) xp += Math.min(12, dom ? g.roundsWon * 3 : g.captures * 2);
    P.xp += xp; P.points += coins;
    const after = levelInfo(P.xp);
    let bonus = 0; if (after.level > before.level) { bonus = 50 * (after.level - before.level); P.points += bonus; }

    // challenges (giving up does not count as a played match)
    freshChallenges();
    const delta = { wins: g.won ? 1 : 0, games: g.forfeit ? 0 : 1, games4: !g.forfeit && g.players === 4 ? 1 : 0,
      captures: dom ? 0 : g.captures, home: dom ? 0 : g.home, sixes: dom ? 0 : g.sixes,
      domWins: dom && g.won ? 1 : 0, domOuts: dom ? g.outs : 0, domPts: dom ? g.points : 0 };
    const done = [];
    P.ch.d.concat(P.ch.w).forEach(c => { const d = defOf(c.id); if (!d) return; const was = c.n >= d.goal; c.n = Math.min(d.goal, c.n + (delta[d.m] || 0)); if (!was && c.n >= d.goal) done.push(c.id); });
    const badges = checkBadges(g);
    save();
    return { xp, coins, bonus, points: coins + bonus, levelBefore: before.level, levelAfter: after.level, titleUp: after.titleIndex > before.titleIndex ? after.title : '', badges, challengesDone: done };
  }

  /* ---------- style items ---------- */
  const catalog = kind => kind === 'avatar' ? AVATARS.map(a => ({ id: a[0], emoji: a[1], price: a[2], drawn: !a[1] })) : (kind === 'dice' ? DICE_SKINS : BOARD_SKINS).map(a => ({ id: a[0], price: a[1] }));
  const owns = (kind, id) => P.owned[kind].includes(id) || (catalog(kind).find(i => i.id === id) || {}).price === 0;
  function buy(kind, id) {
    const item = catalog(kind).find(i => i.id === id); if (!item) return 'missing';
    if (owns(kind, id)) return 'owned';
    if (P.points < item.price) return 'poor';
    P.points -= item.price; P.owned[kind].push(id); save();
    return 'ok';
  }
  function equip(kind, id) {
    if (!owns(kind, id)) return false;
    if (kind === 'avatar') Accounts.saveProfile({ avatar: id });
    else { P.equipped[kind] = id; save(); }
    return true;
  }

  /* ---------- cloud copy: the same progress on the phone and on the website ----------
     Each device keeps the last copy it agreed with the server ("base"). A sync adds what this device changed
     since then to the server copy, inside one transaction. So matches played on two devices both count, even
     if one of them was offline for a while.
     Every sync that carries a change has an id. The id and the snapshot it sends are saved on the device before
     sending, and the server copy remembers the last id of each device ("ops"). If the answer is lost, or the app
     is closed in the middle, the same change is sent again with the same id and the server counts it once. */
  const SUMS = ['games', 'wins', 'losses', 'forfeits', 'captures', 'lost', 'sixes', 'home', 'rolls', 'timeSec'];
  const DSUMS = ['games', 'wins', 'losses', 'forfeits', 'rounds', 'roundsWon', 'outs', 'points', 'blockWins', 'timeSec'];
  function merge3(L, B, R) {
    const add = (l, b, r) => Math.max(0, Math.round((+r || 0) + (+l || 0) - (+b || 0)));
    const m = JSON.parse(JSON.stringify(R));
    m.xp = add(L.xp, B.xp, R.xp);
    m.points = add(L.points, B.points, R.points);
    const ls = L.stats, bs = B.stats, rs = R.stats, ms = m.stats;
    SUMS.forEach(k => { ms[k] = add(ls[k], bs[k], rs[k]); });
    ['easy', 'medium', 'hard'].forEach(lv => ['g', 'w'].forEach(f => { ms.by[lv][f] = add(ls.by[lv][f], bs.by[lv][f], rs.by[lv][f]); }));
    ['p2', 'p4'].forEach(p => ['g', 'w'].forEach(f => { ms[p][f] = add(ls[p][f], bs[p][f], rs[p][f]); }));
    ms.streak = ls.streak !== bs.streak ? ls.streak : rs.streak;
    ms.bestStreak = Math.max(ls.bestStreak, rs.bestStreak, ms.streak);
    const ld = ls.dom, bd = bs.dom, rd = rs.dom, md = ms.dom;
    DSUMS.forEach(k => { md[k] = add(ld[k], bd[k], rd[k]); });
    ['p2', 'p4'].forEach(p => ['g', 'w'].forEach(f => { md[p][f] = add(ld[p][f], bd[p][f], rd[p][f]); }));
    md.streak = ld.streak !== bd.streak ? ld.streak : rd.streak;
    md.bestStreak = Math.max(ld.bestStreak, rd.bestStreak, md.streak);
    md.best = Math.max(ld.best, rd.best);
    const fast = [ls.fastest, rs.fastest].filter(x => x > 0); ms.fastest = fast.length ? Math.min(...fast) : 0;
    for (const id in L.badges) m.badges[id] = m.badges[id] ? Math.min(m.badges[id], L.badges[id]) : L.badges[id];
    for (const k of ['avatar', 'dice', 'board']) m.owned[k] = [...new Set([...(R.owned[k] || []), ...(L.owned[k] || [])])];
    for (const k of ['dice', 'board']) if (L.equipped[k] !== B.equipped[k]) m.equipped[k] = L.equipped[k];
    if ((L.daily.last || '') > (R.daily.last || '')) m.daily = L.daily;
    // challenges of the same day/week: the further progress and "claimed" win; ids this version does not know are dropped
    const known = (arr, pool) => (arr || []).filter(c => c && pool.some(d => d.id === c.id));
    const item = c => ({ id: c.id, n: Math.max(0, c.n | 0), claimed: !!c.claimed });
    const list = (a, b, pool) => {
      const A = known(a, pool), out = known(b, pool).map(x => { const y = A.find(z => z.id === x.id); return y ? { id: x.id, n: Math.max(x.n | 0, y.n | 0), claimed: !!(x.claimed || y.claimed) } : item(x); });
      A.forEach(y => { if (!out.some(z => z.id === y.id)) out.push(item(y)); });
      return out;
    };
    if (L.ch.day > R.ch.day) { m.ch.day = L.ch.day; m.ch.d = known(L.ch.d, CH_DAILY).map(item); } else if (L.ch.day === R.ch.day) m.ch.d = list(L.ch.d, R.ch.d, CH_DAILY);
    if (L.ch.week > R.ch.week) { m.ch.week = L.ch.week; m.ch.w = known(L.ch.w, CH_WEEKLY).map(item); } else if (L.ch.week === R.ch.week) m.ch.w = list(L.ch.w, R.ch.w, CH_WEEKLY);
    return m;
  }
  /* Text of a value with its keys in a fixed order: the server returns map keys sorted, the device keeps them
     as written, and the two must still compare as equal */
  const canon = v => (Array.isArray(v) ? '[' + v.map(canon).join(',') + ']'
    : v && typeof v === 'object' ? '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + canon(v[k])).join(',') + '}' : JSON.stringify(v === undefined ? null : v));
  const same = (a, b) => canon(a) === canon(b);
  const copy = o => JSON.parse(JSON.stringify(o));
  const VER = 1;                                             // the newest shape of the server copy this version understands
  const CLOUD_KEYS = ['v', 'xp', 'points', 'badges', 'daily', 'ch', 'owned', 'equipped', 'stats'];
  const DEV = (() => { let d = store.get('dev', null); if (!d) { d = Date.now().toString(36) + randInt(1e9).toString(36); store.set('dev', d); } return String(d).slice(0, 24); })();
  const newOp = () => Date.now().toString(36) + '-' + randInt(1e9).toString(36);
  /* What is sent: only the fields the server accepts, plus the last sync id of each device (the 20 most recent) */
  function cloudCopy(o, ops) {
    const c = {}; CLOUD_KEYS.forEach(k => { c[k] = o[k]; });
    const when = id => parseInt(String(id).split('-')[0], 36) || 0;
    c.ops = {}; Object.keys(ops).sort((a, b) => when(ops[b]) - when(ops[a])).slice(0, 20).forEach(d => { c.ops[d] = String(ops[d]).slice(0, 40); });
    c.updatedAt = Date.now();
    return c;
  }
  let timer = 0, running = null, again = false, spins = 0;
  function later(ms = 1500) { if (!Accounts.cloud) return; clearTimeout(timer); timer = setTimeout(() => sync(), ms); }
  /* Two tabs of the website share one account: only one of them talks to the server at a time */
  async function oneAtATime(fn) {
    const locks = typeof navigator !== 'undefined' && navigator.locks;
    if (locks && locks.request) { try { return await locks.request('ludo-sync', fn); } catch (e) { /* locks not allowed here: fn never ran */ } }
    return fn();
  }
  function sync() {
    if (!Accounts.cloud || !P) return Promise.resolve(false);
    if (running) { again = true; return running; }
    running = oneAtATime(syncOnce).then(r => r, () => false).then(r => {
      running = null;
      if (again && spins < 4) { again = false; spins++; later(400); } else again = false;
      return r;
    });
    return running;
  }
  async function syncOnce() {
    const myKey = key;
    try {
      // another tab may have saved since this one last looked
      if (savedOk) { const raw = store.get(myKey, null); if (raw && JSON.stringify(raw) !== lastRaw) { lastRaw = JSON.stringify(raw); adopt(raw); freshChallenges(); } }
      const base = SY.base || normalize(null);
      let pend = SY.pend;
      if (!pend && !same(P, base)) { pend = SY.pend = { op: newOp(), start: copy(P) }; persist(); }   // saved before it is sent
      let newer = false;
      const server = await Accounts.syncProgress(remote => {
        newer = !!remote && (remote.v | 0) > VER;
        if (!pend || newer) return { data: remote, write: false };                    // nothing new here (or a newer app wrote it): only read
        const ops = (remote && remote.ops) || {};
        if (remote && ops[DEV] === pend.op) return { data: remote, write: false };    // this change is already counted
        const merged = remote ? merge3(pend.start, base, normalize(remote)) : normalize(pend.start);
        return { data: cloudCopy(merged, Object.assign({}, ops, { [DEV]: pend.op })), write: true };
      });
      if (key !== myKey) return false;       // signed out or switched account meanwhile; the saved id finishes this later
      if (newer || !server) return !newer;   // (no server copy yet and nothing to send)
      const agreed = normalize(server), before = canon(P);
      P = merge3(P, pend ? pend.start : base, agreed);                                // keep anything changed while we were syncing
      SY = { base: agreed, pend: null };
      persist();
      if (!same(P, agreed)) again = true;
      if (canon(P) !== before && Progress.onSync) Progress.onSync();
      return true;
    } catch (e) {
      if (!/unavailable|offline|network|failed-precondition|deadline/i.test(String(e && (e.code || e.message)))) logErr('sync', e && (e.code || e.message));
      return false;                                              // tried again when back online or on the next change
    }
  }
  if (typeof window !== 'undefined') {
    window.addEventListener('online', () => later(200));
    document.addEventListener('visibilitychange', () => { if (!document.hidden) later(300); });
    // the same account open in another tab: take its saves as they happen
    window.addEventListener('storage', e => {
      if (!key || e.key !== 'ludo:' + key || !e.newValue || e.newValue === lastRaw) return;
      try { lastRaw = e.newValue; adopt(JSON.parse(e.newValue)); if (Progress.onSync) Progress.onSync(); } catch (x) {}
    });
  }

  return {
    STAKE, load, adoptGuest, save, sync, onSync: null, get data() { return P; }, level: () => levelInfo(P.xp), recordGame, dailyState, claimDaily,
    challenges, claimChallenge, readyCount, catalog, owns, buy, equip, badgeList: () => BADGES.map(([id, emoji]) => ({ id, emoji, got: !!P.badges[id] })), avatarOwned: id => owns('avatar', id)
  };
})();
