/* ============ Utilities ============ */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const NATIVE = window.AndroidApp || null;
if (NATIVE) document.documentElement.classList.add('native');
const SYS_RM = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
let RM = SYS_RM;                                   // nothing moves (the player's motion setting, see applyLook)
const EASE = 'cubic-bezier(.22,.8,.24,1)';
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const digitsAr = s => String(s ?? '').replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
const pad2 = n => String(n).padStart(2, '0');
const dayKey = (d = new Date()) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const weekKey = (d = new Date()) => { const x = new Date(d); x.setHours(0, 0, 0, 0); x.setDate(x.getDate() - ((x.getDay() + 1) % 7)); return dayKey(x); }; // weeks start on Saturday
const hashStr = s => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
const randInt = (n) => { try { const a = new Uint32Array(1); crypto.getRandomValues(a); return a[0] % n; } catch (e) { return Math.floor(Math.random() * n); } };
const fmtNum = n => Number(n || 0).toLocaleString('en-US');   // Western digits everywhere, as in usernames, codes and XP

/* localStorage wrapper: never throws (private mode, quota, blocked storage) */
const store = {
  get(k, d) { try { const v = localStorage.getItem('ludo:' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('ludo:' + k, JSON.stringify(v)); return true; } catch (e) { return false; } },
  del(k) { try { localStorage.removeItem('ludo:' + k); } catch (e) {} }
};

/* ============ App state ============ */
const S = {
  lang: store.get('lang', null) || 'ar',
  langChosen: !!store.get('lang', null),
  prefs: Object.assign({ sound: true, music: true, vibrate: true, autoMove: true, speed: 'normal', theme: 'gold', bg: 'bricks', tiles: 'board', tok: 'classic', motion: '' }, store.get('prefs', {})),
  sloganI: randInt(7)
};
const savePrefs = () => store.set('prefs', S.prefs);
const RTL = () => S.lang === 'ar';
function t(k, vars) {
  let v = k.split('.').reduce((o, p) => (o != null ? o[p] : undefined), T[S.lang]);
  if (v === undefined) v = k.split('.').reduce((o, p) => (o != null ? o[p] : undefined), T.ar);
  if (v === undefined) return k;
  if (typeof v === 'string' && vars) for (const x in vars) v = v.split('{' + x + '}').join(vars[x]);
  return v;
}
/* Counted nouns. i18n value = [one, two, few, many]; Arabic: 1, 2, 3–10, then 0 and 11+ */
function countText(n, key) {
  const f = t(key); n = Math.max(0, Math.round(n || 0));
  if (!Array.isArray(f)) return String(f).split('{n}').join(fmtNum(n));
  const m = n % 100;
  const i = S.lang === 'ar' ? (n === 1 ? 0 : n === 2 ? 1 : (m >= 3 && m <= 10) ? 2 : 3) : (n === 1 ? 0 : 3);
  return f[i].split('{n}').join(fmtNum(n));
}

/* ============ Error log: in-app ring buffer + Logcat through the bridge ============ */
const LOG = [];
function logErr(kind, msg) {
  const line = `${new Date().toISOString()} ${kind}: ${String(msg).slice(0, 400)}`;
  LOG.push(line); if (LOG.length > 60) LOG.shift();
  try { if (NATIVE && NATIVE.log) NATIVE.log('E', line); } catch (e) {}
  try { console.warn(line); } catch (e) {}
}
window.addEventListener('error', e => logErr('error', (e.message || '') + ' @' + (e.filename || '').split('/').pop() + ':' + (e.lineno || '')));
window.addEventListener('unhandledrejection', e => logErr('promise', e.reason && (e.reason.stack || e.reason.message || e.reason.code) || e.reason));

/* ============ Haptics ============ */
let wakeLock = null, wantAwake = false;
async function keepAwake(on) {
  wantAwake = on;
  try {
    if (NATIVE && NATIVE.keepAwake) { NATIVE.keepAwake(on); return; }
    if (!('wakeLock' in navigator)) return;
    if (on && !wakeLock && !document.hidden) { wakeLock = await navigator.wakeLock.request('screen'); wakeLock.addEventListener('release', () => { wakeLock = null; }); }
    else if (!on && wakeLock) { const w = wakeLock; wakeLock = null; await w.release(); }
  } catch (e) { wakeLock = null; }
}
document.addEventListener('visibilitychange', () => { if (!document.hidden && wantAwake && !NATIVE) keepAwake(true); });
const IS_SITE = !!window.LUDO_SITE;           // the website edition (not the app, not the preview)

function haptic(kind = 'tap') {
  if (!S.prefs.vibrate) return;
  try {
    if (NATIVE && NATIVE.haptic) { NATIVE.haptic(kind); return; }
    if (navigator.vibrate) navigator.vibrate(kind === 'heavy' ? 40 : kind === 'success' ? [20, 40, 30] : 12);
  } catch (e) {}
}

/* ============ Icons (stroke icons, 24 grid) ============ */
const IP = {
  back: 'M15 5l-7 7 7 7', close: 'M6 6l12 12M18 6L6 18', gear: 'M12 9a3 3 0 1 1 0 6 3 3 0 0 1 0-6zM19.4 13a7.6 7.6 0 0 0 0-2l2-1.6-2-3.4-2.4 1a7.4 7.4 0 0 0-1.7-1L15 3.5h-4L10.7 6a7.4 7.4 0 0 0-1.7 1l-2.4-1-2 3.4L6.6 11a7.6 7.6 0 0 0 0 2l-2 1.6 2 3.4 2.4-1a7.4 7.4 0 0 0 1.7 1l.3 2.5h4l.3-2.5a7.4 7.4 0 0 0 1.7-1l2.4 1 2-3.4z',
  user: 'M12 4a4 4 0 1 1 0 8 4 4 0 0 1 0-8zM4.5 20c1.4-3.6 4.2-5.5 7.5-5.5s6.1 1.9 7.5 5.5', users: 'M9 5a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7zM2.5 19.5c1-3.2 3.4-5 6.5-5s5.5 1.8 6.5 5M16 5.2a3.2 3.2 0 0 1 0 6.3M18 14.6c1.8.7 3 2.3 3.5 4.9',
  gift: 'M4 11h16v9H4zM3 7.5h18V11H3zM12 7.5V20M12 7.5S10.8 3.5 8.3 3.6C6.6 3.7 6.5 6.4 8.7 7.2M12 7.5s1.2-4 3.7-3.9c1.7.1 1.8 2.8-.4 3.6',
  trophy: 'M8 4h8v5a4 4 0 0 1-8 0zM8 6H5c0 3 1.3 4.6 3.4 4.9M16 6h3c0 3-1.3 4.6-3.4 4.9M12 13v4M8.5 20h7M10 17h4v3h-4z',
  book: 'M5 4.5h9.5A2.5 2.5 0 0 1 17 7v12.5H7.5A2.5 2.5 0 0 1 5 17zM5 17a2.5 2.5 0 0 1 2.5-2.5H17M20 7v13.5', palette: 'M12 3.5a8.5 8.5 0 1 0 0 17c1.4 0 1.9-.9 1.6-2-.3-1.3.5-2.3 1.8-2.3h1.6A3.5 3.5 0 0 0 20.5 12 8.5 8.5 0 0 0 12 3.5zM7.6 12.2h.01M9.6 8h.01M14.4 8h.01M16.6 11.5h.01',
  lock: 'M6.5 11h11a1 1 0 0 1 1 1v7.5a1 1 0 0 1-1 1h-11a1 1 0 0 1-1-1V12a1 1 0 0 1 1-1zM8.5 11V8a3.5 3.5 0 0 1 7 0v3', check: 'M5 12.5l4.3 4.3L19 7', chev: 'M9 6l6 6-6 6', menu: 'M4 7h16M4 12h16M4 17h16',
  sound: 'M4 9.5h3.5L12 5.5v13l-4.5-4H4zM16 9a4 4 0 0 1 0 6M18.5 6.5a7.5 7.5 0 0 1 0 11', mute: 'M4 9.5h3.5L12 5.5v13l-4.5-4H4zM16.5 9.5l5 5M21.5 9.5l-5 5', music: 'M9 17.5V6l10-2.5v11.5M9 17.5a2.5 2.5 0 1 1-2.5-2.5 2.5 2.5 0 0 1 2.5 2.5zM19 15a2.5 2.5 0 1 1-2.5-2.5A2.5 2.5 0 0 1 19 15z',
  eye: 'M2.5 12s3.5-6.5 9.5-6.5S21.5 12 21.5 12s-3.5 6.5-9.5 6.5S2.5 12 2.5 12zM12 9.3a2.7 2.7 0 1 1 0 5.4 2.7 2.7 0 0 1 0-5.4z', eyeOff: 'M3 3l18 18M10.6 5.6A9.6 9.6 0 0 1 12 5.5c6 0 9.5 6.5 9.5 6.5a17 17 0 0 1-3 3.7M6.3 6.8C3.9 8.4 2.5 12 2.5 12S6 18.5 12 18.5a9 9 0 0 0 4.2-1M9.9 9.9a3 3 0 0 0 4.2 4.2',
  smile: 'M12 3.5a8.5 8.5 0 1 1 0 17 8.5 8.5 0 0 1 0-17zM8.5 14s1.2 2 3.5 2 3.5-2 3.5-2M9 9.5h.01M15 9.5h.01', star: 'M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.8-5.2 2.8 1-5.8-4.3-4.1 5.9-.9z',
  share: 'M16 6.5l-8 4M8 13.5l8 4M18 5a2 2 0 1 1-4 0 2 2 0 0 1 4 0zM8 12a2 2 0 1 1-4 0 2 2 0 0 1 4 0zM18 19a2 2 0 1 1-4 0 2 2 0 0 1 4 0z', copy: 'M8.5 8.5h11v11h-11zM5 15.5V4.5h11',
  chart: 'M4 20V11M10 20V5M16 20v-6M21 20H3', flag: 'M5 21V4M5 4.5h11l-2 4 2 4H5', home: 'M3.5 11L12 4l8.5 7M6 9.6V20h12V9.6', refresh: 'M19.5 12a7.5 7.5 0 1 1-2.2-5.3M19.5 4.5v4h-4',
  logout: 'M10 4.5H5.5v15H10M15 8l4 4-4 4M19 12H9', trash: 'M4.5 7h15M9.5 7V4.5h5V7M6.5 7l1 13h9l1-13', key: 'M8 11.5a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7zM10.5 12.5l8.5-8.5M16.5 6.5l2.5 2.5M14 9l2 2',
  info: 'M12 3.5a8.5 8.5 0 1 1 0 17 8.5 8.5 0 0 1 0-17zM12 11v5.5M12 7.8v.4', shield: 'M12 3.5l7.5 3v5.5c0 4.6-3.2 7.6-7.5 8.5-4.3-.9-7.5-3.9-7.5-8.5V6.5z', globe: 'M12 3.5a8.5 8.5 0 1 1 0 17 8.5 8.5 0 0 1 0-17zM3.5 12h17M12 3.5c2.8 2.6 2.8 14.4 0 17M12 3.5c-2.8 2.6-2.8 14.4 0 17',
  bolt: 'M13 3L5 13.5h6L10 21l8-10.5h-6z', robot: 'M7 9h10a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-6a2 2 0 0 1 2-2zM12 9V5.5M12 5.5h.01M9.5 13.5h.01M14.5 13.5h.01M3 13v2M21 13v2', vibrate: 'M8.5 3.5h7v17h-7zM4.5 8v8M19.5 8v8',
  pencil: 'M4 20l1-4L16 5l3 3L8 19zM14 7l3 3',
  dice: 'M5.5 4.5h13a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-13a1 1 0 0 1-1-1v-13a1 1 0 0 1 1-1zM8.5 8.5h.01M15.5 8.5h.01M12 12h.01M8.5 15.5h.01M15.5 15.5h.01'
};
const ic = (name, cls = '') => `<svg class="ic ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${IP[name] || ''}"/></svg>`;

/* Brand mark: a dice face whose five pips sit on an Ur-style rosette disc */
const MARK = (size = 64) => `<svg class="mark" width="${size}" height="${size}" viewBox="0 0 64 64" aria-hidden="true">
  <defs><linearGradient id="mkg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" style="stop-color:var(--gold-hi)"/><stop offset="1" style="stop-color:var(--gold-lo)"/></linearGradient></defs>
  <rect x="6" y="6" width="52" height="52" rx="14" fill="url(#mkg)"/>
  <rect x="9" y="9" width="46" height="46" rx="11" fill="none" stroke="#FFFFFF" stroke-opacity=".45" stroke-width="2"/>
  ${[[20, 20], [44, 20], [32, 32], [20, 44], [44, 44]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="5.2" style="fill:var(--gold-ink)"/>`).join('')}
</svg>`;

/* Game money: a small Iraqi-dinar banknote (gold, framed, palm and watermark). Play money only. */
const DINAR = (s = 18, cls = '') => `<svg class="dinar ${cls}" width="${s}" height="${s}" viewBox="0 0 24 24" aria-hidden="true">
  <rect x="3.2" y="4.4" width="19" height="12.4" rx="2" transform="rotate(-10 12.7 10.6)" fill="#7A5A18"/>
  <rect x="1.4" y="6.6" width="21.2" height="12.6" rx="2.1" fill="#E0B95A"/>
  <rect x="1.4" y="6.6" width="21.2" height="4.6" rx="2.1" fill="#F6DE97" opacity=".6"/>
  <rect x="3.1" y="8.3" width="17.8" height="9.2" rx="1.3" fill="none" stroke="#86621A" stroke-width=".9"/>
  <circle cx="16.4" cy="12.9" r="2.5" fill="#F7E7B0" stroke="#86621A" stroke-width=".75"/>
  <g fill="none" stroke="#5E430D" stroke-linecap="round" stroke-width=".95"><path d="M7.6 16.4c-.2-1.5-.1-3 .3-4.3"/>
  <path d="M7.9 12.1c-.9-.9-2.2-1-3.1-.4M7.9 12.1c.9-.9 2.2-1 3.1-.4M7.9 12c-.6-1.1-1.6-1.6-2.6-1.5M7.9 12c.6-1.1 1.6-1.6 2.6-1.5"/></g>
</svg>`;

/* A domino tile drawn in SVG (20 × 40 units, top half a, bottom half b) for icons, art and the rules */
const DOT_AT = { 0: [], 1: [5], 2: [3, 7], 3: [3, 5, 7], 4: [1, 3, 7, 9], 5: [1, 3, 5, 7, 9], 6: [1, 3, 4, 6, 7, 9] };
function domSvgTile(a, b, o = {}) {
  const face = o.face || '#FBF5E8', pip = o.pip || '#17130C';
  let s = `<rect x=".6" y=".6" width="18.8" height="38.8" rx="3.6" fill="${o.edge || '#B3A27C'}"/><rect x=".6" y=".6" width="18.8" height="37.6" rx="3.6" fill="${face}"/>
    <path d="M4 19.6h12" stroke="${o.line || '#A08F6B'}" stroke-width="1"/><circle cx="10" cy="19.6" r="1.5" fill="#C99130"/>`;
  [[a, 0], [b, 19.2]].forEach(([v, oy]) => DOT_AT[v].forEach(p => { const r = Math.ceil(p / 3), c = (p - 1) % 3 + 1; s += `<circle cx="${c * 5}" cy="${(oy + r * 4.9).toFixed(1)}" r="1.85" fill="${pip}"/>`; }));
  return s;
}
/* One tile as a standalone icon */
const DOMI = (a, b, size = 26, o = {}) => `<svg class="domi" width="${size / 2}" height="${size}" viewBox="0 0 20 40" aria-hidden="true">${domSvgTile(a, b, o)}</svg>`;

/* Ur rosette (eight petals) used on safe squares and as an ornament */
function rosette(cx, cy, r, fill, centre) {
  let p = '';
  for (let i = 0; i < 8; i++) {
    const a = i * Math.PI / 4;
    const x = cx + Math.cos(a) * r * .52, y = cy + Math.sin(a) * r * .52;
    p += `<ellipse cx="${x.toFixed(3)}" cy="${y.toFixed(3)}" rx="${(r * .44).toFixed(3)}" ry="${(r * .2).toFixed(3)}" transform="rotate(${i * 45} ${x.toFixed(3)} ${y.toFixed(3)})" fill="${fill}"/>`;
  }
  return p + `<circle cx="${cx}" cy="${cy}" r="${(r * .22).toFixed(3)}" fill="${centre || fill}"/>`;
}

/* ============ Router (same engine as Aqarchi: stacked screens with transitions) ============ */
const SCREENS = {};
const stack = [];
let busy = false;
const screensEl = () => $('#screens');
function mount(name, params) {
  const def = SCREENS[name];
  const el = document.createElement('section');
  el.className = 'screen ' + (def.cls || '');
  el.dataset.screen = name;
  el.innerHTML = def.html(params);
  screensEl().appendChild(el);
  if (def.init) def.init(el, params);
  return el;
}
function anims(kind, top, under, reverse, params) {
  if (RM) kind = 'fade';
  if (kind === 'grow' && !(FX() && params && params._grow)) kind = 'push';
  const out = [], rtl = RTL();
  const A = (el, kf, d = 300, easing = EASE) => { if (el) out.push(el.animate(reverse ? [...kf].reverse() : kf, { duration: d, easing, fill: 'both' })); };
  const x = rtl ? '-100%' : '100%', xu = rtl ? '22%' : '-22%';
  switch (kind) {
    case 'push':
      A(top, [{ transform: `translate3d(${x},0,0)` }, { transform: 'translate3d(0,0,0)' }], 320);
      A(under, [{ transform: 'translate3d(0,0,0)', opacity: 1 }, { transform: `translate3d(${xu},0,0)`, opacity: .5 }], 320);
      break;
    case 'rise':
      A(top, [{ transform: 'translate3d(0,100%,0)' }, { transform: 'translate3d(0,0,0)' }], 360);
      A(under, [{ opacity: 1, transform: 'scale(1)' }, { opacity: .55, transform: 'scale(.96)' }], 360);
      break;
    case 'grow': {
      // the tapped card opens up into the new screen (its gold fades into the screen's own colours)
      const g = params._grow, box = screensEl().getBoundingClientRect();
      const ins = `inset(${Math.max(0, g.top - box.top).toFixed(0)}px ${Math.max(0, box.right - g.right).toFixed(0)}px ${Math.max(0, box.bottom - g.bottom).toFixed(0)}px ${Math.max(0, g.left - box.left).toFixed(0)}px round 24px)`;
      A(top, [{ clipPath: ins }, { clipPath: 'inset(0px 0px 0px 0px round 0px)' }], 520, 'cubic-bezier(.35,.75,.25,1)');
      A(under, [{ transform: 'scale(1)', opacity: 1 }, { transform: 'scale(.96)', opacity: 0 }], 320);
      const f = document.createElement('div'); f.className = 'growfx'; top.appendChild(f);
      const fa = f.animate(reverse ? [{ opacity: 0, offset: 0 }, { opacity: 1, offset: .55 }, { opacity: 1, offset: 1 }] : [{ opacity: 1, offset: 0 }, { opacity: 1, offset: .45 }, { opacity: 0, offset: 1 }], { duration: 520, easing: 'linear', fill: 'both' });
      fa.finished.then(() => f.remove()).catch(() => f.remove());
      out.push(fa);
      break;
    }
    case 'zoom':
      A(top, [{ opacity: 0, transform: 'scale(1.08)' }, { opacity: 1, transform: 'scale(1)' }], 340);
      A(under, [{ opacity: 1, transform: 'scale(1)' }, { opacity: 0, transform: 'scale(.94)' }], 300);
      break;
    default:
      A(top, [{ opacity: 0 }, { opacity: 1 }], 240);
      A(under, [{ opacity: 1 }, { opacity: 0 }], 220);
  }
  return out;
}
async function go(name, params = {}, kind = 'push') {
  if (busy) return; busy = true;
  try {
    const prev = stack[stack.length - 1];
    if (prev && SCREENS[prev.name].leave) SCREENS[prev.name].leave(prev.el, prev.params, false);
    const el = mount(name, params);
    stack.push({ name, params, el, kind });
    const a = anims(kind, el, prev && prev.el, false, params);
    await Promise.all(a.map(x => x.finished.catch(() => {})));
    if (prev) prev.el.hidden = true;
    a.forEach(x => x.cancel());
    trimStack();
    if (SCREENS[name].after) SCREENS[name].after(el, params);
  } finally { busy = false; }
}
async function back() {
  if (busy) return false;
  if (overlayClose()) return true;
  if (stack.length < 2) return false;
  busy = true;
  try {
    const cur = stack.pop(), prev = stack[stack.length - 1];
    if (SCREENS[cur.name].leave) SCREENS[cur.name].leave(cur.el, cur.params, true);
    prev.el.hidden = false;
    refreshEntry(prev);
    const a = anims(cur.kind, cur.el, prev.el, true, cur.params);
    await Promise.all(a.map(x => x.finished.catch(() => {})));
    cur.el.remove(); a.forEach(x => x.cancel());
    if (SCREENS[prev.name].after) SCREENS[prev.name].after(prev.el, prev.params, true);
  } finally { busy = false; }
  return true;
}
async function reset(name, params = {}, kind = 'fade') {
  while (busy) await sleep(30);
  busy = true;
  try {
    const old = stack.splice(0);
    old.forEach(o => { if (SCREENS[o.name].leave) SCREENS[o.name].leave(o.el, o.params, true); });
    const el = mount(name, params);
    stack.push({ name, params, el, kind });
    const a = anims(kind, el, old.length ? old[old.length - 1].el : null, false);
    await Promise.all(a.map(x => x.finished.catch(() => {})));
    old.forEach(o => o.el.remove()); a.forEach(x => x.cancel());
    if (SCREENS[name].after) SCREENS[name].after(el, params);
  } finally { busy = false; }
}
/* Re-render a "live" screen (keeps scroll position) */
function refreshEntry(entry) {
  if (!entry) return;
  const def = SCREENS[entry.name];
  if (!def.live && !entry.cleared) return;
  const sc = $('.scroll', entry.el), top = entry.cleared ? (entry.scroll || 0) : (sc ? sc.scrollTop : 0);
  if (def.leave) def.leave(entry.el, entry.params, false);
  entry.el.innerHTML = def.html(entry.params);
  if (def.init) def.init(entry.el, entry.params, true);
  const sc2 = $('.scroll', entry.el); if (sc2) sc2.scrollTop = top;
  entry.cleared = false;
}
/* Free memory of screens deep in the stack (they are rebuilt when revealed) */
function trimStack() {
  stack.forEach((e, i) => {
    if (i >= stack.length - 3 || e.cleared || SCREENS[e.name].keep) return;
    const sc = $('.scroll', e.el); e.scroll = sc ? sc.scrollTop : 0;
    if (SCREENS[e.name].leave) SCREENS[e.name].leave(e.el, e.params, false);
    e.el.innerHTML = ''; e.cleared = true;
  });
}
const topEntry = () => stack[stack.length - 1];
const refreshTop = () => refreshEntry(topEntry());
function rerenderAll() {
  stack.forEach(e => { const def = SCREENS[e.name]; if (def.leave) def.leave(e.el, e.params, false); e.el.className = 'screen ' + (def.cls || ''); e.el.innerHTML = def.html(e.params); if (def.init) def.init(e.el, e.params, true); e.cleared = false; });
}

/* ============ Overlays: bottom sheets, confirm, toast ============ */
let overlays = [];
function overlayClose() { const o = overlays.pop(); if (o) { o(); return true; } return false; }
function sheet(html, onMount, opts = {}) {
  const wrap = document.createElement('div'); wrap.className = 'overlay';
  wrap.innerHTML = `<div class="scrim"></div><div class="sheet ${opts.cls || ''}" role="dialog" aria-modal="true"><div class="grab"></div>${html}</div>`;
  $('#app').appendChild(wrap);
  const sh = $('.sheet', wrap), sc = $('.scrim', wrap);
  sh.animate([{ transform: 'translate3d(0,100%,0)' }, { transform: 'none' }], { duration: RM ? 1 : 320, easing: EASE });
  sc.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 220 });
  let closed = false;
  const close = async () => {
    if (closed) return; closed = true; overlays = overlays.filter(x => x !== close);
    const a = sh.animate([{ transform: 'none' }, { transform: 'translate3d(0,105%,0)' }], { duration: RM ? 1 : 230, easing: 'cubic-bezier(.4,0,1,1)', fill: 'forwards' });
    sc.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 220, fill: 'forwards' });
    await a.finished.catch(() => {}); wrap.remove();
    if (opts.onClose) opts.onClose();
  };
  if (!opts.locked) sc.addEventListener('click', close);
  overlays.push(close);
  if (onMount) onMount(sh, close);
  return close;
}
function confirmBox(title, text, okLabel, danger) {
  return new Promise(res => {
    let v = false;
    sheet(`<h3>${esc(title)}</h3><p>${esc(text)}</p><div class="acts"><button class="btn ghost" data-x="no">${t('cancel')}</button><button class="btn ${danger ? 'danger' : 'gold'}" data-x="ok">${esc(okLabel)}</button></div>`,
      (sh, c) => sh.addEventListener('click', e => { const b = e.target.closest('[data-x]'); if (!b) return; v = b.dataset.x === 'ok'; c(); }),
      { onClose: () => res(v) });
  });
}
let toastTimer;
function toast(msg, kind = '') {
  const el = $('#toast'); if (!el) return;
  el.textContent = msg; el.className = 'show ' + kind;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.className = ''; }, 2600);
}

/* Header with back button */
function hdr(o) {
  const backBtn = o.back === false ? '<span class="hdr-sp"></span>' : `<button class="iconbtn" data-act="back" aria-label="${t('back')}">${ic('back', 'flip')}</button>`;
  return `<header class="hdr">${backBtn}<h1>${esc(o.title)}</h1>${o.right || '<span class="hdr-sp"></span>'}</header>`;
}

function applyPrefs() {
  applyLook();
  document.documentElement.lang = S.lang;
  document.documentElement.dir = RTL() ? 'rtl' : 'ltr';
  document.title = IS_SITE ? 'عراق لودو · Iraq Ludo' : t('appName');
}

/* Copy text to the clipboard (falls back to a hidden textarea inside the WebView) */
async function copyText(s) {
  try { await navigator.clipboard.writeText(s); return true; } catch (e) {}
  try { const ta = document.createElement('textarea'); ta.value = s; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); const ok = document.execCommand('copy'); ta.remove(); return ok; } catch (e) { return false; }
}
function shareText(s, onFail) {
  if (NATIVE && NATIVE.share) { try { NATIVE.share(s); return true; } catch (e) {} }
  if (navigator.share) { navigator.share({ text: s }).catch(e => { if (!e || e.name !== 'AbortError') onFail && onFail(); }); return true; }
  return false;
}
