/* ============ Config (values in assets/config.js override these) ============ */
const CONFIG = Object.assign({
  appName: 'Iraq Ludo',
  version: '1.4.0',
  build: 1,
  firebase: null,                    // Firebase web config; empty = on-device mode (testing)
  functionsRegion: 'me-central2',    // Cloud Functions region (Dammam), same as Firestore
  loginDomain: '',                   // internal login ID domain; empty = <projectId>.firebaseapp.com (no mail can ever reach it)
  privacyUrl: '',                    // public privacy-policy page (needed for Google Play)
  supportEmail: '',
  androidUrl: '',                    // website only: link to the Android app (Google Play), shown when set
  onlineEnabled: false               // turned on in Phase 3 when the game server is deployed
}, (typeof window !== 'undefined' && window.LUDO_CONFIG) || {});
