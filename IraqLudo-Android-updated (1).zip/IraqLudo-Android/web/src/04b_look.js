/* ============ Look: colour themes, screen backgrounds, tile and token styles, motion level ============
   All of it is a choice of the player (Settings ← Design & colours), kept on the device with the other settings.
   The colours themselves live in CSS (head.html): html[data-ui="…"] swaps the tokens of the whole interface. */
const THEMES = [            // id, night, accent, accent light (used for the swatches)
  ['gold', '#080706', '#E6B44C', '#F9DB8B'], ['turq', '#041113', '#2EC4B6', '#93F1E6'], ['emerald', '#050E09', '#3DD68C', '#A6F5CC'],
  ['violet', '#0A0716', '#A78BFA', '#DCCFFF'], ['rose', '#12060B', '#FF6F96', '#FFC2D2'], ['blue', '#050B16', '#4EA8FF', '#B8DCFF'],
  ['sunset', '#120905', '#FF8A4C', '#FFC9A6'], ['silver', '#0A0B0E', '#CDD5E0', '#F4F7FB']
];
const BACKDROPS = ['bricks', 'ishtar', 'palms', 'stars', 'geo', 'none'];
const TILE_STYLES = ['board', 'ivory', 'onyx', 'color'];
const TOKEN_STYLES = ['classic', 'gem', 'flat'];
const MOTIONS = ['full', 'lite', 'off'];
const LOOK_DEFAULTS = { theme: 'gold', bg: 'bricks', tiles: 'board', tok: 'classic', motion: '' };

/* full: every animation · lite: game moves only, no decoration · off: nothing moves (also the default when the
   phone asks for reduced motion and the player has not chosen) */
const MOTION = () => (MOTIONS.includes(S.prefs.motion) ? S.prefs.motion : (SYS_RM ? 'off' : 'full'));
const FX = () => MOTION() === 'full' && !window.__LUDO_TURBO;       // the extra celebrations (never in the test fast-forward)
const pickOf = (list, v, d) => (list.includes(v) ? v : d);

function applyLook() {
  const h = document.documentElement, P = S.prefs;
  const th = THEMES.find(x => x[0] === P.theme) || THEMES[0];
  h.dataset.ui = th[0];
  h.dataset.bg = pickOf(BACKDROPS, P.bg, 'bricks');
  h.dataset.tiles = pickOf(TILE_STYLES, P.tiles, 'board');
  h.dataset.tok = pickOf(TOKEN_STYLES, P.tok, 'classic');
  const m = MOTION();
  h.classList.toggle('m-off', m === 'off');
  h.classList.toggle('m-lite', m === 'lite');
  RM = m === 'off';
  const meta = document.querySelector('meta[name="theme-color"]'); if (meta) meta.setAttribute('content', th[1]);
}

/* ---------- Design & colours screen ---------- */
const tokPreview = style => `<span class="tokpv" data-tokpv="${style}">${['red', 'green', 'yellow', 'blue'].map(c => `<span class="ptok c-${c}"><i></i></span>`).join('')}</span>`;
const bgPreview = id => `<span class="bgpv" data-bgpv="${id}"></span>`;
SCREENS.design = {
  live: true,
  html: () => {
    const P = S.prefs, theme = document.documentElement.dataset.ui, bg = document.documentElement.dataset.bg;
    const tiles = document.documentElement.dataset.tiles, tok = document.documentElement.dataset.tok, mo = MOTION();
    const board = Progress.data.equipped.board;
    const opt = (k, v, on, inner, label) => `<button class="lopt ${on ? 'on' : ''}" data-act="setLook" data-k="${k}" data-v="${v}" aria-pressed="${on}">${inner}<span>${esc(label)}</span></button>`;
    return `${hdr({ title: t('design') })}<div class="scroll"><div class="wrap">
      <p class="muted" style="text-align:center;margin:0 4px 12px">${esc(t('designSub'))}</p>
      <div class="lookprev">
        <div class="lpv-top">${avatarHtml(Accounts.user.avatar)}<span class="lpv-name"><b>${esc(Accounts.user.guest ? t('guestName') : Accounts.user.name)}</b>${levelBar()}</span>${ptsHtml()}</div>
        <div class="lpv-row"><span class="lpv-board">${boardThumb(board)}</span><span class="lpv-tiles ${dSkin()}"><span class="dt">${dFace(6, 3)}</span><span class="dt">${dFace(5, 1)}</span></span>${tokPreview(tok)}</div>
        <button class="btn gold block sm" tabindex="-1" aria-hidden="true">${ic('dice', 's')}${esc(t('start'))}</button>
      </div>
      <div class="sec">${esc(t('themeL'))}</div>
      <div class="lgrid four">${THEMES.map(([id, night, acc, hi]) => opt('theme', id, theme === id, `<span class="thsw" style="--n:${night};--a:${acc};--h:${hi}"></span>`, t('themes.' + id))).join('')}</div>
      <div class="sec">${esc(t('bgL'))}</div>
      <div class="lgrid three">${BACKDROPS.map(id => opt('bg', id, bg === id, bgPreview(id), t('bgs.' + id))).join('')}</div>
      <div class="sec">${esc(t('boardL'))} <span class="tag free">${esc(t('free'))}</span></div>
      <div class="lgrid three">${BOARD_SKINS.map(([id]) => opt('board', id, board === id, `<span class="bdpv">${boardThumb(id)}</span>`, t('boardNames.' + id))).join('')}</div>
      <div class="sec">${esc(t('tilesL'))}</div>
      <div class="lgrid four">${TILE_STYLES.map(id => opt('tiles', id, tiles === id, `<span class="tlpv ${dSkin()}" data-tiles-pv="${id}"><span class="dt">${dFace(6, 2)}</span></span>`, t('tileNames.' + id))).join('')}</div>
      <div class="sec">${esc(t('tokL'))}</div>
      <div class="lgrid three">${TOKEN_STYLES.map(id => opt('tok', id, tok === id, tokPreview(id), t('tokNames.' + id))).join('')}</div>
      <div class="sec">${esc(t('motionL'))}</div>
      <div class="seg">${MOTIONS.map(m => `<button class="${mo === m ? 'on' : ''}" data-act="setLook" data-k="motion" data-v="${m}">${esc(t('motions.' + m))}</button>`).join('')}</div>
      <p class="help">${esc(t('motionHelp'))}</p>
      <button class="btn ghost block" data-act="lookReset" style="margin-top:18px">${ic('refresh', 's')}${esc(t('lookReset'))}</button>
    </div></div>`;
  }
};
