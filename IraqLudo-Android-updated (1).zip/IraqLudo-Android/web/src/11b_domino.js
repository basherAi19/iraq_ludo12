/* ============ Dominoes (الدومنة) against the computer ============
   Seats: 0 = you (bottom). 2 players: 1 = top. 4 players: 1 = right, 2 = top (your partner), 3 = left.
   The line is drawn as a snake that turns at the table edges; doubles lie across the line.
   The table takes the colours of the board chosen in the Style screen. */
const DE = DominoEngine;
const U0 = 40;                                       // world pixels per unit; a tile is 1 × 2 units
const dHalf = v => `<span class="dh v${v}">${DOT_AT[v].map(p => `<i style="grid-area:${Math.ceil(p / 3)}/${(p - 1) % 3 + 1}"></i>`).join('')}</span>`;
const dFace = (a, b) => `${dHalf(a)}<b class="db"></b>${dHalf(b)}`;
const dRand = () => randInt(1 << 30) / (1 << 30);
const dBoard = () => (BOARD_SKINS.some(b => b[0] === Progress.data.equipped.board) ? Progress.data.equipped.board : 'classic');
const dSkin = () => 'dvars ds-' + dBoard();
/* Decorations on the table, after the chosen board: stars, palms, Babylon lions, turquoise stars, embers, a gold shine.
   Fixed positions (no layout change); they move only with full motion (CSS). */
const DECO_PTS = [[8, 14], [22, 78], [35, 9], [48, 88], [63, 18], [77, 72], [90, 12], [93, 52], [6, 55], [55, 52], [28, 40], [72, 38], [15, 92], [84, 90]];
function dDecoHtml() {
  const b = dBoard();
  const palm = (cls) => `<svg class="dpalm ${cls}" viewBox="0 0 60 60" aria-hidden="true"><path d="M30 58q3-16 0-30" stroke="#5B3F22" stroke-width="3" fill="none" stroke-linecap="round"/>
    <g class="sway">${[[-24, 4], [-18, -10], [-6, -20], [8, -20], [20, -10], [26, 4]].map(([dx, dy]) => `<path d="M30 28q${dx * .5} ${dy - 8} ${dx} ${dy}" stroke="currentColor" stroke-width="4" fill="none" stroke-linecap="round"/>`).join('')}</g></svg>`;
  const lion = `<svg viewBox="0 0 40 22" aria-hidden="true"><path d="M3 15c1-6 6-9 13-9h9c3-4 8-5 10-1c2 2 2 5 0 7l-2 1v6h-3v-5h-6l-2 5h-3l1-5H10l-2 5H5l1-5c-2 0-4-1-4-3c0 0 0 0 1 0z" fill="currentColor"/></svg>`;
  if (b === 'night') return DECO_PTS.map(([x, y], k) => `<i class="dstar" style="left:${x}%;top:${y}%;--d:${(k * .37) % 3}s;--s:${k % 3 ? 5 : 8}px"></i>`).join('');
  if (b === 'palm') return palm('pl') + palm('pr');
  if (b === 'babylon') return `<span class="dlion l1">${lion}</span><span class="dlion l2">${lion}</span><span class="dbrd top"></span><span class="dbrd bot"></span>`;
  if (b === 'turquoise') return DECO_PTS.slice(0, 10).map(([x, y], k) => `<i class="dkhat" style="left:${x}%;top:${y}%;--d:${(k * .53) % 4}s"></i>`).join('');
  if (b === 'sunset') return DECO_PTS.slice(0, 12).map(([x], k) => `<i class="dember" style="left:${x}%;--d:${(k * .71) % 6}s;--x:${(k % 2 ? 1 : -1) * (6 + k)}px"></i>`).join('');
  return '<i class="dshine"></i>';
}

/* ---------- setup: players + match length ---------- */
SCREENS.domSetup = {
  live: true,
  html: (p) => {
    p.players = p.players || store.get('domPlayers', 2);
    p.target = p.target || store.get('domTarget', 100);
    const seats = n => `<span class="pdots">${(n === 2 ? [1, 0] : [1, 0, 1, 0]).map(k => `<i class="${k ? 'tg' : 'ts'}"></i>`).join('')}</span>`;
    return `${hdr({ title: t('domTitle') })}<div class="scroll"><div class="wrap">
      <p class="muted" style="text-align:center;margin:0 0 6px">${esc(t('offSub'))}</p>
      <div class="sec">${esc(t('playersLabel'))}</div>
      <div class="choices">${[2, 4].map(n => `<button class="choice ${p.players === n ? 'on' : ''}" data-act="setDomPlayers" data-v="${n}">${seats(n)}<b>${esc(t(n === 2 ? 'twoP' : 'fourP'))}</b><small>${esc(t(n === 2 ? 'dom2Sub' : 'dom4Sub'))}</small></button>`).join('')}</div>
      <div class="sec">${esc(t('domLength'))}</div>
      <div class="seg">${[[50, 'domShort'], [100, 'domFull']].map(([v, k]) => `<button class="${p.target === v ? 'on' : ''}" data-act="setDomTarget" data-v="${v}">${esc(countText(v, 'domPtsN'))} · ${esc(t(k))}</button>`).join('')}</div>
      <p class="help">${esc(t('domSetupNote'))}</p>
      <div class="stickyfoot">${stakeChips()}<button class="btn gold block" data-act="startDom">${DOMI(6, 6, 26)}${esc(t('start'))}</button></div>
    </div></div>`;
  }
};

/* ---------- match state ---------- */
const DG = { alive: false, busy: false, paused: false, gen: 0, st: null, setup: null, el: null, t0: 0, elapsed: 0, sel: null, view: null, prevView: null, ro: null, sheet: false, deal: false, settled: null, shown: false };
const dLive = gen => DG.alive && DG.gen === gen;
async function dGate(gen) { while (DG.paused && dLive(gen)) await sleep(120); return dLive(gen); }
const dSaveKey = () => 'dsave:' + (Accounts.user ? Accounts.user.uid : 'guest');
function dSaved() {
  const s = store.get(dSaveKey(), null), su = s && s.setup;
  return s && s.st && su && DE.validate(s.st) && s.st.phase !== 'over' && s.st.phase !== 'deal' && su.players === s.st.players
    && Array.isArray(su.names) && su.names.length === su.players && Array.isArray(su.avatars) && su.avatars.length === su.players ? s : null;
}
function dSave() {
  if (!DG.st) { store.del(dSaveKey()); return; }
  if (DG.st.phase === 'over') { dSettle(false); return; }         // decided: counted at once, nothing left to resume
  store.set(dSaveKey(), { setup: DG.setup, st: DG.st, elapsed: DG.elapsed + (DG.alive ? Date.now() - DG.t0 : 0), savedAt: Date.now() });
}
/* Counts the match exactly once: the moment it is decided, or when it is given up.
   (So closing the app while the last summary is open cannot lose a win or dodge a loss.) */
function dSettle(forfeit) {
  if (!DG.settled) {
    if (DG.st.phase === 'over') forfeit = false;                  // already decided: it counts as played
    const res = dResult(forfeit);
    DG.settled = { res, forfeit, reward: forfeit && !dPlayed() ? null : Progress.recordGame(res) };   // a give-up only counts once you have played
    store.del(dSaveKey());
  }
  return DG.settled;
}
const dSpeed = () => TURBO() ? { think: 0, fly: 0, draw: 0, pause: 0, flash: 0 }
  : S.prefs.speed === 'fast' ? { think: 320, fly: 260, draw: 200, pause: 480, flash: 900 } : { think: 650, fly: 380, draw: 300, pause: 760, flash: 1250 };
const dName = s => (s === 0 ? t('you') : DG.setup.names[s]);
const dTeamName = k => (DG.st.players === 4 ? t(k === 0 ? 'domUs' : 'domThem') : dName(k));

function newDomSetup(players, target) {
  const names = [], avatars = [], bot = botPicker();
  for (let s = 0; s < players; s++) {
    if (s === 0) { names.push(Accounts.user.guest ? t('guestName') : Accounts.user.name); avatars.push(Accounts.user.avatar); continue; }
    const b = bot(); names.push(b.name); avatars.push(b.avatar);
  }
  return { game: 'dom', players, target: target === 50 ? 50 : 100, names, avatars };
}
function startDom(setup) {
  DG.alive = false; DG.gen++; DG.busy = false; DG.paused = false; DG.sel = null; DG.sheet = false; DG.settled = null; DG.shown = false;
  DG.setup = setup;
  DG.st = DE.createMatch({ players: setup.players, target: setup.target });
  DE.deal(DG.st, DE.shuffled(dRand));
  DG.elapsed = 0; DG.deal = true;
  store.set('domPlayers', setup.players); store.set('domTarget', setup.target);
  dSave();
  return reset('dgame', {}, 'zoom');
}
function resumeDom() {
  const sv = dSaved(); if (!sv) return;
  DG.alive = false; DG.gen++; DG.busy = false; DG.paused = false; DG.sel = null; DG.sheet = false; DG.deal = false; DG.settled = null; DG.shown = false;
  DG.setup = sv.setup; DG.st = sv.st; DG.elapsed = sv.elapsed || 0;
  return reset('dgame', {}, 'zoom');
}

/* ---------- where the tiles lie ----------
   Units: a tile is 1 × 2, centred at (cx, cy) and turned by rot degrees; `a` is the half that touches the line.
   Each arm runs sideways to the edge (xmax), turns one tile across, then turns back:
   the right arm snakes downwards, the left arm upwards. `ghosts` adds the possible places for a chosen tile. */
function domLayout(st, xmax, ghosts) {
  const out = [], gl = ghosts || [];
  const norm = r => ((r + 180) % 360 + 360) % 360 - 180;
  const rotFor = (dx, dy) => (dx === 1 ? -90 : dx === -1 ? 90 : dy === 1 ? 0 : 180);
  let first = st.first;
  const gc = gl.find(g => g.side === 'C');
  if (!first && gc) first = { id: gc.id, a: DE.TILES[gc.id][0], b: DE.TILES[gc.id][1], ghost: true };
  if (!first) return out;
  const dbl = first.a === first.b;
  out.push({ id: first.id, cx: 0, cy: 0, rot: dbl ? 0 : -90, a: first.a, b: first.b, ghost: !!first.ghost, side: 'C' });
  if (first.ghost) return out;
  const e = DE.ends(st), L = st.L.slice(), R = st.R.slice();
  gl.forEach(g => {
    if (g.side === 'L') L.push({ id: g.id, i: e[0], o: DE.other(g.id, e[0]), ghost: true });
    if (g.side === 'R') R.push({ id: g.id, i: e[1], o: DE.other(g.id, e[1]), ghost: true });
  });
  const arm = (items, x0, dir, vdir, side) => {
    let px = x0, py = 0, dx = dir, dy = 0, hd = dir, turning = false;
    for (const it of items) {
      const d = DE.isDouble(it.id);
      const put = (cx, cy, rot) => out.push({ id: it.id, cx, cy, rot: norm(rot), a: it.i, b: it.o, ghost: !!it.ghost, side });
      if (turning || (dy === 0 && Math.abs(px + dx * (d ? 1 : 2)) > xmax)) {
        // a corner: the tile turns, with its first half beside the open end
        if (!turning) hd = dx;
        const nx = turning ? -hd : 0, ny = turning ? 0 : vdir;
        const cx = px + dx / 2, cy = py + dy / 2;
        put(cx + nx / 2, cy + ny / 2, rotFor(nx, ny));
        px = cx + 1.5 * nx; py = cy + 1.5 * ny; dx = nx; dy = ny;
        turning = !turning;
        continue;
      }
      if (d) { put(px + dx / 2, py + dy / 2, rotFor(dx, dy) + 90); px += dx; py += dy; }     // doubles lie across
      else { put(px + dx, py + dy, rotFor(dx, dy)); px += 2 * dx; py += 2 * dy; }
    }
  };
  arm(R, dbl ? 0.5 : 1, 1, 1, 'R');
  arm(L, dbl ? -0.5 : -1, -1, -1, 'L');
  return out;
}

/* ---------- game screen ---------- */
SCREENS.dgame = {
  cls: 'game dgame', keep: true,
  html: () => {
    const four = DG.st.players === 4;
    return `<div class="gbar">
      <button class="iconbtn" data-act="dMenu" aria-label="${esc(t('menu'))}">${ic('menu')}</button>
      <div class="dsc" id="dsc"></div>
      <button class="iconbtn" data-act="gSound" aria-label="${esc(S.prefs.sound ? t('soundOn') : t('soundOff'))}">${ic(S.prefs.sound ? 'sound' : 'mute')}</button>
    </div>
    <div class="dtop ${four ? 'four' : ''}">${four ? '<div class="dseat col" data-s="3"></div><div class="dseat col mate" data-s="2"></div><div class="dseat col" data-s="1"></div>'
      : '<div class="dseat" data-s="1"></div><div class="dstock" id="dstock"></div>'}</div>
    <div class="dtable" id="dtable"><div class="ddeco" aria-hidden="true">${dDecoHtml()}</div><svg class="dmark" viewBox="0 0 40 40" aria-hidden="true">${rosette(20, 20, 18, 'currentColor')}</svg><div class="dworld" id="dworld"></div></div>
    <div class="dhand" id="dhand"></div>
    <div class="ghint"><span class="dme" data-s="0">${avatarEmoji(DG.setup.avatars[0])}</span><div class="msgtxt" id="gmsg"></div><button class="emobtn" data-act="emoji" aria-label="${esc(t('emojis'))}">😊</button></div>`;
  },
  init(el) {
    DG.el = el;
    el.className = 'screen game dgame ' + dSkin();
    DG.view = null; DG.prevView = null;
    dRenderAll(true);
    if (window.ResizeObserver) {
      if (DG.ro) DG.ro.disconnect();
      let lastW = -1, raf = 0;
      // fit the line again when the table changes size; the hand is redrawn only when the width changed,
      // so a taller hand (a second row of tiles) does not restart the tile animations
      DG.ro = new ResizeObserver(() => {
        cancelAnimationFrame(raf);
        raf = requestAnimationFrame(() => {
          if (DG.el !== el || !el.isConnected) return;
          const w = $('#dtable', el).clientWidth;
          dLayout({ instant: true, ghosts: dGhosts() });
          if (w !== lastW) { if (lastW !== -1) dRenderHand(); lastW = w; }
        });
      });
      DG.ro.observe($('#dtable', el));
    }
    $('#dhand', el).addEventListener('click', e => { const b = e.target.closest('[data-tile]'); if (b) dTapTile(+b.dataset.tile); });
    $('#dworld', el).addEventListener('click', e => { const g = e.target.closest('[data-ghost]'); if (g) dPick(g.dataset.ghost); });
    $('#dworld', el).addEventListener('keydown', e => { const g = e.target.closest('[data-ghost]'); if (g && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); e.stopPropagation(); dPick(g.dataset.ghost); } });
    keepAwake(true);
  },
  after() {
    if (DG.alive) return;
    DG.alive = true; DG.busy = false; DG.paused = false; DG.gen++; DG.t0 = Date.now();
    keepAwake(true);
    dLayout({ instant: true });
    const gen = DG.gen;
    // the tiles cannot be played while they are being dealt (busy), or two turns would run at once
    if (DG.deal) { DG.deal = false; DG.busy = true; dDealAnim(gen).then(() => { if (dLive(gen)) { DG.busy = false; dNext(); } }); } else dNext();
  },
  leave(el, p, final) {
    if (DG.alive && DG.st && DG.st.phase !== 'over') { DG.elapsed += Date.now() - DG.t0; DG.alive = false; dSave(); }
    DG.alive = false; DG.busy = false; DG.gen++;
    if (final && DG.ro) { DG.ro.disconnect(); DG.ro = null; }
    keepAwake(false);
  },
  onBack() { dMenu(); return true; }
};

/* ---------- drawing the screen ---------- */
function dHint(html) { const m = DG.el && $('#gmsg', DG.el); if (m) m.innerHTML = html; }
function dRenderAll(instant) { dRenderScores(); dRenderSeats(); dRenderStock(); dRenderHand(); dLayout({ instant }); }
function dRenderScores() {
  const el = DG.el && $('#dsc', DG.el); if (!el) return;
  const st = DG.st;
  el.innerHTML = `<span class="sc us"><small>${esc(dTeamName(0))}</small><b>${fmtNum(st.scores[0])}</b></span>
    <span class="sct"><small>${esc(t('domTo'))}</small><b>${fmtNum(st.target)}</b></span>
    <span class="sc them"><b>${fmtNum(st.scores[1])}</b><small>${esc(dTeamName(1))}</small></span>`;
}
function dRenderSeats() {
  if (!DG.el) return;
  const st = DG.st, four = st.players === 4;
  $$('.dseat', DG.el).forEach(el => {
    const s = +el.dataset.s, n = (st.hands[s] || []).length, col = four, mate = four && s === 2;
    const keep = $$('.bubble', el);
    el.innerHTML = `<div class="dpav" style="--rc:${DE.teamOf(st, s) === 0 ? 'var(--gold)' : 'var(--ivory)'}">${avatarEmoji(DG.setup.avatars[s])}<span class="dcnt">${fmtNum(n)}</span></div>
      <div class="dpn"><b>${esc(DG.setup.names[s])}</b><small>${mate ? '🤝 ' + esc(t('partner')) : '🤖'}</small></div>
      ${col ? '' : `<div class="dbacks">${Array.from({ length: Math.min(n, 10) }, () => '<i></i>').join('')}${n > 10 ? `<small>+${n - 10}</small>` : ''}</div>`}`;
    keep.forEach(b => el.appendChild(b));
  });
  dTurnGlow();
}
function dTurnGlow() { if (DG.el) $$('[data-s]', DG.el).forEach(x => x.classList.toggle('on', DG.st.phase === 'play' && +x.dataset.s === DG.st.turn)); }
function dRenderStock() {
  const el = DG.el && $('#dstock', DG.el); if (!el) return;
  const n = DG.st.stock.length;
  el.innerHTML = `<span class="dpile">${n ? '<i></i><i></i><i></i>' : ''}</span><span class="dsn"><b>${fmtNum(n)}</b><small>${esc(t('domStock'))}</small></span>`;
  el.classList.toggle('empty', !n);
}
function dRenderHand() {
  const el = DG.el && $('#dhand', DG.el); if (!el) return;
  const st = DG.st, hand = (st.hands[0] || []).slice().sort((x, y) => x - y);
  const my = st.phase === 'play' && st.turn === 0 && !DG.busy;
  const can = new Set(my ? DE.legalMoves(st).map(m => m.id) : []);
  const n = hand.length, W = (el.clientWidth || 360) - 16;
  let per = Math.max(1, n), tw = Math.floor((W - (per - 1) * 6) / per);
  if (tw < 30 && n > 1) { per = Math.ceil(n / 2); tw = Math.floor((W - (per - 1) * 6) / per); }
  el.style.setProperty('--tw', clamp(tw, 22, 46) + 'px');
  el.innerHTML = hand.map(id => { const [a, b] = DE.TILES[id]; return `<button class="dt hand ${my ? (can.has(id) ? 'can' : 'no') : ''} ${DG.sel === id ? 'sel' : ''}" data-tile="${id}" aria-label="${a} | ${b}">${dFace(a, b)}</button>`; }).join('');
}

/* Place every tile on the table and fit the line to the table size */
function dGeom() {
  const tb = DG.el && $('#dtable', DG.el); if (!tb) return null;
  const W = tb.clientWidth, H = tb.clientHeight;
  const aw = Math.max(140, W - 20), ah = Math.max(110, H - 20);
  return { W, H, aw, ah, xmax: clamp(Math.floor((aw / 40 - 2.5) / 2) + 0.5, 4.5, 12.5) };      // aim for ~40 px per unit on wide tables
}
const dGhosts = () => (DG.sel !== null && DG.st && DG.st.phase === 'play' && DG.st.turn === 0 ? DE.legalMoves(DG.st).filter(m => m.id === DG.sel).map(m => ({ side: m.side, id: m.id })) : null);
function dLayout(opts = {}) {
  const g = dGeom(), world = DG.el && $('#dworld', DG.el); if (!g || !world) return [];
  const lay = domLayout(DG.st, g.xmax, opts.ghosts);
  let x0 = -1, x1 = 1, y0 = -1, y1 = 1;
  if (lay.length) {
    x0 = y0 = Infinity; x1 = y1 = -Infinity;
    lay.forEach(p => {
      const v = Math.abs(p.rot) % 180 === 0, hx = v ? 0.5 : 1, hy = v ? 1 : 0.5;
      x0 = Math.min(x0, p.cx - hx); x1 = Math.max(x1, p.cx + hx); y0 = Math.min(y0, p.cy - hy); y1 = Math.max(y1, p.cy + hy);
    });
  }
  const u0 = clamp(g.aw / (2 * g.xmax + 2.5), 18, 46);
  const u = Math.min(u0, g.aw / (x1 - x0 + 0.8), g.ah / (y1 - y0 + 0.8));
  const k = u / U0, tx = g.W / 2 - (x0 + x1) / 2 * u, ty = g.H / 2 - (y0 + y1) / 2 * u;
  DG.prevView = DG.view || { k, tx, ty }; DG.view = { k, tx, ty };
  if (opts.instant) world.classList.add('instant');
  world.style.transform = `translate(${tx.toFixed(1)}px,${ty.toFixed(1)}px) scale(${k.toFixed(4)})`;
  const keep = new Set();
  lay.forEach(p => {
    const key = p.ghost ? `g${p.side}${p.id}` : `t${p.id}`;
    keep.add(key);
    let el = world.querySelector(`[data-k="${key}"]`);
    if (!el) {
      el = document.createElement('div'); el.dataset.k = key;
      el.className = p.ghost ? 'dt ghost' : 'dt';
      el.innerHTML = dFace(p.a, p.b);
      if (p.ghost) { el.dataset.ghost = p.side; el.tabIndex = 0; el.setAttribute('role', 'button'); el.setAttribute('aria-label', `${t('domPickSide')} (${p.a} | ${p.b})`); }
      world.appendChild(el);
    }
    el.style.left = ((p.cx - 0.5) * U0) + 'px'; el.style.top = ((p.cy - 1) * U0) + 'px';
    el.style.transform = `rotate(${p.rot}deg)`;
    p.el = el;
  });
  $$('[data-k]', world).forEach(el => { if (!keep.has(el.dataset.k)) el.remove(); });
  if (opts.instant) { void world.offsetWidth; world.classList.remove('instant'); }
  return lay;
}

/* ---------- motion ---------- */
/* A tile flies from the hand (or a player's seat) to its place; the start uses the table's previous fit */
function dFly(p, from, ms) {
  if (!p || !p.el || !from || RM || !ms) return Promise.resolve();
  const tb = $('#dtable', DG.el).getBoundingClientRect(), o = DG.prevView || DG.view;
  const sx = (from.x - tb.left - o.tx) / o.k, sy = (from.y - tb.top - o.ty) / o.k;
  const sc = clamp(from.w / (U0 * o.k), 0.15, 3);
  const a = p.el.animate([
    { transform: `translate(${(sx - p.cx * U0).toFixed(1)}px,${(sy - p.cy * U0).toFixed(1)}px) rotate(${from.rot || 0}deg) scale(${sc.toFixed(3)})` },
    { transform: `translate(0px,0px) rotate(${p.rot}deg) scale(1)` }
  ], { duration: ms, easing: EASE });
  return a.finished.catch(() => {});
}
function dPoint(el, w = 16) { if (!el) return null; const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2, w, rot: 0 }; }
const dSeatPoint = s => dPoint(DG.el && $(`.dseat[data-s="${s}"] .dpav`, DG.el));
/* A face-down tile slides from the pile to a hand */
function dFlyBack(to, ms) {
  const from = DG.el && $('#dstock .dpile', DG.el), app = $('#app');
  if (!from || !to || RM || !ms) return Promise.resolve();
  const a = from.getBoundingClientRect(), ar = app.getBoundingClientRect();
  const f = document.createElement('div'); f.className = 'dt back flyer';
  f.style.left = (a.left - ar.left + a.width / 2 - 10) + 'px'; f.style.top = (a.top - ar.top + a.height / 2 - 20) + 'px';
  app.appendChild(f);
  const dx = to.x - (a.left + a.width / 2), dy = to.y - (a.top + a.height / 2);
  const an = f.animate([{ transform: 'translate(0,0)' }, { transform: `translate(${dx.toFixed(0)}px,${dy.toFixed(0)}px) rotate(${dx > 0 ? 10 : -10}deg)` }], { duration: ms, easing: EASE });
  return an.finished.then(() => f.remove()).catch(() => f.remove());
}
function dFlash(text, ms) { flashOn(DG.el && $('#dtable', DG.el), text, ms || 1200); }
async function dDealAnim(gen) {
  Sound.fx.shuffle();
  dRenderAll(true);
  if (DG.st.round > 1 || DG.st.players === 4) dFlash(t('roundN', { n: fmtNum(DG.st.round) }), 900);
  if (RM || TURBO()) return;
  if (FX()) return dShuffleDeal(gen);
  const tb = $('#dtable', DG.el).getBoundingClientRect(), cx = tb.left + tb.width / 2, cy = tb.top + tb.height / 2;
  const tiles = $$('#dhand .dt', DG.el);
  tiles.forEach((el, i) => {
    const r = el.getBoundingClientRect();
    el.animate([{ transform: `translate(${(cx - r.left - r.width / 2).toFixed(0)}px,${(cy - r.top - r.height / 2).toFixed(0)}px) scale(.4) rotate(${i % 2 ? 40 : -40}deg)`, opacity: 0 }, { transform: 'none', opacity: 1 }],
      { duration: 420, delay: i * 60, easing: EASE, fill: 'backwards' });
  });
  $$('.dseat .dbacks i', DG.el).forEach((el, i) => el.animate([{ opacity: 0, transform: 'translateY(-8px)' }, { opacity: 1, transform: 'none' }], { duration: 260, delay: i * 35, fill: 'backwards' }));
  await sleep(440 + tiles.length * 60);
}
/* Full motion: the 28 tiles lie face down in the middle, get mixed twice, then go round the table one by one
   to every player (and the rest to the pile). Your own tiles turn face up as they arrive. */
async function dShuffleDeal(gen) {
  const tb = $('#dtable', DG.el); if (!tb) return;
  const R = tb.getBoundingClientRect(), cw = R.width, ch = R.height, k = S.prefs.speed === 'fast' ? .7 : 1;
  const tw = Math.round(clamp(cw / 17, 14, 24)), st = DG.st, n = st.players;
  const layer = document.createElement('div'); layer.className = 'dshuf'; tb.appendChild(layer);
  const tiles = Array.from({ length: 28 }, () => { const e = document.createElement('i'); e.className = 'dt back sh'; e.style.width = tw + 'px'; e.style.height = tw * 2 + 'px'; layer.appendChild(e); return e; });
  const rnd = a => (Math.random() - .5) * a;
  const end = tiles.map(() => ({ x: rnd(cw * .3), y: rnd(ch * .26), r: rnd(140) }));
  // hide what is about to be dealt
  const hand = $$('#dhand .dt', DG.el); hand.forEach(e => { e.style.opacity = '0'; });
  const cnt = $$('.dseat .dcnt', DG.el), backs = $$('.dseat .dbacks i', DG.el), sn = $('#dstock .dsn b', DG.el);
  cnt.forEach(c => { c.textContent = '0'; }); backs.forEach(b => { b.style.opacity = '0'; }); if (sn) sn.textContent = '0';
  const mix = tiles.map((e, i) => {
    const a = { x: rnd(cw * .62), y: rnd(ch * .55), r: rnd(220) }, b = { x: rnd(cw * .5), y: rnd(ch * .45), r: rnd(220) };
    return e.animate([{ transform: 'translate(-50%,-50%) rotate(0deg) scale(.5)', opacity: 0 },
      { transform: `translate(calc(-50% + ${a.x.toFixed(0)}px),calc(-50% + ${a.y.toFixed(0)}px)) rotate(${a.r.toFixed(0)}deg)`, opacity: 1, offset: .35 },
      { transform: `translate(calc(-50% + ${b.x.toFixed(0)}px),calc(-50% + ${b.y.toFixed(0)}px)) rotate(${b.r.toFixed(0)}deg)`, opacity: 1, offset: .72 },
      { transform: `translate(calc(-50% + ${end[i].x.toFixed(0)}px),calc(-50% + ${end[i].y.toFixed(0)}px)) rotate(${end[i].r.toFixed(0)}deg)`, opacity: 1 }],
    { duration: 950 * k, delay: i * 6, easing: 'cubic-bezier(.45,0,.3,1)', fill: 'forwards' });
  });
  setTimeout(() => Sound.fx.shuffle(), 420 * k);
  await Promise.all(mix.map(a => a.finished.catch(() => {})));
  if (!dLive(gen)) { layer.remove(); return; }
  const cx = R.left + cw / 2, cy = R.top + ch / 2;
  const at = el => { if (!el) return { x: cx, y: R.top - 30 }; const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; };
  const seatEl = s => $(`.dseat[data-s="${s}"] .dpav`, DG.el);
  const order = [];
  for (let r = 0; r < 7; r++) for (let s = 0; s < n; s++) order.push(s);
  while (order.length < 28) order.push(-1);                                  // the pile (2 players)
  let hi = 0;
  const flights = order.map((seat, i) => {
    const e = tiles[i], p = seat === -1 ? at($('#dstock .dpile', DG.el)) : seat === 0 ? at(hand[Math.min(hi++, hand.length - 1)]) : at(seatEl(seat));
    const dx = p.x - cx, dy = p.y - cy, last = `translate(calc(-50% + ${end[i].x.toFixed(0)}px),calc(-50% + ${end[i].y.toFixed(0)}px)) rotate(${end[i].r.toFixed(0)}deg)`;
    const a = e.animate([{ transform: last, opacity: 1 }, { transform: `translate(calc(-50% + ${dx.toFixed(0)}px),calc(-50% + ${dy.toFixed(0)}px)) rotate(0deg) scale(${seat === 0 ? 1.1 : .55})`, opacity: seat === 0 ? .9 : .2 }],
      { duration: 340 * k, delay: (seat === -1 ? 7 * n * 42 + (i - 7 * n) * 14 : i * 42) * k, easing: 'cubic-bezier(.3,.6,.3,1)', fill: 'forwards' });
    return a.finished.then(() => {
      e.remove();
      if (!dLive(gen)) return;
      if (seat === 0) { const h = hand.find(x => x.style.opacity === '0'); if (h) { h.style.opacity = ''; h.animate([{ transform: 'rotateY(90deg) translateY(-10px)' }, { transform: 'none' }], { duration: 220, easing: EASE }); } Sound.fx.tile(); }
      else if (seat === -1) { if (sn) sn.textContent = String(+sn.textContent + 1); }
      else { const c = $(`.dseat[data-s="${seat}"] .dcnt`, DG.el); if (c) c.textContent = String(+c.textContent + 1); const b = $$(`.dseat[data-s="${seat}"] .dbacks i`, DG.el).find(x => x.style.opacity === '0'); if (b) b.style.opacity = ''; }
    }).catch(() => e.remove());
  });
  await Promise.all(flights);
  layer.remove();
  hand.forEach(e => { e.style.opacity = ''; });
  if (dLive(gen)) { dRenderSeats(); dRenderStock(); }
}
/* Full motion, end of a round: the counted tiles turn over one by one and their points fly to the winner's score */
async function dReveal(e, gen) {
  const st = DG.st, r = st.result, tb = $('#dtable', DG.el); if (!r || !tb) return;
  const team = e.team, chip = $(`#dsc .sc.${team === 0 ? 'us' : 'them'}`, DG.el), num = chip && $('b', chip);
  const seats = r.hands.map((h, s) => s).filter(s => DE.teamOf(st, s) !== team && r.hands[s].length);
  if (!seats.length || !num) return;
  let score = st.scores[team] - e.points; num.textContent = fmtNum(score);
  const total = seats.reduce((a, s) => a + r.hands[s].length, 0), step = Math.min(230, 2000 / total), TR = tb.getBoundingClientRect();
  const rows = [];
  seats.forEach((s, k) => {
    if (s === 0) { rows.push({ s, tiles: $$('#dhand .dt', DG.el) }); return; }
    const row = document.createElement('div'); row.className = 'drev';
    const seat = $(`.dseat[data-s="${s}"]`, DG.el), sr = seat ? seat.getBoundingClientRect() : TR;
    row.style.left = clamp(sr.left + sr.width / 2 - TR.left, 60, TR.width - 60) + 'px'; row.style.top = (14 + (st.players === 4 ? 0 : k * 40)) + 'px';
    row.innerHTML = r.hands[s].map(() => '<span class="dt mini back"></span>').join('');
    tb.appendChild(row);
    rows.push({ s, tiles: $$('.dt', row), row });
  });
  const flyPts = (from, n) => {
    const f = from.getBoundingClientRect(), c = chip.getBoundingClientRect(), x = document.createElement('b'); x.className = 'dpts'; x.textContent = '+' + n;
    x.style.left = (f.left + f.width / 2) + 'px'; x.style.top = (f.top + f.height / 2) + 'px'; fxLayer().appendChild(x);
    return x.animate([{ transform: 'translate(-50%,-50%) scale(.6)', opacity: 0 }, { transform: 'translate(-50%,-120%) scale(1.2)', opacity: 1, offset: .25 },
      { transform: `translate(calc(-50% + ${(c.left + c.width / 2 - f.left - f.width / 2).toFixed(0)}px),calc(-50% + ${(c.top + c.height / 2 - f.top - f.height / 2).toFixed(0)}px)) scale(.7)`, opacity: .9 }],
    { duration: 620, easing: 'cubic-bezier(.4,0,.3,1)' }).finished.then(() => { x.remove(); score += n; num.textContent = fmtNum(score); pulse(chip, 1.12); Sound.fx.tick(); }).catch(() => x.remove());
  };
  const arrivals = [];
  let i = 0;
  for (const { s, tiles } of rows) {
    const ids = r.hands[s];
    for (let j = 0; j < ids.length; j++) {
      if (!dLive(gen)) break;
      const el = s === 0 ? tiles.find(x => +x.dataset.tile === ids[j]) || tiles[j] : tiles[j];
      if (!el) continue;
      const [a, b] = DE.TILES[ids[j]];
      if (s !== 0) {
        await el.animate([{ transform: 'rotateY(0deg)' }, { transform: 'rotateY(90deg)' }], { duration: step * .4, fill: 'forwards' }).finished.catch(() => {});
        el.classList.remove('back'); el.innerHTML = dFace(a, b);
        el.animate([{ transform: 'rotateY(90deg)' }, { transform: 'rotateY(0deg)' }], { duration: step * .4, fill: 'forwards' });
        Sound.fx.flip();
      } else el.animate([{ transform: 'translateY(0) scale(1)' }, { transform: 'translateY(-12px) scale(1.12)' }, { transform: 'none' }], { duration: step * 1.2 });
      arrivals.push(flyPts(el, a + b));
      await sleep(step * (s !== 0 ? .3 : 1)); i++;
    }
  }
  await Promise.all(arrivals);
  num.textContent = fmtNum(st.scores[team]);
  await sleep(520);
  rows.forEach(x => { if (x.row) x.row.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 220, fill: 'forwards' }).finished.then(() => x.row.remove()).catch(() => x.row.remove()); });
}
function dBubble(s, content, isEmoji) {
  const p = DG.el && $(`[data-s="${s}"]`, DG.el); if (!p) return;
  if (isEmoji && FX()) { bigEmoji($('.dpav', p) || p, content); return; }
  $$('.bubble', p).forEach(b => b.remove());
  const b = document.createElement('div'); b.className = 'bubble' + (isEmoji ? ' emo' : '');
  b.style.setProperty('--bdir', RTL() ? 'rtl' : 'ltr');
  b.textContent = content; p.appendChild(b);
  if (!RM) b.animate([{ opacity: 0, transform: 'translateY(6px) scale(.7)' }, { opacity: 1, transform: 'none' }], { duration: 260, easing: 'cubic-bezier(.3,1.4,.5,1)' });
  setTimeout(() => { if (!b.isConnected) return; b.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 300, fill: 'forwards' }).finished.then(() => b.remove()).catch(() => b.remove()); }, 2000);
}
function dBotReact(s, list, chance) {
  if (!DG.alive || s === 0 || Math.random() > chance) return;
  setTimeout(() => { if (DG.alive) { dBubble(s, list[randInt(list.length)], true); Sound.fx.emoji(); } }, 500 + randInt(700));
}

/* ---------- turn loop ---------- */
function dNext() {
  if (!DG.alive || DG.busy) return;                  // one turn at a time
  const st = DG.st;
  dRenderScores(); dRenderSeats(); dRenderStock();
  if (st.phase === 'roundOver' || st.phase === 'over') { dRenderHand(); dHint(''); dRoundSheet(); return; }
  if (st.turn === 0) dHumanTurn();
  else { DG.sel = null; dRenderHand(); dHint(`<span class="dim">${esc(t('waitTurn', { n: dName(st.turn) }))}</span>`); dBotTurn(DG.gen); }
}
function dHumanTurn() {
  const st = DG.st, moves = DE.legalMoves(st), gen = DG.gen;
  DG.sel = null; dRenderHand(); dLayout();
  if (moves.length) {
    dHint(`<span>${esc(t(!st.first && st.lead !== null ? 'domLead' : 'domYourTurn'))}</span>`);
    Sound.fx.turn();
    const e = DE.ends(st), one = moves.length === 1 || (new Set(moves.map(m => m.id)).size === 1 && e && e[0] === e[1]);
    if (S.prefs.autoMove && one) setTimeout(async () => { if ((await dGate(gen)) && !DG.busy && DG.st.phase === 'play' && DG.st.turn === 0) dTapTile(moves[0].id, true); }, TURBO() ? 0 : 450);
    return;
  }
  if (st.stock.length) {
    dHint(`<span>${esc(t('domNoTile'))}</span><button class="btn gold sm" data-act="dDraw">${esc(t('domDrawBtn'))}</button>`);
    if (S.prefs.autoMove) setTimeout(async () => { if ((await dGate(gen)) && !DG.busy && DG.st.turn === 0) dHumanDraw(true); }, TURBO() ? 0 : 650);
    return;
  }
  // nothing fits and nothing to draw: knock, and the turn passes
  dHint(`<span>${esc(t('domNoTile'))}</span>`);
  DG.busy = true;
  (async () => {
    try { await sleep(TURBO() ? 0 : 450); if (!(await dGate(gen))) return; const ev = DE.pass(DG.st); dSave(); await dEvents(ev, gen); }
    finally { if (dLive(gen)) DG.busy = false; }
    if (dLive(gen)) dNext();
  })();
}
/* Tapping a tile in your hand: play it, or show where it can go when it fits both ends */
function dTapTile(id, auto) {
  const st = DG.st;
  if (DG.busy || !DG.alive || DG.paused || !st || st.phase !== 'play' || st.turn !== 0) return;
  const ms = DE.legalMoves(st).filter(m => m.id === id);
  if (!ms.length) {
    Sound.fx.error();
    const b = $(`#dhand [data-tile="${id}"]`, DG.el);
    if (b && !RM) b.animate([{ transform: 'translateX(0)' }, { transform: 'translateX(-5px)' }, { transform: 'translateX(5px)' }, { transform: 'translateX(0)' }], { duration: 260 });
    return;
  }
  const e = DE.ends(st);
  if (ms.length === 1 || (e && e[0] === e[1])) {
    const m = ms.length === 1 ? ms[0] : (st.R.length <= st.L.length ? ms.find(x => x.side === 'R') : ms.find(x => x.side === 'L'));
    dHumanPlay(m.id, m.side, auto);
    return;
  }
  if (DG.sel === id) { DG.sel = null; dRenderHand(); dLayout(); dHint(`<span>${esc(t('domYourTurn'))}</span>`); return; }
  DG.sel = id; Sound.fx.tap(); haptic(); dRenderHand();
  dLayout({ ghosts: dGhosts() });
  dHint(`<span>${esc(t('domPickSide'))}</span>`);
}
function dPick(side) { if (DG.sel !== null) dHumanPlay(DG.sel, side); }
async function dHumanPlay(id, side, auto) {
  const st = DG.st;
  if (DG.busy || !DG.alive || DG.paused || st.phase !== 'play' || st.turn !== 0) return;
  if (!DE.legalMoves(st).some(m => m.id === id && m.side === side)) { Sound.fx.error(); return; }
  const gen = DG.gen, from = dPoint($(`#dhand [data-tile="${id}"]`, DG.el), 0);
  if (from) from.w = $(`#dhand [data-tile="${id}"]`, DG.el).getBoundingClientRect().width;
  DG.busy = true; DG.sel = null; dHint('');
  if (!auto) haptic();
  try { const ev = DE.play(st, id, side); dSave(); dRenderHand(); await dEvents(ev, gen, from); }
  finally { if (dLive(gen)) DG.busy = false; }
  if (dLive(gen)) dNext();
}
async function dHumanDraw(auto) {
  const st = DG.st;
  if (DG.busy || !DG.alive || DG.paused || st.phase !== 'play' || st.turn !== 0 || !st.stock.length || DE.legalMoves(st).length) return;
  const gen = DG.gen;
  DG.busy = true; dHint('');
  try {
    do {
      if (!(await dGate(gen))) return;
      const ev = DE.draw(DG.st); dSave();
      await dEvents(ev, gen);
    } while (auto && dLive(gen) && DG.st.phase === 'play' && DG.st.turn === 0 && !DE.legalMoves(DG.st).length && DG.st.stock.length);
  } finally { if (dLive(gen)) DG.busy = false; }
  if (dLive(gen)) dNext();
}
async function dBotTurn(gen) {
  const sp = dSpeed();
  DG.busy = true;
  try {
    await sleep(sp.think); if (!(await dGate(gen))) return;
    const seat = DG.st.turn;
    while (DG.st.phase === 'play' && DG.st.turn === seat && !DE.legalMoves(DG.st).length && DG.st.stock.length) {
      const ev = DE.draw(DG.st); dSave();
      await dEvents(ev, gen); if (!(await dGate(gen))) return;
    }
    if (DG.st.phase === 'play' && DG.st.turn === seat) {
      if (DE.legalMoves(DG.st).length) {
        const m = DominoAI.choose(DG.st);
        const ev = DE.play(DG.st, m.id, m.side); dSave();
        await dEvents(ev, gen, dSeatPoint(seat));
        if (DG.st.phase === 'play' && DG.st.hands[seat].length === 1) dBotReact(seat, ['😎', '🔥', '😏'], 0.5);
      } else {
        const ev = DE.pass(DG.st); dSave();
        await dEvents(ev, gen);
      }
    }
  } finally { if (dLive(gen)) DG.busy = false; }
  if (dLive(gen)) dNext();
}

/* Engine events as sound and motion */
async function dEvents(events, gen, from) {
  const sp = dSpeed();
  for (const e of events) {
    if (!dLive(gen)) return;
    if (e.type === 'play') {
      Sound.fx.tile();
      const lay = dLayout();
      $$('#dworld .dt.last', DG.el).forEach(x => x.classList.remove('last'));
      const p = lay.find(x => !x.ghost && x.id === e.id);
      if (p && p.el) p.el.classList.add('last');
      dRenderSeats();
      await dFly(p, from, sp.fly);
    } else if (e.type === 'draw') {
      Sound.fx.draw();
      await dFlyBack(e.seat === 0 ? dPoint($('#dhand', DG.el)) : dSeatPoint(e.seat), sp.draw);
      dRenderStock(); dRenderSeats();
      if (e.seat === 0) {
        dRenderHand();
        const b = $(`#dhand [data-tile="${e.id}"]`, DG.el);
        if (b && !RM) b.animate([{ transform: 'translateY(-16px) scale(1.08)', opacity: .4 }, { transform: 'none', opacity: 1 }], { duration: 280, easing: EASE });
      }
    } else if (e.type === 'pass') {
      Sound.fx.knock();
      dBubble(e.seat, t('knock') + '!', false);
      if (e.seat === 0) dFlash(t('domPassed'), sp.flash);
      await sleep(sp.pause);
    } else if (e.type === 'turn') dTurnGlow();
    else if (e.type === 'round') {
      dRenderScores(); dRenderSeats(); dRenderHand();
      if (e.reason === 'domino') { dFlash(t('domDomino'), sp.flash + 300); Sound.fx.home(); }
      else { dFlash(t('domBlocked'), sp.flash + 300); Sound.fx.knock(); shake($('#dtable', DG.el), 5, 320); }
      if (e.team !== null) for (let s = 1; s < DG.st.players; s++) dBotReact(s, DE.teamOf(DG.st, s) === e.team ? ['😎', '🎉', '👏'] : ['😭', '😡', '🤔'], 0.35);
      await sleep(TURBO() ? 0 : sp.flash + 250);
      if (FX() && e.team !== null && e.points > 0 && dLive(gen)) await dReveal(e, gen);
    }
  }
}

/* ---------- end of a round: everyone shows their tiles ---------- */
function dRoundSheet() {
  if (DG.sheet || !DG.alive) return;
  if (overlays.length) { setTimeout(() => { if (DG.alive && (DG.st.phase === 'roundOver' || DG.st.phase === 'over')) dRoundSheet(); }, 300); return; }
  const st = DG.st, r = st.result; if (!r) return;
  DG.sheet = true;
  const four = st.players === 4, over = st.phase === 'over', mine = r.team === 0;
  const line = r.team === null ? t('roundDraw') : mine ? t(four ? 'roundTeam' : 'roundYou') : four ? t('roundThem') : t('roundOther', { n: dName(r.seat) });
  const why = r.team === null ? t('whyDraw') : r.reason !== 'domino' ? t('whyBlocked') : r.seat === 0 ? t('whyDominoYou') : t('whyDomino', { n: dName(r.seat) });
  const rows = r.hands.map((h, s) => `<div class="rseat ${r.team !== null && DE.teamOf(st, s) === r.team ? 'win' : ''}">
      <span class="av">${avatarEmoji(DG.setup.avatars[s])}</span>
      <span class="rn"><b>${esc(dName(s))}</b><small>${h.length ? esc(countText(r.left[s], 'domPtsN')) : esc(t('domOutTag'))}</small></span>
      <span class="rtiles">${h.map(id => `<span class="dt mini">${dFace(DE.TILES[id][0], DE.TILES[id][1])}</span>`).join('')}</span></div>`).join('');
  sheet(`<div class="rbody"><h3>${esc(t('roundN', { n: fmtNum(r.round) }))}</h3>
    <p class="rres"><b>${esc(line)}</b> ${esc(why)}</p>
    <div class="rseats">${rows}</div>
    ${r.team !== null ? `<div class="rpts">${esc(dTeamName(r.team))}: ${esc(countText(r.points, 'ptsPlusN'))}</div>` : ''}
    <div class="dsc rtot"><span class="sc us"><small>${esc(dTeamName(0))}</small><b>${fmtNum(st.scores[0])}</b></span><span class="sct"><small>${esc(t('domTo'))}</small><b>${fmtNum(st.target)}</b></span><span class="sc them"><b>${fmtNum(st.scores[1])}</b><small>${esc(dTeamName(1))}</small></span></div></div>
    <button class="btn gold block" data-x="ok">${esc(over ? t('seeResult') : t('nextRound'))}</button>`,
    (sh, close) => sh.addEventListener('click', e => { if (e.target.closest('[data-x]')) close(); }),
    { cls: 'rsheet ' + dSkin(), onClose: () => { DG.sheet = false; dAfterRound(); } });
}
async function dAfterRound() {
  if (!DG.alive || !DG.st) return;
  if (DG.st.phase === 'over') { dFinish(false); return; }
  if (DG.st.phase !== 'roundOver') return;
  const gen = DG.gen;
  DE.deal(DG.st, DE.shuffled(dRand)); dSave();
  if (DG.el) $$('#dworld [data-k]', DG.el).forEach(x => x.remove());
  DG.view = null; DG.sel = null;
  DG.busy = true;                                    // no tile can be played while the new round is being dealt
  await dDealAnim(gen);
  if (dLive(gen)) { DG.busy = false; dNext(); }
}

/* ---------- pause menu, giving up, end of the match ---------- */
function dMenu() {
  if (overlays.length || !DG.st || !DG.alive) return;
  DG.paused = true;
  sheet(`<h3>${esc(t('menu'))}</h3><div class="menu-list">
    <button class="row" data-m="resume"><span class="ri">${DOMI(6, 6, 26)}</span><span class="rt">${esc(t('resumeGame'))}</span></button>
    <button class="row" data-m="rules"><span class="ri">${ic('book')}</span><span class="rt">${esc(t('howTo'))}</span></button>
    <button class="row" data-m="exit"><span class="ri">${ic('home')}</span><span class="rt">${esc(t('saveExit'))}<small>${esc(t('saveExitSub'))}</small></span></button>
    <button class="row" data-m="restart"><span class="ri">${ic('refresh')}</span><span class="rt">${esc(t('restart'))}<small>${esc(t('restartP'))}</small></span></button>
    <button class="row danger" data-m="forfeit"><span class="ri">${ic('flag')}</span><span class="rt">${esc(t('forfeit'))}<small>${esc(t('forfeitP'))}</small></span></button></div>`, (sh, close) => {
    sh.addEventListener('click', async e => {
      const b = e.target.closest('[data-m]'); if (!b) return;
      const m = b.dataset.m;
      await close();
      if (m !== 'resume' && m !== 'rules' && DG.st && DG.st.phase === 'over') return;      // already decided: the result sheet opens next
      if (m === 'rules') go('howto', { tab: 'dom' });
      else if (m === 'exit') { dSave(); reset('home', {}, 'fade'); }
      else if (m === 'restart') { if (await confirmBox(t('restartQ'), t('restartP'), t('restart'), true)) { const s = DG.setup; dRecordForfeit(); startDom(newDomSetup(s.players, s.target)); } else DG.paused = false; }
      else if (m === 'forfeit') { if (await confirmBox(t('forfeitQ'), t('forfeitP'), t('forfeit'), true)) dFinish(true); else DG.paused = false; }   // "cancel" carries on with the match
    });
  }, { onClose: () => { setTimeout(() => { if (!overlays.length) DG.paused = false; }, 0); } });
}
function dResult(forfeit) {
  const st = DG.st, done = st.phase === 'roundOver' || st.phase === 'over';
  return { game: 'dom', players: st.players, won: !forfeit && st.phase === 'over' && st.winner === 0, forfeit,
    rounds: done ? st.round : st.round - 1, roundsWon: st.teams[0].roundsWon, outs: st.stats[0].outs, points: st.teams[0].points,
    best: st.teams[0].best, blockWins: st.teams[0].blockWins, durationSec: Math.round((DG.elapsed + (DG.alive ? Date.now() - DG.t0 : 0)) / 1000) };
}
/* a give-up only counts once you have actually played */
const dPlayed = () => !!DG.st && (DG.st.round > 1 || DG.st.stats[0].played + DG.st.stats[0].drawn + DG.st.stats[0].passes > 0);
function dRecordForfeit() {
  if (DG.st) dSettle(true);
  DG.alive = false; DG.gen++;
}
function dFinish(forfeit) {
  const st = DG.st;
  if (!st || !DG.setup || DG.shown) return;          // the result screen is already on its way
  DG.shown = true;
  const done = dSettle(forfeit), res = done.res, reward = done.reward;
  forfeit = done.forfeit;
  DG.alive = false; DG.gen++;
  while (overlayClose());                            // nothing may stay open over the result (a round sheet, the menu)
  if (res.won) { Sound.fx.win(); haptic('success'); } else Sound.fx.lose();
  const p = { won: res.won, forfeit, reward, setup: DG.setup, scores: st.scores.slice(), target: st.target, players: st.players };
  setTimeout(() => reset('domResult', p, 'zoom'), forfeit ? 0 : 400);
}
function domEmoji() {
  emojiTray((content, isE) => {
    dBubble(0, content, isE);
    for (let s = 1; s < DG.st.players; s++) dBotReact(s, ['👍', '😂', '🤔', '😎'], 0.25);
  });
}

/* ---------- result ---------- */
SCREENS.domResult = {
  cls: 'result',
  html: (p) => {
    const four = p.players === 4, s = p.setup, win = p.won ? 0 : 1;
    const teams = four ? [[0, 2], [1, 3]] : [[0], [1]];
    const tname = k => (four ? t(k === 0 ? 'domUs' : 'domThem') : k === 0 ? t('you') : s.names[1]);
    const rows = [win, 1 - win].map((k, i) => `<div class="rank ${k === win ? 'win' : ''}" style="--pc:${k === 0 ? 'var(--gold)' : 'var(--ivory)'}">
        <span class="pl">${k === win ? '👑' : fmtNum(i + 1)}</span><span class="avs">${teams[k].map(x => `<span class="av">${avatarEmoji(s.avatars[x])}</span>`).join('')}</span>
        <span class="rn">${esc(tname(k))}${four ? `<small>${esc(teams[k].map(x => (x === 0 ? t('you') : s.names[x])).join(' · '))}</small>` : ''}</span><b class="rsc">${fmtNum(p.scores[k])}</b></div>`).join('');
    const sub = p.forfeit ? t('forfeitP') : p.won ? t(four ? 'domWonSubTeam' : 'domWonSub') : four ? t('domLostSubTeam') : t('domLostSub', { n: s.names[1] });
    const podium = [win, 1 - win].map((k, i) => ({ place: i + 1, avatars: teams[k].map(x => s.avatars[x]), name: tname(k), color: k === 0 ? 'var(--gold)' : 'var(--ivory)', score: p.scores[k] }));
    const r = p.reward;
    return `<canvas id="confetti"></canvas><div class="respill">${ptsHtml(Progress.data.points - (r ? r.points : 0))}</div><div class="scroll" style="width:100%"><div class="wrap">
      ${podiumHtml(podium, !p.forfeit)}
      <h2>${esc(p.won ? t('youWon') : t('youLost'))}</h2>
      <p class="sub">${esc(sub)}</p>
      ${rewardHtml(p.reward)}
      <div class="sec" style="align-self:stretch;text-align:start">${esc(t('finalScore'))}</div>
      <div class="ranks">${rows}</div>
      <button class="btn gold block" data-act="dPlayAgain">${ic('refresh')}${esc(t('playAgain'))}</button>
      <button class="btn ghost block" data-act="toHome" style="margin-top:12px">${ic('home')}${esc(t('toHome'))}</button>
    </div></div>`;
  },
  init(el, p) { if (p.won && !RM) confetti($('#confetti', el)); },
  after(el, p) { if (p._fx) return; p._fx = true; resultFx(el, p.reward, p.won); },
  onBack() { reset('home'); return true; }
};
