/* ============ Strings: Arabic (Iraqi dialect) + English ============ */
const T = {
ar: {
  appName: 'عراق لودو', tagline: 'لودو ودومنة بروح عراقية',
  back: 'رجوع', close: 'سكّر', cancel: 'إلغاء', ok: 'تمام', save: 'حفظ', yes: 'إي', no: 'لا', next: 'التالي', done: 'تم',
  loading: 'لحظة…', soon: 'قريباً', free: 'مجاني', copy: 'نسخ', copied: 'انتسخ', share: 'مشاركة',
  errGeneric: 'صار خطأ. جرّب مرة ثانية.', netErr: 'ماكو إنترنت. تأكد من الاتصال وجرّب مرة ثانية.',
  level: 'المستوى', levelN: 'مستوى {n}', you: 'إنت', bot: 'كمبيوتر',

  // money: free play dinars (not real money)
  cur: 'دينار', curShort: 'د.ع', myDinars: 'دنانيرك',
  dinarN: ['دينار واحد', 'دينارين', '{n} دنانير', '{n} دينار'],
  dinarPlus: ['\u2066+{n}\u2069 دينار', '\u2066+{n}\u2069 دينار', '\u2066+{n}\u2069 دنانير', '\u2066+{n}\u2069 دينار'], dinarMinus: ['\u2066−{n}\u2069 دينار', '\u2066−{n}\u2069 دينار', '\u2066−{n}\u2069 دنانير', '\u2066−{n}\u2069 دينار'],
  stakeWin: 'الفوز \u2066+50\u2069 دينار', stakeLose: 'الخسارة \u2066−50\u2069 دينار',

  // the two games
  ludo: 'لودو', dom: 'دومنة', vsComputer: 'ضد الكمبيوتر', ludoSub: '2 أو 4 لاعبين', domSub: 'لاعبين أو 4 بالشراكة', gamesFree: 'مجانية ضد الكمبيوتر، وتشتغل بدون إنترنت',

  // language
  chooseLang: 'اختار لغتك', langHint: 'تكدر تغيّرها بعدين من الإعدادات.', langAr: 'العربية', langEn: 'English',
  langArSub: 'باللهجة العراقية', langEnSub: 'Iraq Ludo in English',

  // sign in
  signIn: 'تسجيل الدخول', welcomeBack: 'هلا بيك', signInSub: 'ادخل باسم المستخدم وكلمة المرور.',
  username: 'اسم المستخدم', usernamePh: 'مثلاً ali_99', password: 'كلمة المرور', showPw: 'إظهار كلمة المرور', hidePw: 'إخفاء كلمة المرور',
  noAccount: 'ما عندك حساب؟', createAccount: 'سوّي حساب جديد', forgot: 'نسيت كلمة المرور؟',
  guest: 'العب ضد الكمبيوتر بدون حساب', guestNote: 'تقدمك يبقى على هذا الجهاز بس.',
  badLogin: 'اسم المستخدم أو كلمة المرور غلط.', locked: 'محاولات كثيرة. انتظر {s} وجرّب.', secondsN: ['ثانية وحدة', 'ثانيتين', '{n} ثواني', '{n} ثانية'], tooManyServer: 'محاولات كثيرة. انتظر شوية وجرّب.',
  demoBanner: 'وضع التجربة: الحسابات تنحفظ على هذا الجهاز بس. حتى تصير الحسابات حقيقية، اربط الخادم من ملف config.js.',
  signingIn: 'دا ندخلك…', required: 'هذا الحقل مطلوب.',

  // register
  register: 'حساب جديد', regSub: 'بس اسم مستخدم وكلمة مرور. ما نطلب إيميل ولا رقم موبايل.',
  usernameRules: 'من 3 إلى 20: حروف إنكليزية صغيرة، أرقام، _ أو نقطة. يبدي بحرف.',
  checking: 'دا نتأكد…', available: 'الاسم متاح', taken: 'هذا الاسم مأخوذ. جرّب غيره.', invalidUser: 'اسم المستخدم مو صالح. شوف الشروط تحت الخانة.', reserved: 'هذا الاسم محجوز.',
  displayName: 'اسمك باللعبة', displayNamePh: 'مثلاً: أبو علي', displayNameHint: 'هذا الاسم يشوفه اللاعبين. تكدر تكتبه بالعربي.',
  badName: 'الاسم لازم يكون من 2 إلى 20 حرف، وبدون روابط أو أرقام موبايل.',
  confirmPw: 'أعد كلمة المرور', pwRules: '8 أحرف على الأقل، بيها حرف ورقم.', pwWeak: 'كلمة المرور لازم تكون 8 أحرف على الأقل وبيها حرف ورقم.', pwMismatch: 'كلمتين المرور مو متطابقات.',
  pwStrength: ['ضعيفة', 'مقبولة', 'زينة', 'قوية'],
  agree: 'أوافق على شروط الاستخدام وسياسة الخصوصية', mustAgree: 'لازم توافق على الشروط حتى تكمل.', creating: 'دا نسوي حسابك…', setupErr: 'الخادم مو مضبوط بعد. راجع خطوات ربط Firebase في دليل التشغيل.',

  // recovery code
  rcTitle: 'رمز الاستعادة', rcSub: 'هذا الرمز هو الطريقة الوحيدة حتى ترجع حسابك إذا نسيت كلمة المرور.',
  rcWarn: 'احفظه بمكان أمين: صوّره، أو اكتبه، أو انسخه. إذا ضيّعت كلمة المرور والرمز سوا، ما نكدر نرجّعلك الحساب.',
  rcSaved: 'حفظت الرمز بمكان أمين', rcConfirm: 'أكّد إنك حفظت الرمز أول.', rcShareText: 'رمز استعادة حساب عراق لودو ({u}): {c}', rcContinue: 'كمّل للعبة',

  // recover
  recoverTitle: 'استرجاع الحساب', recoverSub: 'اكتب اسم المستخدم ورمز الاستعادة، واختار كلمة مرور جديدة.',
  rcLabel: 'رمز الاستعادة', newPw: 'كلمة المرور الجديدة', recoverBtn: 'غيّر كلمة المرور',
  recoverOk: 'تغيّرت كلمة المرور. الرمز القديم بطل، وهذا رمزك الجديد.', recoverBad: 'اسم المستخدم أو رمز الاستعادة غلط.',
  recoverOff: 'استرجاع الحساب يحتاج تفعيل خادم اللعبة. هذي الخدمة تنفتح ويا اللعب أونلاين.',

  // home
  hello: 'هلا {n}', guestName: 'ضيف',
  playOnline: 'العب أونلاين مع لاعبين', playOnlineSub: 'لاعبين حقيقيين، 2 أو 4 بالمباراة',
  daily: 'المكافآت اليومية', dailyReady: 'جاهزة', dailyDone: 'استلمتها', challenges: 'التحديات', challengesN: '{n} جاهزة', profile: 'ملفي الشخصي', shop: 'المظهر',
  resumeLudo: 'كمّل مباراة اللودو', resumeDom: 'كمّل مباراة الدومنة', playersN: ['لاعب واحد', 'لاعبين', '{n} لاعبين', '{n} لاعب'], howTo: 'طريقة اللعب', settings: 'الإعدادات',
  slogans: ['تعال واربح ويانا!', 'يلا نلعب!', 'حظك اليوم شنو؟', 'تحدّى الكمبيوتر واثبت مهارتك!', 'مستعد تصير بطل الگهوة؟', 'لودو لو دومنة؟ إنت اختار!', 'كل يوم لعبة، وكل يوم تحدي!'],
  guestHomeNote: 'تلعب كضيف', makeAccount: 'سوّي حساب',

  // Ludo setup
  offTitle: 'لودو ضد الكمبيوتر', offSub: 'مجاني دائماً، ويشتغل بدون إنترنت.', playersLabel: 'عدد اللاعبين', twoP: 'لاعبين', twoPSub: 'إنت ضد الكمبيوتر', fourP: '4 لاعبين', fourPSub: 'إنت ضد 3',
  yourColor: 'لونك', colorNames: { red: 'أحمر رماني', green: 'أخضر نخيلي', yellow: 'أصفر تمري', blue: 'أزرق فراتي' }, colorShort: { red: 'أحمر', green: 'أخضر', yellow: 'أصفر', blue: 'أزرق' }, start: 'ابدأ اللعب',
  botNames: ['كرار', 'زهراء', 'حيدر', 'نور', 'مصطفى', 'بنين', 'عباس', 'رقية', 'سجاد', 'زينب', 'مرتضى', 'آيات'],

  // dominoes setup
  domTitle: 'دومنة ضد الكمبيوتر', dom2Sub: 'إنت ضد الكمبيوتر، ويا سحب من الكومة', dom4Sub: 'إنت وشريكك ضد اثنين',
  domLength: 'المباراة على', domPtsN: ['نقطة وحدة', 'نقطتين', '{n} نقاط', '{n} نقطة'], domShort: 'قصيرة', domFull: 'كاملة',
  domSetupNote: 'اللي يخلّص حجاره أول واحد ياخذ نقاط حجار الخصم. أول واحد يوصل الهدف يفوز بالمباراة.',

  // dominoes game
  domUs: 'إحنا', domThem: 'هم', domTo: 'الهدف', partner: 'شريكك', domStock: 'بالكومة',
  domYourTurn: 'دورك: اختار حجر يركب', domLead: 'إنت تبدي: العب الحجر المضوي', domPickSide: 'اختار وين تحطه', domNoTile: 'ما عندك حجر يركب',
  domDrawBtn: 'اسحب من الكومة', domPassed: 'ما عندك حجر يركب، دگّيت', knock: 'دگّ', domDomino: 'دومنة!', domBlocked: 'انسدّت!', domOpens: '{n} يبدي',
  roundN: 'الجولة {n}', roundYou: 'فزت بالجولة!', roundTeam: 'فريقك فاز بالجولة!', roundOther: '{n} فاز بالجولة', roundThem: 'الخصوم فازوا بالجولة', roundDraw: 'الجولة تعادل',
  whyDomino: '{n} خلّص حجاره أول واحد.', whyDominoYou: 'خلّصت حجارك أول واحد.', whyBlocked: 'انسدّت ومحد يكدر يلعب، واللي حجاره أقل فاز.', whyDraw: 'انسدّت والنقاط متساوية، فمحد أخذ شي.',
  ptsPlusN: ['\u2066+{n}\u2069 نقطة', '\u2066+{n}\u2069 نقطة', '\u2066+{n}\u2069 نقاط', '\u2066+{n}\u2069 نقطة'], domOutTag: 'ما بقى عنده حجر', nextRound: 'الجولة الجاية', seeResult: 'شوف النتيجة',
  domWonSub: 'وصلت للهدف قبل الخصم.', domWonSubTeam: 'فريقك وصل للهدف قبل الخصوم.', domLostSub: '{n} وصل للهدف قبلك.', domLostSubTeam: 'الخصوم وصلوا للهدف قبل فريقك.', finalScore: 'النتيجة',

  // online
  onTitle: 'اللعب أونلاين', onHero: 'العب ويا لاعبين حقيقيين من كل العراق', onSub: 'راح يكون مجاني مثل باقي اللعبة، بدون أي دفع.',
  onFeat: ['لودو ودومنة ويا ناس حقيقيين', 'مباريات لاعبين أو 4 لاعبين', 'الخادم يوزع الحجار ويرمي النرد ويتحقق من كل حركة', 'بدون محادثات: بس إيموجي وعبارات جاهزة'],
  findMatch: 'دوّر على لاعبين', onSoon: 'اللعب أونلاين قيد التجهيز، وراح ينفتح قريباً.',
  needAccount: 'تحتاج حساب حتى تلعب أونلاين.',

  // welcome
  welcome: [
    ['هلا بيك بعراق لودو!', 'ألعاب الگهوة اللي تجمع الأهل والربع، هسه بموبايلك وبطابع عراقي.'],
    ['لودو ودومنة', 'العب الاثنين ضد الكمبيوتر، لاعبين أو أربعة، وبدون إنترنت.'],
    ['اجمع الدنانير', 'كل فوز يجيبلك 50 دينار، وكل خسارة تنقص 50. دنانير اللعبة مو فلوس حقيقية: مجانية، ما تنشرى ولا تنسحب.']
  ],
  getApp: 'حمّل تطبيق أندرويد',
  welcomeSkip: 'تخطي', welcomeNext: 'التالي', welcomeGo: 'يلا نلعب!', welcomeAgain: 'شاشة الترحيب',

  // matchmaking
  mmTitle: 'دوّر على لاعبين', mmGame: 'اللعبة', mmMode: 'نوع المباراة', mmColor: 'لونك المفضل', mmAny: 'أي لون', mmColorNote: 'إذا اختار أكثر من لاعب نفس اللون، الخادم يوزع الألوان بالقرعة.',
  mmStart: 'ابدأ البحث', mmSearching: 'دا ندوّرلك على لاعبين…', mmCancel: 'إلغاء البحث', mmOff: 'خادم اللعب أونلاين ما تفعّل بعد، فماكو لاعبين نوصلك بيهم هسه. العب ضد الكمبيوتر لحد ما ينفتح.', mmOffBtn: 'العب ضد الكمبيوتر',

  // Ludo game
  yourTurn: 'دورك! ارمِ النرد', rollBtn: 'ارمِ النرد', pickToken: 'اختار الحجر اللي تحركه', waitTurn: 'دور {n}…',
  noMove: 'ما عندك حركة', threeSixes: '3 ستات ورا بعض! راح الدور', againSix: 'ستة! ارمِ مرة ثانية', againCapture: 'كتلت حجر! ارمِ مرة ثانية', againHome: 'وصل للنهاية! ارمِ مرة ثانية',
  botAgain: '{n} يرمي مرة ثانية', youCaptured: 'كتلت حجر {b}!', gotCaptured: '{a} كتل حجرك!', otherCaptured: '{a} كتل حجر {b}', tokenHome: 'حجر وصل للنهاية',
  menu: 'القائمة', resumeGame: 'كمّل اللعب', saveExit: 'احفظ واطلع', saveExitSub: 'تكملها بعدين من الرئيسية', restart: 'ابدأ من جديد', restartQ: 'تبدي مباراة جديدة؟', restartP: 'المباراة الحالية تنحسب خسارة، وتنقص منك 50 دينار.',
  forfeit: 'انسحب', forfeitQ: 'تنسحب من المباراة؟', forfeitP: 'الانسحاب ينحسب خسارة، وتنقص منك 50 دينار.', soundOn: 'الصوت شغال', soundOff: 'الصوت مطفي',
  emojis: 'إيموجي', phrases: 'عبارات', phraseList: ['يلا نلعب!', 'حظ موفق', 'عاشت إيدك', 'هااا، شنو هذا الحظ؟', 'قربت أفوز!', 'يلا بعدك!'],
  sendWait: 'انتظر شوية قبل ما ترسل', home: 'البيت', finishedN: '{n}/4 وصلن',

  // result
  youWon: 'فزت! عاشت إيدك', youLost: 'خسرت هالمرة', wonSub: 'دخلت أحجارك الأربعة قبل الكل.', lostSub: '{n} فاز. المرة الجاية إلك!',
  earned: 'حصّلت', xpPlus: '\u2066+{n} XP\u2069', levelUp: 'صعدت للمستوى {n}!', newTitle: 'لقب جديد: {t}', newBadge: 'شارة جديدة', playAgain: 'العب مرة ثانية', toHome: 'الرئيسية',
  capturesL: 'كتلات', homeL: 'وصلن', turnsL: 'أدوار', durationL: 'المدة', winner: 'الفائز',

  // profile
  editName: 'غيّر الاسم', changeAvatar: 'غيّر الصورة', games: 'المباريات', wins: 'انتصارات', winRate: 'نسبة الفوز', titleL: 'اللقب', badges: 'الشارات',
  seeStats: 'كل الإحصائيات', memberSince: 'يلعب من {d}', guestProfile: 'إنت تلعب كضيف. سوّي حساب حتى تحفظ تقدمك وتلعب أونلاين.', nameSaved: 'انحفظ الاسم', pickAvatar: 'اختار صورتك', nextLevel: '\u2066{n} XP\u2069 للمستوى الجاي',

  // stats
  statsTitle: 'الإحصائيات', onlineStats: 'أونلاين', onlineStatsSoon: 'تظهر لما ينفتح اللعب أونلاين.', losses: 'خسارات',
  capturesMade: 'أحجار كتلتها', tokensLost: 'أحجار انكتلت', sixes: 'ستات رميتها', homeTokens: 'أحجار وصلت', bestStreak: 'أطول سلسلة فوز', currentStreak: 'السلسلة الحالية',
  fastestWin: 'أسرع فوز', turnsN: ['دور واحد', 'دورين', '{n} أدوار', '{n} دور'], playTime: 'وقت اللعب', minutesN: ['دقيقة وحدة', 'دقيقتين', '{n} دقايق', '{n} دقيقة'], forfeits: 'انسحابات', byPlayers: 'حسب عدد اللاعبين', none: '—',
  domRounds: 'الجولات', domRoundsWon: 'جولات فزت بيها', domOuts: 'مرات خلّصت حجارك أول واحد', domPoints: 'النقاط اللي جمعتها', domBest: 'أكبر جولة', domBlocks: 'جولات مسدودة فزت بيها',

  // settings
  language: 'اللغة', sound: 'المؤثرات الصوتية', music: 'الموسيقى', vibration: 'الاهتزاز', autoMove: 'العب تلقائياً إذا اكو خيار واحد', speed: 'سرعة اللعب', speedNormal: 'عادية', speedFast: 'سريعة',
  game: 'اللعب', account: 'الحساب', changePw: 'غيّر كلمة المرور', currentPw: 'كلمة المرور الحالية', pwChanged: 'تغيّرت كلمة المرور', wrongPw: 'كلمة المرور الحالية غلط.',
  logout: 'تسجيل الخروج', logoutQ: 'تطلع من حسابك؟', logoutP: 'تقدمك محفوظ بحسابك على هذا الجهاز.', deleteAcc: 'حذف الحساب', deleteQ: 'تحذف حسابك نهائياً؟', deleteP: 'ينحذف ملفك وتقدمك واسم المستخدم، وما يرجع.', deletePw: 'اكتب كلمة المرور حتى تأكد', deleted: 'انحذف الحساب',
  about: 'حول اللعبة', aboutP: 'عراق لودو: لودو ودومنة بروح عراقية. اللعبة مجانية بالكامل، واللعب ضد الكمبيوتر يشتغل بدون إنترنت. دنانير اللعبة مو فلوس حقيقية. ماكو محادثات، بس إيموجي وعبارات جاهزة.', version: 'الإصدار',
  privacy: 'الخصوصية', privacyP: 'نحفظ بس: اسم المستخدم، اسمك باللعبة، الصورة اللي تختارها، وبيانات لعبك. ما نطلب إيميل ولا رقم موبايل ولا موقع، وما نشارك بياناتك ويا أحد. كلمة المرور ما تنحفظ عندنا أبداً بشكلها الأصلي.',
  privacyWhere: 'حسابك وتقدّمك ينحفظون على خوادم Google Firebase حتى تفتحهم من التطبيق والموقع. لعب الضيف ينحفظ على جهازك بس.',
  privacyLocal: 'بهذا الوضع كل شي ينحفظ على جهازك بس، وما يطلع منه.',
  termsP: 'الشروط: اللعبة مجانية وللتسلية. دنانير اللعبة مو فلوس حقيقية، وما تنباع ولا تنسحب. ممنوع الأسماء المسيئة أو الروابط. وتگدر تحذف حسابك وكل بياناته بأي وقت من الإعدادات.',
  privacyFull: 'سياسة الخصوصية الكاملة', contactUs: 'راسل الدعم',
  savedQ: 'عندك مباراة محفوظة', savedP: 'إذا بدأت مباراة جديدة، المحفوظة تنحسب خسارة وتنقص منك 50 دينار. تگدر ترجع وتكمّلها من الرئيسية.', startNew: 'ابدأ جديدة',
  sessionEnded: 'انتهت جلستك على هذا الجهاز. سجّل دخول من جديد.', recoverSignIn: 'تغيّرت كلمة المرور. سجّل دخول بيها هسه.',
  guestAccount: 'تلعب كضيف', signInOrCreate: 'سجّل دخول أو سوّي حساب',

  // how to play: Ludo
  rulesTitle: 'طريقة اللعب', rulesIntro: 'الهدف: توصل أحجارك الأربعة للنهاية بالوسط قبل الكل.',
  rules: [
    ['البداية', 'كل لاعب عنده 4 أحجار ببيته الملوّن.'],
    ['الستة تطلّع', 'تحتاج رقم 6 حتى تطلّع حجر لمربع البداية.'],
    ['الحركة', 'حرّك حجر واحد بعدد النرد، ويا عقارب الساعة.'],
    ['الستة رمية زيادة', 'الستة تعطيك رمية ثانية. بس 3 ستات ورا بعض تلغي دورك.'],
    ['الكتل', 'إذا وقفت على حجر خصم وحيد بمربع عادي، تكتله ويرجع لبيته، وتاخذ رمية زيادة.'],
    ['مربعات الوردة', 'مربعات البداية والمربعات اللي بيها وردة آمنة. محد ينكتل بيها.'],
    ['الحجرين سوا', 'حجرين من نفس اللون بنفس المربع محميين. محد يكدر يكتلهم.'],
    ['الطريق الملوّن', 'بعد دورة كاملة، يدخل الحجر بطريقه الملوّن الخاص. هناك محد يوصله.'],
    ['النهاية بالضبط', 'لازم الرقم يكون مضبوط حتى يوصل الحجر للنهاية. الوصول يعطيك رمية زيادة.'],
    ['الفوز', 'أول واحد يدخّل أحجاره الأربعة يفوز وتخلص المباراة.'],
    ['ماكو حركة؟', 'إذا ما عندك حركة، يروح الدور للي بعدك. ويا الستة ترمي مرة ثانية.'],
    ['أونلاين', '15 ثانية لكل حركة. 3 أدوار تفوتك ورا بعض أو الطلعة من المباراة تنحسب خسارة.']
  ],
  urNote: 'الوردة بالمربعات الآمنة مأخوذة من لعبة أور الملكية، لقوها بمدينة أور بجنوب العراق، وهي من أقدم ألعاب الطاولة بالعالم.',
  // how to play: dominoes
  domIntro: 'الهدف: خلّص حجارك قبل الكل، وجمّع النقاط لحد ما توصل الهدف.',
  domRules: [
    ['الحجار', 'الدومنة بيها 28 حجر، من 0|0 إلى 6|6. نقاط الحجر هي مجموع رقميه.'],
    ['التوزيع', 'كل لاعب ياخذ 7 حجار. بلعبة لاعبين، الـ 14 الباقية تبقى بالكومة. بلعبة 4، تتوزع كل الحجار.'],
    ['منو يبدي', 'بأول جولة، اللي عنده أكبر دوبل يبدي بيه، يعني 6|6 إذا موجود. بعدين، الفايز بالجولة يبدي بأي حجر.'],
    ['اللعب', 'حط حجر رقمه يطابق واحد من الطرفين المفتوحين. الدور يمشي عكس عقارب الساعة.'],
    ['ما عندك حجر يركب؟', 'بلعبة لاعبين، اسحب من الكومة لحد ما يطلعلك حجر يركب. إذا خلصت الكومة، أو بلعبة 4، تدگّ ويروح الدور.'],
    ['الدومنة', 'اللي يخلّص حجاره أول واحد يفوز بالجولة، وياخذ مجموع نقاط حجار الخصوم.'],
    ['انسدّت', 'إذا محد يكدر يلعب، يفوز اللي نقاط حجاره أقل، وياخذ نقاط الخصوم. إذا تساووا، محد ياخذ شي.'],
    ['الشراكة', 'بلعبة 4، اللي گبالك شريكك. نقاط أي واحد منكم تنحسب للفريق، ونقاط شريكك ما تنحسب عليك.'],
    ['الفوز', 'أول لاعب أو فريق يوصل للهدف (50 أو 100 نقطة) يفوز بالمباراة.']
  ],

  // daily
  dailyTitle: 'المكافآت اليومية', dailySub: 'ادخل كل يوم وكبّر مكافأتك. إذا فاتك يوم، السلسلة ترجع من الأول.', dayN: 'يوم {n}', claim: 'استلم', claimed: 'استلمت',
  comeBack: 'ارجعلنا باچر للمكافأة الجاية', streakN: ['سلسلتك: يوم واحد', 'سلسلتك: يومين', 'سلسلتك: {n} أيام', 'سلسلتك: {n} يوم'], dailyGot: '\u2066+{n}\u2069 دينار!',

  // challenges
  chTitle: 'التحديات', dailyCh: 'تحديات اليوم', weeklyCh: 'تحديات الأسبوع', badgesTab: 'الشارات', renewDaily: 'تتجدد كل يوم', renewWeekly: 'تتجدد كل أسبوع', rewardOf: '\u2066+{p}\u2069 دينار، \u2066+{x} XP\u2069', claimedCh: 'استلمت المكافأة',
  ch: {
    win1: 'افز بأي مباراة ضد الكمبيوتر', domWin1: 'افز بمباراة دومنة', cap5: 'اكتل 5 أحجار باللودو', home8: 'وصّل 8 أحجار للنهاية باللودو', six8: 'ارمِ 8 ستات باللودو',
    play3: 'العب 3 مباريات', four1: 'العب مباراة 4 لاعبين', domOut2: 'خلّص حجارك أول واحد بجولتين', domPts50: 'اجمع 50 نقطة بالدومنة',
    win5: 'افز بـ 5 مباريات', cap25: 'اكتل 25 حجر باللودو', domWin3: 'افز بـ 3 مباريات دومنة', play10: 'العب 10 مباريات', domPts300: 'اجمع 300 نقطة بالدومنة'
  },

  // shop
  shopTitle: 'المظهر', shopSub: 'اختار شكل لعبتك. اللوحات كلها مجانية، والصور والنرد تنفتح بدنانير اللعبة.', avatarsTab: 'الصور', diceTab: 'النرد', boardsTab: 'اللوحات',
  boardsFree: 'كل اللوحات مجانية. اختار اللي يعجبك، وتصير هي طاولة الدومنة هم.',
  equip: 'استخدم', equipped: 'مستخدم', unlockFor: 'افتح بـ {n}', notEnough: 'دنانيرك ما تكفي. فوز بالمباريات واستلم المكافآت حتى تجمع.', unlocked: 'انفتح وصار مستخدم!',
  pointsNote: 'دنانير اللعبة مو فلوس حقيقية. مجانية: كل فوز \u2066+50\u2069 وكل خسارة \u2066−50\u2069، وتجمع غيرها من المكافآت. ما تنشرى ولا تنسحب، وما تعطي أفضلية باللعب.',
  diceNames: { classic: 'كلاسيك', night: 'ليلي', turquoise: 'فيروزي', rose: 'وردي', violet: 'بنفسجي', gold: 'ذهبي', marble: 'رخام', palm: 'خشب النخل' },
  boardNames: { classic: 'كلاسيك', babylon: 'بابل', night: 'ليل بغداد', palm: 'بستان النخيل', turquoise: 'فيروز سامراء', sunset: 'غروب دجلة' },
  charNames: { haji: 'الحجي', hajiya: 'الحجية', shab: 'الشاب', bint: 'البنية', talib: 'الطالب', muallima: 'الست', falah: 'الفلاح', chayji: 'الچايچي', sayyad: 'الصياد', tabiba: 'الدكتورة', oudi: 'العوّاد', riyadiya: 'الرياضية', kabtin: 'الكابتن', sheikh: 'الشيخ' },
  charsL: 'شخصيات عراقية', emojisL: 'رموز',
  design: 'التصميم والألوان', designSub: 'غيّر شكل اللعبة على كيفك. التغيير يبين فوراً.', designRowSub: 'الألوان، الخلفية، اللوحة، الحجار، الحركات',
  themeL: 'لون الواجهة', themes: { gold: 'ذهبي', turq: 'فيروزي', emerald: 'زمردي', violet: 'بنفسجي', rose: 'رماني', blue: 'فراتي', sunset: 'برتقالي', silver: 'فضي' },
  bgL: 'خلفية الشاشة', bgs: { bricks: 'طابوق', ishtar: 'بوابة عشتار', palms: 'نخيل', stars: 'نجوم', geo: 'زخرفة', none: 'سادة' },
  boardL: 'اللوحة وطاولة الدومنة', tilesL: 'حجار الدومنة', tileNames: { board: 'حسب اللوحة', ivory: 'عاجي', onyx: 'أسود وذهبي', color: 'نقاط ملوّنة' },
  tokL: 'حجار اللودو', tokNames: { classic: 'كلاسيك', gem: 'جوهرة', flat: 'حديث' },
  motionL: 'الحركات', motions: { full: 'كاملة', lite: 'خفيفة', off: 'بدون' },
  motionHelp: 'الكاملة بيها كل الحركات والاحتفالات. الخفيفة تخلي حركات اللعب بس. «بدون» للموبايلات الضعيفة.',
  lookReset: 'رجّع الشكل الأصلي', lookResetDone: 'رجع الشكل الأصلي', tapToClose: 'اضغط حتى تكمّل',

  // titles + badges
  titles: ['مبتدئ', 'ابن المحلة', 'لاعب گهوة', 'شيخ الطاولة', 'أسطورة دجلة', 'سلطان الگهوة'],
  badgeNames: {
    firstWin: ['أول فوز', 'افز بأول مباراة'], hunter10: ['صياد', 'اكتل 10 أحجار باللودو'], hunter50: ['ما يرحم', 'اكتل 50 حجر باللودو'],
    clean: ['نظيف', 'افز باللودو بدون ما ينكتل ولا حجر'], comeback: ['رجعة الأبطال', 'افز باللودو بعد ما ينكتلن 4 أحجار منك'], six50: ['أبو الستات', 'ارمِ 50 ستة'],
    games10: ['مدمن الطاولة', 'العب 10 مباريات'], games50: ['ابن الگهوة', 'العب 50 مباراة'], streak7: ['وفي', 'سلسلة دخول 7 أيام'], table4: ['ملك الطاولة', 'افز بمباراة لودو 4 لاعبين'], level10: ['شيخ', 'وصل للمستوى 10'],
    domWin: ['أول دومنة', 'افز بأول مباراة دومنة'], domOut10: ['إيده خفيفة', 'خلّص حجارك أول واحد 10 مرات'], domBig: ['ضربة معلم', 'اربح 30 نقطة أو أكثر بجولة وحدة'], domBlock: ['يعرف يسكّر', 'افز بجولة دومنة مسدودة']
  },
  lockedBadge: 'مقفلة'
},
en: {
  appName: 'Iraq Ludo', tagline: 'Ludo and dominoes with an Iraqi soul',
  back: 'Back', close: 'Close', cancel: 'Cancel', ok: 'OK', save: 'Save', yes: 'Yes', no: 'No', next: 'Next', done: 'Done',
  loading: 'One moment…', soon: 'Coming soon', free: 'Free', copy: 'Copy', copied: 'Copied', share: 'Share',
  errGeneric: 'Something went wrong. Try again.', netErr: 'No internet. Check your connection and try again.',
  level: 'Level', levelN: 'Level {n}', you: 'You', bot: 'Computer',

  cur: 'dinars', curShort: 'IQD', myDinars: 'Your dinars',
  dinarN: ['{n} dinar', '{n} dinars', '{n} dinars', '{n} dinars'],
  dinarPlus: ['+{n} dinar', '+{n} dinars', '+{n} dinars', '+{n} dinars'], dinarMinus: ['−{n} dinar', '−{n} dinars', '−{n} dinars', '−{n} dinars'],
  stakeWin: 'Win +50 dinars', stakeLose: 'Lose −50 dinars',

  ludo: 'Ludo', dom: 'Dominoes', vsComputer: 'Vs the computer', ludoSub: '2 or 4 players', domSub: '2 players, or 4 in pairs', gamesFree: 'Free against the computer, and no internet needed',

  chooseLang: 'Choose your language', langHint: 'You can change it later in Settings.', langAr: 'العربية', langEn: 'English',
  langArSub: 'باللهجة العراقية', langEnSub: 'Iraq Ludo in English',

  signIn: 'Sign in', welcomeBack: 'Welcome back', signInSub: 'Sign in with your username and password.',
  username: 'Username', usernamePh: 'e.g. ali_99', password: 'Password', showPw: 'Show password', hidePw: 'Hide password',
  noAccount: 'No account yet?', createAccount: 'Create an account', forgot: 'Forgot your password?',
  guest: 'Play the computer without an account', guestNote: 'Your progress stays on this device only.',
  badLogin: 'Wrong username or password.', locked: 'Too many attempts. Wait {s} and try again.', secondsN: ['{n} second', '{n} seconds', '{n} seconds', '{n} seconds'], tooManyServer: 'Too many attempts. Wait a little and try again.',
  demoBanner: 'Test mode: accounts are saved on this device only. To make accounts real, connect the server in config.js.',
  signingIn: 'Signing you in…', required: 'This field is required.',

  register: 'New account', regSub: 'Just a username and a password. No email, no phone number.',
  usernameRules: '3 to 20 characters: lowercase English letters, digits, _ or a dot. Starts with a letter.',
  checking: 'Checking…', available: 'Username is available', taken: 'That username is taken. Try another.', invalidUser: 'That username is not valid. See the rules below the field.', reserved: 'That username is reserved.',
  displayName: 'Your in-game name', displayNamePh: 'e.g. Abu Ali', displayNameHint: 'Other players see this name. It can be in Arabic.',
  badName: 'Names need 2 to 20 characters, with no links or phone numbers.',
  confirmPw: 'Repeat the password', pwRules: 'At least 8 characters, with a letter and a digit.', pwWeak: 'Passwords need at least 8 characters with a letter and a digit.', pwMismatch: 'The two passwords do not match.',
  pwStrength: ['Weak', 'Fair', 'Good', 'Strong'],
  agree: 'I agree to the terms of use and the privacy policy', mustAgree: 'Agree to the terms to continue.', creating: 'Creating your account…', setupErr: 'The server is not set up yet. Follow the Firebase steps in the setup guide.',

  rcTitle: 'Your recovery code', rcSub: 'This code is the only way to get your account back if you forget your password.',
  rcWarn: 'Keep it somewhere safe: take a screenshot, write it down or copy it. If you lose both your password and this code, we cannot recover the account.',
  rcSaved: 'I saved the code somewhere safe', rcConfirm: 'Confirm that you saved the code first.', rcShareText: 'Iraq Ludo account recovery code ({u}): {c}', rcContinue: 'Continue to the game',

  recoverTitle: 'Recover your account', recoverSub: 'Enter your username and recovery code, then choose a new password.',
  rcLabel: 'Recovery code', newPw: 'New password', recoverBtn: 'Change password',
  recoverOk: 'Password changed. Your old code no longer works; this is your new code.', recoverBad: 'Wrong username or recovery code.',
  recoverOff: 'Account recovery needs the game server. It opens together with online play.',

  hello: 'Hi {n}', guestName: 'Guest',
  playOnline: 'Play online with people', playOnlineSub: 'Real players, 2 or 4 per match',
  daily: 'Daily rewards', dailyReady: 'Ready', dailyDone: 'Claimed', challenges: 'Challenges', challengesN: '{n} ready', profile: 'My profile', shop: 'Style',
  resumeLudo: 'Continue your Ludo match', resumeDom: 'Continue your dominoes match', playersN: ['{n} player', '{n} players', '{n} players', '{n} players'], howTo: 'How to play', settings: 'Settings',
  slogans: ['Come and win with us!', "Let's play!", "What's your luck today?", 'Challenge the computer and prove your skill!', 'Ready to be the café champion?', 'Ludo or dominoes? You choose!', 'A game every day, a challenge every day!'],
  guestHomeNote: 'Playing as a guest', makeAccount: 'Create account',

  offTitle: 'Ludo vs computer', offSub: 'Always free, and works without internet.', playersLabel: 'Players', twoP: '2 players', twoPSub: 'You vs the computer', fourP: '4 players', fourPSub: 'You vs 3',
  yourColor: 'Your colour', colorNames: { red: 'Pomegranate red', green: 'Palm green', yellow: 'Date yellow', blue: 'Euphrates blue' }, colorShort: { red: 'Red', green: 'Green', yellow: 'Yellow', blue: 'Blue' }, start: 'Start the game',
  botNames: ['Karrar', 'Zahraa', 'Haider', 'Noor', 'Mustafa', 'Baneen', 'Abbas', 'Ruqaya', 'Sajjad', 'Zainab', 'Murtadha', 'Ayat'],

  domTitle: 'Dominoes vs computer', dom2Sub: 'You vs the computer, with a draw pile', dom4Sub: 'You and your partner vs two',
  domLength: 'Play to', domPtsN: ['{n} point', '{n} points', '{n} points', '{n} points'], domShort: 'Short', domFull: 'Full',
  domSetupNote: 'Whoever plays all their tiles first scores the pips left in the opponent\'s hand. The first to reach the target wins the match.',

  domUs: 'Us', domThem: 'Them', domTo: 'Target', partner: 'Your partner', domStock: 'in the pile',
  domYourTurn: 'Your turn: pick a tile that fits', domLead: 'You open: play the highlighted tile', domPickSide: 'Choose where it goes', domNoTile: 'No tile fits',
  domDrawBtn: 'Draw from the pile', domPassed: 'No tile fits, you knock', knock: 'Knock', domDomino: 'Domino!', domBlocked: 'Blocked!', domOpens: '{n} opens',
  roundN: 'Round {n}', roundYou: 'You won the round!', roundTeam: 'Your team won the round!', roundOther: '{n} won the round', roundThem: 'The other team won the round', roundDraw: 'A drawn round',
  whyDomino: '{n} played all their tiles first.', whyDominoYou: 'You played all your tiles first.', whyBlocked: 'Nobody could play, and the lowest hand won.', whyDraw: 'Nobody could play and the hands were equal, so no points.',
  ptsPlusN: ['+{n} point', '+{n} points', '+{n} points', '+{n} points'], domOutTag: 'No tiles left', nextRound: 'Next round', seeResult: 'See the result',
  domWonSub: 'You reached the target first.', domWonSubTeam: 'Your team reached the target first.', domLostSub: '{n} reached the target first.', domLostSubTeam: 'The other team reached the target first.', finalScore: 'Final score',

  onTitle: 'Online play', onHero: 'Play real people from all over Iraq', onSub: 'It will be free like the rest of the game, with no payments.',
  onFeat: ['Ludo and dominoes with real people', 'Matches for 2 or 4 players', 'The server deals the tiles, rolls the dice and checks every move', 'No chat: only emojis and ready-made phrases'],
  findMatch: 'Find players', onSoon: 'Online play is being prepared and opens soon.',
  needAccount: 'You need an account to play online.',

  welcome: [
    ['Welcome to Iraq Ludo!', 'The café games that bring family and friends together, now on your phone with an Iraqi touch.'],
    ['Ludo and dominoes', 'Play both against the computer, with two or four players, and no internet needed.'],
    ['Collect dinars', 'Every win brings 50 dinars, and every loss takes 50. Game dinars are not real money: they are free and cannot be bought or cashed out.']
  ],
  getApp: 'Get the Android app',
  welcomeSkip: 'Skip', welcomeNext: 'Next', welcomeGo: "Let's play!", welcomeAgain: 'Welcome screen',

  mmTitle: 'Find players', mmGame: 'Game', mmMode: 'Match type', mmColor: 'Preferred colour', mmAny: 'Any', mmColorNote: 'If several players pick the same colour, the server assigns colours by draw.',
  mmStart: 'Start searching', mmSearching: 'Looking for players…', mmCancel: 'Stop searching', mmOff: 'The online server is not switched on yet, so there are no players to connect you with right now. Play the computer until it opens.', mmOffBtn: 'Play the computer',

  yourTurn: 'Your turn! Roll the dice', rollBtn: 'Roll the dice', pickToken: 'Pick the token to move', waitTurn: "{n}'s turn…",
  noMove: 'No move possible', threeSixes: 'Three sixes in a row! Turn lost', againSix: 'A six! Roll again', againCapture: 'Captured! Roll again', againHome: 'Home! Roll again',
  botAgain: '{n} rolls again', youCaptured: "You captured {b}'s token!", gotCaptured: '{a} captured your token!', otherCaptured: '{a} captured {b}', tokenHome: 'A token reached home',
  menu: 'Menu', resumeGame: 'Keep playing', saveExit: 'Save and exit', saveExitSub: 'Continue later from the home screen', restart: 'Start over', restartQ: 'Start a new match?', restartP: 'The current match counts as a loss, and you lose 50 dinars.',
  forfeit: 'Give up', forfeitQ: 'Give up this match?', forfeitP: 'Giving up counts as a loss, and you lose 50 dinars.', soundOn: 'Sound on', soundOff: 'Sound off',
  emojis: 'Emojis', phrases: 'Phrases', phraseList: ["Let's play!", 'Good luck', 'Well played', 'Whoa, what luck!', "I'm about to win!", 'Your move!'],
  sendWait: 'Wait a moment before sending again', home: 'Home', finishedN: '{n}/4 home',

  youWon: 'You won! Well played', youLost: 'Not this time', wonSub: 'All four of your tokens reached home first.', lostSub: '{n} won. Next one is yours!',
  earned: 'You earned', xpPlus: '+{n} XP', levelUp: 'You reached level {n}!', newTitle: 'New title: {t}', newBadge: 'New badge', playAgain: 'Play again', toHome: 'Home',
  capturesL: 'Captures', homeL: 'Home', turnsL: 'Turns', durationL: 'Time', winner: 'Winner',

  editName: 'Change name', changeAvatar: 'Change picture', games: 'Matches', wins: 'Wins', winRate: 'Win rate', titleL: 'Title', badges: 'Badges',
  seeStats: 'All statistics', memberSince: 'Playing since {d}', guestProfile: 'You are playing as a guest. Create an account to keep your progress and play online.', nameSaved: 'Name saved', pickAvatar: 'Choose your picture', nextLevel: '{n} XP to the next level',

  statsTitle: 'Statistics', onlineStats: 'Online', onlineStatsSoon: 'Shown once online play opens.', losses: 'Losses',
  capturesMade: 'Tokens you captured', tokensLost: 'Tokens you lost', sixes: 'Sixes rolled', homeTokens: 'Tokens home', bestStreak: 'Longest win streak', currentStreak: 'Current streak',
  fastestWin: 'Fastest win', turnsN: ['{n} turn', '{n} turns', '{n} turns', '{n} turns'], playTime: 'Time played', minutesN: ['{n} min', '{n} min', '{n} min', '{n} min'], forfeits: 'Matches given up', byPlayers: 'By number of players', none: '—',
  domRounds: 'Rounds', domRoundsWon: 'Rounds won', domOuts: 'Times you went out first', domPoints: 'Points scored', domBest: 'Best round', domBlocks: 'Blocked rounds won',

  language: 'Language', sound: 'Sound effects', music: 'Music', vibration: 'Vibration', autoMove: 'Play automatically when there is one choice', speed: 'Game speed', speedNormal: 'Normal', speedFast: 'Fast',
  game: 'Gameplay', account: 'Account', changePw: 'Change password', currentPw: 'Current password', pwChanged: 'Password changed', wrongPw: 'The current password is wrong.',
  logout: 'Sign out', logoutQ: 'Sign out of your account?', logoutP: 'Your progress stays saved with your account on this device.', deleteAcc: 'Delete account', deleteQ: 'Delete your account for good?', deleteP: 'Your profile, progress and username are deleted and cannot be restored.', deletePw: 'Enter your password to confirm', deleted: 'Account deleted',
  about: 'About', aboutP: 'Iraq Ludo: Ludo and dominoes with an Iraqi soul. The whole game is free, and playing the computer works offline. Game dinars are not real money. No chat, only emojis and ready-made phrases.', version: 'Version',
  privacy: 'Privacy', privacyP: 'We keep only your username, in-game name, chosen picture and game data. We never ask for an email, phone number or location, and we share nothing. Your password is never stored in its original form.',
  privacyWhere: 'Your account and progress are kept on Google Firebase servers so the app and the website show the same thing. Guest play stays on your device only.',
  privacyLocal: 'In this mode everything stays on your device and never leaves it.',
  termsP: 'Terms: the game is free and for fun. Game dinars are not real money and cannot be bought, sold or cashed out. No offensive names or links. You can delete your account and all its data at any time in Settings.',
  privacyFull: 'Full privacy policy', contactUs: 'Contact support',
  savedQ: 'You have a saved match', savedP: 'Starting a new match counts the saved one as a loss and takes 50 dinars. You can go back and resume it from the home screen.', startNew: 'Start new',
  sessionEnded: 'Your session on this device ended. Sign in again.', recoverSignIn: 'Your password is changed. Sign in with it now.',
  guestAccount: 'Playing as a guest', signInOrCreate: 'Sign in or create an account',

  rulesTitle: 'How to play', rulesIntro: 'Goal: bring all four of your tokens to the centre before everyone else.',
  rules: [
    ['Start', 'Each player has 4 tokens in a coloured yard.'],
    ['A six to start', 'You need a 6 to move a token out onto your start square.'],
    ['Moving', 'Move one token by the number rolled, clockwise.'],
    ['Sixes roll again', 'A 6 gives you another roll. Three 6s in a row cancel your turn.'],
    ['Capturing', 'Land on a single opponent token on a normal square to send it back to its yard. You roll again.'],
    ['Rosette squares', 'Start squares and rosette squares are safe. No token can be captured there.'],
    ['Pairs', 'Two tokens of the same colour on one square are protected and cannot be captured.'],
    ['Your own path', 'After almost a full lap, a token enters its coloured home path, where no one can reach it.'],
    ['Exact finish', 'You need the exact number to reach the centre. Getting home gives you another roll.'],
    ['Winning', 'The first player to bring all four tokens home wins, and the match ends.'],
    ['No move?', 'If you cannot move, the turn passes. With a 6 you still roll again.'],
    ['Online', '15 seconds per action. Missing 3 turns in a row or leaving the match counts as a loss.']
  ],
  urNote: 'The rosette on the safe squares comes from the Royal Game of Ur, found at the city of Ur in southern Iraq and one of the oldest board games in the world.',
  domIntro: 'Goal: play all your tiles before everyone else, and collect points until you reach the target.',
  domRules: [
    ['The tiles', 'A set has 28 tiles, from 0|0 to 6|6. A tile is worth the sum of its two numbers.'],
    ['Dealing', 'Each player takes 7 tiles. With 2 players the other 14 stay in the draw pile. With 4 players every tile is dealt.'],
    ['Who opens', 'In the first round the highest double opens, which is 6|6 when someone holds it. After that the round winner opens with any tile.'],
    ['Playing', 'Place a tile whose number matches one of the two open ends. Turns go anticlockwise.'],
    ['No tile fits?', 'With 2 players, draw from the pile until a tile fits. When the pile is empty, or with 4 players, you knock and the turn passes.'],
    ['Domino', 'The first player to play all their tiles wins the round and scores the pips left in the opponents\' hands.'],
    ['Blocked', 'If nobody can play, the lowest hand wins and scores the opponents\' pips. Equal hands score nothing.'],
    ['Partners', 'With 4 players, the player across from you is your partner. Either of you can score for the team, and your partner\'s tiles never count against you.'],
    ['Winning', 'The first player or team to reach the target (50 or 100 points) wins the match.']
  ],

  dailyTitle: 'Daily rewards', dailySub: 'Come back every day to grow your reward. Miss a day and the streak starts over.', dayN: 'Day {n}', claim: 'Claim', claimed: 'Claimed',
  comeBack: 'Come back tomorrow for the next reward', streakN: ['Your streak: {n} day', 'Your streak: {n} days', 'Your streak: {n} days', 'Your streak: {n} days'], dailyGot: '+{n} dinars!',

  chTitle: 'Challenges', dailyCh: "Today's challenges", weeklyCh: "This week's challenges", badgesTab: 'Badges', renewDaily: 'New every day', renewWeekly: 'New every week', rewardOf: '+{p} dinars, +{x} XP', claimedCh: 'Reward claimed',
  ch: {
    win1: 'Win any match against the computer', domWin1: 'Win a dominoes match', cap5: 'Capture 5 Ludo tokens', home8: 'Bring 8 Ludo tokens home', six8: 'Roll 8 sixes in Ludo',
    play3: 'Play 3 matches', four1: 'Play a 4-player match', domOut2: 'Go out first in 2 rounds', domPts50: 'Score 50 points in dominoes',
    win5: 'Win 5 matches', cap25: 'Capture 25 Ludo tokens', domWin3: 'Win 3 dominoes matches', play10: 'Play 10 matches', domPts300: 'Score 300 points in dominoes'
  },

  shopTitle: 'Style', shopSub: 'Choose your look. All boards are free; pictures and dice unlock with game dinars.', avatarsTab: 'Pictures', diceTab: 'Dice', boardsTab: 'Boards',
  boardsFree: 'Every board is free. Pick the one you like; it also becomes your dominoes table.',
  equip: 'Use', equipped: 'In use', unlockFor: 'Unlock for {n}', notEnough: 'Not enough dinars yet. Win matches and claim rewards to earn more.', unlocked: 'Unlocked and in use!',
  pointsNote: 'Game dinars are not real money. They are free: +50 for every win, −50 for every loss, plus rewards. They cannot be bought or cashed out, and they give no advantage in matches.',
  diceNames: { classic: 'Classic', night: 'Night', turquoise: 'Turquoise', rose: 'Rose', violet: 'Violet', gold: 'Gold', marble: 'Marble', palm: 'Palm wood' },
  boardNames: { classic: 'Classic', babylon: 'Babylon', night: 'Baghdad night', palm: 'Palm grove', turquoise: 'Samarra turquoise', sunset: 'Tigris sunset' },
  charNames: { haji: 'The Haji', hajiya: 'The Hajiya', shab: 'The young man', bint: 'The girl', talib: 'The student', muallima: 'The teacher', falah: 'The farmer', chayji: 'The tea seller', sayyad: 'The fisherman', tabiba: 'The doctor', oudi: 'The oud player', riyadiya: 'The athlete', kabtin: 'The captain', sheikh: 'The sheikh' },
  charsL: 'Iraqi characters', emojisL: 'Symbols',
  design: 'Design & colours', designSub: 'Make the game look the way you like. Changes show at once.', designRowSub: 'Colours, background, board, tiles, motion',
  themeL: 'Interface colour', themes: { gold: 'Gold', turq: 'Turquoise', emerald: 'Emerald', violet: 'Violet', rose: 'Rose', blue: 'Euphrates', sunset: 'Orange', silver: 'Silver' },
  bgL: 'Screen background', bgs: { bricks: 'Bricks', ishtar: 'Ishtar Gate', palms: 'Palms', stars: 'Stars', geo: 'Pattern', none: 'Plain' },
  boardL: 'Board and dominoes table', tilesL: 'Dominoes tiles', tileNames: { board: 'Match the board', ivory: 'Ivory', onyx: 'Black and gold', color: 'Coloured pips' },
  tokL: 'Ludo tokens', tokNames: { classic: 'Classic', gem: 'Gem', flat: 'Modern' },
  motionL: 'Motion', motions: { full: 'Full', lite: 'Light', off: 'None' },
  motionHelp: 'Full has every animation and celebration. Light keeps only the game moves. None is for slow phones.',
  lookReset: 'Back to the original look', lookResetDone: 'Original look restored', tapToClose: 'Tap to continue',

  titles: ['Rookie', 'Neighbourhood kid', 'Café player', 'Table sheikh', 'Tigris legend', 'Café sultan'],
  badgeNames: {
    firstWin: ['First win', 'Win your first match'], hunter10: ['Hunter', 'Capture 10 Ludo tokens'], hunter50: ['Merciless', 'Capture 50 Ludo tokens'],
    clean: ['Spotless', 'Win at Ludo without losing a single token'], comeback: ['Comeback', 'Win at Ludo after losing 4 tokens'], six50: ['Six master', 'Roll 50 sixes'],
    games10: ['Table fan', 'Play 10 matches'], games50: ['Café regular', 'Play 50 matches'], streak7: ['Loyal', 'A 7-day sign-in streak'], table4: ['King of the table', 'Win a 4-player Ludo match'], level10: ['Sheikh', 'Reach level 10'],
    domWin: ['First domino', 'Win your first dominoes match'], domOut10: ['Quick hands', 'Go out first 10 times'], domBig: ['Master stroke', 'Score 30 points or more in one round'], domBlock: ['Lock master', 'Win a blocked dominoes round']
  },
  lockedBadge: 'Locked'
}};
