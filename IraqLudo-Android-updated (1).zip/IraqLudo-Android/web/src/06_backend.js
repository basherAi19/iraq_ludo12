/* ============ Accounts: username + password, no email, no phone ============
   Two backends behind one interface:
   - 'local': no server configured. Accounts live on this device only (testing / demo).
              Passwords are hashed with PBKDF2-SHA-256 (210,000 iterations, random salt).
   - 'fb':    Firebase Auth + Firestore. Each username maps to an internal login ID
              <username>@<projectId>.firebaseapp.com that is never shown. Nobody can receive mail at that
              address, so Firebase's password-reset e-mail can never reach anyone: the recovery code is the
              only way back in. Firebase hashes passwords with its scrypt variant; the app never stores them. */

const USERNAME_RE = /^[a-z][a-z0-9_.]{2,19}$/;
const RESERVED = ['admin', 'administrator', 'root', 'support', 'help', 'system', 'moderator', 'mod', 'staff', 'iraqludo', 'iraq_ludo', 'ludo', 'official', 'guest', 'bot', 'computer', 'null', 'undefined', 'test'];
const RC_ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

const normUser = u => digitsAr(String(u || '')).trim().toLowerCase();
function checkUsernameFormat(u) {
  u = normUser(u);
  if (!USERNAME_RE.test(u) || u.includes('..') || u.endsWith('.')) return 'invalid';
  if (RESERVED.includes(u.replace(/[._]/g, ''))) return 'reserved';
  return 'ok';
}
/* Display names are seen by strangers, and there is no chat: block links, handles and phone numbers */
function cleanName(n) { return String(n || '').replace(/\s+/g, ' ').trim(); }
function checkName(n) {
  n = cleanName(n);
  if (n.length < 2 || n.length > 20) return false;
  if (!/^[؀-ۿa-zA-Z0-9 _.\-٠-٩]+$/.test(n)) return false;
  const lower = n.toLowerCase();
  if (/(https?|www|\.com|\.net|\.org|\.iq|t\.me|wa\.me|@)/.test(lower)) return false;
  if ((digitsAr(n).match(/\d/g) || []).length > 3) return false;
  return true;
}
function pwStrength(p) {
  let s = 0;
  if (p.length >= 8) s++;
  if (p.length >= 12) s++;
  if (/[a-z؀-ۿ]/i.test(p) && /\d/.test(p)) s++;
  if (/[^a-zA-Z0-9؀-ۿ]/.test(p) || (/[a-z]/.test(p) && /[A-Z]/.test(p))) s++;
  return clamp(s - 1, 0, 3);
}
const pwOk = p => p.length >= 8 && p.length <= 64 && /[a-zA-Z؀-ۿ]/.test(p) && /\d/.test(digitsAr(p));

function newRecoveryCode() {
  const a = new Uint8Array(16); crypto.getRandomValues(a);
  const s = [...a].map(b => RC_ALPHA[b % 32]).join('');
  return `${s.slice(0, 4)}-${s.slice(4, 8)}-${s.slice(8, 12)}-${s.slice(12, 16)}`;
}
const normCode = c => digitsAr(String(c || '')).toUpperCase().replace(/[^A-Z0-9]/g, '');
const b64 = buf => btoa(String.fromCharCode(...new Uint8Array(buf)));
const fromB64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
async function pbkdf2(secret, saltBytes, iter) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: saltBytes, iterations: iter }, key, 256);
  return b64(bits);
}
async function hashSecret(secret, iter) {
  const salt = new Uint8Array(16); crypto.getRandomValues(salt);
  return { algo: 'pbkdf2-sha256', iter, salt: b64(salt), hash: await pbkdf2(secret, salt, iter) };
}
const sameHash = (a, b) => { if (a.length !== b.length) return false; let x = 0; for (let i = 0; i < a.length; i++) x |= a.charCodeAt(i) ^ b.charCodeAt(i); return x === 0; };

/* Growing local lock after repeated failures (on top of Firebase's own server-side throttling) */
const Lock = {
  left(u) { const l = store.get('lock:' + u, null); return l && l.until > Date.now() ? Math.ceil((l.until - Date.now()) / 1000) : 0; },
  fail(u) { const l = store.get('lock:' + u, { fails: 0, until: 0 }); l.fails++; if (l.fails >= 5) { l.until = Date.now() + Math.min(900, 30 * Math.pow(2, l.fails - 5)) * 1000; } store.set('lock:' + u, l); },
  clear(u) { store.del('lock:' + u); }
};
const AuthErr = (code) => Object.assign(new Error(code), { code });

/* ---------- Local (on-device) backend ---------- */
const LocalAccounts = {
  kind: 'local',
  users() { return store.get('users', {}); },
  async init() { const s = store.get('session', null); const u = s && this.users()[s]; return u ? this.pub(u) : null; },
  pub(u) { return { uid: u.uid, username: u.username, name: u.name, avatar: u.avatar, createdAt: u.createdAt }; },
  async available(u) { return !this.users()[normUser(u)]; },
  async register(username, name, password, avatar) {
    const users = this.users(); const u = normUser(username);
    if (users[u]) throw AuthErr('taken');
    const code = newRecoveryCode();
    const rec = { uid: 'loc_' + Date.now().toString(36) + randInt(1e6).toString(36), username: u, name: cleanName(name), avatar, createdAt: Date.now(),
      pw: await hashSecret(password, 210000), rc: await hashSecret(normCode(code), 120000) };
    users[u] = rec; store.set('users', users); store.set('session', u);
    return { user: this.pub(rec), code };
  },
  async login(username, password) {
    const u = normUser(username); const rec = this.users()[u];
    if (!rec) throw AuthErr('bad');
    const h = await pbkdf2(password, fromB64(rec.pw.salt), rec.pw.iter);
    if (!sameHash(h, rec.pw.hash)) throw AuthErr('bad');
    store.set('session', u); return this.pub(rec);
  },
  async logout() { store.del('session'); },
  async changePassword(user, current, next) {
    await this.verify(user, current);
    const users = this.users(); users[user.username].pw = await hashSecret(next, 210000); store.set('users', users);
  },
  async recover(username, code, next) {
    const users = this.users(); const u = normUser(username); const rec = users[u];
    if (!rec) throw AuthErr('badcode');
    const h = await pbkdf2(normCode(code), fromB64(rec.rc.salt), rec.rc.iter);
    if (!sameHash(h, rec.rc.hash)) throw AuthErr('badcode');
    const newCode = newRecoveryCode();
    rec.pw = await hashSecret(next, 210000); rec.rc = await hashSecret(normCode(newCode), 120000);
    store.set('users', users); store.set('session', u);
    return { user: this.pub(rec), code: newCode };
  },
  async saveProfile(user, patch) { const users = this.users(); const rec = users[user.username]; if (!rec) return; Object.assign(rec, patch); store.set('users', users); },
  async verify(user, password) {
    const rec = this.users()[user.username]; if (!rec) throw AuthErr('wrongpw');
    const h = await pbkdf2(password, fromB64(rec.pw.salt), rec.pw.iter);
    if (!sameHash(h, rec.pw.hash)) throw AuthErr('wrongpw');
  },
  async deleteAccount(user, password) {
    await this.verify(user, password);
    const users = this.users(); delete users[user.username]; store.set('users', users); store.del('session');
  }
};

/* ---------- Firebase backend (the SDK is loaded only when configured) ---------- */
const FireAccounts = {
  kind: 'fb', F: null, app: null, auth: null, db: null, fns: null, onSignedOut: null,
  loginDomain: () => String(CONFIG.loginDomain || `${CONFIG.firebase.projectId}.firebaseapp.com`).toLowerCase(),
  loginId(u) { return `${normUser(u)}@${this.loginDomain()}`; },
  loadSdk() {
    if (window.FB) return Promise.resolve(window.FB);
    return new Promise((res, rej) => {
      const s = document.createElement('script'); s.src = 'firebase.js'; s.async = true;
      s.onload = () => (window.FB ? res(window.FB) : rej(new Error('sdk'))); s.onerror = () => rej(new Error('sdk'));
      document.head.appendChild(s);
    });
  },
  async init() {
    const F = this.F = await this.loadSdk();
    this.app = F.initializeApp(CONFIG.firebase);
    try { this.auth = F.initializeAuth(this.app, { persistence: [F.indexedDBLocalPersistence, F.browserLocalPersistence] }); } catch (e) { this.auth = F.getAuth(this.app); }
    // the website may be open in several tabs; the app has one WebView
    const tabs = !NATIVE && F.persistentMultipleTabManager ? F.persistentMultipleTabManager() : F.persistentSingleTabManager();
    try { this.db = F.initializeFirestore(this.app, { localCache: F.persistentLocalCache({ tabManager: tabs }) }); } catch (e) { this.db = F.getFirestore(this.app); }
    try { this.fns = F.getFunctions(this.app, CONFIG.functionsRegion); } catch (e) { this.fns = null; }
    const first = await new Promise(res => { const un = F.onAuthStateChanged(this.auth, u => { un(); res(u); }); setTimeout(() => res(this.auth.currentUser), 6000); });
    // later on: Firebase ends the session itself when the password was changed or the account deleted on another device
    F.onAuthStateChanged(this.auth, u => { if (this.onSignedOut) this.onSignedOut(u); });
    if (!first) return null;
    const user = await this.profileOf(first);
    if (user.incomplete) { try { await F.signOut(this.auth); } catch (e) {} return null; }   // finished at the next sign-in
    return user;
  },
  ref(...p) { return this.F.doc(this.db, ...p); },
  async profileOf(fu) {
    let p = {}, missing = false;
    try {
      const s = await this.F.getDoc(this.ref('players', fu.uid));
      if (s.exists()) p = s.data() || {};
      else missing = !(s.metadata && s.metadata.fromCache);        // the server itself says there is no profile
    } catch (e) { logErr('profile', e.code || e.message); }
    const username = p.username || String(fu.email || '').split('@')[0];
    const user = { uid: fu.uid, username, name: p.name || fu.displayName || username, avatar: p.avatar || DEFAULT_AVATAR, createdAt: p.createdAt || Date.parse(fu.metadata && fu.metadata.creationTime || '') || Date.now() };
    if (missing) user.incomplete = true;
    return user;
  },
  async available(u) {
    try { const s = await this.F.getDoc(this.ref('usernames', normUser(u))); return !s.exists(); }
    catch (e) { return null; }                                   // unknown: registration itself still rejects duplicates
  },
  async register(username, name, password, avatar) {
    const F = this.F, u = normUser(username);
    let cred;
    try { cred = await F.createUserWithEmailAndPassword(this.auth, this.loginId(u), password); }
    catch (e) { throw AuthErr(/email-already-in-use/.test(e.code) ? 'taken' : /network/.test(e.code) ? 'net' : /too-many/.test(e.code) ? 'toomany' : /operation-not-allowed|configuration|api-key/.test(e.code) ? 'setup' : 'error'); }
    const fu = cred.user, now = Date.now(), nm = cleanName(name);
    let code;
    try { code = await this.writeAccount(fu, u, nm, avatar, now); }
    catch (e) {
      logErr('register-docs', e.code || e.message);
      try { await F.deleteUser(fu); } catch (x) {}               // do not leave a half-made account (if this fails too, the next sign-in finishes it)
      throw AuthErr(e.code === 'taken' ? 'taken' : /permission/.test(e.code || '') ? 'setup' : /unavailable|network|deadline/.test(e.code || '') ? 'net' : 'error');
    }
    try { await F.updateProfile(fu, { displayName: nm }); } catch (e) {}
    return { user: { uid: fu.uid, username: u, name: nm, avatar, createdAt: now }, code };
  },
  /* The three account documents are written together or not at all. A transaction is never kept for later,
     so a recovery code is stored only when it is also shown; and if it is sent twice it still counts once. */
  async writeAccount(fu, u, name, avatar, now) {
    const F = this.F, code = newRecoveryCode();
    const rec = Object.assign(await hashSecret(normCode(code), 120000), { createdAt: now });
    await F.runTransaction(this.db, async tx => {
      const taken = await tx.get(this.ref('usernames', u));
      if (taken.exists()) { if ((taken.data() || {}).uid === fu.uid) return; throw AuthErr('taken'); }
      tx.set(this.ref('usernames', u), { uid: fu.uid, createdAt: now });
      tx.set(this.ref('players', fu.uid), { username: u, name, avatar, lang: S.lang, level: 1, createdAt: now, lastSeen: now });
      tx.set(this.ref('recovery', fu.uid), rec);
    });
    return code;
  },
  async login(username, password) {
    let c;
    try { c = await this.F.signInWithEmailAndPassword(this.auth, this.loginId(username), password); }
    catch (e) { throw AuthErr(/too-many/.test(e.code) ? 'toomany' : /network/.test(e.code) ? 'net' : /invalid|wrong|not-found|user-disabled/.test(e.code) ? 'bad' : 'error'); }
    const user = await this.profileOf(c.user);
    if (user.incomplete) {
      // signed in, but the account was never finished (the connection dropped while it was being made): finish it now
      const name = checkName(user.name) ? cleanName(user.name) : checkName(user.username) ? user.username : 'Player';
      try { user.newCode = await this.writeAccount(c.user, user.username, name, user.avatar, Date.now()); user.name = name; delete user.incomplete; }
      catch (e) { logErr('finish-account', e.code || e.message); }
    }
    return user;
  },
  async logout() { await this.F.signOut(this.auth); },
  async reauth(password) {
    const fu = this.auth.currentUser; if (!fu) throw AuthErr('bad');
    try { await this.F.reauthenticateWithCredential(fu, this.F.EmailAuthProvider.credential(fu.email, password)); }
    catch (e) { throw AuthErr(/too-many/.test(e.code) ? 'toomany' : /network/.test(e.code) ? 'net' : 'wrongpw'); }
    return fu;
  },
  async changePassword(user, current, next) { const fu = await this.reauth(current); await this.F.updatePassword(fu, next); },
  async recover(username, code, next) {
    if (!this.fns) throw AuthErr('off');
    let r;
    try { r = await this.F.httpsCallable(this.fns, 'recoverAccount')({ username: normUser(username), code: normCode(code), newPassword: next }); }
    catch (e) { throw AuthErr(/permission-denied|invalid-argument/.test(e.code || '') ? 'badcode' : /resource-exhausted/.test(e.code || '') ? 'toomany' : /unavailable|network|internal|not-found|deadline/.test(e.code || '') ? 'off' : 'error'); }
    // the password is already changed and the old code is dead: the new code must reach the player even if signing in fails now
    let user = null;
    try { user = await this.login(username, next); } catch (e) { logErr('recover-login', e.code || e.message); }
    return { user, code: r.data && r.data.code };
  },
  async saveProfile(user, patch) { await this.F.updateDoc(this.ref('players', user.uid), Object.assign({}, patch, { updatedAt: Date.now() })); },
  /* Progress copy shared by the app and the website: read, merge and write in one transaction.
     merge(remote) returns { data, write }: nothing is written when this device has nothing new. */
  async syncProgress(user, merge) {
    const F = this.F, ref = this.ref('players', user.uid, 'progress', 'main');
    return F.runTransaction(this.db, async tx => {
      const snap = await tx.get(ref);
      const out = merge(snap.exists() ? snap.data() : null);
      if (out.write) tx.set(ref, out.data);
      return out.data;
    });
  },
  async deleteAccount(user, password) {
    const fu = await this.reauth(password);
    // remove the documents first (together, never kept for later); if that fails, keep the sign-in so the player can try again
    try {
      await this.F.runTransaction(this.db, async tx => {
        tx.delete(this.ref('usernames', user.username)); tx.delete(this.ref('players', user.uid)); tx.delete(this.ref('recovery', user.uid));
        tx.delete(this.ref('players', user.uid, 'progress', 'main'));
      });
    } catch (e) { logErr('delete-docs', e.code || e.message); throw AuthErr(/unavailable|network|deadline/.test(e.code || '') ? 'net' : 'error'); }
    try { await this.F.deleteUser(fu); }
    catch (e) { logErr('delete-user', e.code || e.message); throw AuthErr(/network/.test(e.code || '') ? 'net' : 'error'); }   // trying again finishes it
  }
};

/* ---------- Facade used by the screens ---------- */
const HAS_SERVER = !!(CONFIG.firebase && CONFIG.firebase.apiKey && CONFIG.firebase.projectId);
const Accounts = {
  impl: HAS_SERVER ? FireAccounts : LocalAccounts,
  user: null,                       // { uid, username, name, avatar, createdAt } or a guest
  busy: 0,                          // a sign-in, sign-up, sign-out, recovery or deletion is running
  onSessionEnd: null,               // set by the screens: the server ended the session
  get mode() { return this.impl.kind; },
  get isGuest() { return !!(this.user && this.user.guest); },
  /* signed in to the shared server (not a guest, not test mode): progress is copied to the cloud */
  get cloud() { return this.impl === FireAccounts && !this.offline && !this.closing && !!FireAccounts.F && !!this.user && !this.user.guest; },
  async syncProgress(merge) { return FireAccounts.syncProgress(this.user, merge); },
  async during(fn) { this.busy++; try { return await fn(); } finally { this.busy--; } },
  async init() {
    let u = null;
    try { u = await this.impl.init(); }
    catch (e) { logErr('accounts-init', e.message); if (this.impl === FireAccounts) { this.offline = true; } }
    if (!u && store.get('guest', false)) u = this.guestUser();
    this.user = u;
    return u;
  },
  /* The server part could not be loaded at start (no connection): try once more before an account action */
  async ready() {
    if (this.impl !== FireAccounts || FireAccounts.F) return;
    try { await FireAccounts.init(); this.offline = false; } catch (e) { throw AuthErr('net'); }
  },
  guestUser() { const g = store.get('guestProfile', { name: '', avatar: DEFAULT_AVATAR }); return { uid: 'guest', username: '', name: g.name || t('guestName'), avatar: g.avatar || DEFAULT_AVATAR, guest: true, createdAt: store.get('guestSince', Date.now()) }; },
  playAsGuest() { store.set('guest', true); if (!store.get('guestSince', null)) store.set('guestSince', Date.now()); this.user = this.guestUser(); return this.user; },
  async available(u) { try { await this.ready(); } catch (e) { return null; } return this.impl.available(u); },
  register(username, name, password, avatar) {
    return this.during(async () => {
      await this.ready();
      const r = await this.impl.register(username, name, password, avatar);
      store.del('guest'); this.user = r.user;
      return r;
    });
  },
  login(username, password) {
    return this.during(async () => {
      const u = normUser(username);
      const wait = Lock.left(u); if (wait) throw Object.assign(AuthErr('locked'), { wait });
      await this.ready();
      try { const user = await this.impl.login(u, password); Lock.clear(u); store.del('guest'); this.user = user; return user; }
      catch (e) { if (e.code === 'bad') Lock.fail(u); throw e; }
    });
  },
  logout() { return this.during(async () => { if (!this.isGuest) await this.impl.logout(); store.del('guest'); this.user = null; }); },
  async changePassword(current, next) { return this.impl.changePassword(this.user, current, next); },
  /* r.user is null when the password was changed but signing in failed just now: the new code is still returned */
  recover(username, code, next) {
    return this.during(async () => {
      await this.ready();
      const r = await this.impl.recover(username, code, next);
      Lock.clear(normUser(username));
      if (r.user) { store.del('guest'); this.user = r.user; }
      return r;
    });
  },
  async saveProfile(patch) {
    if (patch.name) patch.name = cleanName(patch.name);
    Object.assign(this.user, patch);
    if (this.isGuest) { store.set('guestProfile', { name: this.user.name, avatar: this.user.avatar }); return; }
    // not awaited: without a connection the change is kept and sent later, and the screen never waits for it
    Promise.resolve().then(() => this.impl.saveProfile(this.user, patch)).catch(e => logErr('saveProfile', e.code || e.message));
  },
  deleteAccount(password) {
    return this.during(async () => {
      const uid = this.user.uid;
      this.closing = true;                                       // no progress copy may be written while the account is being removed
      try { await this.impl.deleteAccount(this.user, password); } finally { this.closing = false; }
      ['prog:', 'progBase:', 'save:', 'dsave:'].forEach(k => store.del(k + uid));
      this.user = null;
    });
  }
};
/* Firebase ended the session by itself (the password was changed, or the account deleted, on another device),
   or another tab of the website signed in as someone else: this screen must not go on as the old account */
FireAccounts.onSignedOut = u => {
  if (Accounts.impl !== FireAccounts || Accounts.busy || Accounts.closing || !Accounts.user || Accounts.user.guest) return;
  if (u && u.uid === Accounts.user.uid) return;                  // still the same account
  Accounts.closing = true;                                       // stop copying progress; the screens sign the player out
  if (Accounts.onSessionEnd) Accounts.onSessionEnd(); else { Accounts.user = null; Accounts.closing = false; }
};
const authMsg = e => {
  const c = (e && e.code) || '';
  if (c === 'locked') return t('locked', { s: countText(e.wait, 'secondsN') });
  if (c === 'bad') return t('badLogin');
  if (c === 'toomany') return t('tooManyServer');
  if (c === 'net') return t('netErr');
  if (c === 'taken') return t('taken');
  if (c === 'wrongpw') return t('wrongPw');
  if (c === 'badcode') return t('recoverBad');
  if (c === 'off') return t('recoverOff');
  if (c === 'setup') return t('setupErr');
  return t('errGeneric');
};
