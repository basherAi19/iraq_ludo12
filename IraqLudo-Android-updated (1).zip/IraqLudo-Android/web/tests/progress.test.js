'use strict';
/* The shared-progress sync without a browser. web/src/07_progress.js runs unchanged in a sandbox, once per
   "device", against a small stand-in for the server copy. The server can lose its answer after saving, return
   map keys sorted (as Firestore does), or be unreachable; a device can be closed and opened again at any point.
   Run: node web/tests/progress.test.js */
const fs = require('node:fs'), vm = require('node:vm'), path = require('node:path'), assert = require('node:assert/strict');
const SRC_DIR = path.join(__dirname, '..', 'src');
const SRC = fs.readFileSync(path.join(SRC_DIR, '07_progress.js'), 'utf8');
const CORE = fs.readFileSync(path.join(SRC_DIR, '04_core.js'), 'utf8');
const pick = name => { const m = CORE.match(new RegExp('const ' + name + ' = [^\\n]*')); assert.ok(m, 'not found in 04_core.js: ' + name); return m[0]; };
const sortKeys = o => (Array.isArray(o) ? o.map(sortKeys) : o && typeof o === 'object' ? Object.keys(o).sort().reduce((a, k) => { a[k] = sortKeys(o[k]); return a; }, {}) : o);
const ALLOWED = ['v', 'xp', 'points', 'badges', 'daily', 'ch', 'owned', 'equipped', 'stats', 'updatedAt', 'ops'];
const ERRORS = [];                       // anything the module reports as an unexpected error

function newServer(opts) { return Object.assign({ doc: null, reads: 0, writes: 0, offline: false, loseAnswer: 0, sorted: false }, opts); }
function device(server, uid, clock, mem) {
  mem = mem || {};
  const ctx = {
    console, setTimeout: () => 0, clearTimeout: () => {}, Math, JSON, Object, Array, Number, String, Set, Promise, parseInt,
    Date: class extends Date { constructor(...a) { if (a.length) super(...a); else super(clock.now); } static now() { return clock.now++; } },
    DOMI: () => 'tile', t: k => (k === 'titles' ? ['a', 'b', 'c', 'd', 'e', 'f'] : k), randInt: n => Math.floor(Math.random() * n),
    store: { get: (k, d) => (k in mem ? JSON.parse(mem[k]) : d), set: (k, v) => { mem[k] = JSON.stringify(v); return true; }, del: k => { delete mem[k]; } },
    Accounts: { cloud: true, saveProfile() {}, async syncProgress(merge) {
      await null;
      if (server.offline) throw Object.assign(new Error('unavailable'), { code: 'unavailable' });
      const copy = server.doc ? JSON.parse(JSON.stringify(server.doc)) : null;
      const out = merge(server.sorted ? sortKeys(copy) : copy); server.reads++;
      if (out.write) {
        assert.ok(Object.keys(out.data).every(k => ALLOWED.includes(k)), 'only allowed fields are sent: ' + Object.keys(out.data));
        assert.ok(Number.isInteger(out.data.xp) && out.data.xp >= 0 && Number.isInteger(out.data.points) && out.data.points >= 0, 'whole, non-negative xp and points');
        server.doc = JSON.parse(JSON.stringify(out.data)); server.writes++;
      }
      if (server.loseAnswer > 0) { server.loseAnswer--; throw Object.assign(new Error('unavailable'), { code: 'unavailable' }); }   // saved, but the answer never arrives
      return out.data; } },
    logErr: (a, b) => { ERRORS.push(a + ' ' + b); }, window: { addEventListener() {} }, document: { addEventListener() {}, hidden: false }, navigator: {}
  };
  vm.createContext(ctx);
  vm.runInContext([pick('pad2'), pick('dayKey'), pick('weekKey'), pick('hashStr')].join('\n') + '\n' + SRC + '\n;this.Progress = Progress;', ctx);
  ctx.Progress.load(uid);
  return { P: ctx.Progress, mem, ctx, reopen() { return device(server, uid, clock, mem); } };
}
const ludo = won => ({ game: 'ludo', players: 2, won, forfeit: false, captures: 2, lost: 1, sixes: 3, home: won ? 4 : 1, rolls: 20, turns: 40, durationSec: 90 });
const dom = won => ({ game: 'dom', players: 4, won, forfeit: false, rounds: 5, roundsWon: won ? 3 : 2, outs: 2, points: 60, best: 25, blockWins: 1, durationSec: 200 });
const settle = async (...devs) => { for (let k = 0; k < 4; k++) for (const d of devs) await d.P.sync(); };

let passed = 0;
const test = async (name, fn) => { await fn(); assert.deepEqual(ERRORS, [], 'no unexpected errors'); passed++; console.log('ok  ' + name); };

(async () => {
  await test('two devices, lost answers, sudden restarts: every match counts exactly once', async () => {
    for (const sorted of [false, true]) {
      const server = newServer({ sorted }), clock = { now: Date.UTC(2026, 10, 14, 9) };
      let a = device(server, 'u1', clock), b = device(server, 'u1', clock);
      let games = 0, wins = 0, dgames = 0;
      let seed = 12345; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
      for (let i = 0; i < 400; i++) {
        const d = rnd() < 0.5 ? a : b, r = rnd();
        if (r < 0.45) { const w = rnd() < 0.5; d.P.recordGame(ludo(w)); games++; if (w) wins++; }
        else if (r < 0.6) { d.P.recordGame(dom(rnd() < 0.5)); dgames++; }
        else if (r < 0.75) { server.loseAnswer = 1; await d.P.sync(); server.loseAnswer = 0; }
        else if (r < 0.85) { if (d === a) a = a.reopen(); else b = b.reopen(); }                 // closed and opened again
        else if (r < 0.9) { server.offline = true; await d.P.sync(); server.offline = false; }
        else await d.P.sync();
      }
      await settle(a, b);
      for (const who of [a.P.data.stats, b.P.data.stats, server.doc.stats]) {
        assert.equal(who.games, games); assert.equal(who.wins, wins); assert.equal(who.dom.games, dgames);
      }
      assert.equal(a.P.data.xp, server.doc.xp); assert.equal(b.P.data.points, server.doc.points); assert.equal(a.P.data.points, b.P.data.points);
      assert.equal(Object.keys(server.doc.ops).length, 2, 'one sync id per device');
    }
  });

  await test('nothing new: a sync only reads, also when the server returns map keys sorted', async () => {
    const server = newServer({ sorted: true }), clock = { now: Date.UTC(2026, 10, 14, 9) };
    let a = device(server, 'u1', clock);
    a.P.recordGame(ludo(true)); a.P.claimDaily(); await settle(a);
    const w = server.writes;
    for (let i = 0; i < 5; i++) { a = a.reopen(); await settle(a); }                              // five quiet app starts
    assert.equal(server.writes, w, 'no writes without a change');
    a.P.recordGame(dom(true)); await settle(a);
    assert.equal(server.writes, w + 1, 'one change, one write');
  });

  await test('a challenge this version no longer has cannot be claimed again through the server copy', async () => {
    const server = newServer({ sorted: true }), clock = { now: Date.UTC(2026, 10, 14, 9) };
    const a = device(server, 'u1', clock);
    await settle(a);
    const old = JSON.parse(JSON.stringify(server.doc));
    old.ch.d[0] = { id: 'winHard1', n: 0, claimed: false };                                       // written by an older version
    server.doc = old;
    const b = device(server, 'u1', clock); await settle(b);
    const mine = b.P.challenges().daily;
    assert.ok(mine.every(c => c.id !== 'winHard1') && mine.length === 3);
    const pickOne = mine[0];
    for (let i = 0; i < pickOne.goal; i++) b.P.recordGame(pickOne.m.startsWith('dom') ? dom(true) : ludo(true));
    const first = b.P.challenges().daily.find(c => c.ready);
    assert.ok(first, 'a challenge became ready');
    assert.ok(b.P.claimChallenge(first.id), 'claimed once');
    await settle(b);
    assert.equal(b.P.claimChallenge(first.id), null, 'not a second time after syncing');
    assert.ok(server.doc.ch.d.every(c => c.id !== 'winHard1'), 'the unknown challenge is gone from the server copy');
  });

  await test('a save made before 1.3.1 (server copy under its own key) carries over without double counting', async () => {
    const server = newServer(), clock = { now: Date.UTC(2026, 10, 14, 9) };
    const a = device(server, 'u1', clock);
    a.P.recordGame(ludo(true)); await settle(a);
    const rec = JSON.parse(a.mem['prog:u1']), base = rec._s.base;
    delete rec._s;
    const mem = { 'prog:u1': JSON.stringify(rec), 'progBase:u1': JSON.stringify(base) };          // the old layout
    const b = device(server, 'u1', clock, mem);
    b.P.recordGame(ludo(false)); await settle(b);
    assert.equal(server.doc.stats.games, 2); assert.equal(b.P.data.stats.games, 2);
    assert.ok(!('progBase:u1' in b.mem), 'old key removed');
  });

  await test('fields this version does not know are kept on the device but never sent', async () => {
    const server = newServer(), clock = { now: Date.UTC(2026, 10, 14, 9) };
    const mem = { 'prog:u1': JSON.stringify({ xp: 10, points: 100, coins: 7, vip: true }) };
    const a = device(server, 'u1', clock, mem);
    a.P.recordGame(ludo(true)); await settle(a);
    assert.ok(server.doc && !('coins' in server.doc) && !('vip' in server.doc) && server.doc.stats.games === 1);
  });

  await test('a copy written by a newer version is read but not overwritten', async () => {
    const server = newServer(), clock = { now: Date.UTC(2026, 10, 14, 9) };
    const a = device(server, 'u1', clock);
    a.P.recordGame(ludo(true)); await settle(a);
    server.doc.v = 2; const w = server.writes;
    a.P.recordGame(ludo(true)); await settle(a);
    assert.equal(server.writes, w); assert.equal(a.P.data.stats.games, 2, 'still kept on the device');
  });

  console.log(`\n${passed} progress-sync tests passed`);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
