"""Account flow against a fake Firebase (web/tests/fake_firebase.js) that enforces the same checks as
firebase/firestore.rules and the recoverAccount function. Tests the real app build in server mode:
sign-up, unique names, recovery code, sign-in, profile edits, recovery, password change, account deletion,
and the awkward moments: a lost answer, no connection in the middle of sign-up or deletion, a half-made account,
a session left open on a shared device, and a session ended by the server.
Usage:  python3 web/tests/firebase_flow_test.py [chromium_path]"""
import asyncio, functools, http.server, json, os, sys, threading
from playwright.async_api import async_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
ASSETS = os.path.join(ROOT, 'app/src/main/assets')
FAKE = open(os.path.join(ROOT, 'web/tests/fake_firebase.js'), encoding='utf-8').read()
CONFIG = "window.LUDO_CONFIG = { firebase: { apiKey: 'test-key', authDomain: 'demo.firebaseapp.com', projectId: 'demo-iraq-ludo', appId: '1:1:web:1' }, functionsRegion: 'me-central2' };"
CH = (sys.argv[1] or None) if len(sys.argv) > 1 else None
T = '#screens > section:last-of-type '
ID = 'layth.test@demo-iraq-ludo.firebaseapp.com'
results = []

def check(name, cond, info=''):
    results.append((name, bool(cond)))
    print(('PASS ' if cond else 'FAIL ') + name + (f'  [{info}]' if info != '' else ''))

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass

async def main():
    srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(Quiet, directory=ASSETS))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    url = f'http://127.0.0.1:{srv.server_address[1]}/index.html'
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path=CH, args=['--no-sandbox'])
        ctx = await b.new_context(viewport={'width': 412, 'height': 880}, is_mobile=True, has_touch=True)
        await ctx.route('**/config.js', lambda r: r.fulfill(status=200, content_type='application/javascript', body=CONFIG))
        await ctx.route('**/firebase.js', lambda r: r.fulfill(status=200, content_type='application/javascript', body=FAKE))
        pg = await ctx.new_page(); pg.set_default_timeout(8000); errs = []
        pg.on('pageerror', lambda e: errs.append('PAGEERROR: ' + str(e)))
        pg.on('console', lambda m: errs.append(f'{m.type}: {m.text}') if m.type == 'error' else None)
        top = lambda: pg.evaluate("document.querySelector('#screens > section:last-of-type').dataset.screen")
        fake = lambda: pg.evaluate("FAKE.state()")
        async def act(name, w=700): await pg.click(T + f'[data-act="{name}"]'); await pg.wait_for_timeout(w)
        async def logout():
            await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)
            await act('settings'); await act('logout', 500); await pg.click('.sheet [data-x="ok"]'); await pg.wait_for_timeout(900)

        await pg.goto(url); await pg.wait_for_timeout(2300)
        await act('welcomeDone', 1000)          # skip the welcome slides
        check('server mode: sign-in screen without the test-mode notice', await top() == 'login' and await pg.locator(T + '.note').count() == 0)
        check('Firebase SDK loaded on demand, functions in me-central2', await pg.evaluate("FAKE.region()") == 'me-central2')

        # ---------- sign-up ----------
        await act('toRegister')
        await pg.fill('#rg-u', 'layth.test'); await pg.wait_for_timeout(900)
        check('availability check works before signing in', 'متاح' in await pg.inner_text('#rg-um'))
        await pg.fill('#rg-n', 'ليث'); await pg.fill('#rg-p', 'Ludo2026x'); await pg.fill('#rg-p2', 'Ludo2026x')
        await pg.click('#rg-ok'); await pg.click(T + '#rg-av [data-av="eagle"]')
        await act('doRegister', 2500)
        check('account created → recovery code screen', await top() == 'rcode')
        code = await pg.evaluate("prm().code")
        st = await fake()
        uid = st['docs'].get('usernames/layth.test', {}).get('uid')
        check('usernames/layth.test written and bound to the new uid', uid is not None)
        pl = st['docs'].get(f'players/{uid}', {})
        check('players doc passes the rules (exact fields, level 1)', sorted(pl.keys()) == sorted(['username', 'name', 'avatar', 'lang', 'level', 'createdAt', 'lastSeen']) and pl['level'] == 1 and pl['avatar'] == 'eagle')
        rc = st['docs'].get(f'recovery/{uid}', {})
        check('recovery doc holds a hash only (no code, no password)', rc.get('algo') == 'pbkdf2-sha256' and code not in json.dumps(rc) and 'Ludo2026x' not in json.dumps(st['docs']))
        check("internal sign-in ID uses the project's own Firebase domain (no mailbox can exist there)", ID in st['users'], list(st['users'].keys()))
        check('recovery doc cannot be read by the app', await pg.evaluate("FB.getDoc(FB.doc(null, 'recovery', Accounts.user.uid)).then(() => 'read', e => e.code)") == 'permission-denied')
        await pg.click('#rc-ok'); await act('rcDone', 1000)
        check('home after sign-up', await top() == 'home')

        async def register(user, name, pw, wait=2500):
            await pg.evaluate("reset('register')"); await pg.wait_for_timeout(600)
            await pg.fill('#rg-u', user); await pg.wait_for_timeout(700)
            await pg.fill('#rg-n', name); await pg.fill('#rg-p', pw); await pg.fill('#rg-p2', pw); await pg.click('#rg-ok')
            await act('doRegister', wait)

        # ---------- sign-up when the answer from the server is lost: sent again, counted once ----------
        await logout()
        await pg.evaluate("window.__fakeLoseAck = 1")
        await register('ack.user', 'حيدر', 'Ackno2026x')
        st = await fake()
        check('sign-up survives a lost answer (not reported as "taken")', await top() == 'rcode' and 'usernames/ack.user' in st['docs'], await top())
        await pg.click('#rc-ok'); await act('rcDone', 1000)

        # ---------- sign-up while the database cannot be reached: nothing half-made stays ----------
        await logout()
        await pg.evaluate("window.__fakeOffline = true")
        await register('net.user', 'نور', 'Netwo2026x', 2000)
        st = await fake()
        check('no connection during sign-up: clear message, no account left behind',
              'ماكو إنترنت' in await pg.inner_text('#rg-msg') and not any('net.user' in k for k in list(st['users']) + list(st['docs'])), await pg.inner_text('#rg-msg'))
        # ... and when even the clean-up fails, the account is finished at the next sign-in
        await pg.evaluate("window.__fakeAuthDown = true")
        await register('half.made', 'زهراء', 'Halfm2026x', 2000)
        st = await fake()
        check('half-made account: sign-in ID exists but no documents yet', any('half.made' in k for k in st['users']) and not any('half.made' in k for k in st['docs']))
        await pg.reload(); await pg.wait_for_timeout(2500)             # restart: the switches are gone, the SDK still holds the half-made session
        check('a half-made account is not opened as if it were complete', await top() == 'login' and await pg.evaluate("Accounts.user") is None, await top())
        await pg.fill('#li-u', 'half.made'); await pg.fill('#li-p', 'Halfm2026x'); await act('doLogin', 2200)
        st = await fake()
        huid = st['docs'].get('usernames/half.made', {}).get('uid')
        check('signing in finishes the account and shows its recovery code', await top() == 'rcode' and huid is not None
              and f'players/{huid}' in st['docs'] and f'recovery/{huid}' in st['docs'] and len(await pg.evaluate("prm().code")) == 19, await top())
        await pg.click('#rc-ok'); await act('rcDone', 1000)
        check('finished account opens the home screen', await top() == 'home' and await pg.evaluate("Accounts.user.username") == 'half.made')

        # ---------- the same name cannot be taken twice ----------
        await logout()
        await act('toRegister')
        await pg.fill('#rg-u', 'layth.test'); await pg.wait_for_timeout(900)
        check('taken name is flagged while typing', 'مأخوذ' in await pg.inner_text('#rg-um'))
        await pg.fill('#rg-n', 'ثاني'); await pg.fill('#rg-p', 'Other2026x'); await pg.fill('#rg-p2', 'Other2026x'); await pg.click('#rg-ok')
        await act('doRegister', 1500)
        check('taken name is refused on submit', 'مأخوذ' in await pg.inner_text('#rg-msg'))
        await pg.evaluate("reset('login')"); await pg.wait_for_timeout(600)

        # ---------- sign in ----------
        await pg.fill('#li-u', 'layth.test'); await pg.fill('#li-p', 'nope-pass1'); await act('doLogin', 1200)
        check('wrong password refused', 'غلط' in await pg.inner_text('#li-msg'))
        await pg.fill('#li-p', 'Ludo2026x'); await act('doLogin', 1800)
        check('sign in with username + password', await top() == 'home' and await pg.evaluate("Accounts.user.name") == 'ليث')
        await pg.reload(); await pg.wait_for_timeout(2500)
        check('session kept after restarting the app', await top() == 'home')

        # ---------- profile edits go to Firestore ----------
        await act('profile')
        await act('editName', 600); await pg.fill('#nm-in', 'أبو علي'); await pg.click('.sheet [data-x="ok"]'); await pg.wait_for_timeout(900)
        await act('pickAvatar', 600); await pg.click('.sheet [data-av="fish"]'); await pg.wait_for_timeout(900)
        pl = (await fake())['docs'][f'players/{uid}']
        check('name and picture saved to the profile doc', pl['name'] == 'أبو علي' and pl['avatar'] == 'fish', (pl['name'], pl['avatar']))
        denied = await pg.evaluate("FB.updateDoc(FB.doc(null, 'players', Accounts.user.uid), { level: 99 }).then(() => 'written', e => e.code)")
        check('the app cannot raise its own level', denied == 'permission-denied')
        stolen = await pg.evaluate("FB.writeBatch().set(FB.doc(null, 'usernames', 'someone.else'), { uid: Accounts.user.uid, createdAt: 1 }).commit().then(() => 'written', e => e.code)")
        check('a second name cannot be claimed by the same account', stolen == 'permission-denied')
        # a session left open on a shared device: the recovery code cannot be swapped without the password
        await pg.evaluate("FAKE.ageSession(11 * 60 * 1000)")
        gone = await pg.evaluate("FAKE.raw([{ t: 'delete', path: 'recovery/' + Accounts.user.uid }])")
        swap = await pg.evaluate("FAKE.raw([{ t: 'set', path: 'recovery/' + Accounts.user.uid, data: { algo: 'pbkdf2-sha256', iter: 120000, salt: 'A'.repeat(24), hash: 'B'.repeat(44), createdAt: 1 } }])")
        check('an old session cannot remove or replace the recovery code', gone == 'permission-denied' and swap == 'permission-denied', (gone, swap))

        # ---------- recovery with the code ----------
        await logout()
        await act('toRecover')
        await pg.fill('#rv-u', 'layth.test'); await pg.fill('#rv-c', 'AAAA-BBBB-CCCC-DDDD'); await pg.fill('#rv-p', 'NewPass2026'); await pg.fill('#rv-p2', 'NewPass2026')
        await act('doRecover', 1800)
        check('wrong recovery code refused', 'غلط' in await pg.inner_text('#rv-msg'))
        for i in range(5): await act('doRecover', 900)
        check('after 5 wrong codes the server says: too many attempts', 'محاولات كثيرة' in await pg.inner_text('#rv-msg'), await pg.inner_text('#rv-msg'))
        await pg.fill('#rv-c', code); await act('doRecover', 3000)              # the right code still works: guessing cannot lock the owner out
        check('right code sets the new password and signs in', await top() == 'rcode' and await pg.evaluate("prm().renewed") == True)
        code2 = await pg.evaluate("prm().code")
        check('a new recovery code is issued', code2 != code and len(code2) == 19)
        await pg.click('#rc-ok'); await act('rcDone', 1000)
        await logout()
        await pg.fill('#li-u', 'layth.test'); await pg.fill('#li-p', 'Ludo2026x'); await act('doLogin', 1200)
        check('old password no longer works', await top() == 'login')
        await pg.fill('#li-p', 'NewPass2026'); await act('doLogin', 1800)
        check('new password works', await top() == 'home')

        # ---------- recovery when signing in fails right after it: the new code is still shown ----------
        await logout()
        await act('toRecover')
        await pg.fill('#rv-u', 'layth.test'); await pg.fill('#rv-c', code2); await pg.fill('#rv-p', 'Fourth2026x'); await pg.fill('#rv-p2', 'Fourth2026x')
        await pg.evaluate("window.__fakeAuthDown = true")
        await act('doRecover', 3000)
        code3 = await pg.evaluate("prm().code") if await top() == 'rcode' else ''
        check('password changed but sign-in failed: the new recovery code is not lost', await top() == 'rcode' and len(code3) == 19 and code3 != code2 and await pg.evaluate("prm().signIn") == True, await top())
        await pg.evaluate("window.__fakeAuthDown = false")
        await pg.click('#rc-ok'); await act('rcDone', 1000)
        check('then the player is sent to sign in', await top() == 'login')
        await pg.fill('#li-u', 'layth.test'); await pg.fill('#li-p', 'Fourth2026x'); await act('doLogin', 1800)
        check('and signs in with the new password', await top() == 'home')

        # ---------- the server ends the session (password changed on another device) ----------
        await pg.evaluate("FAKE.revoke()"); await pg.wait_for_timeout(1200)
        check('session ended by the server: back to sign-in, signed out here too', await top() == 'login' and await pg.evaluate("Accounts.user") is None and await pg.evaluate("Accounts.closing") is False, await top())
        await pg.fill('#li-u', 'layth.test'); await pg.fill('#li-p', 'Fourth2026x'); await act('doLogin', 1800)
        check('signing in again works', await top() == 'home')

        # ---------- change password ----------
        await act('settings'); await act('changePw', 600)
        await pg.fill('#cp-o', 'Fourth2026x'); await pg.fill('#cp-n', 'Third2026x'); await pg.fill('#cp-n2', 'Third2026x')
        await pg.click('.sheet [data-x="ok"]'); await pg.wait_for_timeout(1800)
        check('password changed after re-entering the current one', (await fake())['users'][ID]['password'] == 'Third2026x')

        # ---------- delete account ----------
        await pg.evaluate("reset('settings')"); await pg.wait_for_timeout(600)
        await pg.click(T + '[data-act="deleteAcc"]'); await pg.wait_for_timeout(600)
        await pg.evaluate("FAKE.ageSession(30 * 60 * 1000)")           # an old session: re-entering the password makes it fresh again
        await pg.evaluate("window.__fakeAuthDown = true")              # the last step (removing the sign-in ID) fails the first time
        await pg.fill('#da-p', 'Third2026x'); await pg.click('.sheet [data-x="ok"]'); await pg.wait_for_timeout(2200)
        st = await fake()
        check('deletion interrupted: documents gone, the player is told and stays signed in',
              ID in st['users'] and 'usernames/layth.test' not in st['docs'] and await top() == 'settings' and (await pg.inner_text('#da-msg')) != '', await pg.inner_text('#da-msg'))
        await pg.evaluate("window.__fakeAuthDown = false")
        await pg.click('.sheet [data-x="ok"]'); await pg.wait_for_timeout(2200)
        st = await fake()
        check('trying again finishes the deletion: back to sign-in', await top() == 'login')
        check('name, profile and recovery docs removed', not any(k.endswith(uid) or k == 'usernames/layth.test' for k in st['docs']), list(st['docs'].keys()))
        check('sign-in ID removed', ID not in st['users'])
        denials = [l for l in st['log'] if l[0] == 'DENIED']
        check('the app itself never hit a rules denial (only the 4 deliberate attempts)', len(denials) == 4, denials)

        check('no console errors', not errs, '\n'.join(errs[:6]))
        print(f"\n{sum(1 for _, ok in results if ok)}/{len(results)} checks passed")
        await b.close()
    srv.shutdown()

asyncio.run(main())
