/* Ludo simulation: node web/tests/sim.js [games]
   Plays many complete games with fair random dice, checks invariants after every step,
   and reports how the computer player (one level) does against a player who moves at random. */
const E = require('../src/01_engine.js');
const AI = require('../src/02_ai.js');
const N = +process.argv[2] || 600;

// small seeded PRNG so runs are reproducible
function rng(seed) { let s = seed >>> 0; return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

// who: colour → 'ai' or 'random'
function play(levels, seed) {
  const colors = Object.keys(levels);
  const st = E.createGame({ colors });
  const r = rng(seed);
  let steps = 0;
  while (st.phase !== 'over') {
    if (++steps > 5000) throw new Error('game did not finish');
    const dice = 1 + Math.floor(r() * 6);
    E.roll(st, dice);
    if (!E.validate(st)) throw new Error('invalid after roll');
    if (st.phase === 'move') {
      const color = E.current(st);
      const legal = E.legalMoves(st);
      const t = levels[color] === 'ai' ? AI.choose(st, r) : legal[Math.floor(r() * legal.length)].t;
      if (!E.legalMoves(st).some(m => m.t === t)) throw new Error('AI chose an illegal move');
      const ev = E.move(st, t);
      if (!E.validate(st)) throw new Error('invalid after move');
      // invariant: after landing on a normal square, no single opponent token is left there
      const mv = ev.find(e => e.type === 'move');
      const g = E.globalOf(color, mv.to);
      if (g >= 0 && !E.isSafe(g)) for (const c of st.colors) {
        if (c !== color && E.tokensAt(st, c, g).length === 1) throw new Error(`missed capture of ${c} on square ${g}`);
      }
    }
  }
  return { winner: st.winner, rolls: Object.values(st.stats).reduce((s, x) => s + x.rolls, 0) };
}

function duel(a, b, games) {
  let wa = 0, rolls = 0;
  for (let i = 0; i < games; i++) {
    // alternate seats so seat order does not bias the result
    const levels = i % 2 ? { red: a, yellow: b } : { red: b, yellow: a };
    const aColor = i % 2 ? 'red' : 'yellow';
    const res = play(levels, 1000 + i);
    if (res.winner === aColor) wa++;
    rolls += res.rolls;
  }
  return { rate: wa / games, avgRolls: rolls / games };
}

const t0 = Date.now();
const out = [];
for (const [a, b] of [['ai', 'random'], ['ai', 'ai']]) {
  const d = duel(a, b, N);
  out.push(`2 players, ${a} vs ${b}: first wins ${(d.rate * 100).toFixed(1)}%  (avg ${d.avgRolls.toFixed(0)} rolls/game)`);
}
// four-player games: the computer against three random players, seats rotated
let hw = 0;
for (let i = 0; i < N; i++) {
  const seats = ['red', 'green', 'yellow', 'blue'];
  const hc = seats[i % 4];
  const levels = {}; seats.forEach(c => { levels[c] = c === hc ? 'ai' : 'random'; });
  if (play(levels, 50000 + i).winner === hc) hw++;
}
out.push(`4 players, computer vs 3 random: computer wins ${(hw / N * 100).toFixed(1)}% (fair share 25%)`);
console.log(out.join('\n'));
console.log(`\n${N * 3} complete games, all invariants held (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
