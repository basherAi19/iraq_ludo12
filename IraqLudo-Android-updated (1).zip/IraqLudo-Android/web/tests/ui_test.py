"""End-to-end UI test (headless Chromium via Playwright).
Usage:  python3 web/tests/ui_test.py [chromium_path] [screenshot_dir]
Runs the Android edition (app/src/main/assets/index.html) in on-device mode: accounts, Ludo, dominoes,
rewards in game dinars, free boards, one hidden computer level, the design settings and celebrations (1.4),
other languages and screen sizes."""
import asyncio, os, sys, json
from playwright.async_api import async_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
URL = 'file://' + os.path.join(ROOT, 'app/src/main/assets/index.html')
CH = (sys.argv[1] or None) if len(sys.argv) > 1 else None
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(ROOT, 'web/tests/shots')
os.makedirs(OUT, exist_ok=True)
T = '#screens > section:last-of-type '
results = []

def check(name, cond, info=''):
    results.append((name, bool(cond)))
    print(('PASS ' if cond else 'FAIL ') + name + (f'  [{info}]' if info != '' else ''))

AUTOPLAY = """async (maxMs) => {
  const t0 = Date.now();
  while (Date.now() - t0 < maxMs) {
    const top = document.querySelector('#screens > section:last-of-type').dataset.screen;
    if (top !== 'game') return top;
    if (!G.busy && G.alive && !G.paused && isHuman(E.current(G.st))) {
      if (G.st.phase === 'roll') humanRoll();
      else if (G.st.phase === 'move') humanMove(LudoAI.choose(G.st));
    }
    await new Promise(r => setTimeout(r, 12));
  }
  return 'timeout';
}"""

DOMAUTO = """async ([maxMs, stopAtSheet]) => {
  const t0 = Date.now();
  while (Date.now() - t0 < maxMs) {
    const top = document.querySelector('#screens > section:last-of-type').dataset.screen;
    if (top !== 'dgame') return top;
    const ok = document.querySelector('.sheet [data-x="ok"]');
    if (ok) { if (stopAtSheet) return 'sheet'; ok.click(); }
    else if (!DG.busy && DG.alive && !DG.paused && DG.st.phase === 'play' && DG.st.turn === 0) {
      if (DE.legalMoves(DG.st).length) { const c = DominoAI.choose(DG.st); dHumanPlay(c.id, c.side); }
      else if (DG.st.stock.length) dHumanDraw(true);
    }
    await new Promise(r => setTimeout(r, 12));
  }
  return 'timeout';
}"""
LEVEL_WORDS = ['سهل', 'متوسط', 'صعب', 'مستوى الكمبيوتر', 'اختار المستوى', 'Easy', 'Medium', 'Hard', 'Computer level']

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path=CH, args=['--no-sandbox', '--autoplay-policy=no-user-gesture-required'])
        ctx = await b.new_context(viewport={'width': 412, 'height': 880}, device_scale_factor=2, is_mobile=True, has_touch=True)
        pg = await ctx.new_page(); errs = []
        pg.set_default_timeout(8000)
        pg.on('pageerror', lambda e: errs.append('PAGEERROR: ' + str(e)))
        pg.on('console', lambda m: errs.append(f'{m.type}: {m.text}') if m.type in ('error', 'warning') else None)
        top = lambda: pg.evaluate("document.querySelector('#screens > section:last-of-type').dataset.screen")
        async def shot(n, w=450): await pg.wait_for_timeout(w); await pg.screenshot(path=f'{OUT}/{n}.png')
        async def act(name, w=650): await pg.click(T + f'[data-act="{name}"]'); await pg.wait_for_timeout(w)

        await pg.goto(URL); await pg.wait_for_timeout(2300)
        check('first launch opens the welcome slides', await top() == 'welcome')
        await shot('01_welcome', 300)
        slide = lambda: pg.evaluate("prm().i")
        await act('welcomeNext', 700)
        check('next moves to slide 2', await slide() == 1)
        # swipe back (Arabic: the previous slide is to the right, so drag left)
        box = await pg.locator(T + '.wview').bounding_box()
        y = box['y'] + box['height'] / 2
        await pg.mouse.move(box['x'] + 120, y); await pg.mouse.down(); await pg.mouse.move(box['x'] + 20, y, steps=6); await pg.mouse.up(); await pg.wait_for_timeout(700)
        check('swipe goes back to slide 1', await slide() == 0)
        await pg.mouse.move(box['x'] + 40, y); await pg.mouse.down(); await pg.mouse.move(box['x'] + 220, y, steps=6); await pg.mouse.up(); await pg.wait_for_timeout(700)
        check('swipe forward to slide 2', await slide() == 1)
        await pg.click(T + '[data-act="pickLang"][data-v="en"]'); await pg.wait_for_timeout(600)
        check('language switch on the welcome screen keeps the slide', await pg.evaluate("document.documentElement.dir") == 'ltr' and await slide() == 1)
        await pg.click(T + '[data-act="pickLang"][data-v="ar"]'); await pg.wait_for_timeout(600)
        await act('welcomeNext', 700)
        check('last slide says يلا نلعب!', 'يلا نلعب' in await pg.inner_text('#wl-next'))
        await shot('02_welcome_last', 100)
        await act('welcomeNext', 1200)
        check('then sign-in screen', await top() == 'login')
        check('welcome is not shown again', await pg.evaluate("store.get('welcomed')") == True)
        check('test-mode notice shown without a server', await pg.locator(T + '.note').count() == 1)

        # ---------- register ----------
        await act('toRegister', 700)
        await pg.fill('#rg-u', 'Layth.Test')
        await pg.wait_for_timeout(700)
        check('username lower-cased while typing', await pg.input_value('#rg-u') == 'layth.test')
        check('availability check says available', 'متاح' in await pg.inner_text('#rg-um'))
        await pg.fill('#rg-n', 'أبو علي www.x.com'); await pg.fill('#rg-p', 'short'); await pg.fill('#rg-p2', 'short')
        await act('doRegister', 300)
        check('name with a link is rejected', 'روابط' in await pg.inner_text('#rg-nm'))
        await pg.fill('#rg-n', 'ليث'); await act('doRegister', 300)
        check('weak password rejected', '8' in await pg.inner_text('#rg-msg'))
        await pg.fill('#rg-p', 'Ludo2026x'); await pg.fill('#rg-p2', 'Ludo2026y'); await act('doRegister', 300)
        check('password mismatch rejected', 'متطابقات' in await pg.inner_text('#rg-msg'))
        await pg.fill('#rg-p2', 'Ludo2026x'); await act('doRegister', 300)
        check('terms must be accepted', 'توافق' in await pg.inner_text('#rg-msg'))
        await pg.click('#rg-ok'); await pg.click(T + '#rg-av [data-av="camel"]')
        await shot('03_register', 100)
        await act('doRegister', 2500)
        check('recovery code screen after sign-up', await top() == 'rcode')
        code = await pg.evaluate("prm().code")
        check('recovery code format XXXX-XXXX-XXXX-XXXX', len(code) == 19 and code.count('-') == 3, code)
        check('continue disabled until saved', await pg.evaluate("document.querySelector('#rc-go').disabled"))
        await shot('04_rcode', 100)
        users = await pg.evaluate("JSON.stringify(store.get('users'))")
        check('password never stored in plain text', 'Ludo2026x' not in users and 'pbkdf2' in users)
        await pg.click('#rc-ok'); await act('rcDone', 900)
        check('home after confirming the code', await top() == 'home')
        check('avatar chosen at sign-up is used', await pg.evaluate("Accounts.user.avatar") == 'camel')
        await shot('05_home', 300)

        # ---------- sign out, wrong password, lock, sign in ----------
        await act('settings', 700); await act('logout', 500); await pg.click('.sheet [data-x="ok"]'); await pg.wait_for_timeout(900)
        check('signed out to sign-in screen', await top() == 'login')
        for i in range(5):
            await pg.fill('#li-u', 'layth.test'); await pg.fill('#li-p', 'wrong-pass1'); await act('doLogin', 900)
        msg = await pg.inner_text('#li-msg')
        check('wrong password rejected', 'غلط' in msg or 'محاولات' in msg, msg)
        await pg.fill('#li-p', 'Ludo2026x'); await act('doLogin', 900)
        check('locked after 5 failures even with the right password', 'محاولات' in await pg.inner_text('#li-msg'))
        await pg.evaluate("store.del('lock:layth.test')")
        await act('doLogin', 1500)
        check('sign in with username + password', await top() == 'home')
        await pg.reload(); await pg.wait_for_timeout(2300)
        check('still signed in after reload', await top() == 'home')

        # ---------- recovery with the code ----------
        await act('settings', 700); await act('logout', 500); await pg.click('.sheet [data-x="ok"]'); await pg.wait_for_timeout(900)
        await act('toRecover', 700)
        await pg.fill('#rv-u', 'layth.test'); await pg.fill('#rv-c', 'AAAA-BBBB-CCCC-DDDD'); await pg.fill('#rv-p', 'NewPass2026'); await pg.fill('#rv-p2', 'NewPass2026')
        await act('doRecover', 1500)
        check('wrong recovery code rejected', 'غلط' in await pg.inner_text('#rv-msg'))
        await pg.fill('#rv-c', code.lower().replace('-', ' ')); await act('doRecover', 2500)
        check('right recovery code resets the password', await top() == 'rcode')
        new_code = await pg.evaluate("prm().code")
        check('a new recovery code replaces the old one', new_code != code and len(new_code) == 19)
        await pg.click('#rc-ok'); await act('rcDone', 900)
        await act('settings', 700); await act('logout', 500); await pg.click('.sheet [data-x="ok"]'); await pg.wait_for_timeout(900)
        await pg.fill('#li-u', 'layth.test'); await pg.fill('#li-p', 'NewPass2026'); await act('doLogin', 1500)
        check('sign in with the new password', await top() == 'home')

        # ---------- every menu screen ----------
        for name, fn in [('daily', '06_daily'), ('challenges', '07_challenges'), ('shop', '08_shop'), ('profile', '09_profile'), ('online', '10_online'), ('howto', '13_howto')]:
            await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)
            await act(name, 800); check(f'{name} screen opens', await top() == {'online': 'online'}.get(name, name)); await shot(fn, 100)
        await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)
        txt = await pg.inner_text('#screens')
        check('no payment wording anywhere on home', not any(w in txt for w in ['مدفوع', 'اشتراك', 'باقة', 'الباقات']))
        check('online is marked coming soon', 'قريباً' in await pg.inner_text(T + '.bigbtn.online'))
        check('game money is shown in Iraqi dinars, not coins', 'د.ع' in await pg.inner_text(T + '.pts') and 'دينار' in txt and 'عملة' not in txt and 'عملات' not in txt)
        check('home offers both games: Ludo and dominoes', await pg.locator(T + '[data-act="playLudo"]').count() == 1 and await pg.locator(T + '[data-act="playDom"]').count() == 1)
        await act('online', 700)
        otxt = await pg.inner_text(T)
        check('online screen says it will be free, no plans', 'مجاني' in otxt and 'الباقات' not in otxt and await pg.locator(T + '[data-act="plans"]').count() == 0)
        await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)
        await act('online', 700); await act('matchmaking', 700); await shot('12a_match', 100)
        await act('mmStart', 500); await shot('12b_match_off', 100)
        check('matchmaking says the server is off (no fake players)', 'ما تفعّل' in await pg.inner_text(T))

        # daily reward + shop
        await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)
        pts0 = await pg.evaluate("Progress.data.points")
        await act('daily', 700); await act('claimDaily', 700)
        pts1 = await pg.evaluate("Progress.data.points")
        check('daily reward adds points once', pts1 == pts0 + 20, (pts0, pts1))
        check('cannot claim twice the same day', await pg.locator(T + '[data-act="claimDaily"]').count() == 0)
        await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)
        await act('shop', 700); await pg.click(T + '[data-act="buy"][data-id="tea"]'); await pg.wait_for_timeout(500)
        check('unlock an avatar with free points', await pg.evaluate("Accounts.user.avatar") == 'tea' and await pg.evaluate("Progress.data.points") == pts1 - 80)
        await pg.click(T + '[data-act="shopTab"][data-v="board"]'); await pg.wait_for_timeout(400)
        check('boards: every board is free (no price, no unlock button)', await pg.locator(T + '[data-act="buy"]').count() == 0 and await pg.locator(T + '.item').count() == 6)
        pts2 = await pg.evaluate("Progress.data.points")
        await pg.click(T + '[data-act="equip"][data-id="babylon"]'); await pg.wait_for_timeout(400)
        check('any board can be chosen, and it costs nothing', await pg.evaluate("Progress.data.equipped.board") == 'babylon' and await pg.evaluate("Progress.data.points") == pts2)
        await pg.click(T + '[data-act="shopTab"][data-v="dice"]'); await pg.wait_for_timeout(400)
        await pg.click(T + '[data-act="buy"][data-id="palm"]'); await pg.wait_for_timeout(400)
        check('not enough dinars for a dice is refused', await pg.evaluate("Progress.data.equipped.dice") == 'classic')
        await pg.click(T + '[data-act="shopTab"][data-v="board"]'); await pg.wait_for_timeout(300)
        await shot('08b_shop_boards', 100)

        # ---------- offline games ----------
        await pg.evaluate("window.__LUDO_TURBO = true")
        async def play_game(players, color, tag):
            await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)
            await act('playLudo', 700)
            await pg.click(T + f'[data-act="setPlayers"][data-v="{players}"]'); await pg.wait_for_timeout(200)
            await pg.click(T + f'[data-act="setColor"][data-v="{color}"]'); await pg.wait_for_timeout(200)
            if tag == 'ludo2':
                await shot('14_offsetup', 100)
                stxt = await pg.inner_text(T)
                check('Ludo setup: no level choice, start straight away, stake shown in dinars', not any(w in stxt for w in LEVEL_WORDS) and await pg.locator(T + '[data-act="startGame"]').count() == 1 and '50' in await pg.inner_text(T + '.stake') and 'دينار' in await pg.inner_text(T + '.stake'))
            await act('startGame', 1200)
            check(f'{tag}: game screen opens', await top() == 'game')
            if tag == 'ludo2':
                gtxt = await pg.inner_text(T)
                check('Ludo game: no level shown on the bar or the player tags', not any(w in gtxt for w in LEVEL_WORDS))
            res = await pg.evaluate(AUTOPLAY, 240000)
            check(f'{tag}: game reaches the result screen', res == 'result', res)
            return await pg.evaluate("JSON.stringify({won: prm().won, winner: prm().winner, reward: prm().reward, ranks: prm().ranks.length})")

        g0 = await pg.evaluate("Progress.data.stats.games")
        r1 = json.loads(await play_game(2, 'blue', 'ludo2')); await shot('17_result_' + ('win' if r1['won'] else 'lose'), 300)
        c1 = r1['reward']['coins']
        check('result shows the dinar change with the banknote icon', (await pg.locator(T + '.earn .dinar').count() == (1 if c1 else 0)) and (not c1 or (str(abs(c1)) in await pg.inner_text(T + '.earn') and 'دينار' in await pg.inner_text(T + '.earn'))), c1)
        r2 = json.loads(await play_game(4, 'red', 'ludo4'))
        r3 = json.loads(await play_game(2, 'green', 'ludo2b'))
        st = await pg.evaluate("JSON.stringify(Progress.data.stats)")
        st = json.loads(st)
        check('stats count 3 games', st['games'] == g0 + 3, st['games'])
        check('wins + losses = games', st['wins'] + st['losses'] == st['games'])
        check('4-player game counted', st['p4']['g'] >= 1)
        check('XP and points awarded', r1['reward']['xp'] > 0 and r2['reward']['xp'] > 0)
        check('each match moves coins by 50 (win +50, loss −50 or what is left)', all(r['reward']['coins'] == 50 if r['won'] else -50 <= r['reward']['coins'] <= 0 for r in (r1, r2, r3)), [(r['won'], r['reward']['coins']) for r in (r1, r2, r3)])
        econ = json.loads(await pg.evaluate("""(() => { const g = won => ({ game: 'ludo', players: 2, won, forfeit: false, captures: 0, lost: 0, sixes: 0, home: 0, rolls: 5, turns: 5, durationSec: 30 });
          const keep = Progress.data.points, out = [];
          const run = won => { const r = Progress.recordGame(g(won)); out.push(r.coins, Progress.data.points - r.bonus); Progress.data.points -= r.bonus; };  // level-up bonus set aside
          Progress.data.points = 120; run(false);
          Progress.data.points = 30; run(false);
          run(false);
          Progress.data.points = 10; run(true);
          Progress.data.points = keep; Progress.save(); return JSON.stringify(out); })()"""))
        check('dinars: loss −50, never below zero, win +50', econ == [-50, 70, -30, 0, 0, 0, 50, 60], econ)

        # ---------- game screen look + save/resume ----------
        await pg.evaluate("window.__LUDO_TURBO = false")
        await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)
        await act('playLudo', 700)
        await pg.click(T + '[data-act="setPlayers"][data-v="4"]'); await act('startGame', 1500)
        # fast-forward a little, then play at normal speed: tap the roll button and stop when a choice of tokens is offered
        await pg.evaluate("window.__LUDO_TURBO = true"); await pg.evaluate(AUTOPLAY, 2500); await pg.evaluate("window.__LUDO_TURBO = false")
        if await top() != 'game':          # the fast-forward finished the whole match: start a fresh one
            await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)
            await act('playLudo', 700); await pg.click(T + '[data-act="setPlayers"][data-v="4"]'); await act('startGame', 1500)
        tapped = False
        for i in range(400):                     # wait for your turn to roll
            s = json.loads(await pg.evaluate("JSON.stringify({h: isHuman(E.current(G.st)), ph: G.st.phase, busy: G.busy})"))
            if s['h'] and not s['busy'] and s['ph'] == 'roll' and await pg.locator(T + '[data-act="roll"]').count(): break
            await pg.wait_for_timeout(250)
        # two of your tokens on the track, so the roll always offers a real choice
        await pg.evaluate("(() => { G.st.tokens[G.setup.human] = [0, 10, -1, -1]; G.view.layout(G.st); saveGame(); })()")
        await pg.click(T + '[data-act="roll"]'); tapped = True
        for i in range(60):
            s = json.loads(await pg.evaluate("JSON.stringify({h: isHuman(E.current(G.st)), ph: G.st.phase, busy: G.busy, n: G.st.phase === 'move' ? new Set(E.legalMoves(G.st).map(m => m.from + ':' + m.to)).size : 0})"))
            if s['h'] and not s['busy'] and s['ph'] == 'move' and s['n'] >= 2: break
            await pg.wait_for_timeout(200)
        check('roll button works by tapping', tapped)
        check('movable tokens are highlighted', await pg.locator(T + '.tok.can').count() >= 2)
        check('keyboard: only the movable tokens can be reached with Tab', await pg.locator(T + '.tok.can[tabindex="0"]').count() == await pg.locator(T + '.tok.can').count()
              and await pg.locator(T + '.tok:not(.can)[tabindex="0"]').count() == 0)
        await shot('16_game', 200)
        await pg.click(T + '[data-act="emoji"]'); await pg.wait_for_timeout(500); await shot('16b_emoji_tray', 100)
        await pg.click('.sheet [data-e="0"]'); await pg.wait_for_timeout(400)
        check('emoji appears (a big flying emoji in full motion, a bubble otherwise)', await pg.locator(T + '.bubble').count() + await pg.locator('#fxl .bigemo').count() >= 1)
        await pg.click(T + '.tok.can >> nth=0'); await pg.wait_for_timeout(1200)
        check('tapping a highlighted token moves it', await pg.evaluate("G.st.phase !== 'move' || !isHuman(E.current(G.st))"))
        await shot('16c_bubble', 50)
        await pg.click(T + '[data-act="gMenu"]'); await pg.wait_for_timeout(600); await shot('16d_menu', 100)
        check('menu pauses the game', await pg.evaluate("G.paused") == True)
        await pg.click('.sheet [data-m="exit"]'); await pg.wait_for_timeout(1200)
        check('save and exit returns home with a resume card', await top() == 'home' and await pg.locator(T + '[data-act="resume"]').count() == 1)
        snap = "JSON.stringify([S.tokens, S.turn, S.phase, S.dice, S.seq])"
        saved = await pg.evaluate("(() => { const S = savedGame().st; return " + snap + "; })()")
        await pg.reload(); await pg.wait_for_timeout(2300)
        await act('resume', 150)   # read before the next turn starts
        check('resume restores the exact game state', await pg.evaluate("(() => { const S = G.st; return " + snap + "; })()") == saved)
        await pg.wait_for_timeout(1200)
        await pg.evaluate("window.__LUDO_TURBO = true")
        res = await pg.evaluate(AUTOPLAY, 240000)
        check('resumed game finishes', res == 'result', res)

        # ---------- dominoes ----------
        await pg.evaluate("window.__LUDO_TURBO = false; reset('home')"); await pg.wait_for_timeout(500)
        await act('playDom', 700)
        dtxt = await pg.inner_text(T)
        check('dominoes setup: players, match length (50 or 100), stake in dinars, no level', await top() == 'domSetup' and '50' in dtxt and '100' in dtxt and 'دينار' in await pg.inner_text(T + '.stake') and not any(w in dtxt for w in LEVEL_WORDS))
        await shot('30_dom_setup', 100)
        await act('startDom', 1800)
        n_hand = await pg.locator(T + '#dhand .dt').count()
        played = await pg.evaluate("DG.st.stats[0].played")           # you may already have opened with your highest double
        check('dominoes: 7 tiles in your hand, 14 in the pile', await top() == 'dgame' and n_hand + played == 7 and played <= 1 and await pg.evaluate("DG.st.stock.length") == 14, (n_hand, played))
        check('dominoes: the table uses the chosen board (Babylon)', 'ds-babylon' in await pg.evaluate("DG.el.className"))
        gtx = await pg.inner_text(T)
        check('dominoes: no level shown in the game', not any(w in gtx for w in LEVEL_WORDS))
        for i in range(40):
            if await pg.evaluate("DG.st.turn === 0 && !DG.busy && DG.st.first !== null"): break
            await pg.wait_for_timeout(250)
        await shot('31_dom_game', 300)
        CRAFT = """([players, mine, stockN]) => {
          const id = (a, b) => DE.TILES.findIndex(t => t[0] === Math.min(a, b) && t[1] === Math.max(a, b));
          const st = DE.createMatch({ players }); st.round = 1; st.phase = 'play';
          st.first = { id: id(6, 6), a: 6, b: 6 }; st.L = [{ id: id(2, 6), i: 6, o: 2 }]; st.R = [{ id: id(5, 6), i: 6, o: 5 }];
          const table = [id(6, 6), id(2, 6), id(5, 6)], my = mine.map(([a, b]) => id(a, b));
          const rest = DE.TILES.map((_, i) => i).filter(i => !table.includes(i) && !my.includes(i));
          st.hands = [my]; let k = 0;
          for (let s = 1; s < players; s++) { const n = s === players - 1 ? rest.length - k - stockN : 7; st.hands.push(rest.slice(k, k + n)); k += n; }
          st.stock = rest.slice(k); st.turn = 0; st.opener = 0; st.lead = null; st.voids = st.hands.map(() => [false, false, false, false, false, false, false]);
          DG.gen++; DG.busy = false; DG.paused = false; DG.sel = null; DG.st = st;
          $$('#dworld [data-k]', DG.el).forEach(x => x.remove()); DG.view = null; dRenderAll(true); dNext();
          return DE.validate(st);
        }"""
        await pg.evaluate("S.prefs.autoMove = false")
        ok = await pg.evaluate(CRAFT, [2, [[2, 5], [0, 0], [0, 1]], 7]); await pg.wait_for_timeout(500)
        await pg.click(T + '#dhand [data-tile="%d"]' % await pg.evaluate("DE.TILES.findIndex(t => t[0] === 2 && t[1] === 5)")); await pg.wait_for_timeout(600)
        check('a tile that fits both ends shows two places to choose from', ok and await pg.locator(T + '#dworld .dt.ghost').count() == 2)
        await shot('32_dom_choose', 100)
        await pg.click(T + '#dworld .dt.ghost[data-ghost="R"]', force=True); await pg.wait_for_timeout(900)
        check('tapping a place puts the tile there', await pg.evaluate("DG.st.R.length === 2 && DG.st.R[1].o === 2 && DG.st.hands[0].length === 2"))
        # the same with the keyboard: the tile is a button, the two places can be focused, Enter chooses
        await pg.evaluate(CRAFT, [2, [[2, 5], [0, 0], [0, 1]], 7]); await pg.wait_for_timeout(500)
        await pg.focus(T + '#dhand [data-tile="%d"]' % await pg.evaluate("DE.TILES.findIndex(t => t[0] === 2 && t[1] === 5)")); await pg.keyboard.press('Enter'); await pg.wait_for_timeout(600)
        nfocus = await pg.locator(T + '#dworld .dt.ghost[tabindex="0"]').count()
        await pg.focus(T + '#dworld .dt.ghost[data-ghost="L"]'); await pg.keyboard.press('Enter'); await pg.wait_for_timeout(900)
        check('keyboard: Enter on a tile, then Enter on one of its two places', nfocus == 2 and await pg.evaluate("DG.st.L.length === 2 && DG.st.L[1].o === 5 && DG.st.hands[0].length === 2"), nfocus)
        await pg.evaluate(CRAFT, [2, [[0, 0], [0, 1], [1, 1]], 7]); await pg.wait_for_timeout(500)
        check('nothing fits: the draw button is offered', await pg.locator(T + '[data-act="dDraw"]').count() == 1)
        await shot('33_dom_draw', 50)
        await act('dDraw', 900)
        check('drawing takes one tile from the pile', await pg.evaluate("DG.st.hands[0].length") == 4 and await pg.evaluate("DG.st.stock.length") == 6)
        await pg.evaluate(CRAFT, [4, [[0, 0], [0, 1], [1, 1]], 0]); await pg.wait_for_timeout(1600)
        check('4 players, nothing fits and no pile: you knock and the turn passes', await pg.evaluate("DG.st.stats[0].passes") == 1 and await pg.evaluate("DG.st.turn") != 0)
        await pg.evaluate("S.prefs.autoMove = true; DG.alive = false; DG.gen++; store.del(dSaveKey())")

        async def play_dom(players, tag, sheet_shot=None):
            await pg.evaluate("window.__LUDO_TURBO = false; reset('home')"); await pg.wait_for_timeout(500)
            await act('playDom', 700)
            await pg.click(T + f'[data-act="setDomPlayers"][data-v="{players}"]'); await pg.wait_for_timeout(200)
            await act('startDom', 1600)
            await pg.evaluate("window.__LUDO_TURBO = true")
            if sheet_shot:
                r = await pg.evaluate(DOMAUTO, [120000, True])
                await pg.wait_for_timeout(600)
                stx = await pg.inner_text('.sheet')
                check(f'{tag}: a round summary shows every hand and the points', r == 'sheet' and 'الجولة' in stx and await pg.locator('.sheet .rseat').count() == players, r)
                await shot(sheet_shot, 50)
            r = await pg.evaluate(DOMAUTO, [300000, False])
            check(f'{tag}: the match reaches the result screen', r == 'domResult', r)
            await pg.evaluate("window.__LUDO_TURBO = false")
            return json.loads(await pg.evaluate("JSON.stringify({won: prm().won, reward: prm().reward, scores: prm().scores})"))
        d0 = json.loads(await pg.evaluate("JSON.stringify(Progress.data.stats.dom)"))
        p0 = await pg.evaluate("Progress.data.points")
        d1 = await play_dom(2, 'dominoes 2 players', '34_dom_round')
        await shot('35_dom_result', 400)
        want = 50 if d1['won'] else -min(50, p0)                      # a loss never takes the balance below zero
        check('dominoes result: +50 for a win, -50 for a loss (never below zero), with the banknote icon',
              d1['reward']['coins'] == want and await pg.locator(T + '.earn .dinar').count() == (1 if want else 0) and ('دينار' in await pg.inner_text(T + '.earn')) == bool(want), (p0, d1['won'], d1['reward']['coins']))
        check('the winner reached the target (100)', max(d1['scores']) >= 100 and (d1['scores'][0] >= 100) == d1['won'], d1['scores'])
        d2 = await play_dom(4, 'dominoes 4 players')
        await shot('36_dom_result4', 300)
        dd = json.loads(await pg.evaluate("JSON.stringify(Progress.data.stats.dom)"))
        check('dominoes statistics count both matches', dd['games'] == d0['games'] + 2 and dd['p2']['g'] == d0['p2']['g'] + 1 and dd['p4']['g'] == d0['p4']['g'] + 1 and dd['wins'] + dd['losses'] == dd['games'] and dd['rounds'] >= 2, dd)

        # save, leave, reload and resume a dominoes match
        await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)
        await act('playDom', 700); await pg.click(T + '[data-act="setDomPlayers"][data-v="2"]'); await act('startDom', 1600)
        await pg.evaluate("window.__LUDO_TURBO = true"); await pg.evaluate(DOMAUTO, [1500, True]); await pg.evaluate("window.__LUDO_TURBO = false")
        if await top() != 'dgame' or await pg.locator('.sheet').count():
            await pg.evaluate("DG.alive = false; DG.gen++; store.del(dSaveKey()); overlayClose(); reset('home')"); await pg.wait_for_timeout(600)
            await act('playDom', 700); await act('startDom', 1600)
        for i in range(40):
            if await pg.evaluate("!DG.busy && DG.st.turn === 0 && DG.st.phase === 'play'"): break
            await pg.wait_for_timeout(250)
        await act('dMenu', 600)
        check('dominoes menu pauses the match', await pg.evaluate("DG.paused") == True)
        await pg.click('.sheet [data-m="exit"]'); await pg.wait_for_timeout(1200)
        check('save and exit: home offers to continue the dominoes match', await top() == 'home' and await pg.locator(T + '[data-act="dResume"]').count() == 1)
        dsnap = "JSON.stringify([D.hands, D.stock, D.first, D.L, D.R, D.turn, D.scores, D.round])"
        saved = await pg.evaluate("(() => { const D = dSaved().st; return " + dsnap + "; })()")
        await pg.reload(); await pg.wait_for_timeout(2300)
        await act('dResume', 150)
        check('resume restores the exact dominoes match', await pg.evaluate("(() => { const D = DG.st; return " + dsnap + "; })()") == saved)
        # play one tile (a give-up only counts once you have played), then give up
        for i in range(60):
            if await pg.evaluate("DG.alive && !DG.paused && !DG.busy && DG.st.turn === 0 && DG.st.phase === 'play'"): break
            await pg.wait_for_timeout(250)
        await pg.evaluate("(() => { const m = DE.legalMoves(DG.st); if (m.length) dHumanPlay(m[0].id, m[0].side); else dHumanDraw(true); })()")
        await pg.wait_for_timeout(1500)
        await act('dMenu', 600); await pg.click('.sheet [data-m="forfeit"]'); await pg.wait_for_timeout(600); await pg.click('.sheet [data-x="ok"]'); await pg.wait_for_timeout(1200)
        df = json.loads(await pg.evaluate("JSON.stringify(Progress.data.stats.dom)"))
        check('giving up a dominoes match counts as a loss', await top() == 'domResult' and df['forfeits'] == dd['forfeits'] + 1 and await pg.evaluate("dSaved()") is None)

        # how to play + statistics for dominoes
        await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)
        await act('howto', 700); await pg.click(T + '[data-act="rulesTab"][data-v="dom"]'); await pg.wait_for_timeout(400)
        htxt = await pg.inner_text(T)
        check('how to play has the dominoes rules', 'الدومنة' in htxt and 'الكومة' in htxt and await pg.locator(T + '.rule').count() == 9)
        await shot('37_dom_rules', 100)
        await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)
        await act('profile', 700); await act('stats', 700); await pg.click(T + '[data-act="statsTab"][data-v="dom"]'); await pg.wait_for_timeout(400)
        check('statistics have a dominoes tab', 'الجولات' in await pg.inner_text(T))
        await shot('38_dom_stats', 100)
        await act('back', 600)
        ptxt = await pg.inner_text(T)
        check('no level wording on the profile apart from your own player level', not any(w in ptxt for w in LEVEL_WORDS))

        # ---------- statistics + settings ----------
        await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)
        await act('profile', 700); await act('stats', 700); await shot('18_stats', 100)
        await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)
        await act('settings', 700); await shot('19_settings', 100)
        await act('welcomeAgain', 900)
        check('welcome slides reopen from settings', await top() == 'welcome')
        await act('welcomeDone', 900)
        check('skip returns to settings', await top() == 'settings')
        await pg.click(T + '[data-act="togglePref"][data-k="sound"]'); await pg.wait_for_timeout(200)
        check('sound toggle saved', await pg.evaluate("store.get('prefs').sound") == False)
        await pg.click(T + '[data-act="togglePref"][data-k="sound"]')
        await act('changePw', 600)
        await pg.fill('#cp-o', 'bad-old-1'); await pg.fill('#cp-n', 'Another2026'); await pg.fill('#cp-n2', 'Another2026')
        await pg.click('.sheet [data-x="ok"]'); await pg.wait_for_timeout(1500)
        check('change password needs the current one', 'غلط' in await pg.inner_text('#cp-msg'))
        await pg.fill('#cp-o', 'NewPass2026'); await pg.click('.sheet [data-x="ok"]'); await pg.wait_for_timeout(1800)
        check('password changed', await pg.locator('.sheet').count() == 0)

        # ---------- English (LTR) ----------
        await pg.click(T + '[data-act="setLang"][data-v="en"]'); await pg.wait_for_timeout(500)
        check('English switches to LTR', await pg.evaluate("document.documentElement.dir") == 'ltr')
        await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500); await shot('20_home_en', 100)
        await pg.evaluate("window.__LUDO_TURBO = false")
        await act('playLudo', 700); await act('startGame', 1500)
        await pg.evaluate("window.__LUDO_TURBO = true"); await pg.evaluate(AUTOPLAY, 3000); await pg.evaluate("window.__LUDO_TURBO = false")
        await pg.wait_for_timeout(1500); await shot('21_game_en', 100)
        await pg.evaluate("window.__LUDO_TURBO = true"); res = await pg.evaluate(AUTOPLAY, 240000)
        await shot('22_result_en', 400)
        await pg.evaluate("window.__LUDO_TURBO = false; reset('home')"); await pg.wait_for_timeout(600)
        await act('playDom', 700); await act('startDom', 1600)
        for i in range(40):
            if await pg.evaluate("!DG.busy && DG.st.turn === 0 && DG.st.first !== null"): break
            await pg.wait_for_timeout(250)
        etxt = await pg.inner_text(T)
        check('dominoes in English', 'Target' in etxt and ('Your turn' in etxt or 'No tile fits' in etxt or 'pick a tile' in etxt), etxt[-120:])
        await shot('26_dom_en', 200)
        await pg.evaluate("DG.alive=false; DG.gen++; store.del(dSaveKey())")
        await pg.evaluate("S.lang='ar'; store.set('lang','ar'); applyPrefs(); reset('home')"); await pg.wait_for_timeout(600)

        # ---------- guest + delete account ----------
        await act('settings', 700); await pg.click(T + '[data-act="deleteAcc"]'); await pg.wait_for_timeout(600)
        await pg.fill('#da-p', 'Another2026'); await pg.click('.sheet [data-x="ok"]'); await pg.wait_for_timeout(1800)
        check('delete account returns to sign-in', await top() == 'login')
        check('deleted account removed', 'layth.test' not in await pg.evaluate("JSON.stringify(store.get('users'))"))
        await act('guest', 1000)
        check('guest can play offline without an account', await top() == 'home')

        # ---------- fixes from the review (1.3.1) ----------
        # privacy: where data is kept, the terms, a link to the full policy and the support address (from config.js)
        await pg.evaluate("(() => { window.__opened = []; window.open = u => { window.__opened.push(u); return null; }; })()")
        await pg.evaluate("CONFIG.privacyUrl = 'https://example.org/privacy'; CONFIG.supportEmail = 'help@example.org'; reset('settings')"); await pg.wait_for_timeout(600)
        await act('privacy', 700)
        ptxt = await pg.inner_text('.sheet')
        check('privacy sheet: what is kept, the terms, the full policy link and the support address',
              'ما نطلب إيميل' in ptxt and 'الشروط' in ptxt and 'على جهازك' in ptxt and await pg.locator('.sheet [data-link]').count() == 2 and 'help@example.org' in ptxt, ptxt[-200:])
        await pg.click('.sheet [data-link="0"]'); await pg.wait_for_timeout(200)
        check('the policy link opens the page set in config.js', await pg.evaluate("window.__opened[0]") == 'https://example.org/privacy', await pg.evaluate("JSON.stringify(window.__opened)"))
        await pg.evaluate("overlayClose()"); await pg.wait_for_timeout(450)
        await pg.evaluate("CONFIG.privacyUrl = 'javascript:alert(1)'; CONFIG.supportEmail = 'not an address'"); await act('privacy', 700)
        check('unsafe link values are never shown', await pg.locator('.sheet [data-link]').count() == 0 and await pg.locator('.sheet').count() == 1)
        await pg.evaluate("overlayClose(); CONFIG.privacyUrl = ''; CONFIG.supportEmail = ''"); await pg.wait_for_timeout(450)

        # keyboard: Tab to a movable Ludo token, Enter moves it
        await pg.evaluate("window.__LUDO_TURBO = true; reset('home')"); await pg.wait_for_timeout(500)
        await act('playLudo', 700); await act('startGame', 1500)
        for i in range(200):
            s = json.loads(await pg.evaluate("JSON.stringify({h: isHuman(E.current(G.st)), ph: G.st.phase, busy: G.busy})"))
            if s['h'] and not s['busy'] and s['ph'] == 'roll': break
            await pg.wait_for_timeout(100)
        await pg.evaluate("(() => { S.prefs.autoMove = false; G.st.tokens[G.setup.human] = [0, 10, -1, -1]; G.view.layout(G.st); })()")
        await pg.keyboard.press('Space')
        for i in range(60):
            if await pg.evaluate("isHuman(E.current(G.st)) && G.st.phase === 'move' && !G.busy && document.querySelectorAll('.tok.can').length > 0"): break
            await pg.wait_for_timeout(100)
        before = await pg.evaluate("JSON.stringify(G.st.tokens[G.setup.human])")
        await pg.focus(T + '.tok.can'); await pg.keyboard.press('Enter'); await pg.wait_for_timeout(700)
        check('keyboard: Space rolls, Enter on a focused token moves it', await pg.evaluate("JSON.stringify(G.st.tokens[G.setup.human])") != before, before)

        # a finished match can never be turned into a give-up (the menu may still be open when the last move lands)
        w0 = json.loads(await pg.evaluate("JSON.stringify([Progress.data.stats.games, Progress.data.stats.wins, Progress.data.stats.forfeits])"))
        # the last move decides the match: it is counted at that moment (saveGame runs after every move) ...
        await pg.evaluate("(() => { G.gen++; G.busy = false; G.st.phase = 'over'; G.st.winner = G.setup.human; saveGame(); gameMenu(); })()"); await pg.wait_for_timeout(300)
        opened = await pg.locator('.sheet').count()
        w1 = json.loads(await pg.evaluate("JSON.stringify([Progress.data.stats.games, Progress.data.stats.wins, Progress.data.stats.forfeits])"))
        # ... and a give-up arriving afterwards (twice, even) changes nothing
        await pg.evaluate("(() => { finishGame(true); finishGame(true); })()"); await pg.wait_for_timeout(1300)
        w2 = json.loads(await pg.evaluate("JSON.stringify([Progress.data.stats.games, Progress.data.stats.wins, Progress.data.stats.forfeits])"))
        check('Ludo: a decided match is counted at once, the pause menu stays closed and a give-up cannot change it',
              opened == 0 and w1 == [w0[0] + 1, w0[1] + 1, w0[2]] and w2 == w1 and await top() == 'result' and await pg.evaluate("prm().won === true && prm().forfeit === false"), (opened, w0, w1, w2))
        await pg.evaluate("G.alive = false; G.gen++; store.del(saveKey()); S.prefs.autoMove = true; reset('home')"); await pg.wait_for_timeout(600)
        await act('playDom', 700); await act('startDom', 1600)
        d0 = json.loads(await pg.evaluate("JSON.stringify([Progress.data.stats.dom.games, Progress.data.stats.dom.wins, Progress.data.stats.dom.forfeits])"))
        await pg.evaluate("(() => { DG.gen++; DG.busy = false; const st = DG.st; st.phase = 'over'; st.winner = 0; st.scores = [st.target, 12]; dFinish(true); })()"); await pg.wait_for_timeout(1200)
        d1 = json.loads(await pg.evaluate("JSON.stringify([Progress.data.stats.dom.games, Progress.data.stats.dom.wins, Progress.data.stats.dom.forfeits])"))
        check('dominoes: a decided match counts as played and won, never as a give-up',
              await top() == 'domResult' and await pg.evaluate("prm().won === true && prm().forfeit === false") and d1 == [d0[0] + 1, d0[1] + 1, d0[2]], (d0, d1))
        await pg.evaluate("window.__LUDO_TURBO = false; reset('home')"); await pg.wait_for_timeout(600)

        # a dominoes match saved while the round summary was open comes back on that summary
        for attempt in range(4):                 # (a first round worth 100 points would end the match at once: very rare, try again)
            await pg.evaluate("window.__LUDO_TURBO = false; DG.alive = false; DG.gen++; store.del(dSaveKey()); while (overlayClose()); reset('home')"); await pg.wait_for_timeout(700)
            await act('playDom', 700); await pg.click(T + '[data-act="setDomPlayers"][data-v="2"]'); await pg.click(T + '[data-act="setDomTarget"][data-v="100"]')
            await pg.evaluate("window.__LUDO_TURBO = true"); await act('startDom', 1400)
            r = await pg.evaluate(DOMAUTO, [120000, True]); await pg.wait_for_timeout(500)
            if await pg.evaluate("DG.st.phase") == 'roundOver': break
        rnd = await pg.evaluate("DG.st.round"); sc = await pg.evaluate("JSON.stringify(DG.st.scores)")
        await pg.evaluate("ludoNative.onPause(); DG.alive = false; DG.gen++; while (overlayClose()); reset('home')"); await pg.wait_for_timeout(900)
        saved_phase = await pg.evaluate("(dSaved() || { st: {} }).st.phase")
        await act('dResume', 1800)
        check('resume after a finished round: the summary is shown again, then the next round is dealt',
              r == 'sheet' and saved_phase == 'roundOver' and await pg.locator('.sheet .rseat').count() == 2 and await pg.evaluate("JSON.stringify(DG.st.scores)") == sc, (r, saved_phase))
        await pg.click('.sheet [data-x="ok"]'); await pg.wait_for_timeout(1500)
        check('the next round starts with the same score', await pg.evaluate("DG.st.round") == rnd + 1 and await pg.evaluate("DG.st.phase") == 'play' and await pg.evaluate("JSON.stringify(DG.st.scores)") == sc)
        await pg.evaluate("window.__LUDO_TURBO = false; DG.alive = false; DG.gen++; store.del(dSaveKey()); reset('home')"); await pg.wait_for_timeout(600)

        # tiles cannot be played while they are being dealt (a tap there used to start two turns at once)
        await pg.evaluate("S.prefs.autoMove = false; window.__LUDO_TURBO = false")
        for attempt in range(12):                # until you are the one who opens
            await pg.evaluate("DG.alive = false; DG.gen++; store.del(dSaveKey()); startDom(newDomSetup(2, 100))"); await pg.wait_for_timeout(550)
            if await pg.evaluate("DG.st.opener === 0"): break
            await pg.wait_for_timeout(700)
        lead = await pg.evaluate("DG.st.lead")
        busy_deal = await pg.evaluate("DG.busy")
        await pg.evaluate(f"dTapTile({lead})")                          # a tap in the middle of the deal
        for i in range(40):                                              # the shuffle and the deal take a few seconds in full motion
            if await pg.evaluate("!DG.busy"): break
            await pg.wait_for_timeout(200)
        after_deal = json.loads(await pg.evaluate("JSON.stringify([DG.st.stats[0].played, DG.st.turn, DG.busy])"))
        await pg.evaluate(f"dTapTile({lead})"); await pg.wait_for_timeout(4500)   # now it is really your turn: one tile, then the computer answers
        st1 = json.loads(await pg.evaluate("JSON.stringify([DG.st.stats[0].played, DG.st.stats[1].played + DG.st.stats[1].drawn > 0])"))
        check('dominoes: a tap during the deal is ignored; afterwards you play one tile and only the computer answers',
              busy_deal is True and after_deal == [0, 0, False] and st1 == [1, True], (busy_deal, after_deal, st1))

        # "cancel" on the give-up question carries on with the match (it used to stay paused)
        for i in range(60):
            if await pg.evaluate("DG.st.turn === 0 && !DG.busy && DG.st.phase === 'play'"): break
            await pg.wait_for_timeout(150)
        await pg.evaluate("dMenu()"); await pg.wait_for_timeout(500)
        await pg.click('.sheet [data-m="forfeit"]'); await pg.wait_for_timeout(700)
        await pg.click('.sheet [data-x="no"]'); await pg.wait_for_timeout(600)
        seq = await pg.evaluate("DG.st.seq")
        mv = await pg.evaluate("(() => { const m = DE.legalMoves(DG.st)[0]; if (m) dHumanPlay(m.id, m.side); else if (DG.st.stock.length) dHumanDraw(false); return !!m || DG.st.stock.length > 0; })()")
        await pg.wait_for_timeout(900)
        check('dominoes: after cancelling "give up" the match goes on', await pg.evaluate("DG.paused") is False and (not mv or await pg.evaluate("DG.st.seq") > seq), (mv, seq))
        await pg.evaluate("DG.alive = false; DG.gen++; store.del(dSaveKey()); reset('home')"); await pg.wait_for_timeout(600)
        await act('playLudo', 700); await act('startGame', 1500)
        for i in range(200):
            if await pg.evaluate("isHuman(E.current(G.st)) && G.st.phase === 'roll' && !G.busy"): break
            await pg.wait_for_timeout(100)
        await pg.evaluate("gameMenu()"); await pg.wait_for_timeout(500)
        await pg.click('.sheet [data-m="restart"]'); await pg.wait_for_timeout(700)
        await pg.click('.sheet [data-x="no"]'); await pg.wait_for_timeout(600)
        rolls = await pg.evaluate("G.st.stats[G.setup.human].rolls")
        await pg.click(T + '[data-act="roll"]'); await pg.wait_for_timeout(1300)
        check('Ludo: after cancelling "start over" the dice roll again', await pg.evaluate("G.paused") is False and await pg.evaluate("G.st.stats[G.setup.human].rolls") == rolls + 1)

        # the pause menu opened while the dice are rolling does not swallow the automatic move
        await pg.evaluate("S.prefs.autoMove = true")
        for i in range(200):
            if await pg.evaluate("isHuman(E.current(G.st)) && G.st.phase === 'roll' && !G.busy"): break
            if await pg.evaluate("isHuman(E.current(G.st)) && G.st.phase === 'move' && !G.busy"): await pg.evaluate("humanMove(LudoAI.choose(G.st))")
            await pg.wait_for_timeout(100)
        await pg.evaluate("(() => { const h = G.setup.human; G.st.tokens[h] = [10, E.HOME, E.HOME, E.HOME]; G.view.layout(G.st); })()")   # any roll leaves exactly one move
        await pg.click(T + '[data-act="roll"]'); await pg.wait_for_timeout(120)
        await pg.evaluate("gameMenu()"); await pg.wait_for_timeout(1700)          # the roll lands and its move comes due behind the open menu
        still = await pg.evaluate("G.st.tokens[G.setup.human][0]")
        await pg.click('.sheet [data-m="resume"]'); await pg.wait_for_timeout(1500)
        check('Ludo: the move waits for the menu to close, then happens', still == 10 and await pg.evaluate("G.st.tokens[G.setup.human][0]") != 10, still)

        # a new match over a saved one: asked first; the saved match counts as a give-up
        for i in range(200):
            if await pg.evaluate("isHuman(E.current(G.st)) && G.st.phase === 'roll' && !G.busy"): break
            await pg.wait_for_timeout(100)
        await pg.evaluate("Progress.data.points = 200; Progress.save()")
        await pg.evaluate("gameMenu()"); await pg.wait_for_timeout(500); await pg.click('.sheet [data-m="exit"]'); await pg.wait_for_timeout(1000)
        f0 = json.loads(await pg.evaluate("JSON.stringify([Progress.data.stats.forfeits, Progress.data.points, !!savedGame()])"))
        await act('playLudo', 700); await act('startGame', 700)
        asked = await pg.locator('.sheet').count() == 1 and 'محفوظة' in await pg.inner_text('.sheet')
        await pg.click('.sheet [data-x="no"]'); await pg.wait_for_timeout(600)
        kept = json.loads(await pg.evaluate("JSON.stringify([Progress.data.stats.forfeits, Progress.data.points, !!savedGame()])"))
        check('a saved match is not replaced without asking', f0[2] is True and asked and kept == f0 and await top() == 'offSetup', (f0, asked, kept))
        await act('startGame', 700); await pg.click('.sheet [data-x="ok"]'); await pg.wait_for_timeout(1800)
        f1 = json.loads(await pg.evaluate("JSON.stringify([Progress.data.stats.forfeits, Progress.data.points])"))
        check('starting anyway counts the saved match as a give-up (-50 dinars) and opens a new one', f1 == [f0[0] + 1, f0[1] - 50] and await top() == 'game' and await pg.evaluate("G.st.stats[G.setup.human].rolls") == 0, (f0, f1))
        # ... but a saved match in which you have not played yet is simply replaced
        await pg.evaluate("G.gen++; G.busy = false; saveGame(); G.alive = false; reset('home')"); await pg.wait_for_timeout(800)
        await act('playLudo', 700); await act('startGame', 1500)
        check('a saved match you never played in is replaced without a question or a loss', await top() == 'game' and await pg.locator('.sheet').count() == 0
              and json.loads(await pg.evaluate("JSON.stringify([Progress.data.stats.forfeits, Progress.data.points])")) == f1)
        await pg.evaluate("G.alive = false; G.gen++; store.del(saveKey()); reset('home')"); await pg.wait_for_timeout(600)

        # a decided dominoes match is counted when the last tile lands, not when the summary is closed
        g0 = await pg.evaluate("Progress.data.stats.dom.games")
        await pg.evaluate("window.__LUDO_TURBO = true"); await act('playDom', 700); await pg.click(T + '[data-act="setDomTarget"][data-v="50"]'); await act('startDom', 1400)
        for i in range(30):
            r = await pg.evaluate(DOMAUTO, [120000, True]); await pg.wait_for_timeout(400)
            if r != 'sheet' or await pg.evaluate("DG.st.phase") == 'over': break
            await pg.click('.sheet [data-x="ok"]'); await pg.wait_for_timeout(300)
        at_sheet = json.loads(await pg.evaluate("JSON.stringify([DG.st.phase, document.querySelectorAll('.sheet').length, Progress.data.stats.dom.games, !!dSaved()])"))
        await pg.reload(); await pg.wait_for_timeout(2600)               # the app is closed with the last summary still open
        check('dominoes: closing the app on the last summary neither loses nor repeats the match',
              at_sheet == ['over', 1, g0 + 1, False] and await top() == 'home' and await pg.evaluate("Progress.data.stats.dom.games") == g0 + 1 and await pg.locator(T + '[data-act="dResume"]').count() == 0, at_sheet)

        # a damaged saved match (no setup) is ignored instead of stopping the app at start-up
        await pg.evaluate("(() => { const st = LudoEngine.createGame({ colors: ['red', 'yellow'] }); store.set(saveKey(), { st }); store.set(dSaveKey(), { st: { phase: 'roundOver' }, setup: {} }); })()")
        await pg.reload(); await pg.wait_for_timeout(2600)
        check('damaged saved matches are ignored at start-up', await top() == 'home' and await pg.locator(T + '[data-act="resume"]').count() == 0 and await pg.locator(T + '[data-act="dResume"]').count() == 0, await top())
        await pg.evaluate("store.del(saveKey()); store.del(dSaveKey())")

        # day 7 of the daily reward brings 50 XP: when that reaches a new level, the level bonus is paid too
        dr = json.loads(await pg.evaluate("""(() => { const P = Progress.data, keep = JSON.stringify(P);
          const y = new Date(); y.setDate(y.getDate() - 1);
          P.xp = 90; P.points = 0; P.daily = { last: dayKey(y), streak: 6 };
          const r = Progress.claimDaily(), out = [r.reward, r.xp, r.bonus, r.levelUp, P.points];
          Object.assign(P, JSON.parse(keep)); Progress.save(); return JSON.stringify(out); })()"""))
        check('daily reward day 7: 150 dinars, 50 XP and the level-up bonus', dr == [150, 50, 50, 2, 200], dr)

        # ---------- 1.4: design settings, drawn characters, celebrations ----------
        await pg.evaluate("reset('settings')"); await pg.wait_for_timeout(600)
        await act('design', 800)
        check('settings open the design screen with every option', await top() == 'design' and await pg.locator(T + '[data-k="theme"]').count() == 8
              and await pg.locator(T + '[data-k="bg"]').count() == 6 and await pg.locator(T + '[data-k="board"]').count() == 6 and await pg.locator(T + '[data-k="tiles"]').count() == 4
              and await pg.locator(T + '[data-k="tok"]').count() == 3 and await pg.locator(T + '[data-k="motion"]').count() == 3)
        acc0 = await pg.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--gold').trim()")
        await pg.click(T + '[data-act="setLook"][data-k="theme"][data-v="violet"]'); await pg.wait_for_timeout(300)
        acc1 = await pg.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--gold').trim()")
        check('a colour theme changes the whole interface at once', acc0.upper() == '#E6B44C' and acc1.upper() == '#A78BFA' and await pg.evaluate("document.documentElement.dataset.ui") == 'violet', (acc0, acc1))
        btn = await pg.evaluate("getComputedStyle(document.querySelector('#screens > section:last-of-type .btn.gold')).backgroundImage")
        check('buttons take the theme colour', '167, 139, 250' in btn or 'a78bfa' in btn.lower(), btn[:120])
        await pg.click(T + '[data-act="setLook"][data-k="bg"][data-v="palms"]'); await pg.click(T + '[data-act="setLook"][data-k="tiles"][data-v="color"]')
        await pg.click(T + '[data-act="setLook"][data-k="tok"][data-v="gem"]'); await pg.click(T + '[data-act="setLook"][data-k="board"][data-v="sunset"]'); await pg.wait_for_timeout(300)
        await pg.reload(); await pg.wait_for_timeout(2600)
        look = json.loads(await pg.evaluate("JSON.stringify([document.documentElement.dataset.ui, document.documentElement.dataset.bg, document.documentElement.dataset.tiles, document.documentElement.dataset.tok, Progress.data.equipped.board])"))
        check('the chosen look is kept after closing the app', look == ['violet', 'palms', 'color', 'gem', 'sunset'], look)
        await pg.evaluate("reset('design')"); await pg.wait_for_timeout(600)
        await pg.click(T + '[data-act="setLook"][data-k="motion"][data-v="off"]'); await pg.wait_for_timeout(200)
        check('motion "none": nothing moves', await pg.evaluate("document.documentElement.classList.contains('m-off') && RM === true && !FX()"))
        await pg.click(T + '[data-act="setLook"][data-k="motion"][data-v="lite"]'); await pg.wait_for_timeout(200)
        check('motion "light": game moves stay, decorations stop', await pg.evaluate("document.documentElement.classList.contains('m-lite') && RM === false && !FX()")
              and await pg.evaluate("getComputedStyle(document.querySelector('#app'), '::before').animationName") == 'none')
        await act('lookReset', 400)
        check('back to the original look in one tap', json.loads(await pg.evaluate("JSON.stringify([document.documentElement.dataset.ui, document.documentElement.dataset.bg, document.documentElement.dataset.tiles, document.documentElement.dataset.tok, Progress.data.equipped.board, FX()])")) == ['gold', 'bricks', 'board', 'classic', 'classic', True])
        # dominoes tiles in another style really change the tiles on the table
        await pg.evaluate("S.prefs.tiles = 'onyx'; applyLook(); startDom(newDomSetup(2, 100))"); await pg.wait_for_timeout(900)
        face = await pg.evaluate("getComputedStyle(document.querySelector('#dhand .dt')).getPropertyValue('--df1').trim()")
        shuf = await pg.locator(T + '.dshuf .dt.back').count()
        check('full motion: the 28 tiles are shuffled face down, then dealt', shuf == 28, shuf)
        check('tile style "black and gold" is used on the table', face.upper() == '#2E2924', face)
        for i in range(40):
            if await pg.evaluate("!DG.busy && DG.st.phase === 'play'"): break
            await pg.wait_for_timeout(200)
        check('after the deal every tile is in place and visible', await pg.locator(T + '.dshuf').count() == 0 and await pg.evaluate("[...document.querySelectorAll('#dhand .dt')].every(e => e.style.opacity !== '0' && +getComputedStyle(e).opacity >= .4)")
              and await pg.evaluate("DG.st.hands[0].length") == await pg.locator(T + '#dhand .dt').count())
        bots = json.loads(await pg.evaluate("JSON.stringify(DG.setup.avatars.slice(1).map(a => isChar(a)))"))
        check('computer players get drawn characters', all(bots) and await pg.locator(T + '.dseat svg.avc').count() >= 1, bots)
        await pg.evaluate("S.prefs.tiles = 'board'; applyLook(); DG.alive = false; DG.gen++; store.del(dSaveKey()); reset('home')"); await pg.wait_for_timeout(600)
        check('home shows the drawn picture and the moving background', await pg.locator(T + '.who svg.avc').count() == 1 or await pg.evaluate("!isChar(Accounts.user.avatar)"))
        # the thrown dice lands on the board and the value is the one the game rolled
        await act('playLudo', 900); await act('startGame', 1500)
        for i in range(200):
            if await pg.evaluate("isHuman(E.current(G.st)) && G.st.phase === 'roll' && !G.busy"): break
            await pg.wait_for_timeout(100)
        await pg.click(T + '[data-act="roll"]'); await pg.wait_for_timeout(450)
        fly = False
        for i in range(40):                       # watch the throw: at some moment the dice is over the board
            fly = await pg.evaluate("(() => { const d = G.dice.getBoundingClientRect(), b = $('#board', G.el).getBoundingClientRect(); return G.dice.classList.contains('flying') && d.left > b.left && d.right < b.right && d.top > b.top && d.bottom < b.bottom; })()")
            if fly: break
            await pg.wait_for_timeout(40)
        for i in range(40):
            if await pg.evaluate("!G.dice.classList.contains('flying')"): break
            await pg.wait_for_timeout(100)
        same = await pg.evaluate("G.st.lastRoll && +G.dice.dataset.v === G.st.lastRoll.value && !G.dice.classList.contains('flying')")
        check('full motion: the dice is thrown onto the board, then shows the rolled value beside the player', fly and same, (fly, same))
        await pg.evaluate("G.alive = false; G.gen++; store.del(saveKey()); reset('home')"); await pg.wait_for_timeout(600)
        # rewards: the daily chest and the level-up badge
        await pg.evaluate("(() => { const y = new Date(); y.setDate(y.getDate() - 1); Progress.data.daily = { last: dayKey(y), streak: 6 }; Progress.data.xp = 60; Progress.data.points = 100; Progress.save(); })()")
        await act('daily', 700); await pg.click(T + '[data-act="claimDaily"]'); await pg.wait_for_timeout(1400)
        gold = await pg.locator('.fxov.chfx.gold').count()
        pill = ''
        for i in range(50):                       # the balance counts up to the new total
            pill = await pg.evaluate("(document.querySelector('#fxl .fpts b') || {}).textContent || ''")
            if pill.replace(',', '') == '300': break
            await pg.wait_for_timeout(100)
        check('day 7: a golden chest opens and the dinars fly to the balance', gold == 1 and pill.replace(',', '') == '300', (gold, pill))
        for i in range(40):
            if await pg.locator('.fxov.lvfx').count(): break
            await pg.wait_for_timeout(200)
        lv = await pg.locator('.fxov.lvfx .lvsvg').count()
        check('reaching a new level shows the big badge', lv == 1 and 'صعدت للمستوى' in await pg.inner_text('.fxov.lvfx'))
        await pg.click('.fxov.lvfx'); await pg.wait_for_timeout(500)
        check('a tap closes the celebration', await pg.locator('.fxov').count() == 0 and await pg.evaluate("Progress.data.points") == 300)
        # the result screen: a podium with the players' pictures
        await pg.evaluate("window.__LUDO_TURBO = true; reset('home')"); await pg.wait_for_timeout(500)
        await act('playLudo', 900); await pg.click(T + '[data-act="setPlayers"][data-v="4"]'); await act('startGame', 1300)
        await pg.evaluate(AUTOPLAY, 240000); await pg.evaluate("window.__LUDO_TURBO = false"); await pg.wait_for_timeout(1500)
        check('result screen: a podium with the top three and a crown for the winner', await pg.locator(T + '.podium .pstep').count() == 3 and await pg.locator(T + '.pstep.p1 .pcrown').count() == 1
              and await pg.locator(T + '.respill .pts').count() == 1)
        while await pg.locator('.fxov').count(): await pg.click('.fxov'); await pg.wait_for_timeout(400)
        await pg.evaluate("reset('home')"); await pg.wait_for_timeout(600)
        # choosing a drawn character
        await act('profile', 700); await act('pickAvatar', 700)
        await pg.click('.sheet [data-av="hajiya"]'); await pg.wait_for_timeout(700)
        check('a drawn character can be chosen as your picture', await pg.evaluate("Accounts.user.avatar") == 'hajiya' and await pg.locator(T + '.prof svg.avc').count() == 1)
        await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)

        # an old browser engine gets a clear message instead of an empty screen
        old = await ctx.new_page()
        await old.add_init_script("window.CSS = { supports: () => false };")
        await old.goto(URL); await old.wait_for_timeout(800)
        check('old browser: a notice explains what to update', await old.evaluate("window.LUDO_OLD === true && getComputedStyle(document.getElementById('oldweb')).display !== 'none'") and 'Android System WebView' in await old.inner_text('#oldweb'))
        await old.close()
        check('a current browser never sees that notice', await pg.evaluate("!window.LUDO_OLD && getComputedStyle(document.getElementById('oldweb')).display === 'none'"))

        # ---------- other screen sizes ----------
        for (w, h, tag) in [(360, 640, 'small'), (800, 1280, 'tablet')]:
            await pg.set_viewport_size({'width': w, 'height': h})
            await pg.evaluate("window.__LUDO_TURBO = false; reset('home')"); await pg.wait_for_timeout(700)
            await shot(f'23_home_{tag}', 100)
            await act('playLudo', 700); await pg.click(T + '[data-act="setPlayers"][data-v="4"]'); await act('startGame', 1500)
            await pg.evaluate("window.__LUDO_TURBO = true"); await pg.evaluate(AUTOPLAY, 2500); await pg.evaluate("window.__LUDO_TURBO = false"); await pg.wait_for_timeout(1200)
            await shot(f'24_game_{tag}', 100)
            bs = await pg.evaluate("parseInt(getComputedStyle(G.el).getPropertyValue('--bs'))")
            check(f'{tag}: board fits the screen', bs >= 220 and bs <= min(w, h), bs)
            await pg.evaluate("G.alive=false; G.gen++; store.del(saveKey()); reset('home')"); await pg.wait_for_timeout(600)
            await act('playDom', 700); await pg.click(T + '[data-act="setDomPlayers"][data-v="4"]'); await act('startDom', 1600)
            await pg.evaluate("window.__LUDO_TURBO = true"); await pg.evaluate(DOMAUTO, [900, True]); await pg.evaluate("window.__LUDO_TURBO = false"); await pg.wait_for_timeout(1500)
            if await pg.locator('.sheet [data-x="ok"]').count():          # a round just ended: deal the next one
                await pg.click('.sheet [data-x="ok"]'); await pg.wait_for_timeout(2200)
            await pg.evaluate("DG.paused = true"); await pg.wait_for_timeout(1200)   # let a tile in flight land first
            await shot(f'25_dom_{tag}', 100)
            fit = await pg.evaluate("""(() => { const tb = $('#dtable', DG.el).getBoundingClientRect();
              const ok = $$('#dworld .dt', DG.el).every(e => { const r = e.getBoundingClientRect(); return r.left >= tb.left - 1 && r.right <= tb.right + 1 && r.top >= tb.top - 1 && r.bottom <= tb.bottom + 1; });
              const h = $('#dhand', DG.el), hr = h.getBoundingClientRect();
              return ok && $$('.dt', h).every(e => { const r = e.getBoundingClientRect(); return r.left >= hr.left - 1 && r.right <= hr.right + 1; }) && $$('.dt', h).length > 0; })()""")
            check(f'{tag}: dominoes table and hand fit the screen', fit)
            await pg.evaluate("DG.paused = false")
            # the round summary of a 4-player match: the button to continue is always in view
            await pg.evaluate("window.__LUDO_TURBO = true"); r = await pg.evaluate(DOMAUTO, [120000, True]); await pg.evaluate("window.__LUDO_TURBO = false"); await pg.wait_for_timeout(700)
            vis = await pg.evaluate("(() => { const b = document.querySelector('.sheet [data-x=\"ok\"]'); if (!b) return false; const r = b.getBoundingClientRect(); return r.top >= 0 && r.bottom <= innerHeight && r.height > 30; })()")
            check(f'{tag}: round summary keeps its button on screen', r == 'sheet' and vis, r)
            await shot(f'27_round_{tag}', 100)
            await pg.evaluate("DG.alive=false; DG.gen++; store.del(dSaveKey()); while (overlayClose()); reset('home')"); await pg.wait_for_timeout(700)
            # sign-up form and the colour row of "find players": nothing sticks out sideways
            wide = []
            for scr, par in [('register', '{}'), ('match', '{}'), ('domSetup', '{}')]:
                for lang in ('ar', 'en'):
                    await pg.evaluate(f"S.lang='{lang}'; applyPrefs(); reset('{scr}', {par})"); await pg.wait_for_timeout(450)
                    if await pg.evaluate("(() => { const sc = document.querySelector('#screens > section:last-of-type .scroll'); const h = document.querySelector('#screens > section:last-of-type .hdr h1'); return sc.scrollWidth > sc.clientWidth + 1 || (h && h.scrollWidth > h.clientWidth + 1); })()"): wide.append(f'{scr}/{lang}')
            check(f'{tag}: sign-up, find-players and dominoes setup fit the width in both languages', not wide, wide)
            await pg.evaluate("S.lang='ar'; applyPrefs(); reset('home')"); await pg.wait_for_timeout(600)

        real_errs = [e for e in errs if 'fonts.g' not in e]
        check('no console errors', not real_errs, '\n'.join(real_errs[:8]))
        print(f"\n{sum(1 for _, ok in results if ok)}/{len(results)} checks passed")
        await b.close()

asyncio.run(main())
