/* Dominoes rules engine + computer player tests: node web/tests/domino.test.js */
const assert = require('assert');
const D = require('../src/02b_domino.js');
const AI = require('../src/02c_domino_ai.js');
let passed = 0;
const test = (name, fn) => { fn(); passed++; console.log('PASS', name); };
const id = (a, b) => D.TILES.findIndex(t => t[0] === Math.min(a, b) && t[1] === Math.max(a, b));
const ids = list => list.map(([a, b]) => id(a, b));
/* A deal order with the given hands first; the rest of the set follows in id order */
function order(...hands) {
  const used = new Set(hands.flat());
  return hands.flat().concat(D.TILES.map((_, i) => i).filter(i => !used.has(i)));
}
function rng(seed) { let s = seed >>> 0; return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

test('double-six set: 28 different tiles, 168 pips in all', () => {
  assert.strictEqual(D.TILES.length, 28);
  assert.strictEqual(new Set(D.TILES.map(t => t.join())).size, 28);
  assert.strictEqual(D.TILES.reduce((s, t) => s + t[0] + t[1], 0), 168);
  for (let v = 0; v <= 6; v++) assert.strictEqual(D.TILES.filter(t => t.includes(v)).length, 7);
});

test('shuffle is a permutation of the 28 ids', () => {
  const a = D.shuffled(rng(7));
  assert.deepStrictEqual(a.slice().sort((x, y) => x - y), D.TILES.map((_, i) => i));
});

test('2 players: 7 tiles each, 14 in the pile; 4 players: all 28 dealt', () => {
  const s2 = D.createMatch({ players: 2 }); D.deal(s2, D.shuffled(rng(1)));
  assert.deepStrictEqual(s2.hands.map(h => h.length), [7, 7]); assert.strictEqual(s2.stock.length, 14);
  const s4 = D.createMatch({ players: 4 }); D.deal(s4, D.shuffled(rng(2)));
  assert.deepStrictEqual(s4.hands.map(h => h.length), [7, 7, 7, 7]); assert.strictEqual(s4.stock.length, 0);
  assert.ok(D.validate(s2) && D.validate(s4));
  assert.strictEqual(s2.target, 100);
});

test('first round: the 6-6 holder opens, and must open with it', () => {
  const st = D.createMatch({ players: 4 });
  const h0 = ids([[0, 0], [0, 1], [0, 2], [0, 3], [0, 4], [0, 5], [0, 6]]);
  const h1 = ids([[1, 1], [1, 2], [1, 3], [1, 4], [1, 5], [1, 6], [2, 2]]);
  const h2 = ids([[6, 6], [2, 3], [2, 4], [2, 5], [2, 6], [3, 3], [3, 4]]);
  const ev = D.deal(st, order(h0, h1, h2));
  assert.strictEqual(st.turn, 2); assert.strictEqual(st.opener, 2);
  assert.strictEqual(st.lead, id(6, 6)); assert.strictEqual(ev[0].lead, id(6, 6));
  assert.deepStrictEqual(D.legalMoves(st), [{ id: id(6, 6), side: 'C' }]);
  assert.throws(() => D.play(st, id(2, 3), 'C'), /illegal-move/);
});

test('2 players with no double: the heaviest tile opens', () => {
  const st = D.createMatch({ players: 2 });
  const h0 = ids([[0, 1], [0, 2], [1, 2], [1, 3], [0, 3], [2, 3], [0, 4]]);
  const h1 = ids([[5, 6], [1, 4], [2, 4], [3, 4], [0, 5], [1, 5], [2, 5]]);
  D.deal(st, order(h0, h1));
  // the pile holds every double, so no hand has one
  assert.strictEqual(st.turn, 1); assert.strictEqual(st.lead, id(5, 6));
});

test('playing on both ends: the line keeps its open numbers', () => {
  const st = D.createMatch({ players: 2 });
  const h0 = ids([[6, 6], [6, 2], [2, 2], [1, 3], [0, 3], [4, 4], [0, 1]]);
  const h1 = ids([[6, 5], [5, 5], [1, 2], [3, 4], [0, 0], [0, 6], [3, 3]]);
  D.deal(st, order(h0, h1));
  assert.strictEqual(st.turn, 0);
  D.play(st, id(6, 6), 'C');
  assert.deepStrictEqual(D.ends(st), [6, 6]);
  assert.strictEqual(st.turn, 1);
  const m = D.legalMoves(st);
  assert.ok(m.some(x => x.id === id(6, 5) && x.side === 'L') && m.some(x => x.id === id(6, 5) && x.side === 'R'));
  D.play(st, id(6, 5), 'R');
  assert.deepStrictEqual(D.ends(st), [6, 5]);
  assert.deepStrictEqual(st.R[0], { id: id(6, 5), i: 6, o: 5 });
  D.play(st, id(6, 2), 'L');
  assert.deepStrictEqual(D.ends(st), [2, 5]);
  assert.throws(() => D.play(st, id(0, 0), 'L'), /illegal-move/);
  D.play(st, id(5, 5), 'R');
  assert.deepStrictEqual(D.ends(st), [2, 5]);
  assert.ok(D.validate(st));
});

test('no fitting tile: draw from the pile (2 players); drawing with a fitting tile is refused', () => {
  const st = D.createMatch({ players: 2 });
  const h0 = ids([[6, 6], [1, 1], [1, 2], [1, 3], [1, 4], [1, 5], [0, 1]]);
  const h1 = ids([[0, 0], [0, 2], [0, 3], [0, 4], [0, 5], [2, 2], [2, 3]]);
  D.deal(st, order(h0, h1));
  D.play(st, id(6, 6), 'C');
  assert.strictEqual(st.turn, 1);
  assert.strictEqual(D.legalMoves(st).length, 0);
  assert.throws(() => D.pass(st), /must-draw/);
  const before = st.stock.length;
  const ev = D.draw(st);
  assert.strictEqual(ev[0].type, 'draw'); assert.strictEqual(st.stock.length, before - 1);
  assert.strictEqual(st.hands[1].length, 8);
  while (!D.legalMoves(st).length) D.draw(st);
  assert.throws(() => D.draw(st), /has-move/);
  assert.ok(D.validate(st));
});

test('4 players: no pile, a player with no fitting tile knocks and the turn passes', () => {
  const st = D.createMatch({ players: 4 });
  const h0 = ids([[6, 6], [6, 5], [5, 5], [0, 0], [0, 1], [0, 2], [0, 3]]);
  const h1 = ids([[1, 1], [1, 2], [1, 3], [1, 4], [1, 5], [2, 2], [2, 3]]);
  const h2 = ids([[6, 4], [4, 4], [3, 3], [3, 4], [2, 4], [0, 4], [0, 5]]);
  D.deal(st, order(h0, h1, h2));
  D.play(st, id(6, 6), 'C');
  assert.strictEqual(st.turn, 1);
  assert.throws(() => D.draw(st), /stock-empty/);
  const ev = D.pass(st);
  assert.strictEqual(ev[0].type, 'pass');
  assert.strictEqual(st.turn, 2);
  assert.ok(st.voids[1][6]);
});

test('domino: the player who goes out scores the pips left in the opponent\'s hand', () => {
  const st = D.createMatch({ players: 2 });
  D.deal(st, D.shuffled(rng(12)));
  st.first = null; st.L = []; st.R = []; st.stock = []; st.lead = id(6, 6); st.opener = 0; st.turn = 0;
  st.hands = [ids([[6, 6], [6, 1]]), ids([[5, 5], [4, 3]])];
  D.play(st, id(6, 6), 'C');
  assert.strictEqual(st.turn, 1);
  D.pass(st);                                          // no 6 and nothing to draw: knock
  const ev = D.play(st, id(6, 1), 'R');
  const r = ev.find(e => e.type === 'round');
  assert.ok(r && r.reason === 'domino' && r.seat === 0 && r.team === 0);
  assert.strictEqual(r.points, 10 + 7);
  assert.deepStrictEqual(st.scores, [17, 0]);
  assert.strictEqual(st.phase, 'roundOver');
  assert.strictEqual(st.next, 0);
  assert.strictEqual(st.stats[0].outs, 1);
  assert.strictEqual(st.teams[0].best, 17);
});

test('blocked: the lowest hand wins and scores the opponent\'s pips; a tie scores nothing', () => {
  const st = D.createMatch({ players: 2 });
  D.deal(st, D.shuffled(rng(3)));
  // hand-made blocked table: ends 6 and 6, nobody holds a 6, empty pile
  st.first = { id: id(6, 6), a: 6, b: 6 }; st.L = []; st.R = []; st.stock = []; st.lead = null;
  st.hands = [ids([[0, 1], [0, 2]]), ids([[5, 5]])];
  assert.ok(D.blocked(st));
  st.turn = 0;
  const ev = D.pass(st);
  const r = ev.find(e => e.type === 'round');
  assert.strictEqual(r.reason, 'blocked'); assert.strictEqual(r.team, 0); assert.strictEqual(r.points, 10);
  assert.deepStrictEqual(r.left, [3, 10]);
  assert.strictEqual(st.teams[0].blockWins, 1);
  // a tie
  const t2 = D.createMatch({ players: 2 });
  D.deal(t2, D.shuffled(rng(4)));
  t2.first = { id: id(6, 6), a: 6, b: 6 }; t2.L = []; t2.R = []; t2.stock = []; t2.lead = null;
  t2.hands = [ids([[0, 4]]), ids([[1, 3]])]; t2.turn = 1; t2.opener = 1;
  const e2 = D.pass(t2).find(e => e.type === 'round');
  assert.strictEqual(e2.team, null); assert.strictEqual(e2.points, 0);
  assert.deepStrictEqual(t2.scores, [0, 0]);
  assert.strictEqual(t2.next, 1);
});

test('4 players: partners share a score; the partner\'s pips never count', () => {
  const st = D.createMatch({ players: 4 });
  D.deal(st, D.shuffled(rng(5)));
  st.first = { id: id(6, 6), a: 6, b: 6 }; st.L = []; st.R = []; st.stock = []; st.lead = null;
  st.hands = [ids([[6, 0]]), ids([[1, 1]]), ids([[5, 5]]), ids([[2, 3]])];
  st.turn = 0;
  const r = D.play(st, id(6, 0), 'L').find(e => e.type === 'round');
  assert.strictEqual(r.team, 0); assert.strictEqual(r.points, 2 + 5);   // 1-1 and 2-3; not the partner's 5-5
  assert.deepStrictEqual(st.scores, [7, 0]);
});

test('match: first team to the target wins; the next round is opened by the round winner', () => {
  const st = D.createMatch({ players: 2, target: 20 });
  D.deal(st, D.shuffled(rng(6)));
  st.first = { id: id(6, 6), a: 6, b: 6 }; st.L = []; st.R = []; st.stock = []; st.lead = null;
  st.hands = [ids([[6, 0]]), ids([[5, 5], [4, 4], [3, 3]])]; st.turn = 0; st.scores = [5, 0];
  const ev = D.play(st, id(6, 0), 'R');
  assert.ok(ev.some(e => e.type === 'win' && e.team === 0));
  assert.strictEqual(st.phase, 'over'); assert.strictEqual(st.winner, 0); assert.strictEqual(st.scores[0], 29);
  // a round that does not reach the target goes on: the winner opens with any tile
  const m = D.createMatch({ players: 2 });
  D.deal(m, D.shuffled(rng(8)));
  m.first = { id: id(6, 6), a: 6, b: 6 }; m.L = []; m.R = []; m.stock = []; m.lead = null;
  m.hands = [ids([[2, 2]]), ids([[6, 1]])]; m.turn = 1;
  D.play(m, id(6, 1), 'L');
  assert.strictEqual(m.phase, 'roundOver');
  D.deal(m, D.shuffled(rng(9)));
  assert.strictEqual(m.round, 2); assert.strictEqual(m.turn, 1); assert.strictEqual(m.lead, null);
  assert.strictEqual(D.legalMoves(m).length, 7);
});

test('validate catches a broken saved match', () => {
  const st = D.createMatch({ players: 2 });
  D.deal(st, D.shuffled(rng(10)));
  assert.ok(D.validate(st));
  const a = JSON.parse(JSON.stringify(st)); a.hands[0][0] = a.hands[1][0];
  assert.strictEqual(D.validate(a), false);
  const b = JSON.parse(JSON.stringify(st)); b.turn = 5;
  assert.strictEqual(D.validate(b), false);
  const c = JSON.parse(JSON.stringify(st)); D.play(c, D.legalMoves(c)[0].id, 'C'); c.first.a = (c.first.a + 1) % 7;
  assert.strictEqual(D.validate(c), false);
});

test('validate accepts only saved matches that can be played on', () => {
  const st = D.createMatch({ players: 2 });
  D.deal(st, D.shuffled(rng(11)));
  const edit = (base, fn) => { const c = JSON.parse(JSON.stringify(base)); fn(c); return D.validate(c); };
  assert.ok(D.validate(JSON.parse(JSON.stringify(st))));
  assert.strictEqual(edit(st, c => { delete c.target; }), false, 'no target: the match would never end');
  assert.strictEqual(edit(st, c => { c.v = 7; }), false, 'another rules version');
  assert.strictEqual(edit(st, c => { c.next = 7; }), false, 'next opener out of range');
  assert.strictEqual(edit(st, c => { c.voids[1] = null; }), false, 'voids row missing');
  assert.strictEqual(edit(st, c => { c.lead = c.hands[1 - c.turn][0]; }), false, 'opening tile held by the other player');
  assert.strictEqual(edit(st, c => { c.opener = 9; }), false, 'opener out of range');
  // play a whole round, then break its summary
  const r = rng(12);
  while (st.phase === 'play') {
    const m = D.legalMoves(st);
    if (m.length) { const x = m[Math.floor(r() * m.length)]; D.play(st, x.id, x.side); } else if (st.stock.length) D.draw(st); else D.pass(st);
  }
  assert.ok(st.phase === 'roundOver' || st.phase === 'over');
  assert.ok(D.validate(JSON.parse(JSON.stringify(st))));
  assert.strictEqual(edit(st, c => { c.result = null; }), false, 'round over without its summary');
});

test('computer player: always a legal move, and it sheds heavy tiles', () => {
  for (let k = 0; k < 300; k++) {
    const r = rng(100 + k), st = D.createMatch({ players: k % 2 ? 4 : 2 });
    D.deal(st, D.shuffled(r));
    let guard = 0;
    while (st.phase === 'play' && guard++ < 200) {
      const moves = D.legalMoves(st);
      if (moves.length) { const m = AI.choose(st, r); assert.ok(moves.some(x => x.id === m.id && x.side === m.side)); D.play(st, m.id, m.side); }
      else if (st.stock.length) D.draw(st); else D.pass(st);
      assert.ok(D.validate(st));
    }
    assert.ok(st.phase === 'roundOver' || st.phase === 'over');
  }
  // with 6-5 and 0-1 both fitting the open 6/1 ends, it plays the heavy tile
  const st = D.createMatch({ players: 2 });
  D.deal(st, D.shuffled(rng(11)));
  st.first = { id: id(6, 1), a: 6, b: 1 }; st.L = []; st.R = []; st.lead = null; st.turn = 1;
  const keep = ids([[6, 5], [0, 1]]);
  const pool = st.hands[1].concat(st.hands[0], st.stock).filter(x => !keep.includes(x) && x !== id(6, 1));
  st.hands = [pool.slice(0, 7), keep]; st.stock = pool.slice(7);
  let heavy = 0;
  for (let i = 0; i < 40; i++) if (AI.choose(st, rng(200 + i)).id === id(6, 5)) heavy++;
  assert.ok(heavy >= 36, heavy);
});

console.log(`\n${passed} domino tests passed`);
