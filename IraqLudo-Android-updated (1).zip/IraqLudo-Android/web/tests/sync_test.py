"""The app and the website share one account and one progress.
Two browsers play the parts of the phone (app edition) and the website (firebase/hosting), both talking to
one fake Firebase server held by this script (web/tests/fake_firebase.js enforces the same security rules).
Checks: same account on both, progress copied both ways, Ludo and dominoes matches played on both devices all
count (also while one of them is offline), a sync that is repeated or cut off counts once, two tabs on one
account do not disturb each other, dinars spent on one side show on the other, account deletion removes
the copy, and website extras (offline copy, browser Back button, keyboard roll, icons).
Usage:  python3 web/tests/sync_test.py [chromium_path]"""
import asyncio, functools, http.server, json, os, sys, threading
from playwright.async_api import async_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
APP = os.path.join(ROOT, 'app/src/main/assets')
SITE = os.path.join(ROOT, 'firebase/hosting')
FAKE = open(os.path.join(ROOT, 'web/tests/fake_firebase.js'), encoding='utf-8').read()
CONFIG = "window.LUDO_CONFIG = { firebase: { apiKey: 'test-key', authDomain: 'demo.firebaseapp.com', projectId: 'demo-iraq-ludo', appId: '1:1:web:1' }, functionsRegion: 'me-central2', androidUrl: 'https://play.google.com/store/apps/details?id=iq.iraqludo.app' };"
CH = (sys.argv[1] or None) if len(sys.argv) > 1 else None
T = '#screens > section:last-of-type '
results = []
SERVER = {'state': ''}          # the one fake Firebase server both "devices" talk to

def check(name, cond, info=''):
    results.append((name, bool(cond)))
    print(('PASS ' if cond else 'FAIL ') + name + (f'  [{info}]' if info != '' else ''))

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
def serve(folder):
    srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(Quiet, directory=folder))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv

AUTOPLAY = """async (maxMs) => {
  const t0 = Date.now();
  while (Date.now() - t0 < maxMs) {
    const top = document.querySelector('#screens > section:last-of-type').dataset.screen;
    if (top !== 'game') return top;
    if (!G.busy && G.alive && !G.paused && isHuman(E.current(G.st))) {
      if (G.st.phase === 'roll') humanRoll(); else if (G.st.phase === 'move') humanMove(LudoAI.choose(G.st));
    }
    await new Promise(r => setTimeout(r, 12));
  }
  return 'timeout';
}"""

DOMAUTO = """async (maxMs) => {
  const t0 = Date.now();
  while (Date.now() - t0 < maxMs) {
    const top = document.querySelector('#screens > section:last-of-type').dataset.screen;
    if (top !== 'dgame') return top;
    const ok = document.querySelector('.sheet [data-x="ok"]');
    if (ok) ok.click();
    else if (!DG.busy && DG.alive && !DG.paused && DG.st.phase === 'play' && DG.st.turn === 0) {
      if (DE.legalMoves(DG.st).length) { const c = DominoAI.choose(DG.st); dHumanPlay(c.id, c.side); }
      else if (DG.st.stock.length) dHumanDraw(true);
    }
    await new Promise(r => setTimeout(r, 12));
  }
  return 'timeout';
}"""

async def main():
    app_srv, site_srv = serve(APP), serve(SITE)
    app_url = f'http://127.0.0.1:{app_srv.server_address[1]}/index.html'
    site_url = f'http://localhost:{site_srv.server_address[1]}/'
    async def fake_srv(op, payload):
        if op == 'set': SERVER['state'] = payload
        return SERVER['state']
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path=CH, args=['--no-sandbox'])
        errs = []
        async def device(url, w, h, mobile):
            ctx = await b.new_context(viewport={'width': w, 'height': h}, is_mobile=mobile, has_touch=mobile)
            await ctx.expose_function('__fakeSrv', fake_srv)
            await ctx.route('**/config.js', lambda r: r.fulfill(status=200, content_type='application/javascript', body=CONFIG))
            await ctx.route('**/firebase.js', lambda r: r.fulfill(status=200, content_type='application/javascript', body=FAKE))
            pg = await ctx.new_page(); pg.set_default_timeout(8000)
            tag = 'phone' if mobile else 'site'
            pg.on('pageerror', lambda e: errs.append(f'{tag} PAGEERROR: {e}'))
            pg.on('console', lambda m: errs.append(f'{tag} {m.type}: {m.text}') if m.type == 'error' else None)
            await pg.goto(url); await pg.wait_for_timeout(2300)
            return ctx, pg
        top = lambda pg: pg.evaluate("document.querySelector('#screens > section:last-of-type').dataset.screen")
        async def act(pg, name, w=700): await pg.click(T + f'[data-act="{name}"]'); await pg.wait_for_timeout(w)
        async def play(pg, players=2):
            await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)
            await act(pg, 'playLudo')
            await pg.click(T + f'[data-act="setPlayers"][data-v="{players}"]'); await pg.evaluate("window.__LUDO_TURBO = true")
            await act(pg, 'startGame', 1200)
            res = await pg.evaluate(AUTOPLAY, 240000)
            await pg.evaluate("window.__LUDO_TURBO = false"); await pg.evaluate("reset('home')"); await pg.wait_for_timeout(600)
            return res
        prog = lambda pg: pg.evaluate("JSON.stringify({xp: Progress.data.xp, points: Progress.data.points, games: Progress.data.stats.games, dom: Progress.data.stats.dom.games, owned: Progress.data.owned.avatar})")
        async def play_dom(pg, players=2):
            await pg.evaluate("reset('home')"); await pg.wait_for_timeout(500)
            await act(pg, 'playDom')
            await pg.click(T + f'[data-act="setDomPlayers"][data-v="{players}"]'); await pg.click(T + '[data-act="setDomTarget"][data-v="50"]')
            await pg.evaluate("window.__LUDO_TURBO = true")
            await act(pg, 'startDom', 1400)
            res = await pg.evaluate(DOMAUTO, 240000)
            await pg.evaluate("window.__LUDO_TURBO = false"); await pg.evaluate("reset('home')"); await pg.wait_for_timeout(600)
            return res
        async def server_prog(pg):
            st = await pg.evaluate("FAKE.state()")
            uid = await pg.evaluate("Accounts.user.uid")
            return st['docs'].get(f'players/{uid}/progress/main')

        # ---------- phone: new account, one game ----------
        phone_ctx, phone = await device(app_url, 412, 880, True)
        await act(phone, 'welcomeDone', 1000)
        await act(phone, 'toRegister')
        await phone.fill('#rg-u', 'sync.user'); await phone.wait_for_timeout(800)
        await phone.fill('#rg-n', 'ليث'); await phone.fill('#rg-p', 'Sync2026x'); await phone.fill('#rg-p2', 'Sync2026x'); await phone.click('#rg-ok')
        await act(phone, 'doRegister', 2500); await phone.click('#rc-ok'); await act(phone, 'rcDone', 1200)
        check('phone: account created in server mode', await top(phone) == 'home' and await phone.evaluate("Accounts.cloud") == True)
        check('phone: game 1 finished', await play(phone) == 'result')
        await phone.evaluate("Progress.sync()")
        sp = await server_prog(phone)
        check('progress copied to the server after the game', sp is not None and sp['stats']['games'] == 1, sp and sp['stats']['games'])

        # ---------- website: same account shows the same progress ----------
        site_ctx, site = await device(site_url, 1280, 820, False)
        check('website opens on the welcome slides', await top(site) == 'welcome')
        await act(site, 'welcomeDone', 1000)
        await site.fill('#li-u', 'sync.user'); await site.fill('#li-p', 'Sync2026x'); await act(site, 'doLogin', 1800)
        await site.evaluate("Progress.sync()"); await site.wait_for_timeout(500)
        a, s = json.loads(await prog(phone)), json.loads(await prog(site))
        check('website: same account signs in', await top(site) == 'home' and await site.evaluate("Accounts.user.name") == 'ليث')
        check('website: same XP, points and games as the phone', a['xp'] == s['xp'] and a['points'] == s['points'] and s['games'] == 1, (a, s))
        check('website home shows the synced points', str(s['points']) in (await site.inner_text(T + '.pts')).replace(',', ''))
        check('website: Android app link shown when androidUrl is set', await site.locator(T + 'a.applink').count() == 1)

        # ---------- both devices play; nothing is lost ----------
        await play(phone); await phone.evaluate("Progress.sync()")
        await play(site)                                   # the website has not seen the phone's 2nd game yet
        await site.evaluate("Progress.sync()")
        sp = await server_prog(site)
        check('games from both devices add up (1 + 1 + 1 = 3)', sp['stats']['games'] == 3 and await site.evaluate("Progress.data.stats.games") == 3, sp['stats']['games'])
        await phone.evaluate("Progress.sync()")
        a, s = json.loads(await prog(phone)), json.loads(await prog(site))
        check('phone receives the website game', a['games'] == 3 and a['xp'] == s['xp'] and a['points'] == s['points'], (a, s))

        # ---------- a sync whose answer is lost, or that is cut off, still counts once ----------
        GAME = "Progress.recordGame({ game: 'ludo', players: 2, won: true, forfeit: false, captures: 1, lost: 0, sixes: 1, home: 4, rolls: 10, turns: 30, durationSec: 60 })"
        srv_log = lambda pg: pg.evaluate("FAKE.state().then(s => s.log)")
        await phone.wait_for_timeout(2200)                              # let earlier timers finish
        g0 = (await server_prog(phone))['stats']['games']
        await phone.evaluate("window.__fakeLoseAck = 1"); await phone.evaluate(GAME)
        await phone.evaluate("Progress.sync()")
        sp = await server_prog(phone)
        check('answer lost and the sync sent again: the game counts once', sp['stats']['games'] == g0 + 1 and await phone.evaluate("Progress.data.stats.games") == g0 + 1, sp['stats']['games'])
        await phone.wait_for_timeout(2200)
        await phone.evaluate("window.__fakeDropAfter = 1"); await phone.evaluate(GAME)
        ok = await phone.evaluate("Progress.sync()")
        check('sync cut off after the server saved it: the device knows it is not confirmed', ok is False and (await server_prog(phone))['stats']['games'] == g0 + 2, ok)
        await phone.reload(); await phone.wait_for_timeout(2800)       # the app is closed and opened again
        await phone.evaluate("Progress.sync()")
        sp = await server_prog(phone)
        check('after reopening, that change is not added a second time', sp['stats']['games'] == g0 + 2 and await phone.evaluate("Progress.data.stats.games") == g0 + 2
              and sp['xp'] == await phone.evaluate("Progress.data.xp") and sp['points'] == await phone.evaluate("Progress.data.points"), (sp['stats']['games'], sp['xp']))
        await phone.wait_for_timeout(2200)
        n = len(await srv_log(phone))
        await phone.evaluate("Progress.sync()")
        log = (await srv_log(phone))[n:]
        check('a sync with nothing new only reads (no write)', len(log) > 0 and all(l[0] in ('transaction', 'commit') and l[1] == [] for l in log), log)
        check('the server copy remembers one sync id per device', len(sp.get('ops', {})) == 2, sp.get('ops'))

        # ---------- the same account open in two tabs ----------
        tab2 = await phone_ctx.new_page(); tab2.set_default_timeout(8000)
        tab2.on('pageerror', lambda e: errs.append(f'tab2 PAGEERROR: {e}'))
        await tab2.goto(app_url); await tab2.wait_for_timeout(2800)
        await phone.evaluate(GAME); await phone.evaluate("Progress.sync()"); await tab2.wait_for_timeout(400)
        check('second tab sees the match played in the first', await tab2.evaluate("Progress.data.stats.games") == g0 + 3, await tab2.evaluate("Progress.data.stats.games"))
        await tab2.evaluate("Progress.sync()")
        check('syncing from the other tab does not undo it', (await server_prog(phone))['stats']['games'] == g0 + 3, (await server_prog(phone))['stats']['games'])
        await phone.wait_for_timeout(2200)
        await phone.evaluate("window.__fakeOffline = true"); await tab2.evaluate("window.__fakeOffline = true")
        await phone.evaluate(GAME); await phone.wait_for_timeout(2200)  # both tabs now hold the same unsent match
        await phone.evaluate("window.__fakeOffline = false"); await tab2.evaluate("window.__fakeOffline = false")
        await asyncio.gather(phone.evaluate("Progress.sync()"), tab2.evaluate("Progress.sync()"))
        await phone.wait_for_timeout(1200)
        sp = await server_prog(phone)
        check('two tabs sending the same match: counted once', sp['stats']['games'] == g0 + 4 and await phone.evaluate("Progress.data.stats.games") == g0 + 4 and await tab2.evaluate("Progress.data.stats.games") == g0 + 4,
              (sp['stats']['games'], await phone.evaluate("Progress.data.stats.games"), await tab2.evaluate("Progress.data.stats.games")))
        await tab2.close()
        await site.evaluate("Progress.sync()"); await site.wait_for_timeout(300)

        # ---------- dominoes on the website, seen on the phone ----------
        check('website: a dominoes match (to 50) finishes', await play_dom(site) == 'domResult')
        await site.evaluate("Progress.sync()")
        await phone.evaluate("Progress.sync()"); await phone.wait_for_timeout(300)
        a, s = json.loads(await prog(phone)), json.loads(await prog(site))
        check('the dominoes match played on the website shows on the phone', a['dom'] == 1 and s['dom'] == 1 and a['points'] == s['points'] and a['xp'] == s['xp'], (a, s))

        # ---------- website offline for one game ----------
        await site.evaluate("window.__fakeOffline = true")
        await play(site)
        ok = await site.evaluate("Progress.sync()")
        check('offline: the game stays on the device', ok is False and (await server_prog(site))['stats']['games'] == 7, (await server_prog(site))['stats']['games'])
        await site.evaluate("window.__fakeOffline = false; window.dispatchEvent(new Event('online'))"); await site.wait_for_timeout(1500)
        check('back online: it is sent to the server', (await server_prog(site))['stats']['games'] == 8)

        # ---------- spending points on the website shows on the phone ----------
        pts = await site.evaluate("Progress.data.points")
        await site.evaluate("Progress.data.points = Math.max(Progress.data.points, 120); Progress.save()"); await site.wait_for_timeout(100)
        await site.evaluate("reset('shop')"); await site.wait_for_timeout(600)
        await site.click(T + '[data-act="buy"][data-id="tea"]'); await site.wait_for_timeout(300)
        await site.evaluate("Progress.sync()")
        await phone.evaluate("reset('home')"); await phone.wait_for_timeout(500)
        await phone.evaluate("Progress.sync()"); await phone.wait_for_timeout(400)
        a, s = json.loads(await prog(phone)), json.loads(await prog(site))
        check('item unlocked on the website is owned on the phone', 'tea' in a['owned'] and a['points'] == s['points'], (a['points'], s['points']))
        check('phone home redraws with the new points', str(a['points']) in (await phone.inner_text(T + '.pts')).replace(',', ''))

        # ---------- website extras ----------
        check('website: browser tab title', await site.title() == 'عراق لودو · Iraq Ludo')
        for path in ['manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/favicon.svg', 'icons/og.png', 'sw.js']:
            r = await site.request.get(site_url + path)
            check(f'website file served: {path}', r.ok)
        await site.evaluate("reset('home')"); await site.wait_for_timeout(500)
        await site.mouse.click(5, 5); await site.wait_for_timeout(100)            # a user gesture arms the Back handling
        await act(site, 'howto', 800)
        url_before = site.url
        await site.go_back(); await site.wait_for_timeout(900)
        check('browser Back goes back one screen inside the game', await top(site) == 'home' and site.url == url_before, await top(site))
        await act(site, 'playLudo'); await act(site, 'startGame', 1500)
        for i in range(60):
            if await site.evaluate("isHuman(E.current(G.st)) && G.st.phase === 'roll' && !G.busy"): break
            await site.wait_for_timeout(250)
        rolls = await site.evaluate("G.st.stats[G.setup.human].rolls")
        await site.keyboard.press('Space'); await site.wait_for_timeout(2000)
        check('Space key rolls the dice', await site.evaluate("G.st.stats[G.setup.human].rolls") == rolls + 1)
        await site.evaluate("G.alive = false; G.gen++; reset('home')"); await site.wait_for_timeout(600)
        sw = await site.evaluate("navigator.serviceWorker.ready.then(r => !!r.active).catch(() => false)")
        check('website: offline copy installed (service worker)', sw)
        await site_ctx.set_offline(True)
        await site.reload(); await site.wait_for_timeout(2500)
        check('website opens without internet', await top(site) in ('home', 'login'), await top(site))
        await site_ctx.set_offline(False)

        # ---------- deleting the account removes the shared copy ----------
        uid = await phone.evaluate("Accounts.user.uid")
        await phone.evaluate("reset('settings')"); await phone.wait_for_timeout(600)
        await phone.click(T + '[data-act="deleteAcc"]'); await phone.wait_for_timeout(600)
        await phone.fill('#da-p', 'Sync2026x'); await phone.click('.sheet [data-x="ok"]'); await phone.wait_for_timeout(2200)
        st = await phone.evaluate("FAKE.state()")
        check('account deletion removes the progress copy', f'players/{uid}/progress/main' not in st['docs'] and await top(phone) == 'login')
        denied = [l for l in st['log'] if l[0] == 'DENIED']
        check('no security-rule denials during sync', not denied, denied)

        real = [e for e in errs if 'favicon' not in e]
        check('no console errors on either device', not real, '\n'.join(real[:6]))
        print(f"\n{sum(1 for _, ok in results if ok)}/{len(results)} checks passed")
        await b.close()
    app_srv.shutdown(); site_srv.shutdown()

asyncio.run(main())
