/* Rules engine unit tests: node web/tests/engine.test.js */
const assert = require('assert');
const E = require('../src/01_engine.js');
let passed = 0;
const test = (name, fn) => { fn(); passed++; console.log('PASS', name); };
const setTokens = (st, c, arr) => { st.tokens[c] = arr.slice(); };

test('create: clockwise order, all tokens in yard, red starts', () => {
  const st = E.createGame({ colors: ['blue', 'red', 'yellow', 'green'] });
  assert.deepStrictEqual(st.colors, ['red', 'green', 'yellow', 'blue']);
  assert.strictEqual(E.current(st), 'red');
  assert.ok(st.colors.every(c => st.tokens[c].every(p => p === -1)));
  assert.ok(E.validate(st));
});

test('create: first player can be chosen', () => {
  const st = E.createGame({ colors: ['red', 'yellow'], first: 'yellow' });
  assert.strictEqual(E.current(st), 'yellow');
});

test('track geometry: start squares and pre-home squares', () => {
  assert.strictEqual(E.globalOf('red', 0), 0);
  assert.strictEqual(E.globalOf('green', 0), 13);
  assert.strictEqual(E.globalOf('yellow', 50), 24);
  assert.strictEqual(E.globalOf('blue', 50), 37);
  assert.strictEqual(E.globalOf('red', 51), -1);
  // no colour ever stands on the square just before its own start
  for (const c of E.COLORS) for (let r = 0; r <= 50; r++) assert.notStrictEqual(E.globalOf(c, r), (E.START[c] + 51) % 52);
});

test('non-six with all tokens in the yard passes the turn', () => {
  const st = E.createGame({ colors: ['red', 'green'] });
  const ev = E.roll(st, 4);
  assert.ok(ev.some(e => e.type === 'pass' && e.reason === 'noMove'));
  assert.strictEqual(E.current(st), 'green');
  assert.strictEqual(st.phase, 'roll');
});

test('six enters a token on the start square and gives another roll', () => {
  const st = E.createGame({ colors: ['red', 'green'] });
  const ev = E.roll(st, 6);
  assert.strictEqual(st.phase, 'move');
  assert.deepStrictEqual(ev.find(e => e.type === 'choose').tokens, [0, 1, 2, 3]);
  const ev2 = E.move(st, 2);
  assert.strictEqual(st.tokens.red[2], 0);
  assert.ok(ev2.some(e => e.type === 'again' && e.reason === 'six'));
  assert.strictEqual(E.current(st), 'red');
});

test('three sixes in a row lose the turn', () => {
  const st = E.createGame({ colors: ['red', 'green'] });
  E.roll(st, 6); E.move(st, 0);
  E.roll(st, 6); E.move(st, 0);
  const ev = E.roll(st, 6);
  assert.ok(ev.some(e => e.type === 'pass' && e.reason === 'threeSixes'));
  assert.strictEqual(E.current(st), 'green');
  assert.strictEqual(st.tokens.red[0], 6, 'third six is void');
});

test('a non-six resets the six counter', () => {
  const st = E.createGame({ colors: ['red', 'green'] });
  E.roll(st, 6); E.move(st, 0);
  assert.strictEqual(st.sixes, 1);
  setTokens(st, 'green', [10, -1, -1, -1]);              // green rel 10 = global 23
  st.tokens.red[0] = 20;                                 // red at global 20, roll 3 -> 23 captures
  E.roll(st, 3);
  assert.strictEqual(st.sixes, 0);
  const ev = E.move(st, 0);
  assert.ok(ev.some(e => e.type === 'capture' && e.victim === 'green'));
  assert.ok(ev.some(e => e.type === 'again' && e.reason === 'capture'));
});

test('capture sends the token back to the yard', () => {
  const st = E.createGame({ colors: ['red', 'green'] });
  setTokens(st, 'red', [17, -1, -1, -1]);
  setTokens(st, 'green', [7, -1, -1, -1]);               // green rel 7 = global 20
  E.roll(st, 3);
  const ev = E.move(st, 0);
  assert.strictEqual(st.tokens.green[0], -1);
  assert.strictEqual(st.stats.red.captures, 1);
  assert.strictEqual(st.stats.green.lost, 1);
  assert.ok(ev.some(e => e.type === 'capture' && e.square === 20));
});

test('star squares are safe', () => {
  const st = E.createGame({ colors: ['red', 'green'] });
  setTokens(st, 'red', [18, -1, -1, -1]);
  setTokens(st, 'green', [8, -1, -1, -1]);               // green rel 8 = global 21 (star)
  E.roll(st, 3);
  const ev = E.move(st, 0);
  assert.ok(!ev.some(e => e.type === 'capture'));
  assert.strictEqual(st.tokens.green[0], 8);
  assert.strictEqual(st.tokens.red[0], 21);
});

test('start squares are safe', () => {
  const st = E.createGame({ colors: ['red', 'green'] });
  setTokens(st, 'red', [10, -1, -1, -1]);
  setTokens(st, 'green', [0, -1, -1, -1]);               // on its start square, global 13
  E.roll(st, 3);
  const ev = E.move(st, 0);
  assert.ok(!ev.some(e => e.type === 'capture'));
});

test('a pair of same-colour tokens cannot be captured', () => {
  const st = E.createGame({ colors: ['red', 'green'] });
  setTokens(st, 'red', [17, -1, -1, -1]);
  setTokens(st, 'green', [7, 7, -1, -1]);
  E.roll(st, 3);
  const ev = E.move(st, 0);
  assert.ok(!ev.some(e => e.type === 'capture'));
  assert.deepStrictEqual(st.tokens.green.slice(0, 2), [7, 7]);
});

test('exact roll needed to finish; finishing gives another roll', () => {
  const st = E.createGame({ colors: ['red', 'green'] });
  setTokens(st, 'red', [54, 56, 56, -1]);
  assert.strictEqual(E.moveTarget(st, 'red', 0, 3), null);
  E.roll(st, 2);
  const ev = E.move(st, 0);
  assert.strictEqual(st.tokens.red[0], 56);
  assert.ok(ev.some(e => e.type === 'home'));
  assert.ok(ev.some(e => e.type === 'again' && e.reason === 'home'));
});

test('home column is private: no capture inside it', () => {
  const st = E.createGame({ colors: ['red', 'green'] });
  setTokens(st, 'red', [50, -1, -1, -1]);
  E.roll(st, 3);
  E.move(st, 0);
  assert.strictEqual(st.tokens.red[0], 53);
  assert.strictEqual(E.globalOf('red', 53), -1);
});

test('six with no legal move still gives another roll', () => {
  const st = E.createGame({ colors: ['red', 'green'] });
  setTokens(st, 'red', [52, 53, 54, 56]);
  const ev = E.roll(st, 6);
  assert.ok(ev.some(e => e.type === 'again' && e.reason === 'six'));
  assert.strictEqual(E.current(st), 'red');
});

test('win when all four tokens are home', () => {
  const st = E.createGame({ colors: ['red', 'green'] });
  setTokens(st, 'red', [55, 56, 56, 56]);
  E.roll(st, 1);
  const ev = E.move(st, 0);
  assert.strictEqual(st.winner, 'red');
  assert.strictEqual(st.phase, 'over');
  assert.ok(ev.some(e => e.type === 'win'));
  assert.throws(() => E.roll(st, 3));
});

test('illegal moves are rejected', () => {
  const st = E.createGame({ colors: ['red', 'green'] });
  assert.throws(() => E.move(st, 0), /not-move-phase/);
  E.roll(st, 6);
  setTokens(st, 'red', [-1, -1, -1, 56]);
  assert.throws(() => E.move(st, 3), /illegal-move/);
  assert.throws(() => E.roll(st, 4), /not-roll-phase/);
});

test('bad dice values are rejected', () => {
  const st = E.createGame({ colors: ['red', 'green'] });
  assert.throws(() => E.roll(st, 7)); assert.throws(() => E.roll(st, 0)); assert.throws(() => E.roll(st, 2.5));
});

test('forfeit: tokens leave the board; last player standing wins', () => {
  const st = E.createGame({ colors: ['red', 'green', 'yellow'] });
  setTokens(st, 'green', [5, 20, 56, -1]);
  E.forfeit(st, 'green');
  assert.deepStrictEqual(st.tokens.green, [-1, -1, 56, -1]);
  assert.strictEqual(E.current(st), 'red');
  const ev = E.forfeit(st, 'red');
  assert.strictEqual(st.winner, 'yellow');
  assert.ok(ev.some(e => e.type === 'win' && e.byForfeit));
});

test('turn skips players who left', () => {
  const st = E.createGame({ colors: ['red', 'green', 'yellow', 'blue'] });
  E.forfeit(st, 'green');
  E.roll(st, 2);                                         // red has no move -> pass
  assert.strictEqual(E.current(st), 'yellow');
});

test('validate rejects corrupted saves', () => {
  const st = E.createGame({ colors: ['red', 'green'] });
  const bad = E.clone(st); bad.tokens.red[0] = 99;
  assert.ok(!E.validate(bad));
  assert.ok(!E.validate({}));
});

test('validate accepts only saves that can be played on', () => {
  const st = E.createGame({ colors: ['red', 'green'] });
  const edit = fn => { const c = E.clone(st); fn(c); return E.validate(c); };
  assert.ok(E.validate(E.clone(st)));
  assert.ok(!edit(c => { delete c.stats; }), 'no statistics');
  assert.ok(!edit(c => { delete c.out; }), 'no "left the game" map');
  assert.ok(!edit(c => { c.v = 99; }), 'another rules version');
  assert.ok(!edit(c => { c.colors = ['red', 'purple']; c.tokens.purple = [-1, -1, -1, -1]; }), 'unknown colour');
  assert.ok(!edit(c => { c.tokens.red = [E.HOME, E.HOME, E.HOME, E.HOME]; }), 'decided but still waiting for a roll');
  assert.ok(!edit(c => { c.phase = 'move'; c.dice = 3; }), 'move phase with nothing to move');     // all tokens in the yard and no 6
  assert.ok(!edit(c => { c.lastRoll = { value: 9 }; }), 'impossible last roll');
  assert.ok(!edit(c => { c.phase = 'over'; }), 'over without a winner');
  const live = E.clone(st); E.roll(live, 6); assert.ok(live.phase === 'move' && E.validate(E.clone(live)));
});

console.log(`\n${passed} engine tests passed`);
