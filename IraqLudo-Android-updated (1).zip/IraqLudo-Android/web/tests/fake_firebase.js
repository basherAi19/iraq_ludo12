/* In-browser stand-in for the Firebase SDK bundle (assets/firebase.js) used by web/tests/firebase_flow_test.py.
   It implements only the calls the game makes and enforces the same checks as firebase/firestore.rules and
   the recoverAccount function. The "server" lives in localStorage, or — when the test exposes
   window.__fakeSrv — in the test process, so two browsers (the app and the website) share one server.
   The signed-in account is kept per browser, like Firebase Auth. Test-only: never shipped. */
(() => {
  const KEY = 'FAKE_FIREBASE', SESSION = 'FAKE_SESSION', SESSION_T = 'FAKE_SESSION_T';
  const SHARED = typeof window.__fakeSrv === 'function';
  const blank = () => ({ users: {}, docs: {}, nextUid: 1, log: [] });
  const loadLocal = () => { try { return JSON.parse(localStorage.getItem(KEY)) || null; } catch (e) { return null; } };
  let S = SHARED ? blank() : (loadLocal() || blank());
  async function pull() { if (SHARED) { const j = await window.__fakeSrv('get', ''); if (j) S = JSON.parse(j); } }
  async function push() { if (SHARED) await window.__fakeSrv('set', JSON.stringify(S)); else localStorage.setItem(KEY, JSON.stringify(S)); }
  const session = () => localStorage.getItem(SESSION);
  const listeners = [];
  const notify = () => setTimeout(() => listeners.slice().forEach(cb => { try { cb(auth.currentUser); } catch (e) {} }), 0);
  // the time of the last password sign-in (the ID token's auth_time), kept per browser
  const setSession = email => { if (email) { localStorage.setItem(SESSION, email); localStorage.setItem(SESSION_T, String(Date.now())); } else { localStorage.removeItem(SESSION); localStorage.removeItem(SESSION_T); } notify(); };
  const clone = o => (o === undefined ? undefined : JSON.parse(JSON.stringify(o)));
  const err = code => Object.assign(new Error(code), { code });
  const tick = () => new Promise(r => setTimeout(r, 5));

  /* ---------- auth ---------- */
  const userObj = rec => rec && { uid: rec.uid, email: rec.email, displayName: rec.displayName || null, metadata: { creationTime: new Date(rec.created).toUTCString() } };
  const auth = { get currentUser() { const e = session(); return e && S.users[e] ? userObj(S.users[e]) : null; } };
  const byUid = uid => Object.values(S.users).find(u => u.uid === uid);
  const authCtx = () => { const u = auth.currentUser; return u ? { uid: u.uid, email: u.email, provider: 'password', authTime: +localStorage.getItem(SESSION_T) || 0 } : null; };

  /* ---------- security rules (mirror of firebase/firestore.rules) ---------- */
  const RESERVED = ['admin', 'administrator', 'root', 'support', 'help', 'system', 'moderator', 'mod', 'staff', 'iraqludo', 'ludo', 'official', 'guest', 'bot', 'computer', 'null', 'undefined', 'test'];
  const validUsername = u => typeof u === 'string' && /^[a-z][a-z0-9_.]{2,19}$/.test(u) && !/\.\./.test(u) && !/\.$/.test(u) && !RESERVED.includes(u.replace(/[._]/g, ''));
  const myUsername = a => a.email.split('@')[0];
  const passwordAccount = a => a.provider === 'password' && (/^[a-z0-9_.]+@[a-z0-9-]+\.firebaseapp\.com$/.test(a.email) || /^[a-z0-9_.]+@players\.iraqludo\.app$/.test(a.email));
  const freshLogin = a => Date.now() - a.authTime < 600000;
  const validName = n => typeof n === 'string' && [...n].length >= 2 && [...n].length <= 20 && !/(https?:|www\.|\.com|\.net|\.org|\.iq|t\.me|wa\.me|@)/.test(n.toLowerCase());
  const validAvatar = a => typeof a === 'string' && /^[a-z]{2,12}$/.test(a);
  const hasOnly = (o, keys) => Object.keys(o).every(k => keys.includes(k));
  const isNum = v => typeof v === 'number';
  const isInt = v => Number.isInteger(v);
  const isMap = v => !!v && typeof v === 'object' && !Array.isArray(v);
  const PROGRESS_KEYS = ['v', 'xp', 'points', 'badges', 'daily', 'ch', 'owned', 'equipped', 'stats', 'updatedAt', 'ops'];

  function allowed(op, path, data, before, after, a) {
    const [col, id, sub, subId] = path.split('/');
    const res = before[path], req = data;
    if (col === 'usernames' && !sub) {
      if (op === 'get') return true;
      if (op === 'create') return !!a && passwordAccount(a) && validUsername(id) && myUsername(a) === id && hasOnly(req, ['uid', 'createdAt']) && req.uid === a.uid && isNum(req.createdAt)
        && before['players/' + a.uid] === undefined;
      if (op === 'delete') return !!a && (res === undefined || res.uid === a.uid);
      return false;
    }
    if (col === 'recovery' && !sub) {
      if (op === 'create') return !!a && a.uid === id && passwordAccount(a) && freshLogin(a) && hasOnly(req, ['algo', 'iter', 'salt', 'hash', 'createdAt']) && req.algo === 'pbkdf2-sha256'
        && isInt(req.iter) && req.iter >= 100000 && req.iter <= 1000000 && typeof req.salt === 'string' && req.salt.length === 24
        && typeof req.hash === 'string' && req.hash.length === 44 && isNum(req.createdAt);
      if (op === 'delete') return !!a && a.uid === id && freshLogin(a);
      return false;                                              // get / update: never
    }
    if (col === 'players' && sub === 'progress') {
      const own = !!a && a.uid === id;
      if (op === 'get') return own;
      if (op === 'create' || op === 'update') return own && passwordAccount(a) && subId === 'main' && hasOnly(req, PROGRESS_KEYS) && isInt(req.xp) && req.xp >= 0 && isInt(req.points) && req.points >= 0
        && ['badges', 'daily', 'ch', 'owned', 'equipped', 'stats'].every(k => isMap(req[k])) && (req.ops === undefined || (isMap(req.ops) && Object.keys(req.ops).length <= 40));
      if (op === 'delete') return own;
      return false;
    }
    if (col === 'players' && !sub) {
      const own = !!a && a.uid === id;
      if (op === 'get') return !!a;
      if (op === 'create') return own && passwordAccount(a) && hasOnly(req, ['username', 'name', 'avatar', 'lang', 'level', 'createdAt', 'lastSeen'])
        && req.username === myUsername(a) && (after['usernames/' + req.username] || {}).uid === id && validName(req.name) && validAvatar(req.avatar)
        && ['ar', 'en'].includes(req.lang) && req.level === 1 && isNum(req.createdAt) && isNum(req.lastSeen);
      if (op === 'update') {
        const changed = Object.keys(Object.assign({}, res, req)).filter(k => JSON.stringify(res[k]) !== JSON.stringify(req[k]));
        return own && passwordAccount(a) && changed.every(k => ['name', 'avatar', 'lang', 'lastSeen', 'updatedAt'].includes(k)) && validName(req.name) && validAvatar(req.avatar) && ['ar', 'en'].includes(req.lang)
          && isNum(req.lastSeen) && (req.updatedAt === undefined || isNum(req.updatedAt));
      }
      if (op === 'delete') return own;
    }
    return false;
  }

  /* ---------- firestore ---------- */
  const db = { kind: 'db' };
  const doc = (d, ...segs) => ({ path: segs.join('/') });
  const snapOf = path => { const d = S.docs[path]; return { exists: () => d !== undefined, data: () => clone(d), id: path.split('/').pop() }; };
  async function getDoc(ref) {
    await tick(); await pull();
    if (!allowed('get', ref.path, null, S.docs, S.docs, authCtx())) throw err('permission-denied');
    return snapOf(ref.path);
  }
  function commitOps(ops) {
    const a = authCtx(), before = S.docs, after = clone(S.docs);
    for (const o of ops) {
      if (o.t === 'set') after[o.path] = clone(o.data);
      else if (o.t === 'update') { if (after[o.path] === undefined) throw err('not-found'); after[o.path] = Object.assign(after[o.path], clone(o.data)); }
      else if (o.t === 'delete') delete after[o.path];
    }
    for (const o of ops) {
      const exists = before[o.path] !== undefined;
      const op = o.t === 'delete' ? 'delete' : exists ? 'update' : 'create';     // a delete of a missing document is checked too (resource == null)
      if (!allowed(op, o.path, after[o.path], before, after, a)) { S.log.push(['DENIED', op, o.path]); throw err('permission-denied'); }
    }
    S.docs = after; S.log.push(['commit', ops.map(o => o.t + ' ' + o.path)]);
  }
  const writeBatch = () => {
    const ops = [];
    return { set(ref, data) { ops.push({ t: 'set', path: ref.path, data }); return this; }, update(ref, data) { ops.push({ t: 'update', path: ref.path, data }); return this; },
      delete(ref) { ops.push({ t: 'delete', path: ref.path }); return this; },
      async commit() { await tick(); await pull(); try { commitOps(ops); } finally { await push(); } } };
  };
  async function updateDoc(ref, data) { await tick(); await pull(); try { commitOps([{ t: 'update', path: ref.path, data }]); } finally { await push(); } }
  /* Like the real SDK: reads are checked again at commit time and the function is run again when a document it
     read was changed meanwhile (another browser). Test switches:
       __fakeOffline   the server cannot be reached (nothing is kept for later)
       __fakeLoseAck   n: the next n commits ARE applied but the answer is lost; the SDK then runs the function again
       __fakeDropAfter n: the next n commits are applied, then the call fails for good (as if the app was closed)  */
  async function runTransaction(d, fn) {
    await tick();
    for (let attempt = 0; attempt < 6; attempt++) {
      await pull();
      if (window.__fakeOffline) throw err('unavailable');
      const staged = [], a = authCtx(), seen = {};
      const tx = {
        async get(ref) { if (!allowed('get', ref.path, null, S.docs, S.docs, a)) throw err('permission-denied'); seen[ref.path] = JSON.stringify(S.docs[ref.path]); return snapOf(ref.path); },
        set(ref, data) { staged.push({ t: 'set', path: ref.path, data }); return tx; },
        delete(ref) { staged.push({ t: 'delete', path: ref.path }); return tx; }
      };
      const out = await fn(tx);
      await pull();
      if (Object.keys(seen).some(p => JSON.stringify(S.docs[p]) !== seen[p])) { S.log.push(['retry', Object.keys(seen)]); continue; }   // changed under us
      try { commitOps(staged); } finally { await push(); }
      S.log.push(['transaction', staged.map(o => o.t + ' ' + o.path)]); await push();
      if (window.__fakeDropAfter > 0) { window.__fakeDropAfter--; throw err('unavailable'); }
      if (window.__fakeLoseAck > 0) { window.__fakeLoseAck--; continue; }
      return out;
    }
    throw err('aborted');
  }

  /* ---------- auth calls ---------- */
  async function createUserWithEmailAndPassword(au, email, password) {
    await tick(); await pull();
    if (S.users[email]) throw err('auth/email-already-in-use');
    if (String(password).length < 6) throw err('auth/weak-password');
    const rec = { uid: 'uid' + (S.nextUid++), email, password, created: Date.now() };
    S.users[email] = rec; setSession(email); await push();
    return { user: userObj(rec) };
  }
  async function signInWithEmailAndPassword(au, email, password) {
    await tick(); await pull();
    const rec = S.users[email];
    if (!rec || rec.password !== password) throw err('auth/invalid-credential');
    if (window.__fakeAuthDown) throw err('auth/network-request-failed');
    setSession(email); return { user: userObj(rec) };
  }
  async function signOut() { setSession(null); }
  async function updateProfile(user, p) { await pull(); const r = byUid(user.uid); if (r) { r.displayName = p.displayName; await push(); } }
  async function deleteUser(user) {
    await pull();
    if (window.__fakeAuthDown) throw err('auth/network-request-failed');
    const r = byUid(user.uid); if (r) { delete S.users[r.email]; if (session() === r.email) setSession(null); await push(); }
  }
  const EmailAuthProvider = { credential: (email, password) => ({ email, password }) };
  async function reauthenticateWithCredential(user, cred) {
    await tick(); await pull(); const r = byUid(user.uid); if (!r || r.password !== cred.password) throw err('auth/invalid-credential');
    localStorage.setItem(SESSION_T, String(Date.now()));          // a fresh token
  }
  async function updatePassword(user, pw) { await pull(); const r = byUid(user.uid); r.password = pw; await push(); }

  /* ---------- callable functions (mirror of firebase/functions/index.js) ---------- */
  const b64 = buf => btoa(String.fromCharCode(...new Uint8Array(buf)));
  const fromB64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
  async function pbkdf2(secret, salt, iter) {
    const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), 'PBKDF2', false, ['deriveBits']);
    return b64(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: iter }, k, 256));
  }
  const RC = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const newCode = () => { const a = crypto.getRandomValues(new Uint8Array(16)); const s = [...a].map(b => RC[b % 32]).join(''); return `${s.slice(0, 4)}-${s.slice(4, 8)}-${s.slice(8, 12)}-${s.slice(12)}`; };
  const fns = { region: null };
  const tries = {};
  const callables = {
    async recoverAccount({ username, code, newPassword }) {
      await pull();
      const u = String(username || '').trim().toLowerCase(), c = String(code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
      const pwOk = p => typeof p === 'string' && p.length >= 8 && p.length <= 64 && /[a-zA-Z\u0600-\u06FF]/.test(p) && /\d/.test(p);
      if (!/^[a-z][a-z0-9_.]{2,19}$/.test(u) || c.length !== 16 || !pwOk(newPassword)) throw err('functions/invalid-argument');
      if (window.__fakeFnDown) throw err('functions/unavailable');
      const nd = S.docs['usernames/' + u], rec = nd && S.docs['recovery/' + nd.uid];
      if (!rec || (await pbkdf2(c, fromB64(rec.salt), rec.iter)) !== rec.hash) {
        // only wrong codes are counted (5 per name); the right code always works
        tries[u] = (tries[u] || 0) + 1;
        throw err(tries[u] > 5 ? 'functions/resource-exhausted' : 'functions/permission-denied');
      }
      const r = byUid(nd.uid); r.password = newPassword;
      const fresh = newCode(), salt = crypto.getRandomValues(new Uint8Array(16));
      S.docs['recovery/' + nd.uid] = { algo: 'pbkdf2-sha256', iter: 120000, salt: b64(salt), hash: await pbkdf2(fresh.replace(/-/g, ''), salt, 120000), createdAt: Date.now(), renewedAt: Date.now() };
      delete tries[u]; S.log.push(['recoverAccount', u]); await push();
      return { code: fresh };
    }
  };
  const httpsCallable = (f, name) => async data => { await tick(); return { data: await callables[name](data || {}) }; };

  window.FB = {
    initializeApp: cfg => ({ cfg }), initializeAuth: () => auth, getAuth: () => auth, indexedDBLocalPersistence: {}, browserLocalPersistence: {},
    initializeFirestore: () => db, getFirestore: () => db, persistentLocalCache: () => ({}), persistentSingleTabManager: () => ({ tabs: 1 }), persistentMultipleTabManager: () => ({ tabs: 'many' }),
    getFunctions: (app, region) => { fns.region = region; return fns; },
    onAuthStateChanged: (au, cb) => { listeners.push(cb); setTimeout(async () => { await pull(); if (listeners.includes(cb)) cb(auth.currentUser); }, 10); return () => { const i = listeners.indexOf(cb); if (i >= 0) listeners.splice(i, 1); }; },
    doc, getDoc, writeBatch, updateDoc, runTransaction,
    createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, updateProfile, deleteUser,
    EmailAuthProvider, reauthenticateWithCredential, updatePassword, httpsCallable
  };
  window.FAKE = {
    state: async () => { await pull(); return clone(S); }, region: () => fns.region,
    ageSession: ms => localStorage.setItem(SESSION_T, String((+localStorage.getItem(SESSION_T) || Date.now()) - ms)),   // the password was entered ms ago
    revoke: () => setSession(null),                                // the server ended this browser's session
    /* what a changed client could try: raw writes as the signed-in account (the rules still apply) */
    raw: async ops => { await pull(); try { commitOps(ops); return 'ok'; } catch (e) { return e.code; } finally { await push(); } }
  };
})();
