/* Dominoes simulation: node web/tests/domsim.js [matches]
   Plays complete matches (to 100 points) with the computer player against a random player,
   checks the rules invariants after every action, and reports results. */
const D = require('../src/02b_domino.js');
const AI = require('../src/02c_domino_ai.js');
const N = +process.argv[2] || 400;

function rng(seed) { let s = seed >>> 0; return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const randomMove = (st, r) => { const m = D.legalMoves(st); return m[Math.floor(r() * m.length)]; };

function check(st) {
  if (!D.validate(st)) throw new Error('invalid state');
  const n = st.hands.reduce((s, h) => s + h.length, 0) + st.stock.length + (st.first ? 1 + st.L.length + st.R.length : 0);
  if (n !== 28) throw new Error('tiles lost: ' + n);
}

function match(players, smart, seed) {
  const r = rng(seed), st = D.createMatch({ players });
  let rounds = 0, actions = 0, blocked = 0, pts = 0;
  while (st.phase !== 'over') {
    D.deal(st, D.shuffled(r)); rounds++;
    check(st);
    while (st.phase === 'play') {
      if (++actions > 20000) throw new Error('match did not finish');
      const seat = st.turn, moves = D.legalMoves(st);
      if (moves.length) {
        const m = smart(seat) ? AI.choose(st, r) : randomMove(st, r);
        if (!moves.some(x => x.id === m.id && x.side === m.side)) throw new Error('illegal choice');
        const ends = D.ends(st);
        D.play(st, m.id, m.side);
        if (ends && m.side !== 'C' && !D.has(m.id, ends[m.side === 'L' ? 0 : 1])) throw new Error('tile does not match');
      } else if (st.stock.length) D.draw(st);
      else {
        // knocking is only allowed when this player really has nothing that fits
        D.pass(st);
      }
      check(st);
    }
    if (st.result.reason === 'blocked') blocked++;
    pts += st.result.points;
    if (st.scores.some(x => x < 0)) throw new Error('negative score');
  }
  return { winner: st.winner, rounds, blocked, pts };
}

const t0 = Date.now(), out = [];
for (const players of [2, 4]) {
  let aiWins = 0, rounds = 0, blocked = 0, pts = 0;
  for (let i = 0; i < N; i++) {
    // the computer plays team 0 in even matches and team 1 in odd ones
    const aiTeam = i % 2, smart = seat => (players === 4 ? seat % 2 : seat) === aiTeam;
    const res = match(players, smart, (players * 100000) + i);
    if (res.winner === aiTeam) aiWins++;
    rounds += res.rounds; blocked += res.blocked; pts += res.pts;
  }
  out.push(`${players} players: computer vs random wins ${(aiWins / N * 100).toFixed(1)}%, ` +
    `${(rounds / N).toFixed(1)} rounds per match, ${(pts / rounds).toFixed(1)} points per round, ${(blocked / rounds * 100).toFixed(1)}% rounds blocked`);
}
// mirror matches: same player on both sides
let mirror = 0;
for (let i = 0; i < N; i++) { const res = match(2, () => true, 900000 + i); if (res.winner === 0) mirror++; }
out.push(`2 players, computer vs computer: seat 0 wins ${(mirror / N * 100).toFixed(1)}% (fair share 50%)`);
console.log(out.join('\n'));
console.log(`\n${N * 3} complete matches, all invariants held (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
