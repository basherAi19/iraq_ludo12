#!/usr/bin/env bash
# Builds the game into three editions from the same source (web/src):
#   app/src/main/assets/index.html   Android app (bundled font, reads config.js)
#   firebase/hosting/                 website for Firebase Hosting (same config.js → same accounts and progress)
#   web/dist/index.html               quick browser preview (Google Fonts, on-device test mode)
# Usage:  bash web/build.sh
set -euo pipefail
cd "$(dirname "$0")"
SRC=src
ASSETS=../app/src/main/assets
SITE=../firebase/hosting
DIST=dist
mkdir -p "$ASSETS/fonts" "$DIST" "$SITE/fonts" "$SITE/icons"

JS="$DIST/.bundle.js"
{
  echo '"use strict";'
  cat "$SRC/00_config.js" "$SRC/01_engine.js" "$SRC/02_ai.js" "$SRC/02b_domino.js" "$SRC/02c_domino_ai.js" "$SRC/03_i18n.js" \
      "$SRC/04_core.js" "$SRC/04b_look.js" "$SRC/04c_avatars.js" "$SRC/04d_fx.js" "$SRC/05_audio.js" "$SRC/06_backend.js" "$SRC/07_progress.js" "$SRC/08_board.js" "$SRC/09_screens_entry.js" \
      "$SRC/10_screens_main.js" "$SRC/11_game.js" "$SRC/11b_domino.js" "$SRC/12_actions.js"
} > "$JS"
node --check "$JS"
if grep -q '</script' "$JS"; then echo "bundle must not contain a closing script tag"; exit 1; fi

python3 - "$SRC/head.html" "$JS" "$ASSETS/index.html" "$SITE/index.html" "$DIST/index.html" <<'PY'
import sys
head, js, out_app, out_site, out_web = sys.argv[1:6]
h = open(head, encoding='utf-8').read()
code = open(js, encoding='utf-8').read()
local_font = ("<style>@font-face{font-family:'Baloo Bhaijaan 2';src:url(fonts/BalooBhaijaan2.ttf) format('truetype');"
              "font-weight:400 800;font-display:swap}</style>\n")
app_head = local_font + '<script src="config.js"></script>'
site_head = (
    '<meta name="description" content="لودو ودومنة بروح عراقية، مجاناً: العب ضد الكمبيوتر، واجمع الدنانير والشارات. نفس حسابك وتقدمك بالتطبيق والموقع.">\n'
    '<meta property="og:type" content="website">\n<meta property="og:title" content="عراق لودو · Iraq Ludo">\n'
    '<meta property="og:description" content="لودو ودومنة بروح عراقية، مجاناً. العب ضد الكمبيوتر، واجمع الدنانير والشارات.">\n'
    '<meta property="og:image" content="icons/og.png">\n<meta property="og:locale" content="ar_IQ">\n<meta name="twitter:card" content="summary_large_image">\n'
    '<link rel="icon" href="icons/favicon.svg" type="image/svg+xml">\n<link rel="icon" href="icons/icon-192.png" sizes="192x192" type="image/png">\n'
    '<link rel="apple-touch-icon" href="icons/apple-touch-icon.png">\n<link rel="manifest" href="manifest.webmanifest">\n'
    '<meta name="mobile-web-app-capable" content="yes">\n<meta name="apple-mobile-web-app-capable" content="yes">\n'
    '<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">\n'
    + local_font + '<script>window.LUDO_SITE = true;</script>\n<script src="config.js"></script>')
web_head = ('<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
            '<link href="https://fonts.googleapis.com/css2?family=Baloo+Bhaijaan+2:wght@400..800&display=swap" rel="stylesheet">\n'
            '<script>window.LUDO_CONFIG = {};</script>')
tail = code + '\n</script>\n</body>\n</html>\n'
open(out_app, 'w', encoding='utf-8').write(h.replace('<!--FONTS-->', app_head) + tail)
site = h.replace('<!--FONTS-->', site_head).replace('<title>Iraq Ludo</title>', '<title>عراق لودو · Iraq Ludo</title>')
open(out_site, 'w', encoding='utf-8').write(site + tail)
open(out_web, 'w', encoding='utf-8').write(h.replace('<!--FONTS-->', web_head) + tail)
PY
rm -f "$JS"

# website files: same settings, SDK and font as the app, plus icons, manifest and the offline copy
cp "$ASSETS/config.js" "$ASSETS/firebase.js" "$SITE/"
cp "$ASSETS/fonts/BalooBhaijaan2.ttf" "$ASSETS/fonts/OFL.txt" "$SITE/fonts/"
cp site/manifest.webmanifest "$SITE/"
cp site/icons/* "$SITE/icons/"
# the offline copy is renewed whenever any file of the site changes (config.js is always read from the network first)
STAMP=$(cd "$SITE" && find . -type f ! -name sw.js ! -name config.js | LC_ALL=C sort | xargs cat | sha1sum | cut -c1-12)
sed "s/__BUILD__/$STAMP/" site/sw.js > "$SITE/sw.js"

# shared rules engines for the Cloud Functions game server (Phase 3)
mkdir -p ../firebase/functions
cp "$SRC/01_engine.js" ../firebase/functions/engine.js
cp "$SRC/02b_domino.js" ../firebase/functions/domino.js

wc -c "$ASSETS/index.html" "$SITE/index.html" "$DIST/index.html" | sed 's#\.\./##'
