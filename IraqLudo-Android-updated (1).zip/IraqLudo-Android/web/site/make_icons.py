"""Draws the website icons and the link-preview image (black and gold, same die as the app logo).
Usage: python3 web/site/make_icons.py [chromium_path]   (needs Playwright; outputs to web/site/icons/)"""
import asyncio, base64, os, sys
from playwright.async_api import async_playwright
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'icons')
FONT = os.path.join(HERE, '..', '..', 'app', 'src', 'main', 'assets', 'fonts', 'BalooBhaijaan2.ttf')
CH = sys.argv[1] if len(sys.argv) > 1 else None
FONT64 = base64.b64encode(open(FONT, 'rb').read()).decode()

def die(x, y, s):
    """the app's MARK die (64-unit grid) placed at x,y with size s"""
    k = s / 64
    pips = ''.join(f'<circle cx="{px}" cy="{py}" r="5.2" fill="#16120B"/>' for px, py in [(20, 20), (44, 20), (32, 32), (20, 44), (44, 44)])
    return (f'<g transform="translate({x} {y}) scale({k})"><rect x="6" y="6" width="52" height="52" rx="14" fill="url(#dg)"/>'
            f'<rect x="9" y="9" width="46" height="46" rx="11" fill="none" stroke="#FFF3CF" stroke-opacity=".55" stroke-width="2"/>{pips}</g>')
DEFS = ('<defs><linearGradient id="dg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFE7A0"/><stop offset="1" stop-color="#D49A2A"/></linearGradient>'
        '<radialGradient id="bg" cx="50%" cy="42%" r="70%"><stop offset="0" stop-color="#3A2C12"/><stop offset=".55" stop-color="#15110A"/><stop offset="1" stop-color="#050403"/></radialGradient></defs>')

def square(size, die_frac):
    d = size * die_frac; o = (size - d) / 2
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 {size} {size}">{DEFS}<rect width="{size}" height="{size}" fill="url(#bg)"/>{die(o, o, d)}</svg>'

FAVICON = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">{DEFS}{die(0, 0, 64)}</svg>'

OG = f"""<html><head><style>
@font-face{{font-family:B;src:url(data:font/ttf;base64,{FONT64}) format('truetype');font-weight:400 800}}
body{{margin:0;width:1200px;height:630px;background:radial-gradient(70% 90% at 72% 40%,#3A2C12 0%,#15110A 55%,#050403 100%);font-family:B,sans-serif;display:flex;align-items:center;justify-content:center;gap:70px;direction:rtl;overflow:hidden}}
.t{{text-align:right}}
h1{{margin:0;font-size:150px;line-height:1.05;font-weight:800;background:linear-gradient(180deg,#FFF0C4 8%,#F0C35E 52%,#B98321 96%);-webkit-background-clip:text;color:transparent}}
p{{margin:14px 0 0;font-size:40px;font-weight:700;color:#F6EEDC}}
small{{display:block;margin-top:10px;font-size:30px;color:#BDB095;font-weight:600}}
</style></head><body>
<svg width="300" height="300" viewBox="0 0 64 64" style="filter:drop-shadow(0 24px 40px rgba(214,154,40,.5))">{DEFS}{die(0, 0, 64)}</svg>
<div class="t"><h1>عراق لودو</h1><p>لودو عراقي مجاني</p><small>العب ضد الكمبيوتر · بالموبايل والموقع</small></div>
</body></html>"""

async def main():
    os.makedirs(OUT, exist_ok=True)
    open(os.path.join(OUT, 'favicon.svg'), 'w').write(FAVICON)
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path=CH, args=['--no-sandbox'])
        for name, size, frac in [('icon-192.png', 192, .62), ('icon-512.png', 512, .62), ('maskable-512.png', 512, .5), ('apple-touch-icon.png', 180, .62)]:
            pg = await b.new_page(viewport={'width': size, 'height': size})
            await pg.set_content(f'<html><body style="margin:0">{square(size, frac)}</body></html>')
            await pg.screenshot(path=os.path.join(OUT, name), omit_background=False)
            await pg.close()
        pg = await b.new_page(viewport={'width': 1200, 'height': 630})
        await pg.set_content(OG, wait_until='load'); await pg.evaluate('document.fonts.ready'); await pg.wait_for_timeout(600)
        await pg.screenshot(path=os.path.join(OUT, 'og.png'))
        await b.close()
    print('icons ->', OUT, sorted(os.listdir(OUT)))

asyncio.run(main())
