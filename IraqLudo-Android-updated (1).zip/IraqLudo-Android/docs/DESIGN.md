# Iraq Ludo (عراق لودو) — Design Document

Version 1.4.0 · 14 Nov 2026 · Owner: Prof. Dr. Layth Al-Hayder
Covers: requirements, architecture, technology, project files, database, UI, security, performance, roadmap.
Delivery status: **Phase 1 and Phase 2 are built and tested in this package.** Version 1.1 (owner's decision, 23 Oct 2026): the whole game is free, all payment features are removed, the interface is black and gold, and a welcome screen opens the app. Online play stays designed (Phase 3) and is shown as "coming soon". Version 1.2: a website edition shares the same accounts and progress as the app (section 4.5), and the free points became +50 for a win, −50 for a loss (section 4.6). Version 1.3 (owner's decisions, 24 Oct 2026): a second game, **dominoes** (section 4.7, rules in 8b); the game money is shown as **Iraqi dinars** (play money); **every board is free**; the computer has **one level** (the former medium) and no level is chosen or mentioned anywhere. Version 1.3.1 (14 Nov 2026): a review of every file, with fixes in accounts, shared progress, both games, small screens and the Android host (section 16). Version 1.4.0 (owner's request, 14 Nov 2026): design and motion — a Design & colours screen, drawn Iraqi characters, and animations and celebrations in both games (section 17).

---

## 1. Product description

Iraq Ludo is a classic four-colour Ludo game and an Iraqi café dominoes game (الدومنة) for Android and the web, with a modern Iraqi identity.

- **Free mode — play the computer.** Works fully offline, for both games. One computer level (it thinks about its moves and pushes back a bit); no level is chosen or shown. No fees, no forced ads.
- **Online mode — play strangers (Phase 3, free).** 2- or 4-player matches with fair matchmaking. The server rolls every die, checks every move and decides every result. No payments of any kind.
- **No chat of any kind.** Players express themselves with 10 emojis and 6 fixed Iraqi phrases. No free text, no voice, no private messages.
- **Rewards that never buy wins.** XP, player levels, titles, badges, a daily reward streak, daily/weekly challenges and game dinars (drawn as a small Iraqi banknote, written "د.ع"). A win gives +50 dinars and a loss takes 50 (never below zero), in both games. Dinars unlock avatars and dice designs only; every board is free. Game dinars are play money: they cannot be bought, cashed out or turned into anything real, and they give no gameplay advantage.
- **App and website.** The same game runs as an Android app and as a website; one account and one progress on both.
- **Languages.** Arabic (Iraqi dialect, RTL) by default; English (LTR) as the second language.
- **No gambling, no payments.** No betting, no cash prizes, no purchasable currency, no fee for losing. The game has no in-app purchases.

---

## 2. Requirements

### 2.1 Functional

| ID | Requirement | Phase |
|---|---|---|
| A1 | Register with **username + password** only (no email, no phone) | 1 ✅ |
| A2 | Sign in with username + password; session persists across launches | 1 ✅ |
| A3 | Usernames unique (case-insensitive) | 1 ✅ |
| A4 | Profile: display name, avatar, level, games played, wins | 1 ✅ |
| A5 | Sign out, change password, delete account (Google Play policy) | 1 ✅ |
| A6 | Recovery code shown once at registration; reset password with it | 1 ✅ (server part needs Blaze) |
| A7 | Throttle repeated sign-in attempts | 1 ✅ |
| G1 | Full Ludo rules (section 8), shown in "How to play" | 2 ✅ |
| G2 | Play vs computer offline, 2 or 4 players, choose colour | 2 ✅ |
| G3 | One computer level (the former medium); no level choice or wording anywhere | 1.3 ✅ (was easy/medium/hard in 2) |
| G4 | Illegal moves impossible; winner only when all 4 tokens are home | 2 ✅ |
| G5 | Save and resume an unfinished offline game | 2 ✅ |
| G6 | Win/lose screen with effects; correct statistics | 2 ✅ |
| O1 | Online page (free, "coming soon") | 1 ✅ (UI) |
| O2 | Matchmaking (2 or 4 players), rooms, colour preference | 1 ✅ (UI) / 3 |
| O3 | Server-side dice, move validation, results | 3 |
| O4 | Turn timer, disconnect/reconnect, leaving, timeouts | 3 |
| E1 | Emojis + fixed phrases (no chat) | 2 ✅ offline / 5 online |
| R1 | Daily reward + streak, challenges, XP, titles, badges, cosmetics | 2 ✅ local / 5 server-verified |
| S1 | Sound effects (dice, steps, home, win, emoji), music, mute | 2 ✅ |
| U1 | 18 required screens + welcome slides, AR/EN, small and large screens | 1–2 ✅ |
| V1 | Black-and-gold interface; welcome screen on first launch | 1.1 ✅ |
| W1 | Website edition with the same accounts and progress as the app | 1.2 ✅ |
| C1 | +50 per win, −50 per loss, never below zero | 1.2 ✅ |
| C2 | Game money shown as Iraqi dinars (banknote icon, "د.ع"), clearly marked as play money | 1.3 ✅ |
| B1 | Every board is free and can be chosen by anyone; the board also styles the dominoes table | 1.3 ✅ |
| D1 | Dominoes vs the computer: double-six set, 2 players with a draw pile or 4 players in partnerships | 1.3 ✅ |
| D2 | Dominoes rules (section 8b): highest double opens round 1, round winner opens later rounds, knock when nothing fits, domino or blocked end, score = opponents' pips, match to 50 or 100 | 1.3 ✅ |
| D3 | Dominoes save/resume, round summary with every hand, result, statistics, challenges and badges | 1.3 ✅ |

### 2.2 Non-functional

- Runs smoothly on low and mid-range Android phones (Android 8.0+, API 26+).
- Fast start: one HTML file, one font file, no image downloads; the Firebase SDK loads only when a server is configured.
- Low battery: no animation loop when idle; audio suspended in the background.
- Builds exactly like Aqarchi (same Android Studio steps, same versions).
- Google Play target API 36 (required for new apps and updates since 31 Aug 2026).

---

## 3. Architecture decision (ADR-001)

### 3.1 Decision

**Build Iraq Ludo on the same foundation as Aqarchi.** The owner requires it so the game builds and runs on his machine and phone without new setup problems. Aqarchi and UniAttend already build successfully with it.

| Layer | Aqarchi (proven) | Iraq Ludo |
|---|---|---|
| Android host | Kotlin `MainActivity`, full-screen `WebView`, `WebViewAssetLoader` (`https://appassets.androidplatform.net/assets/index.html`) | Same file pattern; package `iq.iraqludo.app` |
| Build | AGP 8.13.2 · Gradle 8.13 · Kotlin 2.1.21 · compileSdk/targetSdk 36 · minSdk 26 · JDK 17 | **Identical** |
| UI | One `index.html` (screens, router, transitions) in `assets/` | Same router engine; game board, dice and tokens added |
| Config | `assets/config.js` (empty = on-device mode) | Same: `window.LUDO_CONFIG` |
| Backend | Firebase JS SDK bundled locally (`firebase.js`) → Auth + Firestore; rules in `firebase/firestore.rules` | Same, plus Cloud Functions for the online game server (Phase 3) |
| CI | `.github/workflows/build-apk.yml` | Same |

### 3.2 Game engine: why not Unity

| Option | Fit for a 2D board game | Cost to the owner | Verdict |
|---|---|---|---|
| Unity 2D | Excellent | New toolchain (Unity Hub + editor + Android modules ~10 GB), different build, APK ~35–60 MB, slower cold start | Rejected: breaks the "same as Aqarchi" requirement for no real gain |
| Godot / Flutter Flame | Good | New toolchain and language | Rejected for the same reason |
| **HTML5 in the Aqarchi WebView** | Board, dice and tokens are simple 2D shapes; GPU-composited CSS/Web-Animations run at 60 fps on mid-range phones | Nothing new to install; APK ~1.5 MB | **Chosen** |

Rendering: the board is one static SVG drawn once. Tokens are small DOM elements moved with `transform` animations (GPU compositor, no layout work). The dice is a CSS 3D cube. Nothing animates when the game is idle.

### 3.3 Online server: options compared

Criteria: authoritative dice and moves, latency fit for a turn-based game, operating burden for a single owner, cost at small scale, path to growth.

| Option | Authoritative logic | Ops burden | Cost at small scale | Notes |
|---|---|---|---|---|
| Photon (Realtime/Fusion) | Relay by default; authority needs server plugins (enterprise) or a Unity host | Low | CCU-based plans | Built for real-time action games and Unity; poor fit here |
| PlayFab (Multiplayer Servers + CloudScript) | Yes, via custom game-server builds | Medium–high (containers, builds) | Core-hour pricing | Strong LiveOps/economy, heavy for a turn-based board game |
| Nakama (Heroic Labs) | Yes (server runtime in TS/Go/Lua) | High if self-hosted (VPS + database + TLS + upgrades) | VPS cost or managed plan | Technically a very good fit; best kept as the growth path |
| Custom Node.js + WebSocket server | Yes | High (servers, scaling, monitoring, security patches) | VPS cost | Lowest latency, most work |
| **Firebase: Auth + Firestore + Cloud Functions (2nd gen)** | **Yes: callable functions own the dice and the state; clients cannot write game documents** | **Very low (no servers)** | **Free quotas: 2M function invocations/month, 50K reads + 20K writes/day** | Same console the owner already uses for Aqarchi |

**Chosen: Firebase.** Ludo is turn-based. A move needs one function call (~150–400 ms warm) plus a Firestore update to the other players (~100–300 ms). That is well inside a 15-second turn and hidden behind the dice animation.

Region: Firestore + Functions in **`me-central2` (Dammam)**, the closest Google Cloud region to Iraq (`me-central1` Doha is the alternative). Both regions support 2nd-gen functions and Firestore.

Requirement: Cloud Functions need the **Blaze (pay-as-you-go) plan**. Usage inside the free quotas costs nothing; a billing account must still be linked. Phases 1–2 do not need Blaze, except the password-recovery function.

### 3.4 Scaling and running cost

- One match ≈ 170 rolls (2 players) → ≈ 340 function calls and ≈ 700 document writes. The free monthly quota covers roughly 5,000 two-player matches; beyond that, functions cost $0.40 per million calls and Firestore writes are cents per 100K.
- Functions scale out automatically. A `minInstances: 1` setting on the game function removes cold starts at launch (small fixed monthly cost; optional).
- Growth path: if concurrent matches grow very large, move only the match loop to a Nakama or Node service. The rules engine is plain JavaScript shared by client and server, so it moves unchanged; accounts and data stay in Firebase.

---

## 4. Architecture

### 4.1 Components

```mermaid
flowchart LR
  subgraph Phone["Android phone"]
    K["Kotlin host (MainActivity)<br/>WebView · back button · haptics<br/>keep-screen-on"]
    W["index.html (game UI)<br/>router · screens · board · dice · audio<br/>rules engine · AI · progress"]
    L[("localStorage<br/>settings · progress · saved game")]
    K <-->|JS bridge AndroidApp| W
    W <--> L
  end
  subgraph Firebase["Firebase project (me-central2)"]
    AU["Firebase Auth<br/>username → internal login ID<br/>password hashing (scrypt)"]
    FS[("Cloud Firestore<br/>players · usernames · games · results")]
    CF["Cloud Functions (2nd gen)<br/>recoverAccount · matchmaking · roll · move<br/>timeouts · claimDaily"]
  end
  W -->|HTTPS| AU
  W <-->|realtime listeners| FS
  W -->|callable functions| CF
  CF --> FS
  CF --> AU
```

### 4.2 Offline game (Phase 2, built)

Everything runs on the phone. `Math.random` gives the dice. The engine applies the rules and returns events. The UI animates the events. The game is saved after every roll and move, so closing the app never loses the match.

### 4.3 Online game (Phase 3)

```mermaid
sequenceDiagram
  participant A as Player A app
  participant F as Cloud Functions
  participant D as Firestore games/{id}
  participant B as Player B app
  A->>F: joinQueue(mode=2)
  B->>F: joinQueue(mode=2)
  F->>D: create game (seats, colours, state, seq=0)
  D-->>A: snapshot (game started)
  D-->>B: snapshot (game started)
  A->>F: roll(gameId, seq)
  F->>F: crypto.randomInt(1,7), engine.roll()
  F->>D: transaction: state, seq+1, turnDeadline
  D-->>A: new state (dice = 6)
  D-->>B: new state
  A->>F: move(gameId, token, seq)
  F->>F: engine.move() validates legality
  F->>D: transaction: state, seq+1
  Note over F,D: Only functions can write games/*. Win is written by the server only. Emojis/phrases: react(gameId, kind, code).
  B->>F: claimTimeout(gameId, seq) when A's deadline passed
  F->>D: auto-play for A, misses+1 (3 misses = forfeit)
```

Rules of the online loop:

- **Dice:** `crypto.randomInt(1, 7)` on the server, never on the phone.
- **Moves:** the server runs the same engine; anything illegal is rejected.
- **Idempotency:** every call carries the `seq` it saw. A stale or repeated call is rejected, so a move can never apply twice.
- **Turn timer:** 15 s to roll, 15 s to move. When it expires, any connected player (or a scheduled sweeper every minute) calls `claimTimeout`; the server auto-plays the turn. Three missed turns in a row = forfeit.
- **Reconnect:** `players/{uid}.activeGame` points to the match; reopening the app resubscribes to it. The full state lives on the server, so nothing is lost.
- **Leaving:** `leaveGame` forfeits; the engine removes that player's tokens; the last player left wins.
- **Results:** written by the server in the same transaction as the final move, together with stats and XP. The app shows win/lose only after the server marks the game `over`.

### 4.4 Payments

Removed in version 1.1 at the owner's request. The game is free and has no in-app purchases, subscriptions or passes. Any future income model (for example optional cosmetics) would be a separate decision; real-money betting is excluded for legal reasons (Iraqi Penal Code art. 389; Google Play real-money gambling policy).

### 4.5 Website edition (v1.2)

`web/build.sh` writes three editions from the same source: the Android app (`app/src/main/assets`), the website (`firebase/hosting`) and a quick preview (`web/dist`). The website is deployed with Firebase Hosting (free on the Spark plan): `firebase deploy --only hosting,firestore:rules`.

- **Same data:** the website reads `config.js` with the same Firebase project as the app, so accounts, game dinars, XP, levels, statistics (Ludo and dominoes), badges, challenges and cosmetics are shared. An unfinished match stays on the device where it was played.
- **Installable and offline:** web manifest + icons; a small service worker keeps a copy, so after the first visit the site opens and plays the computer without internet. Pages and `config.js` are fetched network-first so updates arrive at once; Firebase traffic is never cached.
- **Website details:** browser Back works like the phone's back button (one screen at a time); Space or Enter rolls the dice; the screen stays awake during a match (Wake Lock API); Firestore uses multi-tab persistence; an optional "Get the Android app" link appears when `androidUrl` is set.

### 4.6 Shared progress and game dinars (v1.2, v1.3)

Progress lives on each device (`localStorage`, works offline) and, for a Firebase account, in `players/{uid}/progress/main`. Each device also keeps the last copy it agreed with the server (the *base*). A sync runs inside one Firestore transaction and applies a three-way merge: server + (this device − base). Counters (games, wins, captures, rounds, XP, dinars …) therefore add up even when two devices played while one of them was offline; unlocked items and badges are unions; equipped items, the daily streak and challenges take the latest change. Syncs run after each change (debounced), on start-up, when the app returns to the foreground and when the network comes back. Screens that show progress redraw when a sync brings something new.

**A sync counts once (v1.3.1).** Every sync that carries a change gets an id. The id and the snapshot it sends are saved on the device *before* sending, in the same `localStorage` record as the progress and the base (`_s: { base, pend }`), so the three can never disagree after a sudden close. The server copy remembers the last id of each device (`ops`, at most 20 entries). If the answer is lost, the SDK repeats the transaction, or the app is closed in the middle, the same change is sent again with the same id and the server leaves it alone. A sync with nothing new only reads. On the website, two tabs of one account take turns (Web Locks) and pick up each other's saves (`storage` event). Comparisons ignore the order of map keys, because Firestore returns them sorted. Only the fields the rules accept are sent, and a copy written by a newer app version is read but not overwritten.

Game dinars (stored as `points`): start with 100; a win gives **+50**; a loss or giving up after the first move takes **50**, but never more than the player has (the balance never goes below zero); daily rewards, challenges and level-ups add more. Both setup screens show "win +50 dinars / lose −50 dinars" before every match, and the result screen shows the change. They are play money and are labelled as such on the welcome slides, the daily reward and the style screen. The security rules only accept whole, non-negative values for `xp` and `points`.

Ludo statistics stay in `stats`; dominoes statistics live in `stats.dom` and are merged the same way. Challenge lists are checked against the current challenge set on every device, so a list saved by an older version (with the removed level challenges) is topped up the same way everywhere. Update the app and the website together when both are in use.

### 4.7 Dominoes (v1.3)

- **Rules engine** `02b_domino.js`: pure UMD module like the Ludo engine (also copied to `firebase/functions/domino.js` for the future server). The shuffled tile order comes from outside (`crypto.getRandomValues` offline, the server online), so the same engine can run on the server. State: hands, draw pile, the opening tile and two arms of the line, turn, scores per team, knock information, per-seat and per-team statistics. `validate()` checks a saved match (all 28 tiles exactly once, every tile matching its neighbour).
- **Computer player** `02c_domino_ai.js`, one level: sheds heavy tiles, plays doubles while it can, keeps tiles that fit the next ends, keeps numbers it controls open, closes numbers the opponents knocked on, avoids blocking its partner. It only uses what a player at the table can know (its own tiles, the table, tile counts, knocks).
- **Table**: the line is drawn as a snake that runs sideways to the table edge, turns one tile across and runs back (right arm downwards, left arm upwards); doubles lie across the line; the line is re-fitted to the table after every move with a smooth scale. 41,848 random layouts at four table widths were checked: no two tiles overlap and every tile touches its neighbour. A tile that fits both ends with different results shows two glowing places to choose from.
- **Table style**: the board chosen in the Style screen (classic, Babylon, Baghdad night, palm grove) also colours the dominoes table and tiles.
- **Flow**: deal → (2 players: draw from the pile until a tile fits; when nothing fits and nothing can be drawn: knock "دگّ") → round ends by domino or blocked → round summary with every hand and the points → next round, until a team reaches 50 or 100.

---

## 5. Technology

| Area | Technology | Why |
|---|---|---|
| Android host | Kotlin 2.1.21, AppCompat, AndroidX WebKit `WebViewAssetLoader`, SplashScreen API | Identical to Aqarchi |
| Build | Android Gradle Plugin 8.13.2, Gradle 8.13, JDK 17, compile/target SDK 36, min SDK 26 | Identical to Aqarchi; meets Play's API 36 rule |
| Game UI | HTML5 + CSS + vanilla JavaScript (ES2019), Web Animations API, inline SVG | No framework download; runs offline from assets |
| Rules | `01_engine.js` — pure UMD module | Same file runs in the app and in Cloud Functions |
| AI | `02_ai.js` (Ludo) and `02c_domino_ai.js` (dominoes) — heuristic evaluators, one level each | Play only legal moves; never see future dice or hidden tiles |
| Dominoes | `02b_domino.js` rules engine (UMD) · `11b_domino.js` table, hands, round summary, result | Same engine can run on the server later |
| Audio | Web Audio API, synthesised effects + a short original Hijaz-mode loop | No audio files to ship |
| Font | Baloo Bhaijaan 2 (SIL OFL), one variable file 285 KB | Rounded, playful, full Arabic + Latin |
| Backend | Firebase Auth, Cloud Firestore, Cloud Functions 2nd gen (Node 22) | Section 3.3 |
| Logs | JS errors → native bridge → Logcat tag `IraqLudo`; Functions → Cloud Logging | Visible in Android Studio and the Firebase console |
| CI | GitHub Actions (`assembleDebug`) | Same as Aqarchi |

---

## 6. Project files

```
IraqLudo-Android/
├─ settings.gradle.kts, build.gradle.kts, gradle.properties     same as Aqarchi
├─ gradlew, gradlew.bat, gradle/wrapper/                        Gradle 8.13 wrapper
├─ app/
│  ├─ build.gradle.kts                                          namespace iq.iraqludo.app
│  ├─ proguard-rules.pro
│  └─ src/main/
│     ├─ AndroidManifest.xml
│     ├─ java/iq/iraqludo/app/MainActivity.kt                   WebView host + JS bridge
│     ├─ res/ (values, values-ar, drawable, mipmap-anydpi-v26)  name, colours, theme, icon, splash
│     └─ assets/
│        ├─ index.html                                          the whole game (built from web/src)
│        ├─ config.js                                           Firebase settings (empty = on-device)
│        ├─ firebase.js                                         bundled Firebase SDK (loaded only when configured)
│        └─ fonts/BalooBhaijaan2.ttf
├─ web/
│  ├─ src/                                                      game source, assembled by build.sh
│  │  ├─ head.html          styles + page skeleton
│  │  ├─ 00_config.js       defaults merged with config.js
│  │  ├─ 01_engine.js       rules engine (shared with the server)
│  │  ├─ 02_ai.js           Ludo computer player (one level)
│  │  ├─ 02b_domino.js      dominoes rules engine (shared with the server later)
│  │  ├─ 02c_domino_ai.js   dominoes computer player (one level)
│  │  ├─ 03_i18n.js         Arabic (Iraqi) + English strings
│  │  ├─ 04_core.js         utilities, storage, router, sheets, icons
│  │  ├─ 05_audio.js        sound effects + music
│  │  ├─ 06_backend.js      accounts: on-device mode + Firebase mode
│  │  ├─ 07_progress.js     XP, levels, titles, dinars, badges, daily reward, challenges, cosmetics, cloud sync
│  │  ├─ 08_board.js        board drawing, tokens, dice, animations
│  │  ├─ 09_screens_entry.js  splash, language, sign-in, register, recovery
│  │  ├─ 10_screens_main.js   home and all menu screens
│  │  ├─ 11_game.js         Ludo game screen + result screen
│  │  ├─ 11b_domino.js      dominoes setup, table, hands, round summary, result
│  │  └─ 12_actions.js      button actions + start-up
│  ├─ build.sh              builds the app (app/src/main/assets), the website (firebase/hosting) and web/dist
│  ├─ site/                 website extras: manifest, service worker, icons (+ make_icons.py)
│  └─ tests/                engine.test.js · domino.test.js · sim.js · domsim.js · ui_test.py · firebase_flow_test.py · sync_test.py (+ fake_firebase.js)
├─ firebase/
│  ├─ firestore.rules       security rules
│  ├─ firebase.json, firestore.indexes.json
│  ├─ hosting/              the website (built by web/build.sh; config.js must match the app's)
│  └─ functions/            Cloud Functions, Node 22: index.js (recoverAccount now; game server in Phase 3),
│                           lib.js (hashing/validation shared with the app), engine.js + domino.js (copied by build.sh), test/
├─ docs/DESIGN.md           this document
├─ SETUP-AR.md              step-by-step guide in Arabic
├─ README.md                short bilingual overview
└─ .github/workflows/build-apk.yml
```

---

## 7. Database (Cloud Firestore)

### 7.1 Mapping of the requested tables

| Requested table | Firestore location | Written by |
|---|---|---|
| Users | Firebase Auth user + `usernames/{username}` + `recovery/{uid}` | Client at sign-up (rules-checked); server for recovery |
| PlayerProfiles | `players/{uid}` | Owner (name, avatar, language); server (level for online) |
| GameSessions | `games/{gameId}` (+ `moves`, `presence`, `reactions` sub-collections) | **Server only** (presence and reactions are sent through Cloud Functions) |
| GameResults | `results/{gameId}` | **Server only** |
| PlayerStatistics | `players/{uid}/stats/online` (server, Phase 3) · statistics against the computer inside `players/{uid}/progress/main` (owner) | Split by trust level |
| Purchases / Subscriptions | Not used (the game is free) | — |
| Achievements | `players/{uid}/progress/main.badges` | Owner's devices (app + website, merged) |
| DailyRewards | `players/{uid}/progress/main.daily` | Owner (Ph.2) → server `claimDaily` (Ph.5) |
| PlayerCosmetics | `players/{uid}/progress/main.owned / equipped` | Owner (Ph.2) → server (Ph.5) |

Supporting collections: `queue/{uid}` (matchmaking tickets), `rateLimits/{key}`, `config/game` (timers, plan list).

### 7.2 Documents and fields

```
usernames/{username}            uid, createdAt
recovery/{uid}                  algo:'pbkdf2-sha256', iter:120000, salt, hash, createdAt      (no client read)
players/{uid}                   username, name, avatar, lang, level, title, createdAt, lastSeen, activeGame?
players/{uid}/stats/online      games, wins, losses, by2{g,w}, by4{g,w}, rating, forfeits, updatedAt   (server only)
players/{uid}/progress/main     v, xp, points (game dinars), badges{id:ts}, daily{last, streak}, ch{day,d[],week,w[]}, owned{avatar[],dice[],board[]}, equipped{dice,board},
                                stats{Ludo counters…, dom{games, wins, losses, forfeits, rounds, roundsWon, outs, points, best, blockWins, p2, p4, streak, bestStreak, timeSec}}, ops{deviceId: last sync id}, updatedAt
games/{gameId}                  mode:2|4, seats[{uid,color,name,avatar,level}], state(engine), seq, status:'live'|'over',
                                turnDeadline, misses{color:n}, createdAt, updatedAt, winner?
games/{gameId}/moves/{seq}      type, color, dice|token, at                         (audit trail for disputes)
games/{gameId}/presence/{uid}   at                                                  (heartbeat every 15 s)
games/{gameId}/reactions/{id}   uid, kind:'emoji'|'phrase', code, at               (written by the react function; code from a fixed list)
results/{gameId}                mode, players[{uid,color,place,captures}], winner, reason, durationSec, endedAt
queue/{uid}                     mode, colorPref, level, joinedAt, status:'waiting'|'matched', gameId?
rateLimits/{key}                count, windowStart
```

### 7.3 Relationships

```mermaid
erDiagram
  AUTH_USER ||--|| USERNAMES : "unique name"
  AUTH_USER ||--o| RECOVERY : "recovery code hash"
  AUTH_USER ||--|| PLAYERS : "profile"
  PLAYERS ||--|| STATS_OFFLINE : has
  PLAYERS ||--|| STATS_ONLINE : has
  PLAYERS ||--|| PROGRESS : "XP, dinars, badges, daily, cosmetics"
  PLAYERS ||--o| QUEUE : "waits in"
  GAMES ||--|{ PLAYERS : "2 or 4 seats"
  GAMES ||--o{ MOVES : logs
  GAMES ||--o{ REACTIONS : "emojis / phrases"
  GAMES ||--o{ PRESENCE : heartbeats
  GAMES ||--|| RESULTS : "final result"
```

### 7.4 Security rules (summary)

- `usernames/{name}`: anyone may read one document (availability check); nobody may list; create only by the signed-in password account whose internal login ID is `name@<projectId>.firebaseapp.com`, and only while that account has no profile yet (one name per account); reserved names blocked with or without dots and underscores; never updated; deleted only by its owner (deleting a name that is already gone is allowed, so an interrupted account deletion can be repeated).
- `recovery/{uid}`: created by the owner with a fixed shape (PBKDF2-SHA256, 100k–1M iterations, 16-byte salt, 32-byte hash); **never readable by any app**; never updated by an app (only `recoverAccount` issues a new code). Creating or deleting it needs a sign-in from the last 10 minutes (`auth_time`), so a session left open on a shared device cannot swap the code and take the account over.
- `players/{uid}`: any signed-in player may read one profile (no listing); creation must match the `usernames` document written in the same transaction and start at level 1; the owner may change only name, avatar, language and timestamps (typed). Level, title and `activeGame` are server-only.
- `players/{uid}/progress/main`: owner only (a password account of this game), with a field allow-list and types: whole non-negative `xp` and `points`, maps for the rest, `ops` at most 40 entries.
- `games` (and every sub-collection), `results`, `queue`, `rateLimits`: **no client writes**; reads limited to the participants or the owner. `config`: read-only.
- Reactions (emojis and fixed phrases) go through the `react` function: fixed codes only, one per 2 seconds per player.

The full file is `firebase/firestore.rules`.

---

## 8. Game rules (unified, shown in "How to play")

1. Each player has 4 tokens in their coloured yard.
2. A token leaves the yard only with a **6**, onto its colour's start square.
3. Move one token by the number rolled, clockwise.
4. A **6 gives another roll**. Three 6s in a row cancel the turn (the third 6 is not played).
5. Landing on a **single** opponent token on a normal square captures it: it returns to its yard and you get **another roll**.
6. **Safe squares** (start squares and star squares) protect every token on them.
7. **Two tokens of the same colour on one square form a protected pair.** They cannot be captured; other tokens may pass or share the square.
8. After almost a full lap, a token turns into its own **coloured home column**, where no one can touch it.
9. Reaching the centre needs the **exact number**. Bringing a token home gives **another roll**.
10. The **first player to bring all 4 tokens home wins**, and the match ends.
11. If no move is possible, the turn passes (with a 6 you still roll again).
12. Online: 15 s per action; three missed turns forfeit; leaving forfeits.

Engine positions: `-1` yard · `0–50` shared track · `51–55` home column · `56` finished. Shared track = 52 squares; start squares 0/13/26/39; star squares 8/21/34/47.

## 8b. Dominoes rules (shown in "How to play", Dominoes tab)

1. Double-six set: 28 tiles from 0|0 to 6|6. A tile is worth the sum of its two numbers.
2. Each player takes 7 tiles. With 2 players the other 14 form the draw pile; with 4 players (two teams, partners opposite) all tiles are dealt.
3. Round 1: the highest double opens (6|6 when someone holds it; with no double in any hand, the heaviest tile). Later rounds: the round winner opens with any tile; after a drawn round the same player opens again.
4. Place a tile whose number matches one of the two open ends. Turns go anticlockwise.
5. No fitting tile: with 2 players draw one tile at a time until one fits; when the pile is empty, or with 4 players, knock and the turn passes.
6. Domino: the first player to play all their tiles wins the round and scores the pips in the opponents' hands (never the partner's).
7. Blocked: when nobody can play, the lowest hand wins and scores the opponents' pips; if opponents tie on the lowest hand, the team with fewer pips in total wins; equal totals score nothing.
8. The first player or team to reach the target (50 or 100) wins the match.

Measured over 1,800 simulated matches to 100 (`node web/tests/domsim.js 600`): the computer beats a random player 77% (2 players) and 88% (4 players); mirror matches are fair (49%); about 9 rounds per match against a random player, ~18 points per round, 10% (2 players) and 20% (4 players) of rounds end blocked.

---

## 9. Computer players

**Ludo.** Each legal move gets a score: progress, entering the board, reaching the home column, finishing, capturing (worth more the further the victim had travelled), and **risk** — the probability that an opponent behind can hit the token before its next turn (1/6 within 6 squares, 1/36 within 12 via a 6, yard tokens entering with a 6). It also likes to stand a few squares behind exposed opponents. Since v1.3 there is **one level** (the former medium: moderate risk awareness, 12% relaxed moves, some noise); it is never named on screen.

Measured with fair dice (`node web/tests/sim.js 400`, seats alternated):

| Match-up | Win rate of the computer |
|---|---|
| Computer vs a random player (2 players) | 91% |
| Computer vs computer | 48% (fair baseline) |
| Computer vs 3 random players | 72% (fair share 25%) |

Ludo keeps a large luck element, so the computer can lose — that is intended.

**Dominoes.** Section 4.7 describes the heuristic; results are in section 8b.

---

## 10. User interface

### 10.1 Visual identity

- **Mood (v1.1):** black lacquer and gold leaf — near-black backgrounds with a warm gold glow, gold buttons and hairlines, ivory text. The four Ludo colours are the only other hues. Modern and clean; Iraqi touches are light.
- **Iraqi touches:** the safe squares carry an eight-point star (Mesopotamian motif); the "Babylon" board skin uses Ishtar-gate cobalt and gold; titles use Iraqi café culture ("لاعب گهوة"); game money is a small Iraqi-dinar banknote with "د.ع"; dominoes use café words ("الكومة", "دگّ", "دومنة!", "انسدّت!"); all copy in Iraqi dialect.
- **Dominoes table:** black lacquer with a double gold inlay and a faint Ur rosette in the centre; ivory tiles with a brass centre pin. The chosen board recolours the table (Babylon cobalt, Baghdad-night onyx with gold pips, palm-grove green).
- **Player colours:** pomegranate red, palm green, date gold, Euphrates blue.
- **Type:** Baloo Bhaijaan 2 (400–800).
- **Shape language:** rounded cards (18–22 px radius), large tap targets (≥ 48 px), soft glows instead of heavy shadows.
- **Motion:** screen transitions 260–340 ms; token hops 130 ms per square; dice roll 600 ms; respects "reduce motion".

### 10.2 Screens

| # | Screen | Main content |
|---|---|---|
| 1 | Splash | Animated logo (gold dice + wordmark), loading |
| + | Welcome | Three swipeable slides on first launch (welcome, play the computer, completely free), language switch, skip; reopened from Settings |
| 2 | Sign in | Username, password, show/hide, sign in, create account, forgot password, play offline as guest |
| 3 | Create account | Username (live availability), display name, password + strength, confirm, terms; then **recovery code screen** (copy/share, "I saved it" confirmation) |
| 4 | Language | العربية / English cards (from Settings and the sign-in screen; the welcome slides have their own switch) |
| 5 | Home | Avatar, level bar, dinars; rotating Iraqi slogan; two game cards (Ludo, dominoes), play online (coming soon), daily rewards, challenges, profile, style; resume cards for saved matches |
| 6 | Ludo vs computer | 2 or 4 players, your colour, "win +50 / lose −50 dinars", start (no level step) |
| 7 | (removed) | The computer-level screen was removed in v1.3: one level, never shown |
| + | Dominoes vs computer | 2 or 4 players (partners), match to 50 or 100 points, stake in dinars, start |
| + | Dominoes table | Scores and target, opponents with tile counts, draw pile (2 players), the line, your hand (fitting tiles raised), choose an end, knock, emojis, pause menu |
| + | Round summary | Who won the round and why (domino / blocked / drawn), every hand face up with its pips, points, totals |
| + | Dominoes result | Podium by team with scores, final score, dinars flying to or from the balance, XP, play again |
| 8 | Online | What online play will include (free), coming-soon note, find players / play the computer |
| 9 | (removed) | The plans screen was removed in v1.1: the game is free |
| 10 | Finding players | 2/4 players, colour preference, searching animation, cancel |
| 11 | Game board | Board, 4 player panels with dice slot, turn glow, emoji tray, pause menu |
| 12 | Win / lose | Podium with the top three (crown for the winner), confetti and fireworks for a win, balance pill with the dinars flying to or from it, rank list, XP, level-up badge, play again |
| 13 | Profile | Avatar, display name (editable), level/title, games, wins, win rate, badges showcase |
| 14 | Statistics | Tabs: Ludo (totals, streaks, fastest win, captures, sixes, by players), Dominoes (rounds, rounds won, times out first, points, best round, blocked wins, by players), Online |
| 15 | Settings | Design & colours (first row), language, sound, music, vibration, auto-move, speed, account (password, sign out, delete), privacy, about |
| + | Design & colours | Live preview; interface colour (8), screen background (6), board and dominoes table (6, free), dominoes tiles (4), Ludo tokens (3), motion (full / light / none), back to the original look |
| 16 | How to play | Tabs: Ludo (12 rules with board strips) and Dominoes (9 rules with tile pictures) |
| 17 | Daily reward | 7-day calendar, streak, claim — a chest opens (golden on day 7) and the dinars fly to the balance |
| 18 | Challenges | Daily + weekly challenges with progress bars and claim; badges tab |
| + | Style shop | Avatars and dice unlocked with game dinars; every board free; equip |
| + | Forgot password | Username + recovery code + new password |

### 10.3 Navigation

```mermaid
flowchart TD
  S[Splash] --> LG{First launch?}
  LG -- yes --> WEL[Welcome slides + language] --> AUTH
  LG -- no --> AUTH{Signed in?}
  AUTH -- no --> IN[Sign in]
  IN --> REG[Create account] --> RC[Recovery code] --> H
  IN --> FG[Forgot password]
  IN -- guest --> H[Home]
  AUTH -- yes --> H
  H --> OFF[Ludo setup] --> G[Ludo board] --> RES[Win / lose]
  H --> DSET[Dominoes setup] --> DG[Dominoes table] --> RS[Round summary] --> DG
  RS --> DRES[Dominoes result]
  H --> ON[Online - coming soon] --> MM[Finding players] --> G
  H --> DR[Daily reward]
  H --> CH[Challenges]
  H --> PR[Profile] --> ST[Statistics]
  PR --> SHOP[Style shop]
  H --> SET[Settings] --> HOW[How to play]
```

---

## 11. Accounts and security

### 11.1 Username + password without email

- Usernames: 3–20 characters, `a–z 0–9 _ .`, start with a letter, stored lowercase (unique ignoring case). Display names may be Arabic and are what other players see.
- Firebase Auth needs an identifier, so each username maps to an **internal login ID** `username@<projectId>.firebaseapp.com`. It is never shown. The address is on the project's own Firebase domain, where nobody can receive mail, so Firebase's built-in password-reset e-mail (which cannot be switched off) can never reach anyone. Until 1.3.1 the ID used `players.iraqludo.app`, a domain the project does not own: whoever registered it could have reset any password by e-mail. `loginDomain` in `config.js` keeps old accounts working until they are moved; the rules accept both forms.
- Sign-up writes the three account documents in one transaction (never queued for later) that is safe to repeat. If the connection drops in between and even the clean-up fails, the next sign-in finishes the account and shows its recovery code. Deletion removes the documents in one transaction, then the sign-in ID; an interrupted deletion can simply be repeated.
- If Firebase ends the session (password changed or account deleted on another device), the app saves the match in progress, signs out and asks to sign in again.
- **Passwords are never stored by the app.** Firebase Auth hashes them with its modified **scrypt** (memory-hard, same class as Argon2id/bcrypt). The app never sees a hash.
- On-device mode (no server configured, for testing only): PBKDF2-SHA-256, 210,000 iterations, random 16-byte salt, via WebCrypto.
- Uniqueness is enforced twice: Firebase Auth rejects a duplicate login ID, and the `usernames/{name}` document can be created only by its owner.
- **Brute-force protection:** Firebase throttles repeated failures server-side (`auth/too-many-requests`); the app adds a growing local lock (5 failures → 30 s, doubling up to 15 min). Email-enumeration protection hides whether a username exists on sign-in.
- **Recovery code:** 16 characters from a 32-letter alphabet without look-alikes (80 bits), shown once, e.g. `K7QM-4XHT-9RWA-2PZD`. Stored only as a PBKDF2 hash in `recovery/{uid}`, which no client can read. The `recoverAccount` function checks it (per hour: 30 calls per network address, counted on the hop Google's front end adds, and 5 wrong codes per username; only wrong codes are counted and the right code always works, so nobody can lock an owner out on purpose; a wrong name costs the same time as a wrong code), sets the new password, signs out all sessions and returns a **new** code. The app explains clearly: lose both the password and the code, and the account cannot be recovered.
- **Minimal data:** username, display name, avatar choice, game data. No email, phone, photo upload, contacts or location.
- **No contact sharing:** display names reject links, `@` handles and long digit runs (phone numbers), because there is no chat by design.
- **Account deletion** inside Settings (Google Play requirement): asks for the password, deletes profile, username, recovery hash, progress and the Auth user. If removing the profile fails (no internet), the sign-in is kept so the player can try again and no orphaned name is left.

### 11.2 Anti-cheat

| Threat | Defence |
|---|---|
| Fake dice | Server rolls with `crypto.randomInt`; clients only request a roll |
| Illegal or edited moves | Server re-runs the engine; game documents are server-write-only |
| Double/replayed moves | `seq` check inside a Firestore transaction |
| Faking a win | Results written only by the server in the final-move transaction |
| Stalling / rage-quitting | 15 s timers, auto-play, 3 misses = forfeit, leaving = loss; sweeper function |
| Disconnect abuse | Disconnect does not pause the timer; reconnect restores the live state |
| Repeated daily reward | Phase 5: `claimDaily` uses server time (Asia/Baghdad) inside a transaction |
| Edited offline progress | Offline results only affect cosmetics; Phase 5 adds server caps per day |
| Spam emojis | Fixed codes only, 1 per 2 s per player (`react` function; clients cannot write reactions) |

---

## 12. Performance

- One HTML file (~0.4 MB) + one font (285 KB); no images; the Firebase SDK (744 KB) loads lazily and only when configured.
- Board drawn once as SVG; tokens move with `transform` only; no `requestAnimationFrame` loop unless confetti is showing.
- Screen transitions use opacity/transform only; off-screen screens are trimmed from memory.
- Audio is synthesised on demand; the audio context suspends when the app goes to the background.
- "Fast" animation setting and "reduce motion" support.
- Online data: one small document update per action (~1–2 KB); Firestore local cache avoids re-downloads.

## 13. Errors and logs

- `window.onerror` and unhandled promise rejections are caught, kept in a small in-app ring buffer and forwarded to Logcat (tag `IraqLudo`) through the bridge, so they appear in Android Studio.
- Every Firebase call maps its error code to a friendly Iraqi-Arabic message; nothing fails silently.
- A corrupted saved game is detected by `validate()` and discarded safely.
- Cloud Functions log through `firebase-functions/logger` (Cloud Logging).

## 14. Roadmap

| Phase | Content | Status |
|---|---|---|
| 0 | This design | ✅ |
| 1 | Project (Aqarchi foundation), all screens, accounts (on-device + Firebase), recovery code | ✅ delivered |
| 2 | Offline Ludo vs computer: full rules, 3 levels, animations, sounds, save/resume, results, stats, local rewards | ✅ delivered |
| 1.1 | Black-and-gold interface, welcome slides, all payment features removed | ✅ delivered |
| 1.2 | Website edition (same accounts and progress), progress merged across devices, +50 win / −50 loss | ✅ delivered |
| 1.3 | Dominoes (2 players or 4 in partnerships), Iraqi-dinar game money, every board free, one computer level | ✅ delivered |
| 1.3.1 | Full review of every file: fixes in accounts, sync, both games, small screens and the Android host (section 16) | ✅ delivered |
| 1.4 | Design & colours screen, drawn Iraqi characters, animations and celebrations (section 17) | ✅ delivered |
| 3 | Cloud Functions game server (free) for Ludo and dominoes: matchmaking (2/4), rooms, server dice/deals/moves, timers, reconnect, leaving, results | On hold (owner) |
| 4 | ~~Play Billing~~ | Cancelled: the game is free |
| 5 | Online emojis/phrases; server-verified daily reward, challenges, cosmetics; anti-abuse caps | After 3 |
| 6 | Device testing, performance tuning, crash reporting, signed AAB, store listing, privacy policy page | Last |

What the owner provides later: a new Firebase project (Blaze plan only if online play or password recovery is switched on), a Google Play Console developer account, and a privacy-policy web page.

## 15. Testing

- `node web/tests/engine.test.js` — 21 Ludo rules tests, including that only saved games which can be played on are accepted.
- `node web/tests/domino.test.js` — 15 dominoes tests: the double-six set, dealing for 2 and 4 players, who opens (highest double, heaviest tile, round winner), matching both ends, drawing, knocking, domino and blocked scoring (ties score nothing), partners, reaching the target, broken or unplayable saves rejected, the computer never plays an illegal tile and sheds heavy tiles.
- `node web/tests/sim.js 400` — 1,200 complete Ludo games with invariant checks (computer vs random, mirror, 4 players).
- `node web/tests/domsim.js 600` — 1,800 complete dominoes matches to 100 with invariant checks after every action (all 28 tiles accounted for, every tile matches its end, no negative scores).
- Table layout check — 62,772 random dominoes lines at six table widths: no tiles overlap and every tile touches its neighbour.
- `node web/tests/progress.test.js` — 6 tests of the shared-progress sync without a browser: two devices with lost answers, unreachable server and sudden restarts end with exact totals; nothing new means no write (also with map keys returned sorted); removed challenges cannot be claimed again; saves from before 1.3.1 carry over; unknown fields are never sent; a newer copy is not overwritten.
- `python3 web/tests/ui_test.py` — 152 checks: welcome slides; accounts (sign-up, recovery code, lock after 5 wrong passwords, recovery, password change, deletion, guest); both games on home; game money in dinars (home, shop, result; +50 win, −50 loss, never below zero); every board free; Ludo with no level step or wording; complete Ludo games, save/resume; dominoes setup, table colours, choosing an end by tap and by keyboard, drawing, knocking, round summary, complete 2- and 4-player matches, save/resume (also at a round summary), give-up; privacy sheet and links; keyboard play; a decided match counted at once and never as a give-up; no play during the deal; cancel on the give-up question; the move that waits for the menu; asking before a saved match is replaced; damaged saves ignored; the day-7 bonus; the old-browser notice; English; small phone and tablet sizes (board, table, round summary, widths in both languages); and for 1.4 the Design & colours screen (every option, a theme really recolours the interface, the look is kept after reopening, motion none/light, back to the original look), tile style on the table, the 28 tiles shuffled face down and dealt, drawn characters for the computer players and on home, the dice thrown onto the board showing the rolled value, the golden day-7 chest, the level-up badge, the result podium, and choosing a drawn picture.
- `python3 web/tests/firebase_flow_test.py` — 43 checks of the real app in server mode against a stand-in for Firebase that enforces the same checks as `firestore.rules` and `recoverAccount`: the normal flows, and a lost answer during sign-up, no connection in the middle of sign-up or deletion, a half-made account finished at sign-in, an old session that cannot swap the recovery code, too many wrong recovery codes (the right one still works), a failed sign-in after recovery, and a session ended by the server.
- `python3 web/tests/sync_test.py` — 38 checks with two browsers (the app and the website) on one stand-in server: same account, progress both ways, Ludo games from both devices add up, a sync that is repeated or cut off counts once (also after reopening the app), a sync with nothing new only reads, two tabs on one account, a dominoes match played on the website shows on the phone, offline game sent later, items unlocked with dinars appear on the other device, website files, browser Back, Space to roll, opening without internet, deletion removes the copy, no security-rule denials.
- `node firebase/functions/test/recovery.test.js` — 26 checks that the server accepts recovery hashes made by the app and applies the same username/password rules.
- `node firebase/functions/test/limits.test.js` — 11 checks of `recoverAccount` with the Firebase modules replaced: limits, their order, and that the right code works after wrong ones.
- Screen audit (review of 1.3.1) — every screen in Arabic and English at 360 and 412 px wide: nothing cut or outside the screen; at 320 px nothing is outside the screen and only the longest computer name is shortened.

The stand-ins follow the rules and the function line by line, but they are not Firebase: after connecting a real project, sign up and sign in once to confirm (SETUP-AR, section 3).

## 16. Review of every file (v1.3.1)

Version 1.3.0 was reviewed file by file: the Android host and build, the accounts and Firebase side, the website, and the game code. Three independent reviews ran next to the main one, and each finding was checked against the code or reproduced before anything was changed. What was found and what was done:

### 16.1 Accounts and server

| Finding | Fix |
|---|---|
| Login IDs used `@players.iraqludo.app`, a domain the project does not own. Firebase's password-reset e-mail cannot be switched off, so whoever registered that domain could have taken over any account. | IDs now use `<projectId>.firebaseapp.com`, where no mailbox can exist. `loginDomain` keeps accounts made earlier working; the rules accept both forms. |
| The recovery code could be replaced without the password (delete + create), so a session left open on a shared device could become a takeover. | Creating or deleting `recovery/{uid}` needs a sign-in from the last 10 minutes. |
| Five wrong recovery codes locked the real owner out for an hour, and the per-network limit could be bypassed by forging `X-Forwarded-For`. | Only wrong codes are counted and the right code always works. The network limit is checked first, on the hop Google adds. Counters stop writing at the limit and carry `expireAt`. |
| Sign-up and deletion used batches, which Firestore keeps for later when offline: a recovery code could be stored without ever being shown, and a half-deleted account could never be finished. | Both use transactions (never queued, safe to repeat). A half-made account is finished at the next sign-in and gets its code then. Deleting a name that is already gone is allowed. |
| After a recovery, a failed sign-in threw the new recovery code away. | The code is always shown; the player then signs in. |
| The app did not notice when Firebase ended the session. | It saves the match, signs out and asks to sign in again. |
| Rules: unchecked types and sizes, reserved names bypassed with dots, an unused `stats` block. | Typed fields, password-account requirement on every write, reserved names checked without dots/underscores, unused block removed. |
| A profile edit waited for the server and hung offline; a missing function was reported as "wrong code". | The edit is sent in the background; a missing function says recovery is not available. |

### 16.2 Shared progress

| Finding | Fix |
|---|---|
| A lost answer, a repeated transaction or a sudden close could add the same match twice (XP, dinars, statistics). | Sync ids (section 4.6): a change is counted once whatever happens. |
| Two tabs on one account could erase or double each other's matches. | Tabs take turns and pick up each other's saves. |
| Every sync wrote, even with nothing new; key order from the server could cause extra writes. | Read-only when nothing changed; comparisons ignore key order. |
| A challenge removed in a newer version came back through the server copy and could be claimed again. | Only known challenges are merged. |
| A sync during account deletion could re-create the progress copy. | No sync while an account is being removed. |

### 16.3 The two games

| Finding | Fix |
|---|---|
| Dominoes: a tap while the tiles were being dealt started two turns at once, and the computer then played the human's tiles. | Tiles cannot be played during the deal, and only one turn can run at a time (both games). |
| Both games: "Cancel" on the give-up / start-over question left the match paused; nothing responded until the menu was opened again. | Cancel carries on with the match. |
| Ludo: opening the menu while the dice rolled dropped the automatic move and left no token to tap. | The move waits for the menu to close. |
| A decided match was only counted after the last animation or summary; closing the app there lost a win or dodged a loss. With the menu open it could even be turned into a give-up. | The match is counted the moment it is decided, exactly once. |
| Starting a new match silently replaced a saved one (a free give-up, or a lost match by accident). | The player is asked; a saved match already played in counts as a give-up. |
| A damaged saved match could stop the app at start-up; saved states that could not be played on were accepted. | Saved matches are checked fully (both engines and their setup) and ignored when unusable. |
| The level-up bonus was not paid for the day-7 daily reward or shown for challenges; give-ups counted towards the "matches played" badges; play time included time in the background; a guest's saved matches were left behind on sign-up. | All four fixed. |

### 16.4 Screens and website

- At 360 px the sign-up picture row and the colour row of "find players" stuck out of the screen, and a long English title was cut. All fit now. Every screen was checked in both languages at 360 and 412 px (nothing cut or outside the screen) and at 320 px (nothing outside the screen; only the longest computer name is shortened with "…").
- The round summary of a 4-player dominoes match pushed its button off small screens. The list scrolls and the button stays in view.
- Keyboard play on the website: movable Ludo tokens and the two places for a dominoes tile can be reached with Tab and chosen with Enter.
- `privacyUrl` and `supportEmail` from `config.js` were never shown. The privacy sheet now says what is kept and where, states the terms, and links to the full policy and the support address (https and e-mail only).
- Website: the offline copy could keep an old file after a deploy, and a weak connection blocked the page although a copy existed. The copy is fetched fresh on install, pages wait at most 4 seconds for the network, and the catch-all rewrite was removed.
- A browser engine from before 2021 showed an empty screen. It now shows what to update.

### 16.5 Android host and build

- External links: only `https`, `http` and `mailto` can be opened from the page; the app host is matched with its scheme.
- A page lost in the background is rebuilt when the player returns (not immediately, under memory pressure), and a page that dies twice in a row closes the app instead of looping.
- `android:appCategory="game"` keeps the portrait lock on Android 16 tablets and foldables.
- CI actions moved to versions that run on Node 24 (GitHub removed Node 20 from its runners in September 2026). `.gitignore` now excludes signing keys.

### 16.6 Left as they are (owner's decisions and known limits)

- **Rules and functions were checked with stand-ins, not on a real Firebase project** (none was available). After connecting Firebase, create an account and sign in once to confirm (SETUP-AR, section 3).
- Accounts created before 1.3.1 on a real project stay on the old login domain until moved (`loginDomain`).
- APKs built by GitHub Actions are each signed with a different debug key, so one cannot be installed over another. Builds from one Android Studio installation are not affected.
- `allowBackup` stays on: Android's backup keeps a guest's progress when changing phones. It also carries the sign-in to the new phone.
- A reward claimed on two devices before they sync is paid on both, and challenge progress across devices takes the larger value, not the sum. Both follow from working offline; the amounts are play money.
- The network limit of `recoverAccount` assumes the last `X-Forwarded-For` entry is the caller's address, as observed on Cloud Run URLs. The per-username limit and the 80-bit code do not depend on it.

## 17. Design and motion (v1.4)

Requested by the owner after the review: all fourteen proposed design and animation additions, plus settings that let every player change the look of the game, with new modern colours.

### 17.1 Design & colours (Settings, first row)

| Option | Choices | How it works |
|---|---|---|
| Interface colour | Gold (original), turquoise, emerald, violet, pomegranate, Euphrates blue, orange, silver | Every interface colour in `head.html` is a CSS token (`--gold`, `--acc` as an RGB triple, `--deep1` …). `html[data-ui]` swaps the whole set; dice, boards, tokens and banknotes keep their own colours. |
| Screen background | Bricks (original), Ishtar Gate, palms, stars, pattern, plain | One SVG pattern used as a mask on `#app::before`, painted in the theme colour; it drifts upwards with full motion (a compositor transform, not a repaint). |
| Board and dominoes table | Classic, Babylon, Baghdad night, palm grove, Samarra turquoise, Tigris sunset — all free | The same choice as in the Style screen (`equipped.board`, shared across devices). Each board has a small picture in every yard (stars and moon, a lion, a palm, a turquoise star, a sun, a rosette) and matching decorations on the dominoes table. |
| Dominoes tiles | Match the board, ivory, black and gold, coloured pips (one colour per number) | `html[data-tiles]` overrides the table's tile tokens. |
| Ludo tokens | Classic, gem, modern | `html[data-tok]` changes the token face. |
| Motion | Full, light, none | Full: everything. Light: the game moves only (no decoration, no celebrations). None: nothing moves. When the player has not chosen, the phone's reduced-motion setting decides. |

These are device settings (kept with sound and speed); the board is part of the shared progress. "Back to the original look" restores all of them. The live preview at the top of the screen shows the player's picture, balance, board, tiles, tokens and a button in the chosen colours.

### 17.2 Drawn characters

Fourteen original Iraqi characters drawn as SVG from a few parts (skin, hair or head cover, clothes, face, an object in hand): the Haji (red-and-white shemagh and agal), the Hajiya, the young man, the girl, the student, the teacher (free), the farmer, the tea seller (istikan), the fisherman, the doctor, the oud player, the athlete, the captain, the sheikh (80–300 game dinars). They contain no ids, gradients or clip paths, so one picture can appear many times on a screen; CSS cuts them round. The emoji pictures of earlier versions stay available under "Symbols" (owned ones stay owned). Computer players get a character that matches the gender of their name. Picture ids keep the rules' format (`[a-z]{2,12}`).

### 17.3 Animations

- **Ludo:** with full motion the dice is thrown from the player's corner onto the middle of the board, tumbles with a shadow, settles and goes back (same value, decided before the animation). Tokens glide from square to square while their face jumps in an arc and squashes on landing. A capture spins the token home and shakes the board. A token reaching home lights its column square by square and sets off fireworks in its colour (three bursts when the fourth token arrives).
- **Dominoes:** at the start of every round the 28 tiles lie face down in the middle, are mixed twice and go round the table one by one; your tiles turn face up as they arrive, the opponents' counts and the pile fill up. At the end of a round the counted tiles turn over one by one and each tile's points fly to the winner's score, which counts up; a blocked round shakes the table.
- **Celebrations:** dinars fly from the reward to the balance (or away from it after a loss or a purchase) while the number rolls; a golden level-up badge with rays; the daily chest drops, shakes and opens (golden with jewels on day 7); a podium on both result screens; emojis fly up big from the sender's picture; the tapped game card grows into the setup screen; a light passes over the home wordmark.

All of it is decoration: the rules engines and the turn loops do not wait for anything that can be skipped, and the celebrations are left out with light or no motion and in the test fast-forward.
