# عراق لودو · Iraq Ludo — Android + موقع (v1.4.0)

## بالعربي

لعبة لودو ودومنة عراقية لأندرويد، مبنية على نفس أساس **عقارجي**: Kotlin + WebView،
وكل الواجهات واللعب داخل `app/src/main/assets/index.html`.

### الجديد بـ 1.4 (التصميم والحركة)
- **التصميم والألوان** (الإعدادات ← التصميم والألوان): 8 ألوان للواجهة، 6 خلفيات متحركة (طابوق، بوابة عشتار، نخيل، نجوم، زخرفة، سادة)، 6 لوحات مجانية (جديد: فيروز سامراء، غروب دجلة)، 4 أشكال لحجار الدومنة، 3 أشكال لحجار اللودو، ومستوى الحركات (كاملة، خفيفة، بدون). التغيير يبين فوراً، وزر يرجّع الشكل الأصلي.
- **شخصيات عراقية مرسومة** بدل الإيموجي: 14 شخصية (6 مجانية)، والكمبيوتر ياخذ شخصية تناسب اسمه.
- **حركات اللودو**: النرد ينرمي على اللوحة ويا ظل، الحجر يقفز بقوس، القتل يدوّر الحجر ويهز اللوحة، وصول البيت يضوي العمود ويطلق ألعاب نارية.
- **حركات الدومنة**: الحجار تنخلط مقلوبة وتتوزع وحدة وحدة، وبنهاية الجولة حجار الخصم تنقلب ونقاطها تطير للنتيجة. الطاولة بيها زينة متحركة حسب اللوحة.
- **الاحتفالات**: الدنانير تطير للرصيد، شارة ذهبية لصعود المستوى، صندوق للمكافأة اليومية (ذهبي باليوم السابع)، منصة الفائزين، وإيموجي كبير يطير.
- بطاقة اللعبة بالرئيسية تكبر لحد ما تصير شاشة اللعب، ولمعة ذهب تمر على الشعار.
- 3 ألوان نرد جديدة (وردي، بنفسجي، رخام).

### تصليحات 1.3.1 (مراجعة كل الملفات)
- **الحسابات**: معرّف الدخول الداخلي صار على نطاق مشروع Firebase نفسه، فمحد يگدر ياخذ حساب برسالة «تغيير كلمة المرور». رمز الاستعادة ما يتبدل بدون كلمة المرور. الحساب اللي ينقطع الإنترنت بنص تسجيله يكمل عند أول دخول.
- **مشاركة التقدم**: المباراة تنحسب مرة وحدة حتى لو انقطع الاتصال أو انغلق التطبيق بنص الإرسال، وحتى لو الموقع مفتوح بتبويبين.
- **اللعب**: بالدومنة، النقر وقت توزيع الحجار ما عاد يخلّي الكمبيوتر يلعب حجارك. «إلغاء» بسؤال الانسحاب يكمّل اللعب وما يوقف اللعبة. المباراة تنحسب لحظة ما تنحسم، مرة وحدة، حتى لو انغلق التطبيق. إذا عندك مباراة محفوظة وبدأت جديدة، اللعبة تسألك أول. ملخص الجولة زره يبقى ظاهر بالشاشات الصغيرة. لعب بالكيبورد كامل بالموقع.
- **الشاشات الصغيرة (360)**: شاشة التسجيل وصف الألوان ما يطلعون برا الشاشة.
- **التطبيق**: الروابط الخارجية بس https والإيميل، وتصنيف «لعبة» حتى يبقى الاتجاه عمودي على التابلت، ورسالة واضحة إذا WebView قديم.
- رابط سياسة الخصوصية وإيميل الدعم صاروا يظهرون داخل اللعبة (من `config.js`).

### الجديد بالنسخة 1.3
- **الدومنة**: لعبة ثانية بنفس التطبيق والموقع. لاعبين (ويا سحب من الكومة) أو 4 لاعبين بالشراكة، مباراة على 50 أو 100 نقطة، وحفظ تلقائي.
- **الدينار العراقي** بدل العملات: كل فوز +50 دينار، وكل خسارة −50 (ما تنزل تحت الصفر). دنانير اللعبة مو فلوس حقيقية: مجانية، ما تنشرى ولا تنسحب.
- **اللوحات كلها مجانية**: أي لاعب يختار اللوحة اللي تعجبه، وهي نفسها تصير طاولة الدومنة.
- **مستوى واحد**: الكمبيوتر يلعب بالمستوى المتوسط دائماً، وماكو أي اختيار أو ذكر لمستويات الصعوبة.

### شنو موجود من قبل
- **موقع** بنفس اللعبة (مجلد `firebase/hosting`)، مربوط ويا التطبيق: نفس الحساب، ونفس الدنانير والمستوى والإحصائيات.
- واجهات بالأسود والذهبي، وشاشة ترحيب بأول تشغيل. اللعبة كلها مجانية، ماكو أي دفع.
- حسابات باسم مستخدم وكلمة مرور فقط، بدون إيميل ولا رقم موبايل، مع رمز استعادة.
- لودو ضد الكمبيوتر بدون إنترنت: 2 أو 4 لاعبين، قوانين كاملة.
- إحصائيات لكل لعبة، مستوى اللاعب (XP) وألقاب، مكافأة يومية، تحديات، شارات.
- إيموجي وعبارات عراقية جاهزة فقط. ماكو محادثة نهائياً. أصوات وموسيقى مع زر كتم.

### التشغيل
اقرأ `SETUP-AR.md`. باختصار: Android Studio ← Open ← `IraqLudo-Android` ← انتظر Gradle ← ▶.
والموقع: `firebase deploy --only hosting,firestore:rules` من مجلد `firebase` (الخطوة 4 بالدليل).

### الخطوات الجاية (موقفة هسه حسب طلبك)
- اللعب أونلاين المجاني (لودو ودومنة): مطابقة، والخادم يوزع ويرمي ويتحقق من كل حركة.
- تجربة على أجهزة، تحسين الأداء، والنشر.

التفاصيل الكاملة بـ `docs/DESIGN.md`.

## English

Iraqi Ludo and dominoes for Android on the same foundation as Aqarchi: a Kotlin WebView host serving
`app/src/main/assets/index.html` through `WebViewAssetLoader`.

- **v1.4.0 (design and motion):** Settings ← Design & colours: 8 interface colour themes (every colour is a CSS token, swapped by `html[data-ui]`), 6 slowly drifting screen backgrounds, 6 free boards (new: Samarra turquoise, Tigris sunset) with small moving pictures in the yards and on the dominoes table, 4 dominoes tile styles, 3 Ludo token styles, and a motion level (full, light, none; the phone's reduced-motion setting is the default). 14 original drawn Iraqi characters as player pictures (SVG, no ids). Ludo: the dice is thrown onto the board, tokens hop in an arc, captures spin with a board shake, home columns light up with fireworks. Dominoes: face-down shuffle and deal, end-of-round reveal with points flying to the score. Celebrations: dinars fly to the balance, level-up badge, daily chest (golden on day 7), result podium, big flying emojis, card-grow transition.
- **v1.3.1 (full review):** login IDs moved to `<projectId>.firebaseapp.com` (no mailbox can exist there, so Firebase's reset e-mail cannot take over an account); sign-up and deletion are atomic and repeatable; the recovery code cannot be swapped without the password; recovery limits cannot lock an owner out; progress sync is idempotent (a repeated or interrupted sync counts once; two tabs are safe) and writes only when something changed; dominoes tiles cannot be played while they are dealt (a tap there made the computer play the human's hand); "cancel" on the give-up question no longer leaves the match paused; a match is counted the moment it is decided, exactly once, and never as a give-up; starting a new match over a saved one asks first; keyboard play on the website; small-screen fixes; the privacy-policy link and support address from `config.js` are shown in the game; Android host opens only https/mailto links and declares the game category; an old WebView gets a clear notice.
- **v1.3:** dominoes (2 players with a draw pile, or 4 players in partnerships; matches to 50 or 100 points; save/resume; its own statistics, challenges and badges); game money shown as Iraqi dinars (play money: +50 per win, −50 per loss); every board free (the chosen board also styles the dominoes table); one computer level (the former medium) with no level choice or wording anywhere.
- **v1.2:** website edition in `firebase/hosting` sharing the same accounts and progress as the app; progress merged across devices (`players/{uid}/progress/main`).
- **v1.1:** black-and-gold interface, welcome slides on first launch, all payment features removed (the game is free).
- **Built (Phases 1–2):** all screens (Arabic RTL + English), username/password accounts with a recovery code
  (on-device test mode, or Firebase Auth + Firestore), offline play vs the computer, XP, titles, daily reward,
  challenges, badges, cosmetics, fixed emojis/phrases (no chat), sound and music.
- **Config:** `app/src/main/assets/config.js`. Empty = on-device test mode.
- **Server:** `firebase/` — security rules and Cloud Functions (Node 22, `me-central2`); `recoverAccount` now, a free online game server later (both rules engines are copied to `firebase/functions`).
- **Stack:** AGP 8.13.2, Gradle 8.13, Kotlin 2.1.21, compileSdk/targetSdk 36, minSdk 26, JDK 17, androidx.webkit 1.13.
- **Build:** `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`; CI in `.github/workflows/build-apk.yml`.
- **Edit the game:** sources in `web/src`, then `bash web/build.sh`.
- **Website:** `cd firebase && firebase deploy --only hosting,firestore:rules`; `firebase/hosting/config.js` must match `app/src/main/assets/config.js`.
- **Tests:** `node web/tests/engine.test.js`, `node web/tests/domino.test.js`, `node web/tests/progress.test.js`, `node web/tests/sim.js 800`, `node web/tests/domsim.js 600`,
  `python3 web/tests/ui_test.py`, `python3 web/tests/firebase_flow_test.py`, `python3 web/tests/sync_test.py`,
  `node firebase/functions/test/recovery.test.js`, `node firebase/functions/test/limits.test.js`.
- **Design:** `docs/DESIGN.md`.
