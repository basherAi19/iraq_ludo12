/* =====================================================================
   عراق لودو — إعدادات اللعبة (Iraq Ludo settings)
   عدّل القيم بين علامات التنصيص فقط، احفظ الملف، ثم ابنِ التطبيق من جديد.

   إذا تركت firebase فارغ: اللعبة تشتغل بوضع التجربة، والحسابات تنحفظ على الجهاز بس.
   If firebase stays empty, the game runs in test mode with accounts kept on the device only.

   مهم: الموقع يقرأ نسخة من هذا الملف بـ firebase/hosting/config.js.
   خلي القيم نفسها بالملفين حتى يكون الحساب والتقدم نفسه بالتطبيق والموقع.
   ===================================================================== */
window.LUDO_CONFIG = {
  // Firebase ← Project settings ← Your apps ← (Web app) ← SDK setup and configuration ← Config
  firebase: {
    apiKey: '',
    authDomain: '',
    projectId: '',
    storageBucket: '',
    messagingSenderId: '',
    appId: ''
  },

  // منطقة Cloud Functions (نفس منطقة Firestore). الدمام = me-central2
  functionsRegion: 'me-central2',

  // رابط صفحة سياسة الخصوصية (مطلوب لـ Google Play) وإيميل الدعم
  privacyUrl: '',
  supportEmail: '',

  // للموقع فقط: رابط تحميل تطبيق أندرويد (Google Play). إذا تركته فارغ ما يظهر زر التحميل.
  androidUrl: ''
};
