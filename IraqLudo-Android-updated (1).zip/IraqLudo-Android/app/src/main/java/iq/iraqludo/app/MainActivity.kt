package iq.iraqludo.app

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.HapticFeedbackConstants
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.view.Gravity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.webkit.WebViewAssetLoader

/**
 * Iraq Ludo — the whole game (screens, board, rules, computer players, sounds) lives in assets/index.html.
 * This activity hosts it full-screen and adds the native parts:
 * system bars, splash, Android back button, sharing, vibration, keep-screen-on during a match, pause/resume.
 * Same host as Aqarchi: WebView + WebViewAssetLoader + a small JavaScript bridge (window.AndroidApp).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var bannerAd: AdView? = null
    private lateinit var contentLayout: LinearLayout
    @Volatile private var pageReady = false
    private var rendererGone = false
    private var started = false           // the activity is on screen (between onStart and onStop)
    private var restartOnStart = false    // the page was lost in the background: rebuild it when the player returns

    // Serves app/src/main/assets over https://appassets.androidplatform.net/assets/
    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { !pageReady }
        Handler(Looper.getMainLooper()).postDelayed({ pageReady = true }, 2500)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )

        val night = Color.parseColor("#080706")
        webView = WebView(this).apply { setBackgroundColor(night) }
        contentLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(night)
            addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(contentLayout)

        // Google demo banner unit: safe for development; replace with your own AdMob unit before release.
        MobileAds.initialize(this) {
            runOnUiThread {
                if (isFinishing || isDestroyed || bannerAd != null) return@runOnUiThread
                val ad = AdView(this).apply {
                    adUnitId = "ca-app-pub-3940256099942544/6300978111"
                    setAdSize(AdSize.BANNER)
                }
                bannerAd = ad
                contentLayout.addView(ad, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                })
                ad.loadAd(AdRequest.Builder().build())
            }
        }

        // Keep content clear of the status bar, navigation bar, camera cutout and keyboard
        ViewCompat.setOnApplyWindowInsetsListener(contentLayout) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            view.updatePadding(left = bars.left, top = bars.top, right = bars.right, bottom = maxOf(bars.bottom, ime.bottom))
            WindowInsetsCompat.CONSUMED
        }

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true           // accounts (test mode), progress, saved match, settings
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            textZoom = 100                      // keep the designed layout regardless of system font size
            mediaPlaybackRequiresUserGesture = false   // game sounds and music resume without an extra tap
            offscreenPreRaster = true           // pre-draws the page off-screen → smoother animations
        }
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
        webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true)
        webView.isVerticalScrollBarEnabled = false
        webView.isHorizontalScrollBarEnabled = false
        webView.overScrollMode = WebView.OVER_SCROLL_NEVER
        webView.addJavascriptInterface(Bridge(), "AndroidApp")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                // Frames (Firebase) load normally; only full-page links leave the app
                val url = request.url
                if (!request.isForMainFrame || (url.scheme == "https" && url.host == APP_HOST)) return false
                openExternal(url)                // privacy page or an e-mail to support
                return true
            }

            override fun onPageFinished(view: WebView, url: String) {
                pageReady = true
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                // The page's renderer crashed or Android reclaimed it for memory.
                // Rebuild the screen instead of closing the app; the saved match stays on the device.
                Log.w(TAG, "WebView renderer gone (crashed=${detail.didCrash()}); restarting the screen")
                rendererGone = true
                (view.parent as? ViewGroup)?.removeView(view)
                view.destroy()
                restartScreen()
                return true
            }
        }

        // Android back button / gesture: the game goes back screen by screen (and opens the pause menu
        // during a match); the app closes only from the home or sign-in screen
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (rendererGone) { finish(); return }
                webView.evaluateJavascript("(window.ludoBack ? window.ludoBack() : false)") { handled ->
                    if (handled != "true") finish()
                }
            }
        })

        webView.loadUrl(START_URL)
    }

    /** Opens a link outside the game. Only web pages and e-mail: nothing else can be started from the page. */
    private fun openExternal(uri: Uri) {
        val intent = when (uri.scheme?.lowercase()) {
            "https", "http" -> Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)
            "mailto" -> Intent(Intent.ACTION_SENDTO, uri)
            else -> { Log.w(TAG, "blocked link with scheme ${uri.scheme}"); return }
        }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.no_app, Toast.LENGTH_SHORT).show()
        } catch (e: SecurityException) {
            Log.w(TAG, "link not opened: ${e.message}")
        }
    }

    /**
     * Rebuilds the screen after the page was lost. In the background it waits until the player comes back
     * (Android took the memory on purpose); if the page dies again straight away the app closes instead of looping.
     */
    private fun restartScreen() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastRestart < 10_000L) { finish(); return }
        if (started) { lastRestart = now; recreate() } else restartOnStart = true
    }

    override fun onStart() {
        super.onStart()
        started = true
        if (restartOnStart) {
            restartOnStart = false
            lastRestart = SystemClock.elapsedRealtime()
            recreate()
        }
    }

    override fun onStop() {
        started = false
        super.onStop()
    }

    private fun callJs(js: String) {
        if (!rendererGone) webView.evaluateJavascript(js, null)
    }

    override fun onResume() {
        super.onResume()
        if (rendererGone) return
        webView.onResume()
        bannerAd?.resume()
        callJs("window.ludoNative && window.ludoNative.onResume()")
    }

    override fun onPause() {
        if (!rendererGone) {
            callJs("window.ludoNative && window.ludoNative.onPause()")   // saves the match, pauses music
            webView.onPause()
            bannerAd?.pause()
        }
        super.onPause()
    }

    override fun onDestroy() {
        bannerAd?.destroy()
        bannerAd = null
        if (!rendererGone) webView.destroy()
        super.onDestroy()
    }

    /** Methods the game UI can call through window.AndroidApp */
    inner class Bridge {
        @JavascriptInterface
        fun share(text: String) {
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text.take(4000))
                }
                startActivity(Intent.createChooser(send, null))
            }
        }

        /** Opens the privacy page or an e-mail to support (https:, http: and mailto: only) */
        @JavascriptInterface
        fun open(url: String) {
            runOnUiThread { openExternal(Uri.parse(url.take(2000))) }
        }

        /** Short vibration: "tap", "success" (win, reward, sign-in), "heavy" (a token got captured) */
        @JavascriptInterface
        fun haptic(kind: String) {
            runOnUiThread {
                if (rendererGone) return@runOnUiThread
                val type = when {
                    kind == "success" && Build.VERSION.SDK_INT >= 30 -> HapticFeedbackConstants.CONFIRM
                    kind == "heavy" -> HapticFeedbackConstants.LONG_PRESS
                    else -> HapticFeedbackConstants.VIRTUAL_KEY
                }
                webView.performHapticFeedback(type)
            }
        }

        /** Shows ads for free accounts; only a server-verified VIP entitlement may hide them. */
        @JavascriptInterface
        fun setAdsVisible(visible: Boolean) {
            runOnUiThread { bannerAd?.visibility = if (visible) android.view.View.VISIBLE else android.view.View.GONE }
        }

        /** Keeps the screen on during a match so it does not dim while the player thinks */
        @JavascriptInterface
        fun keepAwake(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        /** Error lines from the game go to Logcat (filter by tag "IraqLudo") */
        @JavascriptInterface
        fun log(level: String, message: String) {
            val m = message.take(2000)
            when (level) {
                "E" -> Log.e(TAG, m)
                "W" -> Log.w(TAG, m)
                else -> Log.i(TAG, m)
            }
        }

        @JavascriptInterface
        fun platform(): String = "android"

        @JavascriptInterface
        fun appVersion(): String = BuildConfig.VERSION_NAME
    }

    companion object {
        private const val TAG = "IraqLudo"
        private const val APP_HOST = "appassets.androidplatform.net"
        private const val START_URL = "https://$APP_HOST/assets/index.html"
        private var lastRestart = -60_000L          // when the screen was last rebuilt after losing the page
    }
}
