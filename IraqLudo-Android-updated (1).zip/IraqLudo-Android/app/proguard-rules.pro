# Keep the JavaScript bridge methods called from the game UI (window.AndroidApp)
-keepclassmembers class iq.iraqludo.app.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
