'use strict';
/* Checks that a recovery-code hash made by the app (WebCrypto code taken from web/src/06_backend.js)
   is accepted by the server (lib.js), and that the input rules match on both sides.
   Run: node test/recovery.test.js   (no Firebase needed) */
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const L = require('../lib');

const SRC = path.join(__dirname, '..', '..', '..', 'web', 'src');
const core = fs.readFileSync(path.join(SRC, '04_core.js'), 'utf8');
const backend = fs.readFileSync(path.join(SRC, '06_backend.js'), 'utf8');
const pick = (src, re) => { const m = src.match(re); assert.ok(m, 'snippet not found: ' + re); return m[0]; };
const clientCode = [
  pick(core, /const digitsAr = .*\n/),
  pick(backend, /const USERNAME_RE = .*\n/),
  pick(backend, /const RC_ALPHA = .*\n/),
  pick(backend, /const pwOk = .*\n/),
  pick(backend, /function newRecoveryCode\(\) \{[\s\S]*?\n\}\n/),
  pick(backend, /const normCode = .*\n/),
  pick(backend, /const b64 = .*\n/),
  pick(backend, /const fromB64 = .*\n/),
  pick(backend, /async function pbkdf2\([\s\S]*?\n\}\n/),
  pick(backend, /async function hashSecret\([\s\S]*?\n\}\n/),
  'globalThis.C = { USERNAME_RE, RC_ALPHA, pwOk, newRecoveryCode, normCode, hashSecret };'
].join('');
const ctx = { crypto: globalThis.crypto, btoa, atob, TextEncoder, Uint8Array, String, Math, Number };
vm.createContext(ctx);
vm.runInContext(clientCode, ctx);
const C = ctx.C;

(async () => {
  let n = 0;
  const ok = (cond, msg) => { assert.ok(cond, msg); n++; };

  // same alphabet, username rule and password rule
  ok(C.RC_ALPHA === L.RC_ALPHA, 'alphabet');
  ok(String(C.USERNAME_RE) === String(L.USERNAME_RE), 'username regex');
  for (const p of ['short1', 'abcdefgh', '12345678', 'Ludo2026x', 'لودو٢٠٢٦حلو', 'x'.repeat(70) + '1', 'pass word 1'])
    ok(C.pwOk(p) === L.pwOk(p), 'pwOk agrees on ' + p);

  // app-made hash (120,000 iterations, as at sign-up) is verified by the server
  const code = C.newRecoveryCode();
  ok(/^[A-Z2-9]{4}(-[A-Z2-9]{4}){3}$/.test(code), 'code format ' + code);
  const rec = await C.hashSecret(C.normCode(code), 120000);
  ok(rec.salt.length === 24 && rec.hash.length === 44 && rec.algo === 'pbkdf2-sha256', 'record shape fits the security rules');
  ok(await L.verifySecret(L.normCode(code), rec), 'server accepts the app hash');
  ok(await L.verifySecret(L.normCode(code.toLowerCase().replace(/-/g, ' ')), rec), 'lower case and spaces are fine');
  ok(!(await L.verifySecret(L.normCode('AAAA-BBBB-CCCC-DDDD'), rec)), 'wrong code rejected');
  ok(!(await L.verifySecret(L.normCode(code), null)), 'missing record rejected');
  ok(!(await L.verifySecret(L.normCode(code), { algo: 'md5', salt: rec.salt, hash: rec.hash, iter: 1 })), 'unknown algorithm rejected');

  // server-made code + hash keeps the same format the app expects
  const fresh = L.newRecoveryCode();
  const rec2 = await L.hashSecret(L.normCode(fresh));
  ok(/^[A-Z2-9]{4}(-[A-Z2-9]{4}){3}$/.test(fresh), 'server code format');
  ok(await L.verifySecret(L.normCode(fresh), rec2), 'server hash round trip');

  // usernames
  for (const [u, want] of [['layth.test', true], ['ab', false], ['9abc', false], ['abc..d', false], ['abc.', false], ['abc_d', true], ['ABC', false]])
    ok(L.validUsername(u) === want, 'username ' + u);
  ok(L.normUser('  Layth١٢ ') === 'layth12', 'Arabic digits and case in usernames');

  console.log(`recovery tests: ${n} passed`);
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
