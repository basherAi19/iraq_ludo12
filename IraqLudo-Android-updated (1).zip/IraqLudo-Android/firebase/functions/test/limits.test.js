'use strict';
/* recoverAccount with the Firebase modules replaced by small stand-ins: the limits and the order of the checks.
   - only wrong codes are counted per username (5 an hour); the right code always works
   - the network limit (30 an hour) uses the last X-Forwarded-For entry, the one the caller cannot forge
   - a blocked network creates no per-name counters; counters carry expireAt for a TTL policy
   Run: node test/limits.test.js   (no Firebase needed) */
const Module = require('node:module');
const assert = require('node:assert/strict');
const path = require('node:path');

const store = new Map();
const plain = d => JSON.parse(JSON.stringify(d));
const docRef = p => ({
  path: p,
  get: async () => ({ exists: store.has(p), data: () => store.get(p), get: k => (store.get(p) || {})[k] }),
  set: async d => { store.set(p, plain(d)); },
  delete: async () => { store.delete(p); }
});
const db = {
  collection: c => ({ doc: k => docRef(c + '/' + k) }),
  doc: p => docRef(p),
  runTransaction: async fn => fn({ get: r => r.get(), set: (r, d) => { store.set(r.path, plain(d)); } })
};
let password = null, revoked = 0;
const stubs = {
  'firebase-functions/v2/https': { onCall: (opts, fn) => fn, HttpsError: class extends Error { constructor(code, msg) { super(msg); this.code = code; } } },
  'firebase-functions/v2': { setGlobalOptions() {} },
  'firebase-functions/logger': { info() {} },
  'firebase-admin/app': { initializeApp() {} },
  'firebase-admin/firestore': { getFirestore: () => db, Timestamp: { fromMillis: ms => ({ ms }) } },
  'firebase-admin/auth': { getAuth: () => ({ updateUser: async (uid, o) => { password = o.password; }, revokeRefreshTokens: async () => { revoked++; } }) }
};
const load = Module._load;
Module._load = function (name, ...rest) { return stubs[name] || load.call(this, name, ...rest); };
const F = require(path.join(__dirname, '..', 'index.js'));
const L = require(path.join(__dirname, '..', 'lib.js'));

let n = 0;
const ok = (cond, name) => { assert.ok(cond, name); n++; };
const call = (data, xff) => F.recoverAccount({ data, rawRequest: { headers: { 'x-forwarded-for': xff }, ip: '9.9.9.9' } }).then(r => ({ ok: r }), e => ({ err: e.code }));

(async () => {
  const code = L.newRecoveryCode();
  store.set('usernames/layth', { uid: 'u1' });
  store.set('recovery/u1', { ...(await L.hashSecret(L.normCode(code))), createdAt: 1 });
  const wrong = { username: 'layth', code: 'AAAA-AAAA-AAAA-AAAA', newPassword: 'Passw0rd1' };

  const seen = [];
  for (let i = 0; i < 6; i++) seen.push((await call(wrong, '1.1.1.1, 5.5.5.5')).err);
  assert.deepEqual(seen, ['permission-denied', 'permission-denied', 'permission-denied', 'permission-denied', 'permission-denied', 'resource-exhausted']); n++;

  const good = await call({ username: 'layth', code, newPassword: 'Passw0rd1' }, '1.1.1.1, 5.5.5.5');
  ok(good.ok && good.ok.code && good.ok.code !== code, 'the right code works even after five wrong ones');
  ok(password === 'Passw0rd1' && revoked === 1, 'password set and other sessions signed out');
  ok(!store.has('rateLimits/recover_u_layth'), 'the name counter is cleared after a success');
  ok((await call({ username: 'layth', code, newPassword: 'Passw0rd2' }, '2.2.2.2')).err === 'permission-denied', 'the old code is dead');
  ok((await call({ username: 'layth', code: good.ok.code, newPassword: 'Passw0rd3' }, '2.2.2.2')).ok, 'the new code works');

  // one network, forging the first X-Forwarded-For entry on every call: still limited by the last entry
  let denied = 0, last = '';
  for (let i = 0; i < 40; i++) {
    const r = await call({ username: 'nobody' + i, code: 'AAAA-AAAA-AAAA-AAAA', newPassword: 'Passw0rd1' }, (i + 10) + '.0.0.1, 7.7.7.7');
    last = r.err; if (r.err === 'permission-denied') denied++;
  }
  ok(denied === 30 && last === 'resource-exhausted', '30 calls an hour per network, counted on the last hop');
  const c = store.get('rateLimits/recover_ip_7.7.7.7');
  ok(c.count === 30 && c.expireAt && c.expireAt.ms > Date.now(), 'the counter stops at the limit and carries expireAt');
  ok(!store.has('rateLimits/recover_u_nobody35'), 'a blocked network creates no per-name counters');
  ok((await call({ username: 'x', code: '1', newPassword: 'short' }, '3.3.3.3')).err === 'invalid-argument', 'bad input is refused before anything is counted');
  ok(!store.has('rateLimits/recover_ip_3.3.3.3'), '(nothing counted for bad input)');
  console.log(`\n${n} recovery-limit checks passed`);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
