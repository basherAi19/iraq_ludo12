'use strict';
/* Shared helpers for the account functions. They mirror web/src/06_backend.js exactly:
   same username rules, same password rule, same recovery-code alphabet and the same
   PBKDF2-SHA256 hash format { algo, iter, salt(base64 16 B), hash(base64 32 B) }. */
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const pbkdf2 = promisify(crypto.pbkdf2);

const USERNAME_RE = /^[a-z][a-z0-9_.]{2,19}$/;
const RC_ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const RECOVERY_ITER = 120000;

const digitsAr = s => String(s ?? '').replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
const normUser = u => digitsAr(String(u || '')).trim().toLowerCase();
const normCode = c => digitsAr(String(c || '')).toUpperCase().replace(/[^A-Z0-9]/g, '');
const validUsername = u => typeof u === 'string' && USERNAME_RE.test(u) && !u.includes('..') && !u.endsWith('.');
const pwOk = p => typeof p === 'string' && p.length >= 8 && p.length <= 64 && /[a-zA-Z؀-ۿ]/.test(p) && /\d/.test(digitsAr(p));

function newRecoveryCode() {
  const s = [...crypto.randomBytes(16)].map(b => RC_ALPHA[b % 32]).join('');
  return `${s.slice(0, 4)}-${s.slice(4, 8)}-${s.slice(8, 12)}-${s.slice(12, 16)}`;
}

async function hashSecret(secret, iter = RECOVERY_ITER) {
  const salt = crypto.randomBytes(16);
  const hash = await pbkdf2(secret, salt, iter, 32, 'sha256');
  return { algo: 'pbkdf2-sha256', iter, salt: salt.toString('base64'), hash: hash.toString('base64') };
}

// Stand-in record: a wrong username costs the same time as a wrong code, so timing does not reveal names
const DUMMY = { algo: 'pbkdf2-sha256', iter: RECOVERY_ITER, salt: Buffer.alloc(16).toString('base64'), hash: Buffer.alloc(32).toString('base64') };

async function verifySecret(secret, rec) {
  const real = !!(rec && rec.algo === 'pbkdf2-sha256' && typeof rec.salt === 'string' && typeof rec.hash === 'string');
  const r = real ? rec : DUMMY;
  const iter = Math.min(Math.max(Number(r.iter) | 0, 1000), 1000000);
  const got = await pbkdf2(String(secret), Buffer.from(r.salt, 'base64'), iter, 32, 'sha256');
  const want = Buffer.from(r.hash, 'base64');
  const same = want.length === got.length && crypto.timingSafeEqual(got, want);
  return real && same;
}

module.exports = { USERNAME_RE, RC_ALPHA, RECOVERY_ITER, digitsAr, normUser, normCode, validUsername, pwOk, newRecoveryCode, hashSecret, verifySecret };
