/* =====================================================================
   Iraq Ludo — Dominoes (الدومنة): rules engine
   Pure and deterministic given the shuffled tile order, which comes from
   outside (crypto random offline; the server once online play opens).

   Double-six set: 28 tiles, ids 0..27 → [a, b] with a <= b.
   Seats: 0 = the human (bottom), then counter-clockwise: 1 right, 2 top, 3 left.
   2 players (seats 0 and 1): 7 tiles each; the other 14 are the draw pile ("الكومة").
   4 players: two teams, partners sit opposite (0+2 against 1+3); all 28 are dealt, no drawing.
   First round: the highest double opens (6-6 when someone holds it). Later rounds: the round winner opens.
   A round ends when a player plays his last tile ("دومنة") or nobody can play ("انسدّت").
   The winning team scores the pips left in the opponents' hands. First team to `target` wins the match.

   The line on the table: `first` (the opening tile) and two arms, L and R, each listed from the
   centre outwards as { id, i, o }: i = the value touching the line, o = the new open end.
   ===================================================================== */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.DominoEngine = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const TILES = [];
  for (let a = 0; a <= 6; a++) for (let b = a; b <= 6; b++) TILES.push([a, b]);
  const RULES_VERSION = 1, HAND = 7, TARGET = 100;

  const pips = id => TILES[id][0] + TILES[id][1];
  const isDouble = id => TILES[id][0] === TILES[id][1];
  const has = (id, v) => TILES[id][0] === v || TILES[id][1] === v;
  const other = (id, v) => (TILES[id][0] === v ? TILES[id][1] : TILES[id][0]);
  const handPips = hand => hand.reduce((s, id) => s + pips(id), 0);
  const teamOf = (st, seat) => (st.players === 4 ? seat % 2 : seat);
  const nextSeat = (st, seat) => (seat + 1) % st.players;

  /* A fair shuffle of the 28 ids; rand() returns a number in [0, 1) */
  function shuffled(rand) {
    const a = TILES.map((_, i) => i);
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); const x = a[i]; a[i] = a[j]; a[j] = x; }
    return a;
  }

  function createMatch(opts) {
    const players = opts && opts.players === 4 ? 4 : 2;
    const target = opts && opts.target > 0 ? Math.floor(opts.target) : TARGET;
    const st = {
      v: RULES_VERSION, players, target, scores: [0, 0], round: 0, phase: 'deal',
      hands: [], stock: [], first: null, L: [], R: [], turn: 0, opener: null, next: null, lead: null,
      passes: 0, voids: [], seq: 0, last: null, stats: [], teams: [], result: null, winner: null
    };
    for (let s = 0; s < players; s++) st.stats.push({ played: 0, drawn: 0, passes: 0, outs: 0 });
    for (let k = 0; k < 2; k++) st.teams.push({ roundsWon: 0, points: 0, best: 0, blockWins: 0 });
    return st;
  }

  /* Deal a new round from a shuffled order of the 28 ids */
  function deal(st, order) {
    if (st.phase !== 'deal' && st.phase !== 'roundOver') throw new Error('not-deal-phase');
    if (!Array.isArray(order) || order.length !== TILES.length || new Set(order).size !== TILES.length ||
        order.some(x => !(Number.isInteger(x) && x >= 0 && x < TILES.length))) throw new Error('bad-order');
    st.round++;
    st.hands = [];
    for (let s = 0; s < st.players; s++) st.hands.push(order.slice(s * HAND, s * HAND + HAND));
    st.stock = order.slice(st.players * HAND);
    st.first = null; st.L = []; st.R = []; st.passes = 0; st.result = null; st.last = null;
    st.voids = st.hands.map(() => [false, false, false, false, false, false, false]);
    let opener = st.next, lead = null;
    if (opener === null || opener === undefined) {
      // first round: the highest double opens; with no double in any hand (possible with 2 players), the heaviest tile
      let best = -1;
      for (let s = 0; s < st.players; s++) for (const id of st.hands[s]) {
        const [a, b] = TILES[id];
        const rank = a === b ? 100 + a : (a + b) * 7 + b;
        if (rank > best) { best = rank; opener = s; lead = id; }
      }
    }
    st.opener = opener; st.turn = opener; st.lead = lead; st.next = null;
    st.phase = 'play'; st.seq++;
    return [{ type: 'deal', round: st.round, opener, lead }];
  }

  /* The two open ends [left, right], or null before the opening tile */
  const ends = st => (st.first ? [st.L.length ? st.L[st.L.length - 1].o : st.first.a, st.R.length ? st.R[st.R.length - 1].o : st.first.b] : null);

  /* Legal placements for a seat: { id, side } with side 'C' (opening tile), 'L' or 'R' */
  function movesFor(st, seat) {
    const hand = st.hands[seat] || [], out = [];
    if (!st.first) {
      for (const id of hand) if (st.lead === null || st.lead === undefined || id === st.lead) out.push({ id, side: 'C' });
      return out;
    }
    const [l, r] = ends(st);
    for (const id of hand) {
      if (has(id, l)) out.push({ id, side: 'L' });
      if (has(id, r)) out.push({ id, side: 'R' });
    }
    return out;
  }
  const legalMoves = st => (st.phase === 'play' ? movesFor(st, st.turn) : []);
  const canPlay = (st, seat) => movesFor(st, seat).length > 0;
  /* Nobody can play and nobody can draw */
  const blocked = st => !!st.first && !st.stock.length && st.hands.every((h, s) => !canPlay(st, s));

  function play(st, id, side) {
    if (st.phase !== 'play') throw new Error('not-play-phase');
    const seat = st.turn, hand = st.hands[seat];
    if (!movesFor(st, seat).some(m => m.id === id && m.side === side)) throw new Error('illegal-move');
    hand.splice(hand.indexOf(id), 1);
    const ev = [];
    if (side === 'C') {
      st.first = { id, a: TILES[id][0], b: TILES[id][1] };
      st.lead = null;
      ev.push({ type: 'play', seat, id, side, i: null, o: null });
    } else {
      const e = ends(st)[side === 'L' ? 0 : 1], item = { id, i: e, o: other(id, e) };
      (side === 'L' ? st.L : st.R).push(item);
      ev.push({ type: 'play', seat, id, side, i: item.i, o: item.o });
    }
    st.passes = 0; st.seq++; st.stats[seat].played++; st.last = { seat, id, side };
    if (!hand.length) return endRound(st, ev, 'domino', seat);
    if (blocked(st)) return endRound(st, ev, 'blocked', null);
    st.turn = nextSeat(st, seat);
    ev.push({ type: 'turn', seat: st.turn });
    return ev;
  }

  /* 2 players: a player with no fitting tile draws from the pile, one tile at a time */
  function draw(st) {
    if (st.phase !== 'play') throw new Error('not-play-phase');
    const seat = st.turn;
    if (canPlay(st, seat)) throw new Error('has-move');
    if (!st.stock.length) throw new Error('stock-empty');
    const id = st.stock.pop();
    st.hands[seat].push(id); st.stats[seat].drawn++; st.seq++;
    const ev = [{ type: 'draw', seat, id, left: st.stock.length }];
    if (!st.stock.length && blocked(st)) return endRound(st, ev, 'blocked', null);
    return ev;
  }

  /* No fitting tile and nothing to draw: knock ("دگّ") and the turn passes */
  function pass(st) {
    if (st.phase !== 'play') throw new Error('not-play-phase');
    const seat = st.turn;
    if (canPlay(st, seat)) throw new Error('has-move');
    if (st.stock.length) throw new Error('must-draw');
    const e = ends(st);
    if (e) { st.voids[seat][e[0]] = true; st.voids[seat][e[1]] = true; }   // public knowledge: this player lacks both numbers
    st.passes++; st.stats[seat].passes++; st.seq++;
    const ev = [{ type: 'pass', seat }];
    if (st.passes >= st.players || blocked(st)) return endRound(st, ev, 'blocked', null);
    st.turn = nextSeat(st, seat);
    ev.push({ type: 'turn', seat: st.turn });
    return ev;
  }

  function endRound(st, ev, reason, seat) {
    const left = st.hands.map(handPips);
    let team = null, winner = null;
    if (reason === 'domino') { winner = seat; team = teamOf(st, seat); }
    else {
      // blocked: the player with the fewest pips wins the round for his team
      const min = Math.min(...left), low = [];
      left.forEach((p, s) => { if (p === min) low.push(s); });
      const lowTeams = [...new Set(low.map(s => teamOf(st, s)))];
      if (lowTeams.length === 1) { team = lowTeams[0]; winner = low[0]; }
      else {
        // opponents tie on the lowest hand: the team with fewer pips in total wins; equal totals = a drawn round
        const tt = [0, 0];
        left.forEach((p, s) => { tt[teamOf(st, s)] += p; });
        if (tt[0] !== tt[1]) { team = tt[0] < tt[1] ? 0 : 1; winner = low.find(s => teamOf(st, s) === team); }
      }
    }
    let points = 0;
    if (team !== null) {
      left.forEach((p, s) => { if (teamOf(st, s) !== team) points += p; });
      st.scores[team] += points;
      const T = st.teams[team];
      T.roundsWon++; T.points += points; T.best = Math.max(T.best, points);
      if (reason === 'blocked') T.blockWins++;
      if (reason === 'domino') st.stats[winner].outs++;
    }
    st.next = winner !== null ? winner : st.opener;     // a drawn round is opened again by the same player
    const over = team !== null && st.scores[team] >= st.target;
    st.result = { round: st.round, reason, team, seat: winner, points, left, hands: st.hands.map(h => h.slice()) };
    st.phase = over ? 'over' : 'roundOver';
    st.seq++;
    if (over) st.winner = team;
    ev.push({ type: 'round', reason, team, seat: winner, points, left, over });
    if (over) ev.push({ type: 'win', team });
    return ev;
  }

  /* Integrity check (used when restoring a saved match) */
  function validate(st) {
    try {
      if (!st || st.v !== RULES_VERSION || (st.players !== 2 && st.players !== 4)) return false;
      if (['deal', 'play', 'roundOver', 'over'].indexOf(st.phase) === -1) return false;
      if (!(Number.isInteger(st.target) && st.target > 0) || !(Number.isInteger(st.round) && st.round >= 0)) return false;
      if (!Array.isArray(st.scores) || st.scores.length !== 2 || st.scores.some(x => !Number.isInteger(x) || x < 0)) return false;
      if (!Array.isArray(st.stats) || st.stats.length !== st.players || !Array.isArray(st.teams) || st.teams.length !== 2) return false;
      if (st.stats.some(s => !s || ['played', 'drawn', 'passes', 'outs'].some(k => !(Number.isInteger(s[k]) && s[k] >= 0)))) return false;
      if (st.teams.some(t => !t || ['roundsWon', 'points', 'best', 'blockWins'].some(k => !(Number.isInteger(t[k]) && t[k] >= 0)))) return false;
      const seat = x => Number.isInteger(x) && x >= 0 && x < st.players;
      if (st.next !== null && st.next !== undefined && !seat(st.next)) return false;
      if (st.phase === 'deal') return true;
      if (!Array.isArray(st.hands) || st.hands.length !== st.players || st.hands.some(h => !Array.isArray(h))) return false;
      if (!Array.isArray(st.stock) || !Array.isArray(st.L) || !Array.isArray(st.R)) return false;
      if (!Array.isArray(st.voids) || st.voids.length !== st.players || st.voids.some(v => !Array.isArray(v) || v.length !== 7)) return false;
      if (!seat(st.turn) || !seat(st.opener)) return false;
      if (st.phase === 'roundOver' || st.phase === 'over') {
        const r = st.result;                                              // the round summary is drawn from this
        if (!r || !Array.isArray(r.hands) || r.hands.length !== st.players || r.hands.some(h => !Array.isArray(h)) || !Array.isArray(r.left) || r.left.length !== st.players) return false;
        if (r.team !== null && r.team !== 0 && r.team !== 1) return false;
        if (st.phase === 'over' && st.winner !== 0 && st.winner !== 1) return false;
      }
      if (st.lead !== null && st.lead !== undefined && !(st.phase === 'play' && !st.first && st.hands[st.turn].indexOf(st.lead) !== -1)) return false;
      const seen = new Set();
      const add = id => { if (!(Number.isInteger(id) && id >= 0 && id < TILES.length) || seen.has(id)) throw new Error('dup'); seen.add(id); };
      st.hands.forEach(h => h.forEach(add)); st.stock.forEach(add);
      if (st.first) {
        add(st.first.id);
        if (st.first.a !== TILES[st.first.id][0] || st.first.b !== TILES[st.first.id][1]) return false;
        for (const [arm, start] of [[st.L, st.first.a], [st.R, st.first.b]]) {
          let e = start;
          for (const it of arm) { add(it.id); if (it.i !== e || !has(it.id, e) || other(it.id, e) !== it.o) return false; e = it.o; }
        }
      } else if (st.L.length || st.R.length) return false;
      if (seen.size !== TILES.length) return false;
      if (st.phase === 'play' && st.hands.some(h => !h.length)) return false;
      return Number.isInteger(st.turn) && st.turn >= 0 && st.turn < st.players;
    } catch (e) { return false; }
  }

  return {
    TILES, RULES_VERSION, HAND, TARGET, pips, isDouble, has, other, handPips, teamOf, nextSeat, shuffled,
    createMatch, deal, ends, movesFor, legalMoves, canPlay, blocked, play, draw, pass, validate
  };
});
