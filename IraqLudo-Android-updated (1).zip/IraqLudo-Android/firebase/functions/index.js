'use strict';
/**
 * Iraq Ludo — Cloud Functions (2nd gen, Node 22).
 *
 * Phase 1 (now):  recoverAccount — set a new password with the recovery code shown at sign-up.
 * Phase 3 (next): joinQueue · leaveQueue · roll · move · claimTimeout · react — online matches where the
 *                 server rolls the dice (crypto.randomInt), validates every move with engine.js (the same
 *                 rules engine the app uses; web/build.sh copies it here) and writes the result.
 * Phase 5:        claimDaily / claimChallenge — rewards decided on the server.
 * The game is free: there are no purchase functions.
 */
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { setGlobalOptions } = require('firebase-functions/v2');
const logger = require('firebase-functions/logger');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, Timestamp } = require('firebase-admin/firestore');
const { getAuth } = require('firebase-admin/auth');
const L = require('./lib');

// Must match functionsRegion in app/src/main/assets/config.js. Keep it next to your Firestore location
// (Dammam = me-central2, Doha = me-central1, Frankfurt = europe-west3).
const REGION = 'me-central2';
setGlobalOptions({ region: REGION, maxInstances: 10 });

initializeApp();
const db = getFirestore();
const auth = getAuth();
const HOUR = 3600 * 1000;
const NAME_TRIES = 5;       // wrong codes per username, per hour
const NET_TRIES = 30;       // calls per network address, per hour

/**
 * Fixed-window counter in rateLimits/{key}. Counts this call and returns true while the limit is not passed;
 * once it is passed it returns false and writes nothing more. `expireAt` lets a Firestore TTL policy on the
 * rateLimits collection group remove old counters (optional; see SETUP-AR.md).
 */
async function allow(key, limit, windowMs) {
  const ref = db.collection('rateLimits').doc(key);
  return db.runTransaction(async tx => {
    const snap = await tx.get(ref);
    const now = Date.now();
    let d = snap.exists ? snap.data() : null;
    if (!d || now - d.windowStart > windowMs) d = { count: 0, windowStart: now };
    if (d.count >= limit) return false;
    d.count += 1;
    d.expireAt = Timestamp.fromMillis(d.windowStart + windowMs + 24 * HOUR);
    tx.set(ref, d);
    return true;
  });
}

/**
 * The caller's network address. Each proxy appends the address it received the request from to X-Forwarded-For,
 * so on a function URL the LAST entry is the one written by Google's front end; earlier entries come from the
 * caller and can be forged.
 */
function clientIp(request) {
  const raw = request.rawRequest || {};
  const hops = String((raw.headers && raw.headers['x-forwarded-for']) || '').split(',').map(s => s.trim()).filter(Boolean);
  const ip = hops.length ? hops[hops.length - 1] : (raw.ip || 'unknown');
  return String(ip).replace(/[^0-9a-fA-F:.]/g, '').slice(0, 64) || 'unknown';
}

/**
 * recoverAccount({ username, code, newPassword }) → { code }   (the new recovery code; the old one stops working)
 * Errors: invalid-argument · permission-denied (wrong name or code) · resource-exhausted (too many tries).
 * Limits per hour: 30 calls per network address, and 5 wrong codes per username. Only wrong codes are counted
 * per name and the right code always works, so nobody can lock an owner out by guessing on purpose.
 */
exports.recoverAccount = onCall({ memory: '256MiB', timeoutSeconds: 30 }, async (request) => {
  const data = request.data || {};
  const username = L.normUser(data.username);
  const code = L.normCode(data.code);
  const password = data.newPassword;
  if (!L.validUsername(username) || code.length !== 16 || !L.pwOk(password)) {
    throw new HttpsError('invalid-argument', 'Check the username, the recovery code and the new password.');
  }

  if (!(await allow(`recover_ip_${clientIp(request)}`, NET_TRIES, HOUR))) {
    throw new HttpsError('resource-exhausted', 'Too many attempts. Try again later.');
  }

  const nameSnap = await db.doc(`usernames/${username}`).get();
  const uid = nameSnap.exists ? nameSnap.get('uid') : null;
  const recSnap = uid ? await db.doc(`recovery/${uid}`).get() : null;
  const rec = recSnap && recSnap.exists ? recSnap.data() : null;
  const ok = await L.verifySecret(code, rec);
  if (!uid || !ok) {
    const within = await allow(`recover_u_${username}`, NAME_TRIES, HOUR);
    if (!within) throw new HttpsError('resource-exhausted', 'Too many attempts. Try again later.');
    throw new HttpsError('permission-denied', 'Wrong username or recovery code.');
  }

  await auth.updateUser(uid, { password });
  await auth.revokeRefreshTokens(uid);            // signs the account out on every other device
  const fresh = L.newRecoveryCode();
  const now = Date.now();
  await db.doc(`recovery/${uid}`).set({ ...(await L.hashSecret(L.normCode(fresh))), createdAt: now, renewedAt: now });
  await db.doc(`rateLimits/recover_u_${username}`).delete().catch(() => {});
  logger.info('account recovered', { uid });
  return { code: fresh };
});
