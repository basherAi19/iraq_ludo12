/* =====================================================================
   Iraq Ludo — rules engine (pure, deterministic given the dice values)
   Shared by the app (offline games) and, from Phase 3, by the server
   (Cloud Functions) so both sides apply exactly the same rules.

   Positions are stored per token as a "relative" step count for its colour:
     -1        = in the yard (home base)
      0 .. 50  = on the shared 52-square track (0 = the colour's start square)
     51 .. 55  = on the colour's private home column
     56        = finished (reached the centre)
   ===================================================================== */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.LudoEngine = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const COLORS = ['red', 'green', 'yellow', 'blue'];          // clockwise = turn order
  const START = { red: 0, green: 13, yellow: 26, blue: 39 };  // start square on the shared track
  const SAFE = [0, 8, 13, 21, 26, 34, 39, 47];                // start squares + star squares
  const YARD = -1, LAST_MAIN = 50, HOME = 56, TRACK = 52;
  const RULES_VERSION = 1;

  const isSafe = g => SAFE.indexOf(g) !== -1;
  const globalOf = (color, rel) => (rel >= 0 && rel <= LAST_MAIN) ? (START[color] + rel) % TRACK : -1;

  /* ---------- game creation ---------- */
  function createGame(opts) {
    const colors = (opts && opts.colors ? opts.colors.slice() : COLORS.slice())
      .filter(c => COLORS.indexOf(c) !== -1)
      .sort((a, b) => COLORS.indexOf(a) - COLORS.indexOf(b));       // always clockwise order
    if (colors.length < 2 || colors.length > 4 || new Set(colors).size !== colors.length) throw new Error('bad-colors');
    let first = 0;
    if (opts && opts.first && colors.indexOf(opts.first) !== -1) first = colors.indexOf(opts.first);
    const tokens = {}, stats = {}, out = {};
    colors.forEach(c => {
      tokens[c] = [YARD, YARD, YARD, YARD];
      stats[c] = { captures: 0, lost: 0, sixes: 0, home: 0, rolls: 0, turns: 0, moves: 0 };
      out[c] = false;
    });
    stats[colors[first]].turns = 1;
    return {
      v: RULES_VERSION, colors, turn: first, phase: 'roll', dice: null, sixes: 0,
      tokens, stats, out, winner: null, seq: 0, turnNo: 1, lastRoll: null
    };
  }

  const current = st => st.colors[st.turn];
  const clone = st => JSON.parse(JSON.stringify(st));
  const active = (st, c) => !st.out[c] && st.winner !== c;

  /* Token indexes of colour c that stand on shared-track square g */
  function tokensAt(st, c, g) {
    const res = [];
    const tk = st.tokens[c];
    for (let i = 0; i < 4; i++) if (tk[i] >= 0 && tk[i] <= LAST_MAIN && globalOf(c, tk[i]) === g) res.push(i);
    return res;
  }

  /* Where token t of colour would go with this dice value; null when illegal */
  function moveTarget(st, color, t, dice) {
    if (!st.tokens[color] || st.out[color]) return null;
    const from = st.tokens[color][t];
    if (from === undefined || from === HOME) return null;
    let to;
    if (from === YARD) { if (dice !== 6) return null; to = 0; }
    else { to = from + dice; if (to > HOME) return null; }       // exact roll needed to finish
    const m = { t, from, to, enter: from === YARD, home: to === HOME, captures: [], path: [] };
    if (from === YARD) m.path.push(0); else for (let p = from + 1; p <= to; p++) m.path.push(p);
    if (to <= LAST_MAIN) {
      const g = globalOf(color, to);
      m.square = g;
      if (!isSafe(g)) {
        for (const c of st.colors) {
          if (c === color || st.out[c]) continue;
          const here = tokensAt(st, c, g);
          if (here.length === 1) m.captures.push({ color: c, t: here[0], rel: st.tokens[c][here[0]] });
          // two or more tokens of one colour on a square form a protected pair: no capture
        }
      }
    }
    return m;
  }

  function legalMoves(st, dice) {
    const d = dice === undefined ? st.dice : dice;
    if (st.phase === 'over' || !d) return [];
    const color = current(st), out = [];
    for (let t = 0; t < 4; t++) { const m = moveTarget(st, color, t, d); if (m) out.push(m); }
    return out;
  }

  /* Pass the turn to the next colour that is still playing */
  function advance(st, ev) {
    st.sixes = 0; st.dice = null; st.phase = 'roll';
    const n = st.colors.length;
    for (let k = 1; k <= n; k++) {
      const i = (st.turn + k) % n;
      if (active(st, st.colors[i])) { st.turn = i; break; }
    }
    st.turnNo++;
    st.stats[current(st)].turns++;
    ev.push({ type: 'turn', color: current(st) });
  }

  /* Apply a dice roll (the value comes from outside: Math.random offline, the server online) */
  function roll(st, dice) {
    if (st.phase !== 'roll') throw new Error('not-roll-phase');
    if (!(dice >= 1 && dice <= 6) || Math.floor(dice) !== dice) throw new Error('bad-dice');
    const color = current(st);
    const ev = [{ type: 'roll', color, value: dice }];
    st.dice = dice; st.lastRoll = { color, value: dice }; st.seq++;
    st.stats[color].rolls++;
    if (dice === 6) { st.sixes++; st.stats[color].sixes++; } else st.sixes = 0;
    if (dice === 6 && st.sixes >= 3) {                     // third six in a row: the turn is lost
      ev.push({ type: 'pass', color, reason: 'threeSixes' });
      advance(st, ev);
      return ev;
    }
    const moves = legalMoves(st);
    if (!moves.length) {
      if (dice === 6) { st.phase = 'roll'; st.dice = null; ev.push({ type: 'again', color, reason: 'six' }); }
      else { ev.push({ type: 'pass', color, reason: 'noMove' }); advance(st, ev); }
      return ev;
    }
    st.phase = 'move';
    ev.push({ type: 'choose', color, tokens: moves.map(m => m.t) });
    return ev;
  }

  /* Move token t of the current colour with the rolled value */
  function move(st, t) {
    if (st.phase !== 'move') throw new Error('not-move-phase');
    const color = current(st);
    const m = moveTarget(st, color, t, st.dice);
    if (!m) throw new Error('illegal-move');
    const ev = [];
    st.tokens[color][t] = m.to; st.seq++;
    st.stats[color].moves++;
    ev.push({ type: 'move', color, t, from: m.from, to: m.to, path: m.path, enter: m.enter });
    for (const cap of m.captures) {
      st.tokens[cap.color][cap.t] = YARD;
      st.stats[color].captures++; st.stats[cap.color].lost++;
      ev.push({ type: 'capture', color, t, victim: cap.color, vt: cap.t, rel: cap.rel, square: m.square });
    }
    if (m.home) { st.stats[color].home++; ev.push({ type: 'home', color, t }); }
    if (st.tokens[color].every(p => p === HOME)) {
      st.winner = color; st.phase = 'over'; st.dice = null;
      ev.push({ type: 'win', color });
      return ev;
    }
    const reason = m.captures.length ? 'capture' : m.home ? 'home' : st.dice === 6 ? 'six' : null;
    if (reason) { st.phase = 'roll'; st.dice = null; ev.push({ type: 'again', color, reason }); }
    else advance(st, ev);
    return ev;
  }

  /* A player leaves or is removed (online): tokens leave the board; last one standing wins */
  function forfeit(st, color) {
    if (!st.tokens[color] || st.out[color] || st.phase === 'over') return [];
    const ev = [{ type: 'leave', color }];
    st.out[color] = true; st.seq++;
    st.tokens[color] = st.tokens[color].map(p => (p === HOME ? HOME : YARD));
    const left = st.colors.filter(c => !st.out[c]);
    if (left.length === 1) { st.winner = left[0]; st.phase = 'over'; st.dice = null; ev.push({ type: 'win', color: left[0], byForfeit: true }); return ev; }
    if (current(st) === color) advance(st, ev);
    return ev;
  }

  /* Progress 0..1 of a colour (used for rankings and the AI) */
  function progress(st, c) {
    return st.tokens[c].reduce((s, p) => s + (p === YARD ? 0 : p + 1), 0) / (4 * (HOME + 1));
  }

  /* Integrity check (used when restoring a saved game or a server document): a state that passes can be
     played on without errors. Saves from another rules version, or damaged ones, are refused. */
  function validate(st) {
    try {
      if (!st || st.v !== RULES_VERSION || !Array.isArray(st.colors) || st.colors.length < 2 || st.colors.length > 4) return false;
      if (new Set(st.colors).size !== st.colors.length || st.colors.some(c => COLORS.indexOf(c) === -1)) return false;
      if (['roll', 'move', 'over'].indexOf(st.phase) === -1) return false;
      if (!st.tokens || !st.stats || !st.out) return false;
      for (const c of st.colors) {
        const tk = st.tokens[c], s = st.stats[c];
        if (!Array.isArray(tk) || tk.length !== 4) return false;
        if (tk.some(p => !(Number.isInteger(p) && p >= YARD && p <= HOME))) return false;
        if (!s || ['captures', 'lost', 'sixes', 'home', 'rolls', 'turns'].some(k => !(Number.isInteger(s[k]) && s[k] >= 0))) return false;
        if (typeof st.out[c] !== 'boolean') return false;
      }
      if (!(Number.isInteger(st.turn) && st.turn >= 0 && st.turn < st.colors.length)) return false;
      if (st.lastRoll !== null && st.lastRoll !== undefined && !(Number.isInteger(st.lastRoll.value) && st.lastRoll.value >= 1 && st.lastRoll.value <= 6)) return false;
      const done = st.colors.some(c => st.tokens[c].every(p => p === HOME));
      if (st.phase === 'over') return st.colors.indexOf(st.winner) !== -1;
      if (done || st.out[current(st)]) return false;                       // decided, or the turn belongs to someone who left
      if (st.phase === 'move') return Number.isInteger(st.dice) && st.dice >= 1 && st.dice <= 6 && legalMoves(st).length > 0;
      return true;
    } catch (e) { return false; }
  }

  return { COLORS, START, SAFE, YARD, LAST_MAIN, HOME, TRACK, RULES_VERSION, isSafe, globalOf,
    createGame, current, clone, tokensAt, moveTarget, legalMoves, roll, move, forfeit, progress, validate, active };
});
