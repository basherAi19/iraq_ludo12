/* Iraq Ludo website — offline copy.
   After the first visit the game opens without internet (playing the computer needs no server).
   Pages and settings: network first (for up to 4 seconds), so updates arrive at once and a weak connection
   still opens the saved copy. Other files: from the copy; a new build replaces the whole copy.
   Firebase traffic (other domains) is never touched. 2c1292ef13c5 is replaced by web/build.sh on every build. */
const CACHE = 'iraq-ludo-2c1292ef13c5';
const CORE = ['./', 'index.html', 'config.js', 'firebase.js', 'fonts/BalooBhaijaan2.ttf', 'manifest.webmanifest',
  'icons/favicon.svg', 'icons/icon-192.png', 'icons/icon-512.png'];
const WAIT = 4000;

self.addEventListener('install', e => {
  // 'reload' skips the browser's own cache, so a new build never stores an old file under the new name
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE.map(u => new Request(u, { cache: 'reload' })))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
const keep = (req, res) => { if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); } return res; };
const saved = req => caches.match(req).then(r => r || caches.match('index.html'));

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  const fresh = req.mode === 'navigate' || url.pathname.endsWith('/') || url.pathname.endsWith('index.html') || url.pathname.endsWith('config.js');
  if (fresh) {
    const net = fetch(req).then(res => { keep(req, res); return res; });
    const slow = new Promise(resolve => setTimeout(resolve, WAIT, null));
    e.respondWith(
      Promise.race([net.catch(() => null), slow])
        .then(res => (res && res.ok ? res : caches.match(req).then(hit => hit || res || net.catch(() => saved(req)))))
        .then(res => res || saved(req))
    );
    return;
  }
  e.respondWith(caches.match(req).then(hit => hit || fetch(req.url, { cache: 'no-cache' }).then(res => keep(req, res))));
});
